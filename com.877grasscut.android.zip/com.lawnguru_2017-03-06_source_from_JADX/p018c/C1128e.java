package p018c;

import java.io.InputStream;

/* renamed from: c.e */
public interface C1128e extends C0946s {
    long m4747a(byte b);

    long m4748a(C0954r c0954r);

    void m4749a(long j);

    C1129c m4750b();

    C1130f m4751c(long j);

    boolean m4752e();

    InputStream m4753f();

    byte[] m4754f(long j);

    void m4755g(long j);

    byte m4756h();

    short m4757i();

    int m4758j();

    short m4759k();

    int m4760l();

    long m4761m();

    String m4762p();

    byte[] m4763q();
}
