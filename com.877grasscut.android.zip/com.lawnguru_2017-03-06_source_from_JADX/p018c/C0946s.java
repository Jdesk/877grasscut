package p018c;

import java.io.Closeable;

/* renamed from: c.s */
public interface C0946s extends Closeable {
    void close();

    long read(C1129c c1129c, long j);

    C0993t timeout();
}
