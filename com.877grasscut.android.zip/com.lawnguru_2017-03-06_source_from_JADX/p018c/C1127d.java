package p018c;

import java.io.OutputStream;

/* renamed from: c.d */
public interface C1127d extends C0954r {
    long m4734a(C0946s c0946s);

    C1129c m4735b();

    C1127d m4736b(C1130f c1130f);

    C1127d m4737b(String str);

    C1127d m4738c(byte[] bArr);

    C1127d m4739c(byte[] bArr, int i, int i2);

    OutputStream m4740c();

    void flush();

    C1127d m4741g(int i);

    C1127d m4742h(int i);

    C1127d m4743i(int i);

    C1127d m4744j(long j);

    C1127d m4745k(long j);

    C1127d m4746u();
}
