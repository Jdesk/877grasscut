package p018c;

import java.io.Closeable;
import java.io.Flushable;

/* renamed from: c.r */
public interface C0954r extends Closeable, Flushable {
    void m3815a(C1129c c1129c, long j);

    void close();

    void flush();

    C0993t timeout();
}
