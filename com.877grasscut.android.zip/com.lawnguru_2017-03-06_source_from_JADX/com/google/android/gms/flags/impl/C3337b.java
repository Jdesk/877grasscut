package com.google.android.gms.flags.impl;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.android.gms.p095b.by;
import java.util.concurrent.Callable;

/* renamed from: com.google.android.gms.flags.impl.b */
public class C3337b {
    private static SharedPreferences f10035a;

    /* renamed from: com.google.android.gms.flags.impl.b.1 */
    class C33361 implements Callable<SharedPreferences> {
        final /* synthetic */ Context f10034a;

        C33361(Context context) {
            this.f10034a = context;
        }

        public SharedPreferences m16414a() {
            return this.f10034a.getSharedPreferences("google_sdk_flags", 1);
        }

        public /* synthetic */ Object call() {
            return m16414a();
        }
    }

    static {
        f10035a = null;
    }

    public static SharedPreferences m16415a(Context context) {
        SharedPreferences sharedPreferences;
        synchronized (SharedPreferences.class) {
            if (f10035a == null) {
                f10035a = (SharedPreferences) by.m9904a(new C33361(context));
            }
            sharedPreferences = f10035a;
        }
        return sharedPreferences;
    }
}
