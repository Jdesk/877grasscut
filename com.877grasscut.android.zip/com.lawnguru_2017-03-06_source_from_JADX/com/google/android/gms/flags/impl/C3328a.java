package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import com.google.android.gms.p095b.by;
import java.util.concurrent.Callable;

/* renamed from: com.google.android.gms.flags.impl.a */
public abstract class C3328a<T> {

    /* renamed from: com.google.android.gms.flags.impl.a.a */
    public static class C3329a extends C3328a<Boolean> {

        /* renamed from: com.google.android.gms.flags.impl.a.a.1 */
        class C33271 implements Callable<Boolean> {
            final /* synthetic */ SharedPreferences f10022a;
            final /* synthetic */ String f10023b;
            final /* synthetic */ Boolean f10024c;

            C33271(SharedPreferences sharedPreferences, String str, Boolean bool) {
                this.f10022a = sharedPreferences;
                this.f10023b = str;
                this.f10024c = bool;
            }

            public Boolean m16406a() {
                return Boolean.valueOf(this.f10022a.getBoolean(this.f10023b, this.f10024c.booleanValue()));
            }

            public /* synthetic */ Object call() {
                return m16406a();
            }
        }

        public static Boolean m16407a(SharedPreferences sharedPreferences, String str, Boolean bool) {
            return (Boolean) by.m9904a(new C33271(sharedPreferences, str, bool));
        }
    }

    /* renamed from: com.google.android.gms.flags.impl.a.b */
    public static class C3331b extends C3328a<Integer> {

        /* renamed from: com.google.android.gms.flags.impl.a.b.1 */
        class C33301 implements Callable<Integer> {
            final /* synthetic */ SharedPreferences f10025a;
            final /* synthetic */ String f10026b;
            final /* synthetic */ Integer f10027c;

            C33301(SharedPreferences sharedPreferences, String str, Integer num) {
                this.f10025a = sharedPreferences;
                this.f10026b = str;
                this.f10027c = num;
            }

            public Integer m16408a() {
                return Integer.valueOf(this.f10025a.getInt(this.f10026b, this.f10027c.intValue()));
            }

            public /* synthetic */ Object call() {
                return m16408a();
            }
        }

        public static Integer m16409a(SharedPreferences sharedPreferences, String str, Integer num) {
            return (Integer) by.m9904a(new C33301(sharedPreferences, str, num));
        }
    }

    /* renamed from: com.google.android.gms.flags.impl.a.c */
    public static class C3333c extends C3328a<Long> {

        /* renamed from: com.google.android.gms.flags.impl.a.c.1 */
        class C33321 implements Callable<Long> {
            final /* synthetic */ SharedPreferences f10028a;
            final /* synthetic */ String f10029b;
            final /* synthetic */ Long f10030c;

            C33321(SharedPreferences sharedPreferences, String str, Long l) {
                this.f10028a = sharedPreferences;
                this.f10029b = str;
                this.f10030c = l;
            }

            public Long m16410a() {
                return Long.valueOf(this.f10028a.getLong(this.f10029b, this.f10030c.longValue()));
            }

            public /* synthetic */ Object call() {
                return m16410a();
            }
        }

        public static Long m16411a(SharedPreferences sharedPreferences, String str, Long l) {
            return (Long) by.m9904a(new C33321(sharedPreferences, str, l));
        }
    }

    /* renamed from: com.google.android.gms.flags.impl.a.d */
    public static class C3335d extends C3328a<String> {

        /* renamed from: com.google.android.gms.flags.impl.a.d.1 */
        class C33341 implements Callable<String> {
            final /* synthetic */ SharedPreferences f10031a;
            final /* synthetic */ String f10032b;
            final /* synthetic */ String f10033c;

            C33341(SharedPreferences sharedPreferences, String str, String str2) {
                this.f10031a = sharedPreferences;
                this.f10032b = str;
                this.f10033c = str2;
            }

            public String m16412a() {
                return this.f10031a.getString(this.f10032b, this.f10033c);
            }

            public /* synthetic */ Object call() {
                return m16412a();
            }
        }

        public static String m16413a(SharedPreferences sharedPreferences, String str, String str2) {
            return (String) by.m9904a(new C33341(sharedPreferences, str, str2));
        }
    }
}
