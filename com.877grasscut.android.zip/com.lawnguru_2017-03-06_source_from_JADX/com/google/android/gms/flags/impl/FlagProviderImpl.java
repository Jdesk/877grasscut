package com.google.android.gms.flags.impl;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager.NameNotFoundException;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.util.DynamiteApi;
import com.google.android.gms.flags.impl.C3328a.C3329a;
import com.google.android.gms.flags.impl.C3328a.C3331b;
import com.google.android.gms.flags.impl.C3328a.C3333c;
import com.google.android.gms.flags.impl.C3328a.C3335d;
import com.google.android.gms.p095b.bx.C2476a;
import com.google.android.gms.p097a.C2046a;
import com.google.android.gms.p097a.C2060d;

@DynamiteApi
public class FlagProviderImpl extends C2476a {
    private boolean f10020a;
    private SharedPreferences f10021b;

    public FlagProviderImpl() {
        this.f10020a = false;
    }

    public boolean getBooleanFlagValue(String str, boolean z, int i) {
        return !this.f10020a ? z : C3329a.m16407a(this.f10021b, str, Boolean.valueOf(z)).booleanValue();
    }

    public int getIntFlagValue(String str, int i, int i2) {
        return !this.f10020a ? i : C3331b.m16409a(this.f10021b, str, Integer.valueOf(i)).intValue();
    }

    public long getLongFlagValue(String str, long j, int i) {
        return !this.f10020a ? j : C3333c.m16411a(this.f10021b, str, Long.valueOf(j)).longValue();
    }

    public String getStringFlagValue(String str, String str2, int i) {
        return !this.f10020a ? str2 : C3335d.m16413a(this.f10021b, str, str2);
    }

    public void init(C2046a c2046a) {
        Context context = (Context) C2060d.m7974a(c2046a);
        if (!this.f10020a) {
            try {
                this.f10021b = C3337b.m16415a(context.createPackageContext(GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE, 0));
                this.f10020a = true;
            } catch (NameNotFoundException e) {
            }
        }
    }
}
