package com.google.android.gms.common.stats;

import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.util.Log;
import com.google.android.gms.common.util.C3292b;
import java.util.Collections;
import java.util.List;

/* renamed from: com.google.android.gms.common.stats.a */
public class C3286a {
    private static final Object f9965a;
    private static C3286a f9966b;
    private final List<String> f9967c;
    private final List<String> f9968d;
    private final List<String> f9969e;
    private final List<String> f9970f;

    static {
        f9965a = new Object();
    }

    private C3286a() {
        this.f9967c = Collections.EMPTY_LIST;
        this.f9968d = Collections.EMPTY_LIST;
        this.f9969e = Collections.EMPTY_LIST;
        this.f9970f = Collections.EMPTY_LIST;
    }

    public static C3286a m16282a() {
        synchronized (f9965a) {
            if (f9966b == null) {
                f9966b = new C3286a();
            }
        }
        return f9966b;
    }

    private boolean m16283a(Context context, Intent intent) {
        ComponentName component = intent.getComponent();
        return component == null ? false : C3292b.m16300a(context, component.getPackageName());
    }

    @SuppressLint({"UntrackedBindService"})
    public void m16284a(Context context, ServiceConnection serviceConnection) {
        context.unbindService(serviceConnection);
    }

    public void m16285a(Context context, ServiceConnection serviceConnection, String str, Intent intent) {
    }

    public boolean m16286a(Context context, Intent intent, ServiceConnection serviceConnection, int i) {
        return m16287a(context, context.getClass().getName(), intent, serviceConnection, i);
    }

    @SuppressLint({"UntrackedBindService"})
    public boolean m16287a(Context context, String str, Intent intent, ServiceConnection serviceConnection, int i) {
        if (!m16283a(context, intent)) {
            return context.bindService(intent, serviceConnection, i);
        }
        Log.w("ConnectionTracker", "Attempted to bind to a service in a STOPPED package.");
        return false;
    }

    public void m16288b(Context context, ServiceConnection serviceConnection) {
    }
}
