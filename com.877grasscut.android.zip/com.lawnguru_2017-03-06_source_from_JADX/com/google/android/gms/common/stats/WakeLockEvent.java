package com.google.android.gms.common.stats;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import io.card.payment.BuildConfig;
import java.util.List;

public final class WakeLockEvent extends StatsEvent {
    public static final Creator<WakeLockEvent> CREATOR;
    final int f9950a;
    private final long f9951b;
    private int f9952c;
    private final String f9953d;
    private final String f9954e;
    private final String f9955f;
    private final int f9956g;
    private final List<String> f9957h;
    private final String f9958i;
    private final long f9959j;
    private int f9960k;
    private final String f9961l;
    private final float f9962m;
    private final long f9963n;
    private long f9964o;

    static {
        CREATOR = new C3289d();
    }

    WakeLockEvent(int i, long j, int i2, String str, int i3, List<String> list, String str2, long j2, int i4, String str3, String str4, float f, long j3, String str5) {
        this.f9950a = i;
        this.f9951b = j;
        this.f9952c = i2;
        this.f9953d = str;
        this.f9954e = str3;
        this.f9955f = str5;
        this.f9956g = i3;
        this.f9964o = -1;
        this.f9957h = list;
        this.f9958i = str2;
        this.f9959j = j2;
        this.f9960k = i4;
        this.f9961l = str4;
        this.f9962m = f;
        this.f9963n = j3;
    }

    public WakeLockEvent(long j, int i, String str, int i2, List<String> list, String str2, long j2, int i3, String str3, String str4, float f, long j3, String str5) {
        this(2, j, i, str, i2, list, str2, j2, i3, str3, str4, f, j3, str5);
    }

    public long m16267a() {
        return this.f9951b;
    }

    public int m16268b() {
        return this.f9952c;
    }

    public long m16269c() {
        return this.f9964o;
    }

    public String m16270d() {
        String valueOf = String.valueOf("\t");
        String valueOf2 = String.valueOf(m16271e());
        String valueOf3 = String.valueOf("\t");
        int h = m16274h();
        String valueOf4 = String.valueOf("\t");
        String join = m16275i() == null ? BuildConfig.FLAVOR : TextUtils.join(",", m16275i());
        String valueOf5 = String.valueOf("\t");
        int l = m16278l();
        String valueOf6 = String.valueOf("\t");
        String f = m16272f() == null ? BuildConfig.FLAVOR : m16272f();
        String valueOf7 = String.valueOf("\t");
        String m = m16279m() == null ? BuildConfig.FLAVOR : m16279m();
        String valueOf8 = String.valueOf("\t");
        float n = m16280n();
        String valueOf9 = String.valueOf("\t");
        String g = m16273g() == null ? BuildConfig.FLAVOR : m16273g();
        return new StringBuilder(((((((((((((String.valueOf(valueOf).length() + 37) + String.valueOf(valueOf2).length()) + String.valueOf(valueOf3).length()) + String.valueOf(valueOf4).length()) + String.valueOf(join).length()) + String.valueOf(valueOf5).length()) + String.valueOf(valueOf6).length()) + String.valueOf(f).length()) + String.valueOf(valueOf7).length()) + String.valueOf(m).length()) + String.valueOf(valueOf8).length()) + String.valueOf(valueOf9).length()) + String.valueOf(g).length()).append(valueOf).append(valueOf2).append(valueOf3).append(h).append(valueOf4).append(join).append(valueOf5).append(l).append(valueOf6).append(f).append(valueOf7).append(m).append(valueOf8).append(n).append(valueOf9).append(g).toString();
    }

    public String m16271e() {
        return this.f9953d;
    }

    public String m16272f() {
        return this.f9954e;
    }

    public String m16273g() {
        return this.f9955f;
    }

    public int m16274h() {
        return this.f9956g;
    }

    public List<String> m16275i() {
        return this.f9957h;
    }

    public String m16276j() {
        return this.f9958i;
    }

    public long m16277k() {
        return this.f9959j;
    }

    public int m16278l() {
        return this.f9960k;
    }

    public String m16279m() {
        return this.f9961l;
    }

    public float m16280n() {
        return this.f9962m;
    }

    public long m16281o() {
        return this.f9963n;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C3289d.m16292a(this, parcel, i);
    }
}
