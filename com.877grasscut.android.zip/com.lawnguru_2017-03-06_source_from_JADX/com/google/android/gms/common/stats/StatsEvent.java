package com.google.android.gms.common.stats;

import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.C2149a;

public abstract class StatsEvent extends C2149a implements ReflectedParcelable {
    public abstract long m16263a();

    public abstract int m16264b();

    public abstract long m16265c();

    public abstract String m16266d();

    public String toString() {
        long a = m16263a();
        String valueOf = String.valueOf("\t");
        int b = m16264b();
        String valueOf2 = String.valueOf("\t");
        long c = m16265c();
        String valueOf3 = String.valueOf(m16266d());
        return new StringBuilder(((String.valueOf(valueOf).length() + 51) + String.valueOf(valueOf2).length()) + String.valueOf(valueOf3).length()).append(a).append(valueOf).append(b).append(valueOf2).append(c).append(valueOf3).toString();
    }
}
