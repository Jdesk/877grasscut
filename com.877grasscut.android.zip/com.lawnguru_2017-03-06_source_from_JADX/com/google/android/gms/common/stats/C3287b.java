package com.google.android.gms.common.stats;

import android.content.ComponentName;
import com.google.android.gms.common.GooglePlayServicesUtil;

/* renamed from: com.google.android.gms.common.stats.b */
public final class C3287b {
    public static final ComponentName f9971a;
    public static int f9972b;
    public static int f9973c;
    public static int f9974d;
    public static int f9975e;
    public static int f9976f;
    public static int f9977g;
    public static int f9978h;
    public static int f9979i;

    static {
        f9971a = new ComponentName(GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE, "com.google.android.gms.common.stats.GmsCoreStatsService");
        f9972b = 0;
        f9973c = 1;
        f9974d = 2;
        f9975e = 4;
        f9976f = 8;
        f9977g = 16;
        f9978h = 32;
        f9979i = 1;
    }
}
