package com.google.android.gms.common.stats;

import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.common.util.C3297g;
import java.util.List;

/* renamed from: com.google.android.gms.common.stats.e */
public class C3290e {
    private static C3290e f9980a;
    private static Boolean f9981b;

    static {
        f9980a = new C3290e();
    }

    public static C3290e m16295a() {
        return f9980a;
    }

    private static boolean m16296a(Context context) {
        if (f9981b == null) {
            f9981b = Boolean.valueOf(false);
        }
        return f9981b.booleanValue();
    }

    public void m16297a(Context context, String str, int i, String str2, String str3, String str4, int i2, List<String> list) {
        m16298a(context, str, i, str2, str3, str4, i2, list, 0);
    }

    public void m16298a(Context context, String str, int i, String str2, String str3, String str4, int i2, List<String> list, long j) {
        if (!C3290e.m16296a(context)) {
            return;
        }
        if (TextUtils.isEmpty(str)) {
            String str5 = "WakeLockTracker";
            String str6 = "missing wakeLock key. ";
            String valueOf = String.valueOf(str);
            Log.e(str5, valueOf.length() != 0 ? str6.concat(valueOf) : new String(str6));
            return;
        }
        long currentTimeMillis = System.currentTimeMillis();
        if (7 == i || 8 == i || 10 == i || 11 == i) {
            try {
                context.startService(new Intent().setComponent(C3287b.f9971a).putExtra("com.google.android.gms.common.stats.EXTRA_LOG_EVENT", new WakeLockEvent(currentTimeMillis, i, str2, i2, C3288c.m16291a((List) list), str, SystemClock.elapsedRealtime(), C3297g.m16325a(context), str3, C3288c.m16290a(context.getPackageName()), C3297g.m16327b(context), j, str4)));
            } catch (Throwable e) {
                Log.wtf("WakeLockTracker", e);
            }
        }
    }
}
