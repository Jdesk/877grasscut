package com.google.android.gms.common.stats;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import com.zopim.android.sdk.api.C5264R;
import io.card.payment.CreditCard;
import io.techery.properratingbar.C5501a.C5500d;
import java.util.List;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.common.stats.d */
public class C3289d implements Creator<WakeLockEvent> {
    static void m16292a(WakeLockEvent wakeLockEvent, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16168a(parcel, 1, wakeLockEvent.f9950a);
        C3264c.m16169a(parcel, 2, wakeLockEvent.m16267a());
        C3264c.m16177a(parcel, 4, wakeLockEvent.m16271e(), false);
        C3264c.m16168a(parcel, 5, wakeLockEvent.m16274h());
        C3264c.m16189b(parcel, 6, wakeLockEvent.m16275i(), false);
        C3264c.m16169a(parcel, 8, wakeLockEvent.m16277k());
        C3264c.m16177a(parcel, 10, wakeLockEvent.m16272f(), false);
        C3264c.m16168a(parcel, 11, wakeLockEvent.m16268b());
        C3264c.m16177a(parcel, 12, wakeLockEvent.m16276j(), false);
        C3264c.m16177a(parcel, 13, wakeLockEvent.m16279m(), false);
        C3264c.m16168a(parcel, 14, wakeLockEvent.m16278l());
        C3264c.m16167a(parcel, 15, wakeLockEvent.m16280n());
        C3264c.m16169a(parcel, 16, wakeLockEvent.m16281o());
        C3264c.m16177a(parcel, 17, wakeLockEvent.m16273g(), false);
        C3264c.m16164a(parcel, a);
    }

    public WakeLockEvent m16293a(Parcel parcel) {
        int b = C3263b.m16139b(parcel);
        int i = 0;
        long j = 0;
        int i2 = 0;
        String str = null;
        int i3 = 0;
        List list = null;
        String str2 = null;
        long j2 = 0;
        int i4 = 0;
        String str3 = null;
        String str4 = null;
        float f = 0.0f;
        long j3 = 0;
        String str5 = null;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_duration /*1*/:
                    i = C3263b.m16146f(parcel, a);
                    break;
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    j = C3263b.m16148h(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    str = C3263b.m16154n(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTick /*5*/:
                    i3 = C3263b.m16146f(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickNormalColor /*6*/:
                    list = C3263b.m16162v(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickNormalDrawable /*8*/:
                    j2 = C3263b.m16148h(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickSpacing /*10*/:
                    str3 = C3263b.m16154n(parcel, a);
                    break;
                case C5264R.styleable.Toolbar_popupTheme /*11*/:
                    i2 = C3263b.m16146f(parcel, a);
                    break;
                case C5264R.styleable.Toolbar_titleTextAppearance /*12*/:
                    str2 = C3263b.m16154n(parcel, a);
                    break;
                case C5264R.styleable.Toolbar_subtitleTextAppearance /*13*/:
                    str4 = C3263b.m16154n(parcel, a);
                    break;
                case C5264R.styleable.SearchView_suggestionRowLayout /*14*/:
                    i4 = C3263b.m16146f(parcel, a);
                    break;
                case CreditCard.EXPIRY_MAX_FUTURE_YEARS /*15*/:
                    f = C3263b.m16150j(parcel, a);
                    break;
                case C5264R.styleable.Toolbar_titleMarginEnd /*16*/:
                    j3 = C3263b.m16148h(parcel, a);
                    break;
                case C5264R.styleable.Toolbar_titleMarginTop /*17*/:
                    str5 = C3263b.m16154n(parcel, a);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new WakeLockEvent(i, j, i2, str, i3, list, str2, j2, i4, str3, str4, f, j3, str5);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public WakeLockEvent[] m16294a(int i) {
        return new WakeLockEvent[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m16293a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m16294a(i);
    }
}
