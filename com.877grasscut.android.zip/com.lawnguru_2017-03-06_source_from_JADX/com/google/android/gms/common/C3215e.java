package com.google.android.gms.common;

import android.content.Intent;

/* renamed from: com.google.android.gms.common.e */
public class C3215e extends C3214g {
    private final int f9822a;

    C3215e(int i, String str, Intent intent) {
        super(str, intent);
        this.f9822a = i;
    }
}
