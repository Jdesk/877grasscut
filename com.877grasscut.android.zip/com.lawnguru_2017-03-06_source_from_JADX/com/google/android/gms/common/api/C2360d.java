package com.google.android.gms.common.api;

/* renamed from: com.google.android.gms.common.api.d */
public abstract class C2360d<R extends C2487g> {

    /* renamed from: com.google.android.gms.common.api.d.a */
    public interface C2782a {
        void m12886a(Status status);
    }

    public Integer m9303a() {
        throw new UnsupportedOperationException();
    }

    public void m9304a(C2782a c2782a) {
        throw new UnsupportedOperationException();
    }

    public abstract void m9305a(C2426h<? super R> c2426h);
}
