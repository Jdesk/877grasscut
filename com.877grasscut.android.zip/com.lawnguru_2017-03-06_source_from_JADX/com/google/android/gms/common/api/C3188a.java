package com.google.android.gms.common.api;

import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import com.google.android.gms.common.api.C2854c.C2420b;
import com.google.android.gms.common.api.C2854c.C2421c;
import com.google.android.gms.common.internal.C2353o.C2930f;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.common.internal.C3255p;
import com.google.android.gms.common.internal.aa;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/* renamed from: com.google.android.gms.common.api.a */
public final class C3188a<O extends C2312a> {
    private final C2308b<?, O> f9750a;
    private final C3186i<?, O> f9751b;
    private final C3184g<?> f9752c;
    private final C3187j<?> f9753d;
    private final String f9754e;

    /* renamed from: com.google.android.gms.common.api.a.e */
    public static abstract class C2307e<T extends C2354c, O> {
        public int m9072a() {
            return ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED;
        }

        public List<Scope> m9073a(O o) {
            return Collections.emptyList();
        }
    }

    /* renamed from: com.google.android.gms.common.api.a.b */
    public static abstract class C2308b<T extends C2355f, O> extends C2307e<T, O> {
        public abstract T m9074a(Context context, Looper looper, C3255p c3255p, O o, C2420b c2420b, C2421c c2421c);
    }

    /* renamed from: com.google.android.gms.common.api.a.a */
    public interface C2312a {

        /* renamed from: com.google.android.gms.common.api.a.a.a */
        public interface C2313a extends C2312a {
        }

        /* renamed from: com.google.android.gms.common.api.a.a.c */
        public interface C2314c extends C2312a {
        }

        /* renamed from: com.google.android.gms.common.api.a.a.d */
        public interface C2315d extends C2313a, C2314c {
        }

        /* renamed from: com.google.android.gms.common.api.a.a.b */
        public static final class C3182b implements C2314c {
            private C3182b() {
            }
        }
    }

    /* renamed from: com.google.android.gms.common.api.a.c */
    public interface C2354c {
    }

    /* renamed from: com.google.android.gms.common.api.a.f */
    public interface C2355f extends C2354c {
        void m9274a(aa aaVar, Set<Scope> set);

        void m9275a(C2930f c2930f);

        void m9276a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

        boolean m9277c();

        Intent m9278d();

        void m9279f();

        boolean m9280g();

        boolean m9281h();

        boolean m9282i();

        boolean m9283j();

        IBinder m9284k();
    }

    /* renamed from: com.google.android.gms.common.api.a.d */
    public static class C3183d<C extends C2354c> {
    }

    /* renamed from: com.google.android.gms.common.api.a.g */
    public static final class C3184g<C extends C2355f> extends C3183d<C> {
    }

    /* renamed from: com.google.android.gms.common.api.a.h */
    public interface C3185h<T extends IInterface> extends C2354c {
        T m15895a(IBinder iBinder);

        String m15896a();

        String m15897b();
    }

    /* renamed from: com.google.android.gms.common.api.a.i */
    public static abstract class C3186i<T extends C3185h, O> extends C2307e<T, O> {
    }

    /* renamed from: com.google.android.gms.common.api.a.j */
    public static final class C3187j<C extends C3185h> extends C3183d<C> {
    }

    public <C extends C2355f> C3188a(String str, C2308b<C, O> c2308b, C3184g<C> c3184g) {
        C3234c.m16043a((Object) c2308b, (Object) "Cannot construct an Api with a null ClientBuilder");
        C3234c.m16043a((Object) c3184g, (Object) "Cannot construct an Api with a null ClientKey");
        this.f9754e = str;
        this.f9750a = c2308b;
        this.f9751b = null;
        this.f9752c = c3184g;
        this.f9753d = null;
    }

    public C2307e<?, O> m15898a() {
        return this.f9750a;
    }

    public C2308b<?, O> m15899b() {
        C3234c.m16048a(this.f9750a != null, (Object) "This API was constructed with a SimpleClientBuilder. Use getSimpleClientBuilder");
        return this.f9750a;
    }

    public C3183d<?> m15900c() {
        if (this.f9752c != null) {
            return this.f9752c;
        }
        throw new IllegalStateException("This API was constructed with null client keys. This should not be possible.");
    }

    public String m15901d() {
        return this.f9754e;
    }
}
