package com.google.android.gms.common.api;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.C3233b;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.C2149a;

public final class Status extends C2149a implements C2487g, ReflectedParcelable {
    public static final Creator<Status> CREATOR;
    public static final Status f9739a;
    public static final Status f9740b;
    public static final Status f9741c;
    public static final Status f9742d;
    public static final Status f9743e;
    public static final Status f9744f;
    public static final Status f9745g;
    final int f9746h;
    private final int f9747i;
    private final String f9748j;
    private final PendingIntent f9749k;

    static {
        f9739a = new Status(0);
        f9740b = new Status(14);
        f9741c = new Status(8);
        f9742d = new Status(15);
        f9743e = new Status(16);
        f9744f = new Status(17);
        f9745g = new Status(18);
        CREATOR = new C3201q();
    }

    public Status(int i) {
        this(i, null);
    }

    Status(int i, int i2, String str, PendingIntent pendingIntent) {
        this.f9746h = i;
        this.f9747i = i2;
        this.f9748j = str;
        this.f9749k = pendingIntent;
    }

    public Status(int i, String str) {
        this(1, i, str, null);
    }

    public Status(int i, String str, PendingIntent pendingIntent) {
        this(1, i, str, pendingIntent);
    }

    public Status m15889a() {
        return this;
    }

    PendingIntent m15890b() {
        return this.f9749k;
    }

    public String m15891c() {
        return this.f9748j;
    }

    public boolean m15892d() {
        return this.f9747i <= 0;
    }

    public int m15893e() {
        return this.f9747i;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof Status)) {
            return false;
        }
        Status status = (Status) obj;
        return this.f9746h == status.f9746h && this.f9747i == status.f9747i && C3233b.m16040a(this.f9748j, status.f9748j) && C3233b.m16040a(this.f9749k, status.f9749k);
    }

    public String m15894f() {
        return this.f9748j != null ? this.f9748j : C3189b.m15902a(this.f9747i);
    }

    public int hashCode() {
        return C3233b.m16038a(Integer.valueOf(this.f9746h), Integer.valueOf(this.f9747i), this.f9748j, this.f9749k);
    }

    public String toString() {
        return C3233b.m16039a((Object) this).m16037a("statusCode", m15894f()).m16037a("resolution", this.f9749k).toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C3201q.m15927a(this, parcel, i);
    }
}
