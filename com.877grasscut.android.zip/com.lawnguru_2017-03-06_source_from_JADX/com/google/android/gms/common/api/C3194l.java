package com.google.android.gms.common.api;

/* renamed from: com.google.android.gms.common.api.l */
public class C3194l extends Exception {
    protected final Status f9774a;

    public C3194l(Status status) {
        super(status.m15891c());
        this.f9774a = status;
    }
}
