package com.google.android.gms.common.api;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import com.google.android.gms.common.C3181a;
import com.google.android.gms.common.C3205c;
import com.google.android.gms.p095b.C3121x;
import net.cachapa.expandablelayout.C5541a.C5538a;

public class GoogleApiActivity extends Activity implements OnCancelListener {
    protected int f9736a;

    public GoogleApiActivity() {
        this.f9736a = 0;
    }

    public static PendingIntent m15882a(Context context, PendingIntent pendingIntent, int i) {
        return m15883a(context, pendingIntent, i, true);
    }

    public static PendingIntent m15883a(Context context, PendingIntent pendingIntent, int i, boolean z) {
        return PendingIntent.getActivity(context, 0, m15886b(context, pendingIntent, i, z), 134217728);
    }

    private void m15884a() {
        Bundle extras = getIntent().getExtras();
        if (extras == null) {
            Log.e("GoogleApiActivity", "Activity started without extras");
            finish();
            return;
        }
        PendingIntent pendingIntent = (PendingIntent) extras.get("pending_intent");
        Integer num = (Integer) extras.get("error_code");
        if (pendingIntent == null && num == null) {
            Log.e("GoogleApiActivity", "Activity started without resolution");
            finish();
        } else if (pendingIntent != null) {
            try {
                startIntentSenderForResult(pendingIntent.getIntentSender(), 1, null, 0, 0, 0);
                this.f9736a = 1;
            } catch (Throwable e) {
                Log.e("GoogleApiActivity", "Failed to launch pendingIntent", e);
                finish();
            }
        } else {
            C3205c.m15944a().m15963b(this, num.intValue(), 2, this);
            this.f9736a = 1;
        }
    }

    private void m15885a(int i, C3121x c3121x) {
        switch (i) {
            case ErrorResponse.NON_HTTP_ERROR /*-1*/:
                c3121x.m15121d();
            case C5538a.ExpandableLayout_android_orientation /*0*/:
                c3121x.m15119b(new C3181a(13, null), getIntent().getIntExtra("failing_client_id", -1));
            default:
        }
    }

    public static Intent m15886b(Context context, PendingIntent pendingIntent, int i, boolean z) {
        Intent intent = new Intent(context, GoogleApiActivity.class);
        intent.putExtra("pending_intent", pendingIntent);
        intent.putExtra("failing_client_id", i);
        intent.putExtra("notify_manager", z);
        return intent;
    }

    protected void m15887a(int i) {
        setResult(i);
    }

    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 1) {
            boolean booleanExtra = getIntent().getBooleanExtra("notify_manager", true);
            this.f9736a = 0;
            m15887a(i2);
            if (booleanExtra) {
                m15885a(i2, C3121x.m15090a((Context) this));
            }
        } else if (i == 2) {
            this.f9736a = 0;
            m15887a(i2);
        }
        finish();
    }

    public void onCancel(DialogInterface dialogInterface) {
        this.f9736a = 0;
        setResult(0);
        finish();
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (bundle != null) {
            this.f9736a = bundle.getInt("resolution");
        }
        if (this.f9736a != 1) {
            m15884a();
        }
    }

    protected void onSaveInstanceState(Bundle bundle) {
        bundle.putInt("resolution", this.f9736a);
        super.onSaveInstanceState(bundle);
    }
}
