package com.google.android.gms.common.api;

import android.accounts.Account;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import com.google.android.gms.common.api.C2854c.C3190a;
import com.google.android.gms.common.api.C3188a.C2312a;
import com.google.android.gms.common.api.C3188a.C2354c;
import com.google.android.gms.common.api.C3188a.C2355f;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.p095b.C2588f.C2363a;
import com.google.android.gms.p095b.C3121x;
import com.google.android.gms.p095b.C3121x.C3118a;
import com.google.android.gms.p095b.C3134y;
import com.google.android.gms.p095b.abf;
import com.google.android.gms.p095b.abg;
import com.google.android.gms.p095b.aq;
import com.google.android.gms.p095b.ar;

/* renamed from: com.google.android.gms.common.api.n */
public abstract class C2401n<O extends C2312a> {
    protected final C3121x f5763a;
    private final Context f5764b;
    private final C3188a<O> f5765c;
    private final O f5766d;
    private final abg<O> f5767e;
    private final Looper f5768f;
    private final int f5769g;
    private final C2854c f5770h;
    private final ar f5771i;
    private final Account f5772j;

    /* renamed from: com.google.android.gms.common.api.n.a */
    public static class C3198a {
        public static final C3198a f9778a;
        public final ar f9779b;
        public final Account f9780c;
        public final Looper f9781d;

        /* renamed from: com.google.android.gms.common.api.n.a.a */
        public static class C3197a {
            private ar f9776a;
            private Looper f9777b;

            public C3197a m15921a(ar arVar) {
                C3234c.m16043a((Object) arVar, (Object) "StatusExceptionMapper must not be null.");
                this.f9776a = arVar;
                return this;
            }

            public C3198a m15922a() {
                if (this.f9776a == null) {
                    this.f9776a = new abf();
                }
                if (this.f9777b == null) {
                    if (Looper.myLooper() != null) {
                        this.f9777b = Looper.myLooper();
                    } else {
                        this.f9777b = Looper.getMainLooper();
                    }
                }
                return new C3198a(null, this.f9777b, null);
            }
        }

        static {
            f9778a = new C3197a().m15922a();
        }

        private C3198a(ar arVar, Account account, Looper looper) {
            this.f9779b = arVar;
            this.f9780c = account;
            this.f9781d = looper;
        }
    }

    protected C2401n(Context context, C3188a<O> c3188a, Looper looper) {
        C3234c.m16043a((Object) context, (Object) "Null context is not permitted.");
        C3234c.m16043a((Object) c3188a, (Object) "Api must not be null.");
        C3234c.m16043a((Object) looper, (Object) "Looper must not be null.");
        this.f5764b = context.getApplicationContext();
        this.f5765c = c3188a;
        this.f5766d = null;
        this.f5768f = looper;
        this.f5767e = abg.m9595a(c3188a);
        this.f5770h = new C3134y(this);
        this.f5763a = C3121x.m15090a(this.f5764b);
        this.f5769g = this.f5763a.m15120c();
        this.f5771i = new abf();
        this.f5772j = null;
    }

    @Deprecated
    public C2401n(Context context, C3188a<O> c3188a, O o, ar arVar) {
        this(context, (C3188a) c3188a, (C2312a) o, new C3197a().m15921a(arVar).m15922a());
    }

    public C2401n(Context context, C3188a<O> c3188a, O o, C3198a c3198a) {
        C3234c.m16043a((Object) context, (Object) "Null context is not permitted.");
        C3234c.m16043a((Object) c3188a, (Object) "Api must not be null.");
        C3234c.m16043a((Object) c3198a, (Object) "Settings must not be null; use Settings.createDefault() instead.");
        this.f5764b = context.getApplicationContext();
        this.f5765c = c3188a;
        this.f5766d = o;
        this.f5768f = c3198a.f9781d;
        this.f5767e = abg.m9596a(this.f5765c, this.f5766d);
        this.f5770h = new C3134y(this);
        this.f5763a = C3121x.m15090a(this.f5764b);
        this.f5769g = this.f5763a.m15120c();
        this.f5771i = c3198a.f9779b;
        this.f5772j = c3198a.f9780c;
        this.f5763a.m15115a(this);
    }

    private <A extends C2354c, T extends C2363a<? extends C2487g, A>> T m9519a(int i, T t) {
        t.m9323i();
        this.f5763a.m15116a(this, i, t);
        return t;
    }

    public aq m9520a(Context context, Handler handler) {
        return new aq(context, handler);
    }

    public <A extends C2354c, T extends C2363a<? extends C2487g, A>> T m9521a(T t) {
        return m9519a(0, (C2363a) t);
    }

    public C2355f m9522a(Looper looper, C3118a<O> c3118a) {
        return this.f5765c.m15899b().m9074a(this.f5764b, looper, new C3190a(this.f5764b).m15906a(this.f5772j).m15912a(), this.f5766d, c3118a, c3118a);
    }

    public C3188a<O> m9523a() {
        return this.f5765c;
    }

    public abg<O> m9524b() {
        return this.f5767e;
    }

    public <A extends C2354c, T extends C2363a<? extends C2487g, A>> T m9525b(T t) {
        return m9519a(1, (C2363a) t);
    }

    public int m9526c() {
        return this.f5769g;
    }

    public <A extends C2354c, T extends C2363a<? extends C2487g, A>> T m9527c(T t) {
        return m9519a(2, (C2363a) t);
    }

    public C2854c m9528d() {
        return this.f5770h;
    }

    public Looper m9529e() {
        return this.f5768f;
    }

    public Context m9530f() {
        return this.f5764b;
    }
}
