package com.google.android.gms.common.api;

/* renamed from: com.google.android.gms.common.api.j */
public abstract class C3193j<R extends C2487g, S extends C2487g> {
    public Status m15917a(Status status) {
        return status;
    }

    public abstract C2360d<S> m15918a(R r);
}
