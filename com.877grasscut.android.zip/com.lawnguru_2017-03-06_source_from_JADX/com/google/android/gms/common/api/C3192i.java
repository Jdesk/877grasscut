package com.google.android.gms.common.api;

/* renamed from: com.google.android.gms.common.api.i */
public abstract class C3192i<R extends C2487g> implements C2426h<R> {
    public abstract void m15915a(Status status);

    public abstract void m15916b(R r);
}
