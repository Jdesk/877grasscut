package com.google.android.gms.common.api;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.common.api.q */
public class C3201q implements Creator<Status> {
    static void m15927a(Status status, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16168a(parcel, 1, status.m15893e());
        C3264c.m16177a(parcel, 2, status.m15891c(), false);
        C3264c.m16172a(parcel, 3, status.m15890b(), i, false);
        C3264c.m16168a(parcel, 1000, status.f9746h);
        C3264c.m16164a(parcel, a);
    }

    public Status m15928a(Parcel parcel) {
        PendingIntent pendingIntent = null;
        int i = 0;
        int b = C3263b.m16139b(parcel);
        String str = null;
        int i2 = 0;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_duration /*1*/:
                    i = C3263b.m16146f(parcel, a);
                    break;
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    str = C3263b.m16154n(parcel, a);
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    pendingIntent = (PendingIntent) C3263b.m16135a(parcel, a, PendingIntent.CREATOR);
                    break;
                case 1000:
                    i2 = C3263b.m16146f(parcel, a);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new Status(i2, i, str, pendingIntent);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public Status[] m15929a(int i) {
        return new Status[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m15928a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m15929a(i);
    }
}
