package com.google.android.gms.common.api;

import com.zopim.android.sdk.api.C5264R;
import io.card.payment.CreditCard;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.common.api.b */
public class C3189b {
    public static String m15902a(int i) {
        switch (i) {
            case ErrorResponse.NON_HTTP_ERROR /*-1*/:
                return "SUCCESS_CACHE";
            case C5538a.ExpandableLayout_android_orientation /*0*/:
                return "SUCCESS";
            case C5538a.ExpandableLayout_el_expanded /*2*/:
                return "SERVICE_VERSION_UPDATE_REQUIRED";
            case C5538a.ExpandableLayout_layout_expandable /*3*/:
                return "SERVICE_DISABLED";
            case C5500d.ProperRatingBar_prb_clickable /*4*/:
                return "SIGN_IN_REQUIRED";
            case C5500d.ProperRatingBar_prb_symbolicTick /*5*/:
                return "INVALID_ACCOUNT";
            case C5500d.ProperRatingBar_prb_symbolicTickNormalColor /*6*/:
                return "RESOLUTION_REQUIRED";
            case C5500d.ProperRatingBar_prb_symbolicTickSelectedColor /*7*/:
                return "NETWORK_ERROR";
            case C5500d.ProperRatingBar_prb_tickNormalDrawable /*8*/:
                return "INTERNAL_ERROR";
            case C5500d.ProperRatingBar_prb_tickSpacing /*10*/:
                return "DEVELOPER_ERROR";
            case C5264R.styleable.Toolbar_subtitleTextAppearance /*13*/:
                return "ERROR";
            case C5264R.styleable.SearchView_suggestionRowLayout /*14*/:
                return "INTERRUPTED";
            case CreditCard.EXPIRY_MAX_FUTURE_YEARS /*15*/:
                return "TIMEOUT";
            case C5264R.styleable.Toolbar_titleMarginEnd /*16*/:
                return "CANCELED";
            case C5264R.styleable.Toolbar_titleMarginTop /*17*/:
                return "API_NOT_CONNECTED";
            case C5264R.styleable.Toolbar_titleMarginBottom /*18*/:
                return "DEAD_CLIENT";
            default:
                return "unknown status code: " + i;
        }
    }
}
