package com.google.android.gms.common.api;

import android.support.v4.util.C0511a;
import android.text.TextUtils;
import com.google.android.gms.common.C3181a;
import com.google.android.gms.common.api.C3188a.C2312a;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.p095b.abg;
import java.util.ArrayList;

/* renamed from: com.google.android.gms.common.api.m */
public class C3195m extends Exception {
    private final C0511a<abg<?>, C3181a> f9775a;

    public C3195m(C0511a<abg<?>, C3181a> c0511a) {
        this.f9775a = c0511a;
    }

    public C0511a<abg<?>, C3181a> m15919a() {
        return this.f9775a;
    }

    public C3181a m15920a(C2401n<? extends C2312a> c2401n) {
        abg b = c2401n.m9524b();
        C3234c.m16052b(this.f9775a.get(b) != null, "The given API was not part of the availability request.");
        return (C3181a) this.f9775a.get(b);
    }

    public String getMessage() {
        Iterable arrayList = new ArrayList();
        Object obj = 1;
        for (abg com_google_android_gms_b_abg : this.f9775a.keySet()) {
            C3181a c3181a = (C3181a) this.f9775a.get(com_google_android_gms_b_abg);
            if (c3181a.m15878b()) {
                obj = null;
            }
            String valueOf = String.valueOf(com_google_android_gms_b_abg.m9597a());
            String valueOf2 = String.valueOf(c3181a);
            arrayList.add(new StringBuilder((String.valueOf(valueOf).length() + 2) + String.valueOf(valueOf2).length()).append(valueOf).append(": ").append(valueOf2).toString());
        }
        StringBuilder stringBuilder = new StringBuilder();
        if (obj != null) {
            stringBuilder.append("None of the queried APIs are available. ");
        } else {
            stringBuilder.append("Some of the queried APIs are unavailable. ");
        }
        stringBuilder.append(TextUtils.join("; ", arrayList));
        return stringBuilder.toString();
    }
}
