package com.google.android.gms.common.api;

import android.os.Looper;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.p095b.as;

/* renamed from: com.google.android.gms.common.api.e */
public final class C3191e {
    public static C2360d<Status> m15914a(Status status) {
        C3234c.m16043a((Object) status, (Object) "Result must not be null");
        C2360d asVar = new as(Looper.getMainLooper());
        asVar.m9314a((C2487g) status);
        return asVar;
    }
}
