package com.google.android.gms.common.api;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.C2149a;

public final class Scope extends C2149a implements ReflectedParcelable {
    public static final Creator<Scope> CREATOR;
    final int f9737a;
    private final String f9738b;

    static {
        CREATOR = new C3200p();
    }

    Scope(int i, String str) {
        C3234c.m16045a(str, (Object) "scopeUri must not be null or empty");
        this.f9737a = i;
        this.f9738b = str;
    }

    public Scope(String str) {
        this(1, str);
    }

    public String m15888a() {
        return this.f9738b;
    }

    public boolean equals(Object obj) {
        return this == obj ? true : !(obj instanceof Scope) ? false : this.f9738b.equals(((Scope) obj).f9738b);
    }

    public int hashCode() {
        return this.f9738b.hashCode();
    }

    public String toString() {
        return this.f9738b;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C3200p.m15924a(this, parcel, i);
    }
}
