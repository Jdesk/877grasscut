package com.google.android.gms.common.api;

/* renamed from: com.google.android.gms.common.api.k */
public abstract class C2425k<R extends C2487g> {
}
