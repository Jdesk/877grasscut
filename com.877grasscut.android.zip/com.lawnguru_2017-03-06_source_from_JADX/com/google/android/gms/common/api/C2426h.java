package com.google.android.gms.common.api;

/* renamed from: com.google.android.gms.common.api.h */
public interface C2426h<R extends C2487g> {
    void m9683a(R r);
}
