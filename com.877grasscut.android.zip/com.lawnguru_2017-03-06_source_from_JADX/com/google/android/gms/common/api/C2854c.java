package com.google.android.gms.common.api;

import android.accounts.Account;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.util.C0511a;
import android.view.View;
import com.google.android.gms.common.C3181a;
import com.google.android.gms.common.C3205c;
import com.google.android.gms.common.api.C3188a.C2307e;
import com.google.android.gms.common.api.C3188a.C2308b;
import com.google.android.gms.common.api.C3188a.C2312a;
import com.google.android.gms.common.api.C3188a.C2312a.C2313a;
import com.google.android.gms.common.api.C3188a.C2312a.C2314c;
import com.google.android.gms.common.api.C3188a.C2354c;
import com.google.android.gms.common.api.C3188a.C2355f;
import com.google.android.gms.common.api.C3188a.C3183d;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.common.internal.C3255p;
import com.google.android.gms.common.internal.C3255p.C3254a;
import com.google.android.gms.p095b.C2482c;
import com.google.android.gms.p095b.C2588f.C2363a;
import com.google.android.gms.p095b.C2644i;
import com.google.android.gms.p095b.C3013t;
import com.google.android.gms.p095b.ae;
import com.google.android.gms.p095b.ap;
import com.google.android.gms.p095b.au;
import com.google.android.gms.p095b.fs;
import com.google.android.gms.p095b.ft;
import com.google.android.gms.p095b.fu;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.locks.ReentrantLock;

/* renamed from: com.google.android.gms.common.api.c */
public abstract class C2854c {
    private static final Set<C2854c> f7967a;

    /* renamed from: com.google.android.gms.common.api.c.b */
    public interface C2420b {
        void m9661a(int i);

        void m9662a(Bundle bundle);
    }

    /* renamed from: com.google.android.gms.common.api.c.c */
    public interface C2421c {
        void m9663a(C3181a c3181a);
    }

    /* renamed from: com.google.android.gms.common.api.c.a */
    public static final class C3190a {
        private Account f9755a;
        private final Set<Scope> f9756b;
        private final Set<Scope> f9757c;
        private int f9758d;
        private View f9759e;
        private String f9760f;
        private String f9761g;
        private final Map<C3188a<?>, C3254a> f9762h;
        private final Context f9763i;
        private final Map<C3188a<?>, C2312a> f9764j;
        private ae f9765k;
        private int f9766l;
        private C2421c f9767m;
        private Looper f9768n;
        private C3205c f9769o;
        private C2308b<? extends ft, fu> f9770p;
        private final ArrayList<C2420b> f9771q;
        private final ArrayList<C2421c> f9772r;
        private boolean f9773s;

        public C3190a(Context context) {
            this.f9756b = new HashSet();
            this.f9757c = new HashSet();
            this.f9762h = new C0511a();
            this.f9764j = new C0511a();
            this.f9766l = -1;
            this.f9769o = C3205c.m15944a();
            this.f9770p = fs.f6849c;
            this.f9771q = new ArrayList();
            this.f9772r = new ArrayList();
            this.f9773s = false;
            this.f9763i = context;
            this.f9768n = context.getMainLooper();
            this.f9760f = context.getPackageName();
            this.f9761g = context.getClass().getName();
        }

        private static <C extends C2355f, O> C m15903a(C2308b<C, O> c2308b, Object obj, Context context, Looper looper, C3255p c3255p, C2420b c2420b, C2421c c2421c) {
            return c2308b.m9074a(context, looper, c3255p, obj, c2420b, c2421c);
        }

        private void m15904a(C2854c c2854c) {
            C2482c.m9931a(this.f9765k).m9934a(this.f9766l, c2854c, this.f9767m);
        }

        private C2854c m15905c() {
            C3255p a = m15912a();
            C3188a c3188a = null;
            Map f = a.m16105f();
            Map c0511a = new C0511a();
            Map c0511a2 = new C0511a();
            ArrayList arrayList = new ArrayList();
            Object obj = null;
            for (C3188a c3188a2 : this.f9764j.keySet()) {
                C3188a c3188a22;
                Object obj2 = this.f9764j.get(c3188a22);
                boolean z = f.get(c3188a22) != null;
                c0511a.put(c3188a22, Boolean.valueOf(z));
                C2420b c2644i = new C2644i(c3188a22, z);
                arrayList.add(c2644i);
                C2307e b = c3188a22.m15899b();
                C2355f a2 = C3190a.m15903a(b, obj2, this.f9763i, this.f9768n, a, c2644i, c2644i);
                c0511a2.put(c3188a22.m15900c(), a2);
                Object obj3 = b.m9072a() == 1 ? obj2 != null ? 1 : null : obj;
                if (!a2.m9277c()) {
                    c3188a22 = c3188a;
                } else if (c3188a != null) {
                    String valueOf = String.valueOf(c3188a22.m15901d());
                    String valueOf2 = String.valueOf(c3188a.m15901d());
                    throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 21) + String.valueOf(valueOf2).length()).append(valueOf).append(" cannot be used with ").append(valueOf2).toString());
                }
                obj = obj3;
                c3188a = c3188a22;
            }
            if (c3188a != null) {
                if (obj != null) {
                    valueOf = String.valueOf(c3188a.m15901d());
                    throw new IllegalStateException(new StringBuilder(String.valueOf(valueOf).length() + 82).append("With using ").append(valueOf).append(", GamesOptions can only be specified within GoogleSignInOptions.Builder").toString());
                }
                C3234c.m16049a(this.f9755a == null, "Must not set an account in GoogleApiClient.Builder when using %s. Set account in GoogleSignInOptions.Builder instead", c3188a.m15901d());
                C3234c.m16049a(this.f9756b.equals(this.f9757c), "Must not set scopes in GoogleApiClient.Builder when using %s. Set account in GoogleSignInOptions.Builder instead.", c3188a.m15901d());
            }
            return new C3013t(this.f9763i, new ReentrantLock(), this.f9768n, a, this.f9769o, this.f9770p, c0511a, this.f9771q, this.f9772r, c0511a2, this.f9766l, C3013t.m14139a(c0511a2.values(), true), arrayList, false);
        }

        public C3190a m15906a(Account account) {
            this.f9755a = account;
            return this;
        }

        public C3190a m15907a(Handler handler) {
            C3234c.m16043a((Object) handler, (Object) "Handler must not be null");
            this.f9768n = handler.getLooper();
            return this;
        }

        public C3190a m15908a(C3188a<? extends C2314c> c3188a) {
            C3234c.m16043a((Object) c3188a, (Object) "Api must not be null");
            this.f9764j.put(c3188a, null);
            Collection a = c3188a.m15898a().m9073a(null);
            this.f9757c.addAll(a);
            this.f9756b.addAll(a);
            return this;
        }

        public <O extends C2313a> C3190a m15909a(C3188a<O> c3188a, O o) {
            C3234c.m16043a((Object) c3188a, (Object) "Api must not be null");
            C3234c.m16043a((Object) o, (Object) "Null options are not permitted for this Api");
            this.f9764j.put(c3188a, o);
            Collection a = c3188a.m15898a().m9073a(o);
            this.f9757c.addAll(a);
            this.f9756b.addAll(a);
            return this;
        }

        public C3190a m15910a(C2420b c2420b) {
            C3234c.m16043a((Object) c2420b, (Object) "Listener must not be null");
            this.f9771q.add(c2420b);
            return this;
        }

        public C3190a m15911a(C2421c c2421c) {
            C3234c.m16043a((Object) c2421c, (Object) "Listener must not be null");
            this.f9772r.add(c2421c);
            return this;
        }

        public C3255p m15912a() {
            fu fuVar = fu.f6855a;
            if (this.f9764j.containsKey(fs.f6853g)) {
                fuVar = (fu) this.f9764j.get(fs.f6853g);
            }
            return new C3255p(this.f9755a, this.f9756b, this.f9762h, this.f9758d, this.f9759e, this.f9760f, this.f9761g, fuVar);
        }

        public C2854c m15913b() {
            C3234c.m16052b(!this.f9764j.isEmpty(), "must call addApi() to add at least one API");
            C2854c c = m15905c();
            synchronized (C2854c.f7967a) {
                C2854c.f7967a.add(c);
            }
            if (this.f9766l >= 0) {
                m15904a(c);
            }
            return c;
        }
    }

    static {
        f7967a = Collections.newSetFromMap(new WeakHashMap());
    }

    public static Set<C2854c> m13236a() {
        Set<C2854c> set;
        synchronized (f7967a) {
            set = f7967a;
        }
        return set;
    }

    public <A extends C2354c, R extends C2487g, T extends C2363a<R, A>> T m13238a(T t) {
        throw new UnsupportedOperationException();
    }

    public <C extends C2355f> C m13239a(C3183d<C> c3183d) {
        throw new UnsupportedOperationException();
    }

    public void m13240a(int i) {
        throw new UnsupportedOperationException();
    }

    public void m13241a(au auVar) {
        throw new UnsupportedOperationException();
    }

    public abstract void m13242a(C2421c c2421c);

    public abstract void m13243a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    public boolean m13244a(ap apVar) {
        throw new UnsupportedOperationException();
    }

    public Context m13245b() {
        throw new UnsupportedOperationException();
    }

    public <A extends C2354c, T extends C2363a<? extends C2487g, A>> T m13246b(T t) {
        throw new UnsupportedOperationException();
    }

    public void m13247b(au auVar) {
        throw new UnsupportedOperationException();
    }

    public abstract void m13248b(C2421c c2421c);

    public Looper m13249c() {
        throw new UnsupportedOperationException();
    }

    public void m13250d() {
        throw new UnsupportedOperationException();
    }

    public abstract void m13251e();

    public abstract C3181a m13252f();

    public abstract void m13253g();

    public abstract C2360d<Status> m13254h();

    public abstract boolean m13255i();
}
