package com.google.android.gms.common.api;

import java.util.Map;
import java.util.WeakHashMap;

/* renamed from: com.google.android.gms.common.api.o */
public abstract class C3199o {
    private static final Map<Object, C3199o> f9782a;
    private static final Object f9783b;

    static {
        f9782a = new WeakHashMap();
        f9783b = new Object();
    }

    public abstract void m15923a(int i);
}
