package com.google.android.gms.common.api;

/* renamed from: com.google.android.gms.common.api.f */
public interface C2510f {
    void e_();
}
