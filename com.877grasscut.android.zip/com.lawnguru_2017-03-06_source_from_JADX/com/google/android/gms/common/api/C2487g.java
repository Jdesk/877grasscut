package com.google.android.gms.common.api;

/* renamed from: com.google.android.gms.common.api.g */
public interface C2487g {
    Status m9974a();
}
