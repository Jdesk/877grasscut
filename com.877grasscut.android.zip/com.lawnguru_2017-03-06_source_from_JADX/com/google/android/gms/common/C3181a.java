package com.google.android.gms.common;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.C3233b;
import com.google.android.gms.common.internal.safeparcel.C2149a;
import com.zopim.android.sdk.api.C5264R;
import io.card.payment.CreditCard;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.common.a */
public final class C3181a extends C2149a {
    public static final Creator<C3181a> CREATOR;
    public static final C3181a f9731a;
    final int f9732b;
    private final int f9733c;
    private final PendingIntent f9734d;
    private final String f9735e;

    static {
        f9731a = new C3181a(0);
        CREATOR = new C3218i();
    }

    public C3181a(int i) {
        this(i, null, null);
    }

    C3181a(int i, int i2, PendingIntent pendingIntent, String str) {
        this.f9732b = i;
        this.f9733c = i2;
        this.f9734d = pendingIntent;
        this.f9735e = str;
    }

    public C3181a(int i, PendingIntent pendingIntent) {
        this(i, pendingIntent, null);
    }

    public C3181a(int i, PendingIntent pendingIntent, String str) {
        this(1, i, pendingIntent, str);
    }

    static String m15876a(int i) {
        switch (i) {
            case ErrorResponse.NON_HTTP_ERROR /*-1*/:
                return "UNKNOWN";
            case C5538a.ExpandableLayout_android_orientation /*0*/:
                return "SUCCESS";
            case C5538a.ExpandableLayout_el_duration /*1*/:
                return "SERVICE_MISSING";
            case C5538a.ExpandableLayout_el_expanded /*2*/:
                return "SERVICE_VERSION_UPDATE_REQUIRED";
            case C5538a.ExpandableLayout_layout_expandable /*3*/:
                return "SERVICE_DISABLED";
            case C5500d.ProperRatingBar_prb_clickable /*4*/:
                return "SIGN_IN_REQUIRED";
            case C5500d.ProperRatingBar_prb_symbolicTick /*5*/:
                return "INVALID_ACCOUNT";
            case C5500d.ProperRatingBar_prb_symbolicTickNormalColor /*6*/:
                return "RESOLUTION_REQUIRED";
            case C5500d.ProperRatingBar_prb_symbolicTickSelectedColor /*7*/:
                return "NETWORK_ERROR";
            case C5500d.ProperRatingBar_prb_tickNormalDrawable /*8*/:
                return "INTERNAL_ERROR";
            case C5500d.ProperRatingBar_prb_tickSelectedDrawable /*9*/:
                return "SERVICE_INVALID";
            case C5500d.ProperRatingBar_prb_tickSpacing /*10*/:
                return "DEVELOPER_ERROR";
            case C5264R.styleable.Toolbar_popupTheme /*11*/:
                return "LICENSE_CHECK_FAILED";
            case C5264R.styleable.Toolbar_subtitleTextAppearance /*13*/:
                return "CANCELED";
            case C5264R.styleable.SearchView_suggestionRowLayout /*14*/:
                return "TIMEOUT";
            case CreditCard.EXPIRY_MAX_FUTURE_YEARS /*15*/:
                return "INTERRUPTED";
            case C5264R.styleable.Toolbar_titleMarginEnd /*16*/:
                return "API_UNAVAILABLE";
            case C5264R.styleable.Toolbar_titleMarginTop /*17*/:
                return "SIGN_IN_FAILED";
            case C5264R.styleable.Toolbar_titleMarginBottom /*18*/:
                return "SERVICE_UPDATING";
            case C5264R.styleable.Toolbar_titleMargins /*19*/:
                return "SERVICE_MISSING_PERMISSION";
            case C5264R.styleable.Toolbar_maxButtonHeight /*20*/:
                return "RESTRICTED_PROFILE";
            case C5264R.styleable.AppCompatTheme_actionBarWidgetTheme /*21*/:
                return "API_VERSION_UPDATE_REQUIRED";
            case C5264R.styleable.AppCompatTheme_buttonBarNegativeButtonStyle /*99*/:
                return "UNFINISHED";
            case 1500:
                return "DRIVE_EXTERNAL_STORAGE_REQUIRED";
            default:
                return "UNKNOWN_ERROR_CODE(" + i + ")";
        }
    }

    public boolean m15877a() {
        return (this.f9733c == 0 || this.f9734d == null) ? false : true;
    }

    public boolean m15878b() {
        return this.f9733c == 0;
    }

    public int m15879c() {
        return this.f9733c;
    }

    public PendingIntent m15880d() {
        return this.f9734d;
    }

    public String m15881e() {
        return this.f9735e;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C3181a)) {
            return false;
        }
        C3181a c3181a = (C3181a) obj;
        return this.f9733c == c3181a.f9733c && C3233b.m16040a(this.f9734d, c3181a.f9734d) && C3233b.m16040a(this.f9735e, c3181a.f9735e);
    }

    public int hashCode() {
        return C3233b.m16038a(Integer.valueOf(this.f9733c), this.f9734d, this.f9735e);
    }

    public String toString() {
        return C3233b.m16039a((Object) this).m16037a("statusCode", C3181a.m15876a(this.f9733c)).m16037a("resolution", this.f9734d).m16037a("message", this.f9735e).toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C3218i.m16001a(this, parcel, i);
    }
}
