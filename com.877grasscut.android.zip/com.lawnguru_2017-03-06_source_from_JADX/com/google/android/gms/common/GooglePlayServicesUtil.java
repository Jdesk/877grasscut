package com.google.android.gms.common;

import android.app.Activity;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface.OnCancelListener;
import android.content.res.Resources;
import android.support.v4.app.Fragment;
import com.google.android.gms.common.internal.C3257r;

public final class GooglePlayServicesUtil extends C3180n {
    public static final String GMS_ERROR_DIALOG = "GooglePlayServicesErrorDialog";
    @Deprecated
    public static final String GOOGLE_PLAY_SERVICES_PACKAGE = "com.google.android.gms";
    @Deprecated
    public static final int GOOGLE_PLAY_SERVICES_VERSION_CODE;
    public static final String GOOGLE_PLAY_STORE_PACKAGE = "com.android.vending";

    static {
        GOOGLE_PLAY_SERVICES_VERSION_CODE = C3180n.GOOGLE_PLAY_SERVICES_VERSION_CODE;
    }

    private GooglePlayServicesUtil() {
    }

    @Deprecated
    public static Dialog getErrorDialog(int i, Activity activity, int i2) {
        return getErrorDialog(i, activity, i2, null);
    }

    @Deprecated
    public static Dialog getErrorDialog(int i, Activity activity, int i2, OnCancelListener onCancelListener) {
        if (zzd(activity, i)) {
            i = 18;
        }
        return C3205c.m15944a().m15946a(activity, i, i2, onCancelListener);
    }

    @Deprecated
    public static PendingIntent getErrorPendingIntent(int i, Context context, int i2) {
        return C3180n.getErrorPendingIntent(i, context, i2);
    }

    @Deprecated
    public static String getErrorString(int i) {
        return C3180n.getErrorString(i);
    }

    @Deprecated
    public static String getOpenSourceSoftwareLicenseInfo(Context context) {
        return C3180n.getOpenSourceSoftwareLicenseInfo(context);
    }

    public static Context getRemoteContext(Context context) {
        return C3180n.getRemoteContext(context);
    }

    public static Resources getRemoteResource(Context context) {
        return C3180n.getRemoteResource(context);
    }

    @Deprecated
    public static int isGooglePlayServicesAvailable(Context context) {
        return C3180n.isGooglePlayServicesAvailable(context);
    }

    @Deprecated
    public static boolean isUserRecoverableError(int i) {
        return C3180n.isUserRecoverableError(i);
    }

    @Deprecated
    public static boolean showErrorDialogFragment(int i, Activity activity, int i2) {
        return showErrorDialogFragment(i, activity, i2, null);
    }

    @Deprecated
    public static boolean showErrorDialogFragment(int i, Activity activity, int i2, OnCancelListener onCancelListener) {
        return showErrorDialogFragment(i, activity, null, i2, onCancelListener);
    }

    public static boolean showErrorDialogFragment(int i, Activity activity, Fragment fragment, int i2, OnCancelListener onCancelListener) {
        if (zzd(activity, i)) {
            i = 18;
        }
        C3205c a = C3205c.m15944a();
        if (fragment == null) {
            return a.m15963b(activity, i, i2, onCancelListener);
        }
        Dialog a2 = a.m15948a((Context) activity, i, C3257r.m16119a(fragment, C3205c.m15944a().m15962b(activity, i, "d"), i2), onCancelListener);
        if (a2 == null) {
            return false;
        }
        a.m15953a(activity, a2, GMS_ERROR_DIALOG, onCancelListener);
        return true;
    }

    @Deprecated
    public static void showErrorNotification(int i, Context context) {
        C3205c a = C3205c.m15944a();
        if (zzd(context, i) || zze(context, i)) {
            a.m15966c(context);
        } else {
            a.m15954a(context, i);
        }
    }

    @Deprecated
    public static boolean zzd(Context context, int i) {
        return C3180n.zzd(context, i);
    }

    @Deprecated
    public static boolean zze(Context context, int i) {
        return C3180n.zze(context, i);
    }
}
