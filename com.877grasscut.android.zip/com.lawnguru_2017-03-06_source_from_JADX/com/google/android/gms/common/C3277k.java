package com.google.android.gms.common;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.common.k */
public class C3277k implements Creator<C3276j> {
    static void m16237a(C3276j c3276j, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16177a(parcel, 1, c3276j.f9937a, false);
        C3264c.m16168a(parcel, 2, c3276j.f9938b);
        C3264c.m16164a(parcel, a);
    }

    public C3276j m16238a(Parcel parcel) {
        int b = C3263b.m16139b(parcel);
        String str = null;
        int i = 0;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_duration /*1*/:
                    str = C3263b.m16154n(parcel, a);
                    break;
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    i = C3263b.m16146f(parcel, a);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new C3276j(str, i);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public C3276j[] m16239a(int i) {
        return new C3276j[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m16238a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m16239a(i);
    }
}
