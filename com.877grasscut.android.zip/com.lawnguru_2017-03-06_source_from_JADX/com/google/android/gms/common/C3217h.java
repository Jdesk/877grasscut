package com.google.android.gms.common;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import com.google.android.gms.common.internal.C3234c;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/* renamed from: com.google.android.gms.common.h */
public class C3217h implements ServiceConnection {
    boolean f9825a;
    private final BlockingQueue<IBinder> f9826b;

    public C3217h() {
        this.f9825a = false;
        this.f9826b = new LinkedBlockingQueue();
    }

    public IBinder m16000a(long j, TimeUnit timeUnit) {
        C3234c.m16054c("BlockingServiceConnection.getServiceWithTimeout() called on main thread");
        if (this.f9825a) {
            throw new IllegalStateException("Cannot call get on this connection more than once");
        }
        this.f9825a = true;
        IBinder iBinder = (IBinder) this.f9826b.poll(j, timeUnit);
        if (iBinder != null) {
            return iBinder;
        }
        throw new TimeoutException("Timed out waiting for the service connection");
    }

    public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        this.f9826b.add(iBinder);
    }

    public void onServiceDisconnected(ComponentName componentName) {
    }
}
