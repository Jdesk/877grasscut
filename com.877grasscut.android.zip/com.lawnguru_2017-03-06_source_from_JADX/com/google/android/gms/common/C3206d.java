package com.google.android.gms.common;

/* renamed from: com.google.android.gms.common.d */
public final class C3206d extends Exception {
    public final int f9792a;

    public C3206d(int i) {
        this.f9792a = i;
    }
}
