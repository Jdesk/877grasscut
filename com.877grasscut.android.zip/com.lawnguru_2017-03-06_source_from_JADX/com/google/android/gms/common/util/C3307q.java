package com.google.android.gms.common.util;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.pm.PackageManager.NameNotFoundException;
import android.util.Log;
import com.google.android.gms.common.C3285o;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.p095b.bn;

/* renamed from: com.google.android.gms.common.util.q */
public final class C3307q {
    public static boolean m16354a(Context context, int i) {
        boolean z = false;
        if (!C3307q.m16355a(context, i, GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE)) {
            return z;
        }
        try {
            return C3285o.m16253a(context).m16259a(context.getPackageManager(), context.getPackageManager().getPackageInfo(GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE, 64));
        } catch (NameNotFoundException e) {
            if (!Log.isLoggable("UidVerifier", 3)) {
                return z;
            }
            Log.d("UidVerifier", "Package manager can't find google play services package, defaulting to false");
            return z;
        }
    }

    @TargetApi(19)
    public static boolean m16355a(Context context, int i, String str) {
        return bn.m9791b(context).m9787a(i, str);
    }
}
