package com.google.android.gms.common.util;

import android.os.Process;
import android.os.StrictMode;
import android.os.StrictMode.ThreadPolicy;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.FileReader;
import java.io.IOException;

/* renamed from: com.google.android.gms.common.util.n */
public class C3304n {
    private static String f9994a;
    private static final int f9995b;

    static {
        f9994a = null;
        f9995b = Process.myPid();
    }

    public static String m16349a() {
        if (f9994a == null) {
            f9994a = C3304n.m16350a(f9995b);
        }
        return f9994a;
    }

    static String m16350a(int i) {
        Closeable bufferedReader;
        Throwable th;
        String str = null;
        if (i > 0) {
            ThreadPolicy allowThreadDiskReads;
            try {
                allowThreadDiskReads = StrictMode.allowThreadDiskReads();
                bufferedReader = new BufferedReader(new FileReader("/proc/" + i + "/cmdline"));
                try {
                    StrictMode.setThreadPolicy(allowThreadDiskReads);
                    str = bufferedReader.readLine().trim();
                    C3301k.m16334a(bufferedReader);
                } catch (IOException e) {
                    C3301k.m16334a(bufferedReader);
                    return str;
                } catch (Throwable th2) {
                    th = th2;
                    C3301k.m16334a(bufferedReader);
                    throw th;
                }
            } catch (IOException e2) {
                bufferedReader = str;
                C3301k.m16334a(bufferedReader);
                return str;
            } catch (Throwable th3) {
                Throwable th4 = th3;
                bufferedReader = str;
                th = th4;
                C3301k.m16334a(bufferedReader);
                throw th;
            }
        }
        return str;
    }
}
