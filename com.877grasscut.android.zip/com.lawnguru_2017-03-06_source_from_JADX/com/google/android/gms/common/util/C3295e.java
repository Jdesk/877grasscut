package com.google.android.gms.common.util;

import android.os.SystemClock;

/* renamed from: com.google.android.gms.common.util.e */
public class C3295e implements C3293c {
    private static C3295e f9983a;

    static {
        f9983a = new C3295e();
    }

    private C3295e() {
    }

    public static C3293c m16316d() {
        return f9983a;
    }

    public long m16317a() {
        return System.currentTimeMillis();
    }

    public long m16318b() {
        return SystemClock.elapsedRealtime();
    }

    public long m16319c() {
        return System.nanoTime();
    }
}
