package com.google.android.gms.common.util;

/* renamed from: com.google.android.gms.common.util.c */
public interface C3293c {
    long m16301a();

    long m16302b();

    long m16303c();
}
