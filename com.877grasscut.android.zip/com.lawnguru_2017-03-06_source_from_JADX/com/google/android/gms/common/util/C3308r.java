package com.google.android.gms.common.util;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.WorkSource;
import android.util.Log;
import com.google.android.gms.p095b.bn;
import io.card.payment.BuildConfig;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* renamed from: com.google.android.gms.common.util.r */
public class C3308r {
    private static final Method f9997a;
    private static final Method f9998b;
    private static final Method f9999c;
    private static final Method f10000d;
    private static final Method f10001e;

    static {
        f9997a = C3308r.m16360a();
        f9998b = C3308r.m16363b();
        f9999c = C3308r.m16365c();
        f10000d = C3308r.m16366d();
        f10001e = C3308r.m16367e();
    }

    public static int m16356a(WorkSource workSource) {
        if (f9999c != null) {
            try {
                return ((Integer) f9999c.invoke(workSource, new Object[0])).intValue();
            } catch (Throwable e) {
                Log.wtf("WorkSourceUtil", "Unable to assign blame through WorkSource", e);
            }
        }
        return 0;
    }

    public static WorkSource m16357a(int i, String str) {
        WorkSource workSource = new WorkSource();
        C3308r.m16361a(workSource, i, str);
        return workSource;
    }

    public static WorkSource m16358a(Context context, String str) {
        if (context == null || context.getPackageManager() == null) {
            return null;
        }
        String str2;
        String str3;
        String valueOf;
        try {
            ApplicationInfo a = bn.m9791b(context).m9785a(str, 0);
            if (a != null) {
                return C3308r.m16357a(a.uid, str);
            }
            str2 = "WorkSourceUtil";
            str3 = "Could not get applicationInfo from package: ";
            valueOf = String.valueOf(str);
            Log.e(str2, valueOf.length() != 0 ? str3.concat(valueOf) : new String(str3));
            return null;
        } catch (NameNotFoundException e) {
            str2 = "WorkSourceUtil";
            str3 = "Could not find package: ";
            valueOf = String.valueOf(str);
            Log.e(str2, valueOf.length() != 0 ? str3.concat(valueOf) : new String(str3));
            return null;
        }
    }

    public static String m16359a(WorkSource workSource, int i) {
        if (f10001e != null) {
            try {
                return (String) f10001e.invoke(workSource, new Object[]{Integer.valueOf(i)});
            } catch (Throwable e) {
                Log.wtf("WorkSourceUtil", "Unable to assign blame through WorkSource", e);
            }
        }
        return null;
    }

    private static Method m16360a() {
        Method method = null;
        try {
            method = WorkSource.class.getMethod("add", new Class[]{Integer.TYPE});
        } catch (Exception e) {
        }
        return method;
    }

    public static void m16361a(WorkSource workSource, int i, String str) {
        if (f9998b != null) {
            if (str == null) {
                str = BuildConfig.FLAVOR;
            }
            try {
                f9998b.invoke(workSource, new Object[]{Integer.valueOf(i), str});
            } catch (Throwable e) {
                Log.wtf("WorkSourceUtil", "Unable to assign blame through WorkSource", e);
            }
        } else if (f9997a != null) {
            try {
                f9997a.invoke(workSource, new Object[]{Integer.valueOf(i)});
            } catch (Throwable e2) {
                Log.wtf("WorkSourceUtil", "Unable to assign blame through WorkSource", e2);
            }
        }
    }

    public static boolean m16362a(Context context) {
        return (context == null || context.getPackageManager() == null || bn.m9791b(context).m9784a("android.permission.UPDATE_DEVICE_STATS", context.getPackageName()) != 0) ? false : true;
    }

    private static Method m16363b() {
        Method method = null;
        if (C3303m.m16342f()) {
            try {
                method = WorkSource.class.getMethod("add", new Class[]{Integer.TYPE, String.class});
            } catch (Exception e) {
            }
        }
        return method;
    }

    public static List<String> m16364b(WorkSource workSource) {
        int i = 0;
        int a = workSource == null ? 0 : C3308r.m16356a(workSource);
        if (a == 0) {
            return Collections.EMPTY_LIST;
        }
        List<String> arrayList = new ArrayList();
        while (i < a) {
            String a2 = C3308r.m16359a(workSource, i);
            if (!C3305o.m16351a(a2)) {
                arrayList.add(a2);
            }
            i++;
        }
        return arrayList;
    }

    private static Method m16365c() {
        Method method = null;
        try {
            method = WorkSource.class.getMethod("size", new Class[0]);
        } catch (Exception e) {
        }
        return method;
    }

    private static Method m16366d() {
        Method method = null;
        try {
            method = WorkSource.class.getMethod("get", new Class[]{Integer.TYPE});
        } catch (Exception e) {
        }
        return method;
    }

    private static Method m16367e() {
        Method method = null;
        if (C3303m.m16342f()) {
            try {
                method = WorkSource.class.getMethod("getName", new Class[]{Integer.TYPE});
            } catch (Exception e) {
            }
        }
        return method;
    }
}
