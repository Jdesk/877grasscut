package com.google.android.gms.common.util;

import java.util.regex.Pattern;

/* renamed from: com.google.android.gms.common.util.o */
public class C3305o {
    private static final Pattern f9996a;

    static {
        f9996a = Pattern.compile("\\$\\{(.*?)\\}");
    }

    public static boolean m16351a(String str) {
        return str == null || str.trim().isEmpty();
    }
}
