package com.google.android.gms.common.util;

import android.support.v4.util.C0511a;
import io.techery.properratingbar.C5501a.C5500d;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.common.util.d */
public final class C3294d {
    public static <T> List<T> m16304a(T t) {
        return Collections.singletonList(t);
    }

    public static <K, V> Map<K, V> m16305a(K k, V v, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5, K k6, V v6) {
        Map c0511a = new C0511a(6);
        c0511a.put(k, v);
        c0511a.put(k2, v2);
        c0511a.put(k3, v3);
        c0511a.put(k4, v4);
        c0511a.put(k5, v5);
        c0511a.put(k6, v6);
        return Collections.unmodifiableMap(c0511a);
    }

    public static <K, V> Map<K, V> m16306a(K[] kArr, V[] vArr) {
        int i = 0;
        C3294d.m16315b((Object[]) kArr, (Object[]) vArr);
        int length = kArr.length;
        switch (length) {
            case C5538a.ExpandableLayout_android_orientation /*0*/:
                return C3294d.m16312b();
            case C5538a.ExpandableLayout_el_duration /*1*/:
                return C3294d.m16313b(kArr[0], vArr[0]);
            default:
                Map c0511a = length <= 32 ? new C0511a(length) : new HashMap(length, 1.0f);
                while (i < length) {
                    c0511a.put(kArr[i], vArr[i]);
                    i++;
                }
                return Collections.unmodifiableMap(c0511a);
        }
    }

    public static <T> Set<T> m16307a() {
        return Collections.emptySet();
    }

    public static <T> Set<T> m16308a(T t, T t2) {
        Set c3291a = new C3291a(2);
        c3291a.add(t);
        c3291a.add(t2);
        return Collections.unmodifiableSet(c3291a);
    }

    public static <T> Set<T> m16309a(T t, T t2, T t3) {
        Set c3291a = new C3291a(3);
        c3291a.add(t);
        c3291a.add(t2);
        c3291a.add(t3);
        return Collections.unmodifiableSet(c3291a);
    }

    public static <T> Set<T> m16310a(T t, T t2, T t3, T t4) {
        Set c3291a = new C3291a(4);
        c3291a.add(t);
        c3291a.add(t2);
        c3291a.add(t3);
        c3291a.add(t4);
        return Collections.unmodifiableSet(c3291a);
    }

    public static <T> Set<T> m16311a(T... tArr) {
        switch (tArr.length) {
            case C5538a.ExpandableLayout_android_orientation /*0*/:
                return C3294d.m16307a();
            case C5538a.ExpandableLayout_el_duration /*1*/:
                return C3294d.m16314b(tArr[0]);
            case C5538a.ExpandableLayout_el_expanded /*2*/:
                return C3294d.m16308a(tArr[0], tArr[1]);
            case C5538a.ExpandableLayout_layout_expandable /*3*/:
                return C3294d.m16309a(tArr[0], tArr[1], tArr[2]);
            case C5500d.ProperRatingBar_prb_clickable /*4*/:
                return C3294d.m16310a(tArr[0], tArr[1], tArr[2], tArr[3]);
            default:
                return Collections.unmodifiableSet(tArr.length <= 32 ? new C3291a(Arrays.asList(tArr)) : new HashSet(Arrays.asList(tArr)));
        }
    }

    public static <K, V> Map<K, V> m16312b() {
        return Collections.emptyMap();
    }

    public static <K, V> Map<K, V> m16313b(K k, V v) {
        return Collections.singletonMap(k, v);
    }

    public static <T> Set<T> m16314b(T t) {
        return Collections.singleton(t);
    }

    private static <K, V> void m16315b(K[] kArr, V[] vArr) {
        if (kArr.length != vArr.length) {
            int length = kArr.length;
            throw new IllegalArgumentException("Key and values array lengths not equal: " + length + " != " + vArr.length);
        }
    }
}
