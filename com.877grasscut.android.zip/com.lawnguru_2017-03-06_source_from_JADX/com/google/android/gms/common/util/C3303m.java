package com.google.android.gms.common.util;

import android.os.Build.VERSION;

/* renamed from: com.google.android.gms.common.util.m */
public final class C3303m {
    public static boolean m16337a() {
        int i = VERSION.SDK_INT;
        return true;
    }

    public static boolean m16338b() {
        int i = VERSION.SDK_INT;
        return true;
    }

    public static boolean m16339c() {
        return VERSION.SDK_INT >= 15;
    }

    public static boolean m16340d() {
        return VERSION.SDK_INT >= 16;
    }

    public static boolean m16341e() {
        return VERSION.SDK_INT >= 17;
    }

    public static boolean m16342f() {
        return VERSION.SDK_INT >= 18;
    }

    public static boolean m16343g() {
        return VERSION.SDK_INT >= 19;
    }

    public static boolean m16344h() {
        return VERSION.SDK_INT >= 20;
    }

    @Deprecated
    public static boolean m16345i() {
        return C3303m.m16346j();
    }

    public static boolean m16346j() {
        return VERSION.SDK_INT >= 21;
    }

    public static boolean m16347k() {
        return VERSION.SDK_INT >= 23;
    }

    public static boolean m16348l() {
        return VERSION.SDK_INT >= 24;
    }
}
