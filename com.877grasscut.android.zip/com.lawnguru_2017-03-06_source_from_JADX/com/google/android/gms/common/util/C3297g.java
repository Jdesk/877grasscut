package com.google.android.gms.common.util;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.PowerManager;
import android.os.SystemClock;

/* renamed from: com.google.android.gms.common.util.g */
public final class C3297g {
    private static IntentFilter f9987a;
    private static long f9988b;
    private static float f9989c;

    static {
        f9987a = new IntentFilter("android.intent.action.BATTERY_CHANGED");
        f9989c = Float.NaN;
    }

    @TargetApi(20)
    public static int m16325a(Context context) {
        int i = 1;
        if (context == null || context.getApplicationContext() == null) {
            return -1;
        }
        Intent registerReceiver = context.getApplicationContext().registerReceiver(null, f9987a);
        int i2 = ((registerReceiver == null ? 0 : registerReceiver.getIntExtra("plugged", 0)) & 7) != 0 ? 1 : 0;
        PowerManager powerManager = (PowerManager) context.getSystemService("power");
        if (powerManager == null) {
            return -1;
        }
        int i3 = (C3297g.m16326a(powerManager) ? 1 : 0) << 1;
        if (i2 == 0) {
            i = 0;
        }
        return i3 | i;
    }

    @TargetApi(20)
    public static boolean m16326a(PowerManager powerManager) {
        return C3303m.m16344h() ? powerManager.isInteractive() : powerManager.isScreenOn();
    }

    public static synchronized float m16327b(Context context) {
        float f;
        synchronized (C3297g.class) {
            if (SystemClock.elapsedRealtime() - f9988b >= 60000 || Float.isNaN(f9989c)) {
                Intent registerReceiver = context.getApplicationContext().registerReceiver(null, f9987a);
                if (registerReceiver != null) {
                    f9989c = ((float) registerReceiver.getIntExtra("level", -1)) / ((float) registerReceiver.getIntExtra("scale", -1));
                }
                f9988b = SystemClock.elapsedRealtime();
                f = f9989c;
            } else {
                f = f9989c;
            }
        }
        return f;
    }
}
