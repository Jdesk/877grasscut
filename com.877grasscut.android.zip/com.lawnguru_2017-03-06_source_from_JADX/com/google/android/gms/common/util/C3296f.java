package com.google.android.gms.common.util;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import com.google.android.gms.common.C3180n;

/* renamed from: com.google.android.gms.common.util.f */
public final class C3296f {
    private static Boolean f9984a;
    private static Boolean f9985b;
    private static Boolean f9986c;

    public static boolean m16320a() {
        boolean z = C3180n.zzayx;
        return "user".equals(Build.TYPE);
    }

    @TargetApi(20)
    public static boolean m16321a(Context context) {
        if (f9984a == null) {
            boolean z = C3303m.m16344h() && context.getPackageManager().hasSystemFeature("android.hardware.type.watch");
            f9984a = Boolean.valueOf(z);
        }
        return f9984a.booleanValue();
    }

    @TargetApi(24)
    public static boolean m16322b(Context context) {
        return (!C3303m.m16348l() || C3296f.m16323c(context)) && C3296f.m16321a(context);
    }

    @TargetApi(21)
    public static boolean m16323c(Context context) {
        if (f9985b == null) {
            boolean z = C3303m.m16346j() && context.getPackageManager().hasSystemFeature("cn.google");
            f9985b = Boolean.valueOf(z);
        }
        return f9985b.booleanValue();
    }

    public static boolean m16324d(Context context) {
        if (f9986c == null) {
            f9986c = Boolean.valueOf(context.getPackageManager().hasSystemFeature("android.hardware.type.iot"));
        }
        return f9986c.booleanValue();
    }
}
