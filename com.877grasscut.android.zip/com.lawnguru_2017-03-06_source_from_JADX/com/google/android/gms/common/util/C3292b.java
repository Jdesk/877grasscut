package com.google.android.gms.common.util;

import android.content.Context;
import android.content.pm.PackageManager.NameNotFoundException;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.p095b.bn;

/* renamed from: com.google.android.gms.common.util.b */
public class C3292b {
    public static boolean m16300a(Context context, String str) {
        GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE.equals(str);
        try {
            return (bn.m9791b(context).m9785a(str, 0).flags & 2097152) != 0;
        } catch (NameNotFoundException e) {
            return false;
        }
    }
}
