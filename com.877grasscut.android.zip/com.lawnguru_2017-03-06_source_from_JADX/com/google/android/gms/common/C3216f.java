package com.google.android.gms.common;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.os.Bundle;
import android.support.v4.app.C0325q;
import android.support.v4.app.FragmentManager;
import com.google.android.gms.common.internal.C3234c;

/* renamed from: com.google.android.gms.common.f */
public class C3216f extends C0325q {
    private Dialog f9823a;
    private OnCancelListener f9824b;

    public C3216f() {
        this.f9823a = null;
        this.f9824b = null;
    }

    public static C3216f m15999a(Dialog dialog, OnCancelListener onCancelListener) {
        C3216f c3216f = new C3216f();
        Dialog dialog2 = (Dialog) C3234c.m16043a((Object) dialog, (Object) "Cannot display null dialog");
        dialog2.setOnCancelListener(null);
        dialog2.setOnDismissListener(null);
        c3216f.f9823a = dialog2;
        if (onCancelListener != null) {
            c3216f.f9824b = onCancelListener;
        }
        return c3216f;
    }

    public void onCancel(DialogInterface dialogInterface) {
        if (this.f9824b != null) {
            this.f9824b.onCancel(dialogInterface);
        }
    }

    public Dialog onCreateDialog(Bundle bundle) {
        if (this.f9823a == null) {
            setShowsDialog(false);
        }
        return this.f9823a;
    }

    public void show(FragmentManager fragmentManager, String str) {
        super.show(fragmentManager, str);
    }
}
