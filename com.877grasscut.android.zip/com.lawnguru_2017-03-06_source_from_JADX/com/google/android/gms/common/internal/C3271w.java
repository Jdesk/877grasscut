package com.google.android.gms.common.internal;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;

/* renamed from: com.google.android.gms.common.internal.w */
public abstract class C3271w {
    private static final Object f9916a;
    private static C3271w f9917b;

    /* renamed from: com.google.android.gms.common.internal.w.a */
    protected static final class C3270a {
        private final String f9913a;
        private final String f9914b;
        private final ComponentName f9915c;

        public C3270a(String str, String str2) {
            this.f9913a = C3234c.m16044a(str);
            this.f9914b = C3234c.m16044a(str2);
            this.f9915c = null;
        }

        public String m16208a() {
            return this.f9914b;
        }

        public ComponentName m16209b() {
            return this.f9915c;
        }

        public Intent m16210c() {
            return this.f9913a != null ? new Intent(this.f9913a).setPackage(this.f9914b) : new Intent().setComponent(this.f9915c);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof C3270a)) {
                return false;
            }
            C3270a c3270a = (C3270a) obj;
            return C3233b.m16040a(this.f9913a, c3270a.f9913a) && C3233b.m16040a(this.f9915c, c3270a.f9915c);
        }

        public int hashCode() {
            return C3233b.m16038a(this.f9913a, this.f9915c);
        }

        public String toString() {
            return this.f9913a == null ? this.f9915c.flattenToString() : this.f9913a;
        }
    }

    static {
        f9916a = new Object();
    }

    public static C3271w m16211a(Context context) {
        synchronized (f9916a) {
            if (f9917b == null) {
                f9917b = new C3273x(context.getApplicationContext());
            }
        }
        return f9917b;
    }

    protected abstract boolean m16212a(C3270a c3270a, ServiceConnection serviceConnection, String str);

    public boolean m16213a(String str, String str2, ServiceConnection serviceConnection, String str3) {
        return m16212a(new C3270a(str, str2), serviceConnection, str3);
    }

    protected abstract void m16214b(C3270a c3270a, ServiceConnection serviceConnection, String str);

    public void m16215b(String str, String str2, ServiceConnection serviceConnection, String str3) {
        m16214b(new C3270a(str, str2), serviceConnection, str3);
    }
}
