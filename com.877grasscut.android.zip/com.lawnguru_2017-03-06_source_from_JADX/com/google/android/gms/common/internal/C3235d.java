package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.internal.safeparcel.C2149a;

/* renamed from: com.google.android.gms.common.internal.d */
public class C3235d extends C2149a {
    public static final Creator<C3235d> CREATOR;
    final int f9839a;
    private final Account f9840b;
    private final int f9841c;
    private final GoogleSignInAccount f9842d;

    static {
        CREATOR = new C3236e();
    }

    C3235d(int i, Account account, int i2, GoogleSignInAccount googleSignInAccount) {
        this.f9839a = i;
        this.f9840b = account;
        this.f9841c = i2;
        this.f9842d = googleSignInAccount;
    }

    public C3235d(Account account, int i, GoogleSignInAccount googleSignInAccount) {
        this(2, account, i, googleSignInAccount);
    }

    public Account m16055a() {
        return this.f9840b;
    }

    public int m16056b() {
        return this.f9841c;
    }

    public GoogleSignInAccount m16057c() {
        return this.f9842d;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C3236e.m16058a(this, parcel, i);
    }
}
