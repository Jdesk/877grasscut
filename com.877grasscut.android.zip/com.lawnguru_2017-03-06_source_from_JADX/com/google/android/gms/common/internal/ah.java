package com.google.android.gms.common.internal;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.ad;
import android.util.Log;
import com.google.android.gms.p095b.bn;

public class ah {
    private static Object f9833a;
    private static boolean f9834b;
    private static String f9835c;
    private static int f9836d;

    static {
        f9833a = new Object();
    }

    public static String m16034a(Context context) {
        m16036c(context);
        return f9835c;
    }

    public static int m16035b(Context context) {
        m16036c(context);
        return f9836d;
    }

    private static void m16036c(Context context) {
        synchronized (f9833a) {
            if (f9834b) {
                return;
            }
            f9834b = true;
            try {
                Bundle bundle = bn.m9791b(context).m9785a(context.getPackageName(), (int) ad.FLAG_HIGH_PRIORITY).metaData;
                if (bundle == null) {
                    return;
                }
                f9835c = bundle.getString("com.google.app.id");
                f9836d = bundle.getInt("com.google.android.gms.version");
            } catch (Throwable e) {
                Log.wtf("MetadataValueReader", "This should never happen.", e);
            }
        }
    }
}
