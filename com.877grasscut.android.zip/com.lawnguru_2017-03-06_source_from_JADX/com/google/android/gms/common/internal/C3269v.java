package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.common.C3181a;
import com.google.android.gms.common.api.C2854c.C2420b;
import com.google.android.gms.common.api.C2854c.C2421c;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicInteger;

/* renamed from: com.google.android.gms.common.internal.v */
public final class C3269v implements Callback {
    final ArrayList<C2420b> f9904a;
    private final C2356a f9905b;
    private final ArrayList<C2420b> f9906c;
    private final ArrayList<C2421c> f9907d;
    private volatile boolean f9908e;
    private final AtomicInteger f9909f;
    private boolean f9910g;
    private final Handler f9911h;
    private final Object f9912i;

    /* renamed from: com.google.android.gms.common.internal.v.a */
    public interface C2356a {
        boolean m9285g();

        Bundle m9286u();
    }

    public C3269v(Looper looper, C2356a c2356a) {
        this.f9906c = new ArrayList();
        this.f9904a = new ArrayList();
        this.f9907d = new ArrayList();
        this.f9908e = false;
        this.f9909f = new AtomicInteger(0);
        this.f9910g = false;
        this.f9912i = new Object();
        this.f9905b = c2356a;
        this.f9911h = new Handler(looper, this);
    }

    public void m16200a() {
        this.f9908e = false;
        this.f9909f.incrementAndGet();
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void m16201a(int r6) {
        /*
        r5 = this;
        r0 = 0;
        r1 = 1;
        r2 = android.os.Looper.myLooper();
        r3 = r5.f9911h;
        r3 = r3.getLooper();
        if (r2 != r3) goto L_0x000f;
    L_0x000e:
        r0 = r1;
    L_0x000f:
        r2 = "onUnintentionalDisconnection must only be called on the Handler thread";
        com.google.android.gms.common.internal.C3234c.m16048a(r0, r2);
        r0 = r5.f9911h;
        r0.removeMessages(r1);
        r1 = r5.f9912i;
        monitor-enter(r1);
        r0 = 1;
        r5.f9910g = r0;	 Catch:{ all -> 0x005e }
        r0 = new java.util.ArrayList;	 Catch:{ all -> 0x005e }
        r2 = r5.f9906c;	 Catch:{ all -> 0x005e }
        r0.<init>(r2);	 Catch:{ all -> 0x005e }
        r2 = r5.f9909f;	 Catch:{ all -> 0x005e }
        r2 = r2.get();	 Catch:{ all -> 0x005e }
        r3 = r0.iterator();	 Catch:{ all -> 0x005e }
    L_0x0030:
        r0 = r3.hasNext();	 Catch:{ all -> 0x005e }
        if (r0 == 0) goto L_0x0048;
    L_0x0036:
        r0 = r3.next();	 Catch:{ all -> 0x005e }
        r0 = (com.google.android.gms.common.api.C2854c.C2420b) r0;	 Catch:{ all -> 0x005e }
        r4 = r5.f9908e;	 Catch:{ all -> 0x005e }
        if (r4 == 0) goto L_0x0048;
    L_0x0040:
        r4 = r5.f9909f;	 Catch:{ all -> 0x005e }
        r4 = r4.get();	 Catch:{ all -> 0x005e }
        if (r4 == r2) goto L_0x0052;
    L_0x0048:
        r0 = r5.f9904a;	 Catch:{ all -> 0x005e }
        r0.clear();	 Catch:{ all -> 0x005e }
        r0 = 0;
        r5.f9910g = r0;	 Catch:{ all -> 0x005e }
        monitor-exit(r1);	 Catch:{ all -> 0x005e }
        return;
    L_0x0052:
        r4 = r5.f9906c;	 Catch:{ all -> 0x005e }
        r4 = r4.contains(r0);	 Catch:{ all -> 0x005e }
        if (r4 == 0) goto L_0x0030;
    L_0x005a:
        r0.m9661a(r6);	 Catch:{ all -> 0x005e }
        goto L_0x0030;
    L_0x005e:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x005e }
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.common.internal.v.a(int):void");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void m16202a(android.os.Bundle r6) {
        /*
        r5 = this;
        r2 = 0;
        r1 = 1;
        r0 = android.os.Looper.myLooper();
        r3 = r5.f9911h;
        r3 = r3.getLooper();
        if (r0 != r3) goto L_0x006e;
    L_0x000e:
        r0 = r1;
    L_0x000f:
        r3 = "onConnectionSuccess must only be called on the Handler thread";
        com.google.android.gms.common.internal.C3234c.m16048a(r0, r3);
        r3 = r5.f9912i;
        monitor-enter(r3);
        r0 = r5.f9910g;	 Catch:{ all -> 0x0080 }
        if (r0 != 0) goto L_0x0070;
    L_0x001b:
        r0 = r1;
    L_0x001c:
        com.google.android.gms.common.internal.C3234c.m16047a(r0);	 Catch:{ all -> 0x0080 }
        r0 = r5.f9911h;	 Catch:{ all -> 0x0080 }
        r4 = 1;
        r0.removeMessages(r4);	 Catch:{ all -> 0x0080 }
        r0 = 1;
        r5.f9910g = r0;	 Catch:{ all -> 0x0080 }
        r0 = r5.f9904a;	 Catch:{ all -> 0x0080 }
        r0 = r0.size();	 Catch:{ all -> 0x0080 }
        if (r0 != 0) goto L_0x0072;
    L_0x0030:
        com.google.android.gms.common.internal.C3234c.m16047a(r1);	 Catch:{ all -> 0x0080 }
        r0 = new java.util.ArrayList;	 Catch:{ all -> 0x0080 }
        r1 = r5.f9906c;	 Catch:{ all -> 0x0080 }
        r0.<init>(r1);	 Catch:{ all -> 0x0080 }
        r1 = r5.f9909f;	 Catch:{ all -> 0x0080 }
        r1 = r1.get();	 Catch:{ all -> 0x0080 }
        r2 = r0.iterator();	 Catch:{ all -> 0x0080 }
    L_0x0044:
        r0 = r2.hasNext();	 Catch:{ all -> 0x0080 }
        if (r0 == 0) goto L_0x0064;
    L_0x004a:
        r0 = r2.next();	 Catch:{ all -> 0x0080 }
        r0 = (com.google.android.gms.common.api.C2854c.C2420b) r0;	 Catch:{ all -> 0x0080 }
        r4 = r5.f9908e;	 Catch:{ all -> 0x0080 }
        if (r4 == 0) goto L_0x0064;
    L_0x0054:
        r4 = r5.f9905b;	 Catch:{ all -> 0x0080 }
        r4 = r4.m9285g();	 Catch:{ all -> 0x0080 }
        if (r4 == 0) goto L_0x0064;
    L_0x005c:
        r4 = r5.f9909f;	 Catch:{ all -> 0x0080 }
        r4 = r4.get();	 Catch:{ all -> 0x0080 }
        if (r4 == r1) goto L_0x0074;
    L_0x0064:
        r0 = r5.f9904a;	 Catch:{ all -> 0x0080 }
        r0.clear();	 Catch:{ all -> 0x0080 }
        r0 = 0;
        r5.f9910g = r0;	 Catch:{ all -> 0x0080 }
        monitor-exit(r3);	 Catch:{ all -> 0x0080 }
        return;
    L_0x006e:
        r0 = r2;
        goto L_0x000f;
    L_0x0070:
        r0 = r2;
        goto L_0x001c;
    L_0x0072:
        r1 = r2;
        goto L_0x0030;
    L_0x0074:
        r4 = r5.f9904a;	 Catch:{ all -> 0x0080 }
        r4 = r4.contains(r0);	 Catch:{ all -> 0x0080 }
        if (r4 != 0) goto L_0x0044;
    L_0x007c:
        r0.m9662a(r6);	 Catch:{ all -> 0x0080 }
        goto L_0x0044;
    L_0x0080:
        r0 = move-exception;
        monitor-exit(r3);	 Catch:{ all -> 0x0080 }
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.common.internal.v.a(android.os.Bundle):void");
    }

    public void m16203a(C3181a c3181a) {
        C3234c.m16048a(Looper.myLooper() == this.f9911h.getLooper(), (Object) "onConnectionFailure must only be called on the Handler thread");
        this.f9911h.removeMessages(1);
        synchronized (this.f9912i) {
            ArrayList arrayList = new ArrayList(this.f9907d);
            int i = this.f9909f.get();
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                C2421c c2421c = (C2421c) it.next();
                if (!this.f9908e || this.f9909f.get() != i) {
                    return;
                } else if (this.f9907d.contains(c2421c)) {
                    c2421c.m9663a(c3181a);
                }
            }
        }
    }

    public void m16204a(C2420b c2420b) {
        C3234c.m16042a((Object) c2420b);
        synchronized (this.f9912i) {
            if (this.f9906c.contains(c2420b)) {
                String valueOf = String.valueOf(c2420b);
                Log.w("GmsClientEvents", new StringBuilder(String.valueOf(valueOf).length() + 62).append("registerConnectionCallbacks(): listener ").append(valueOf).append(" is already registered").toString());
            } else {
                this.f9906c.add(c2420b);
            }
        }
        if (this.f9905b.m9285g()) {
            this.f9911h.sendMessage(this.f9911h.obtainMessage(1, c2420b));
        }
    }

    public void m16205a(C2421c c2421c) {
        C3234c.m16042a((Object) c2421c);
        synchronized (this.f9912i) {
            if (this.f9907d.contains(c2421c)) {
                String valueOf = String.valueOf(c2421c);
                Log.w("GmsClientEvents", new StringBuilder(String.valueOf(valueOf).length() + 67).append("registerConnectionFailedListener(): listener ").append(valueOf).append(" is already registered").toString());
            } else {
                this.f9907d.add(c2421c);
            }
        }
    }

    public void m16206b() {
        this.f9908e = true;
    }

    public void m16207b(C2421c c2421c) {
        C3234c.m16042a((Object) c2421c);
        synchronized (this.f9912i) {
            if (!this.f9907d.remove(c2421c)) {
                String valueOf = String.valueOf(c2421c);
                Log.w("GmsClientEvents", new StringBuilder(String.valueOf(valueOf).length() + 57).append("unregisterConnectionFailedListener(): listener ").append(valueOf).append(" not found").toString());
            }
        }
    }

    public boolean handleMessage(Message message) {
        if (message.what == 1) {
            C2420b c2420b = (C2420b) message.obj;
            synchronized (this.f9912i) {
                if (this.f9908e && this.f9905b.m9285g() && this.f9906c.contains(c2420b)) {
                    c2420b.m9662a(this.f9905b.m9286u());
                }
            }
            return true;
        }
        Log.wtf("GmsClientEvents", "Don't know how to handle message: " + message.what, new Exception());
        return false;
    }
}
