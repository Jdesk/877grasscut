package com.google.android.gms.common.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.common.internal.k */
public class C3242k implements Creator<C3241j> {
    static void m16073a(C3241j c3241j, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16168a(parcel, 1, c3241j.f9851a);
        C3264c.m16164a(parcel, a);
    }

    public C3241j m16074a(Parcel parcel) {
        int b = C3263b.m16139b(parcel);
        int i = 0;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_duration /*1*/:
                    i = C3263b.m16146f(parcel, a);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new C3241j(i);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public C3241j[] m16075a(int i) {
        return new C3241j[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m16074a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m16075a(i);
    }
}
