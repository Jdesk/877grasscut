package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.C3181a;
import com.google.android.gms.common.internal.aa.C3219a;
import com.google.android.gms.common.internal.safeparcel.C2149a;

/* renamed from: com.google.android.gms.common.internal.f */
public class C3237f extends C2149a {
    public static final Creator<C3237f> CREATOR;
    final int f9843a;
    IBinder f9844b;
    private C3181a f9845c;
    private boolean f9846d;
    private boolean f9847e;

    static {
        CREATOR = new C3238g();
    }

    C3237f(int i, IBinder iBinder, C3181a c3181a, boolean z, boolean z2) {
        this.f9843a = i;
        this.f9844b = iBinder;
        this.f9845c = c3181a;
        this.f9846d = z;
        this.f9847e = z2;
    }

    public aa m16061a() {
        return C3219a.m16005a(this.f9844b);
    }

    public C3181a m16062b() {
        return this.f9845c;
    }

    public boolean m16063c() {
        return this.f9846d;
    }

    public boolean m16064d() {
        return this.f9847e;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C3237f)) {
            return false;
        }
        C3237f c3237f = (C3237f) obj;
        return this.f9845c.equals(c3237f.f9845c) && m16061a().equals(c3237f.m16061a());
    }

    public void writeToParcel(Parcel parcel, int i) {
        C3238g.m16065a(this, parcel, i);
    }
}
