package com.google.android.gms.common.internal;

/* renamed from: com.google.android.gms.common.internal.z */
public final class C3275z {
    public static final int f9933a;
    private static final String f9934b;
    private final String f9935c;
    private final String f9936d;

    static {
        f9933a = 23 - " PII_LOG".length();
        f9934b = null;
    }

    public C3275z(String str) {
        this(str, null);
    }

    public C3275z(String str, String str2) {
        C3234c.m16043a((Object) str, (Object) "log tag cannot be null");
        C3234c.m16053b(str.length() <= 23, "tag \"%s\" is longer than the %d character maximum", str, Integer.valueOf(23));
        this.f9935c = str;
        if (str2 == null || str2.length() <= 0) {
            this.f9936d = null;
        } else {
            this.f9936d = str2;
        }
    }
}
