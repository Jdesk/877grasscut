package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.C3276j;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.common.internal.t */
public class C3266t implements Creator<C3261s> {
    static void m16194a(C3261s c3261s, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16168a(parcel, 1, c3261s.f9893a);
        C3264c.m16168a(parcel, 2, c3261s.f9894b);
        C3264c.m16168a(parcel, 3, c3261s.f9895c);
        C3264c.m16177a(parcel, 4, c3261s.f9896d, false);
        C3264c.m16171a(parcel, 5, c3261s.f9897e, false);
        C3264c.m16183a(parcel, 6, c3261s.f9898f, i, false);
        C3264c.m16170a(parcel, 7, c3261s.f9899g, false);
        C3264c.m16172a(parcel, 8, c3261s.f9900h, i, false);
        C3264c.m16183a(parcel, 10, c3261s.f9901i, i, false);
        C3264c.m16164a(parcel, a);
    }

    public C3261s m16195a(Parcel parcel) {
        int i = 0;
        C3276j[] c3276jArr = null;
        int b = C3263b.m16139b(parcel);
        Account account = null;
        Bundle bundle = null;
        Scope[] scopeArr = null;
        IBinder iBinder = null;
        String str = null;
        int i2 = 0;
        int i3 = 0;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_duration /*1*/:
                    i3 = C3263b.m16146f(parcel, a);
                    break;
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    i2 = C3263b.m16146f(parcel, a);
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    i = C3263b.m16146f(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    str = C3263b.m16154n(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTick /*5*/:
                    iBinder = C3263b.m16155o(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickNormalColor /*6*/:
                    scopeArr = (Scope[]) C3263b.m16141b(parcel, a, Scope.CREATOR);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickSelectedColor /*7*/:
                    bundle = C3263b.m16156p(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickNormalDrawable /*8*/:
                    account = (Account) C3263b.m16135a(parcel, a, Account.CREATOR);
                    break;
                case C5500d.ProperRatingBar_prb_tickSpacing /*10*/:
                    c3276jArr = (C3276j[]) C3263b.m16141b(parcel, a, C3276j.CREATOR);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new C3261s(i3, i2, i, str, iBinder, scopeArr, bundle, account, c3276jArr);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public C3261s[] m16196a(int i) {
        return new C3261s[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m16195a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m16196a(i);
    }
}
