package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.common.internal.n */
public class C3245n implements Creator<C3244m> {
    static void m16077a(C3244m c3244m, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16168a(parcel, 1, c3244m.f9852a);
        C3264c.m16171a(parcel, 2, c3244m.f9853b, false);
        C3264c.m16183a(parcel, 3, c3244m.f9854c, i, false);
        C3264c.m16175a(parcel, 4, c3244m.f9855d, false);
        C3264c.m16175a(parcel, 5, c3244m.f9856e, false);
        C3264c.m16164a(parcel, a);
    }

    public C3244m m16078a(Parcel parcel) {
        Integer num = null;
        int b = C3263b.m16139b(parcel);
        int i = 0;
        Integer num2 = null;
        Scope[] scopeArr = null;
        IBinder iBinder = null;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_duration /*1*/:
                    i = C3263b.m16146f(parcel, a);
                    break;
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    iBinder = C3263b.m16155o(parcel, a);
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    scopeArr = (Scope[]) C3263b.m16141b(parcel, a, Scope.CREATOR);
                    break;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    num2 = C3263b.m16147g(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTick /*5*/:
                    num = C3263b.m16147g(parcel, a);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new C3244m(i, iBinder, scopeArr, num2, num);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public C3244m[] m16079a(int i) {
        return new C3244m[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m16078a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m16079a(i);
    }
}
