package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Binder;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.C3180n;
import com.google.android.gms.common.internal.aa.C3219a;

/* renamed from: com.google.android.gms.common.internal.a */
public class C3220a extends C3219a {
    int f9827a;

    public static Account m16006a(aa aaVar) {
        Account account = null;
        if (aaVar != null) {
            long clearCallingIdentity = Binder.clearCallingIdentity();
            try {
                account = aaVar.m16004a();
            } catch (RemoteException e) {
                Log.w("AccountAccessor", "Remote account accessor probably died");
            } finally {
                Binder.restoreCallingIdentity(clearCallingIdentity);
            }
        }
        return account;
    }

    public Account m16007a() {
        int callingUid = Binder.getCallingUid();
        if (callingUid != this.f9827a) {
            if (C3180n.zzf(null, callingUid)) {
                this.f9827a = callingUid;
            } else {
                throw new SecurityException("Caller is not GooglePlayServices");
            }
        }
        return null;
    }

    public boolean equals(Object obj) {
        Account account = null;
        return this == obj ? true : !(obj instanceof C3220a) ? false : account.equals(account);
    }
}
