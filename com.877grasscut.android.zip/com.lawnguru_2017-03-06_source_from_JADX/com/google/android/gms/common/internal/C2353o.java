package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.C3181a;
import com.google.android.gms.common.C3204l;
import com.google.android.gms.common.C3276j;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.C3189b;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.ad.C3224a;
import com.google.android.gms.common.internal.ae.C3226a;
import io.techery.properratingbar.C5501a.C5500d;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.common.internal.o */
public abstract class C2353o<T extends IInterface> {
    public static final String[] f5632d;
    final Handler f5633a;
    protected C2930f f5634b;
    protected AtomicInteger f5635c;
    private int f5636e;
    private long f5637f;
    private long f5638g;
    private int f5639h;
    private long f5640i;
    private final Context f5641j;
    private final Looper f5642k;
    private final C3271w f5643l;
    private final C3204l f5644m;
    private final Object f5645n;
    private final Object f5646o;
    private ae f5647p;
    private T f5648q;
    private final ArrayList<C3246e<?>> f5649r;
    private C3250h f5650s;
    private int f5651t;
    private final C2477b f5652u;
    private final C2478c f5653v;
    private final int f5654w;
    private final String f5655x;

    /* renamed from: com.google.android.gms.common.internal.o.b */
    public interface C2477b {
        void m9905a(int i);

        void m9906a(Bundle bundle);
    }

    /* renamed from: com.google.android.gms.common.internal.o.c */
    public interface C2478c {
        void m9907a(C3181a c3181a);
    }

    /* renamed from: com.google.android.gms.common.internal.o.f */
    public interface C2930f {
        void m13791a(C3181a c3181a);
    }

    /* renamed from: com.google.android.gms.common.internal.o.e */
    protected abstract class C3246e<TListener> {
        private TListener f9857a;
        private boolean f9858b;
        final /* synthetic */ C2353o f9859d;

        public C3246e(C2353o c2353o, TListener tListener) {
            this.f9859d = c2353o;
            this.f9857a = tListener;
            this.f9858b = false;
        }

        protected abstract void m16080a(TListener tListener);

        public void m16081b() {
            synchronized (this) {
                Object obj = this.f9857a;
                if (this.f9858b) {
                    String valueOf = String.valueOf(this);
                    Log.w("GmsClient", new StringBuilder(String.valueOf(valueOf).length() + 47).append("Callback proxy ").append(valueOf).append(" being reused. This is not safe.").toString());
                }
            }
            if (obj != null) {
                try {
                    m16080a(obj);
                } catch (RuntimeException e) {
                    throw e;
                }
            }
            synchronized (this) {
                this.f9858b = true;
            }
            m16082c();
        }

        public void m16082c() {
            m16083d();
            synchronized (this.f9859d.f5649r) {
                this.f9859d.f5649r.remove(this);
            }
        }

        public void m16083d() {
            synchronized (this) {
                this.f9857a = null;
            }
        }
    }

    /* renamed from: com.google.android.gms.common.internal.o.a */
    private abstract class C3247a extends C3246e<Boolean> {
        public final int f9860a;
        public final Bundle f9861b;
        final /* synthetic */ C2353o f9862c;

        protected C3247a(C2353o c2353o, int i, Bundle bundle) {
            this.f9862c = c2353o;
            super(c2353o, Boolean.valueOf(true));
            this.f9860a = i;
            this.f9861b = bundle;
        }

        protected abstract void m16084a(C3181a c3181a);

        protected void m16085a(Boolean bool) {
            PendingIntent pendingIntent = null;
            if (bool == null) {
                this.f9862c.m9232a(1, null);
                return;
            }
            switch (this.f9860a) {
                case C5538a.ExpandableLayout_android_orientation /*0*/:
                    if (!m16087a()) {
                        this.f9862c.m9232a(1, null);
                        m16084a(new C3181a(8, null));
                    }
                case C5500d.ProperRatingBar_prb_tickSpacing /*10*/:
                    this.f9862c.m9232a(1, null);
                    throw new IllegalStateException("A fatal developer error has occurred. Check the logs for further information.");
                default:
                    this.f9862c.m9232a(1, null);
                    if (this.f9861b != null) {
                        pendingIntent = (PendingIntent) this.f9861b.getParcelable("pendingIntent");
                    }
                    m16084a(new C3181a(this.f9860a, pendingIntent));
            }
        }

        protected /* synthetic */ void m16086a(Object obj) {
            m16085a((Boolean) obj);
        }

        protected abstract boolean m16087a();
    }

    /* renamed from: com.google.android.gms.common.internal.o.d */
    final class C3248d extends Handler {
        final /* synthetic */ C2353o f9863a;

        public C3248d(C2353o c2353o, Looper looper) {
            this.f9863a = c2353o;
            super(looper);
        }

        private void m16088a(Message message) {
            ((C3246e) message.obj).m16082c();
        }

        private boolean m16089b(Message message) {
            return message.what == 2 || message.what == 1 || message.what == 5;
        }

        public void handleMessage(Message message) {
            PendingIntent pendingIntent = null;
            if (this.f9863a.f5635c.get() != message.arg1) {
                if (m16089b(message)) {
                    m16088a(message);
                }
            } else if ((message.what == 1 || message.what == 5) && !this.f9863a.m9258h()) {
                m16088a(message);
            } else if (message.what == 3) {
                if (message.obj instanceof PendingIntent) {
                    pendingIntent = (PendingIntent) message.obj;
                }
                C3181a c3181a = new C3181a(message.arg2, pendingIntent);
                this.f9863a.f5634b.m13791a(c3181a);
                this.f9863a.m9246a(c3181a);
            } else if (message.what == 4) {
                this.f9863a.m9232a(4, null);
                if (this.f9863a.f5652u != null) {
                    this.f9863a.f5652u.m9905a(message.arg2);
                }
                this.f9863a.m9242a(message.arg2);
                this.f9863a.m9234a(4, 1, null);
            } else if (message.what == 2 && !this.f9863a.m9257g()) {
                m16088a(message);
            } else if (m16089b(message)) {
                ((C3246e) message.obj).m16081b();
            } else {
                Log.wtf("GmsClient", "Don't know how to handle message: " + message.what, new Exception());
            }
        }
    }

    /* renamed from: com.google.android.gms.common.internal.o.g */
    public static final class C3249g extends C3224a {
        private C2353o f9864a;
        private final int f9865b;

        public C3249g(C2353o c2353o, int i) {
            this.f9864a = c2353o;
            this.f9865b = i;
        }

        private void m16090a() {
            this.f9864a = null;
        }

        public void m16091a(int i, Bundle bundle) {
            Log.wtf("GmsClient", "received deprecated onAccountValidationComplete callback, ignoring", new Exception());
        }

        public void m16092a(int i, IBinder iBinder, Bundle bundle) {
            C3234c.m16043a(this.f9864a, (Object) "onPostInitComplete can be called only once per call to getRemoteService");
            this.f9864a.m9244a(i, iBinder, bundle, this.f9865b);
            m16090a();
        }
    }

    /* renamed from: com.google.android.gms.common.internal.o.h */
    public final class C3250h implements ServiceConnection {
        final /* synthetic */ C2353o f9866a;
        private final int f9867b;

        public C3250h(C2353o c2353o, int i) {
            this.f9866a = c2353o;
            this.f9867b = i;
        }

        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            if (iBinder == null) {
                this.f9866a.m9243a(8, null, this.f9867b);
                return;
            }
            synchronized (this.f9866a.f5646o) {
                this.f9866a.f5647p = C3226a.m16019a(iBinder);
            }
            this.f9866a.m9243a(0, null, this.f9867b);
        }

        public void onServiceDisconnected(ComponentName componentName) {
            synchronized (this.f9866a.f5646o) {
                this.f9866a.f5647p = null;
            }
            this.f9866a.f5633a.sendMessage(this.f9866a.f5633a.obtainMessage(4, this.f9867b, 1));
        }
    }

    /* renamed from: com.google.android.gms.common.internal.o.i */
    protected class C3251i implements C2930f {
        final /* synthetic */ C2353o f9868a;

        public C3251i(C2353o c2353o) {
            this.f9868a = c2353o;
        }

        public void m16093a(C3181a c3181a) {
            if (c3181a.m15878b()) {
                this.f9868a.m9247a(null, this.f9868a.m9273x());
            } else if (this.f9868a.f5653v != null) {
                this.f9868a.f5653v.m9907a(c3181a);
            }
        }
    }

    /* renamed from: com.google.android.gms.common.internal.o.j */
    protected final class C3252j extends C3247a {
        public final IBinder f9869e;
        final /* synthetic */ C2353o f9870f;

        public C3252j(C2353o c2353o, int i, IBinder iBinder, Bundle bundle) {
            this.f9870f = c2353o;
            super(c2353o, i, bundle);
            this.f9869e = iBinder;
        }

        protected void m16094a(C3181a c3181a) {
            if (this.f9870f.f5653v != null) {
                this.f9870f.f5653v.m9907a(c3181a);
            }
            this.f9870f.m9246a(c3181a);
        }

        protected boolean m16095a() {
            try {
                String interfaceDescriptor = this.f9869e.getInterfaceDescriptor();
                if (this.f9870f.m9252b().equals(interfaceDescriptor)) {
                    IInterface b = this.f9870f.m9251b(this.f9869e);
                    if (b == null || !this.f9870f.m9234a(2, 3, b)) {
                        return false;
                    }
                    Bundle u = this.f9870f.m9270u();
                    if (this.f9870f.f5652u != null) {
                        this.f9870f.f5652u.m9906a(u);
                    }
                    return true;
                }
                String valueOf = String.valueOf(this.f9870f.m9252b());
                Log.e("GmsClient", new StringBuilder((String.valueOf(valueOf).length() + 34) + String.valueOf(interfaceDescriptor).length()).append("service descriptor mismatch: ").append(valueOf).append(" vs. ").append(interfaceDescriptor).toString());
                return false;
            } catch (RemoteException e) {
                Log.w("GmsClient", "service probably died");
                return false;
            }
        }
    }

    /* renamed from: com.google.android.gms.common.internal.o.k */
    protected final class C3253k extends C3247a {
        final /* synthetic */ C2353o f9871e;

        public C3253k(C2353o c2353o, int i, Bundle bundle) {
            this.f9871e = c2353o;
            super(c2353o, i, bundle);
        }

        protected void m16096a(C3181a c3181a) {
            this.f9871e.f5634b.m13791a(c3181a);
            this.f9871e.m9246a(c3181a);
        }

        protected boolean m16097a() {
            this.f9871e.f5634b.m13791a(C3181a.f9731a);
            return true;
        }
    }

    static {
        f5632d = new String[]{"service_esmobile", "service_googleme"};
    }

    protected C2353o(Context context, Looper looper, int i, C2477b c2477b, C2478c c2478c, String str) {
        this(context, looper, C3271w.m16211a(context), C3204l.m15931b(), i, (C2477b) C3234c.m16042a((Object) c2477b), (C2478c) C3234c.m16042a((Object) c2478c), str);
    }

    protected C2353o(Context context, Looper looper, C3271w c3271w, C3204l c3204l, int i, C2477b c2477b, C2478c c2478c, String str) {
        this.f5645n = new Object();
        this.f5646o = new Object();
        this.f5649r = new ArrayList();
        this.f5651t = 1;
        this.f5635c = new AtomicInteger(0);
        this.f5641j = (Context) C3234c.m16043a((Object) context, (Object) "Context must not be null");
        this.f5642k = (Looper) C3234c.m16043a((Object) looper, (Object) "Looper must not be null");
        this.f5643l = (C3271w) C3234c.m16043a((Object) c3271w, (Object) "Supervisor must not be null");
        this.f5644m = (C3204l) C3234c.m16043a((Object) c3204l, (Object) "API availability must not be null");
        this.f5633a = new C3248d(this, looper);
        this.f5654w = i;
        this.f5652u = c2477b;
        this.f5653v = c2478c;
        this.f5655x = str;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m9232a(int r5, T r6) {
        /*
        r4 = this;
        r0 = 1;
        r1 = 0;
        r2 = 3;
        if (r5 != r2) goto L_0x001a;
    L_0x0005:
        r3 = r0;
    L_0x0006:
        if (r6 == 0) goto L_0x001c;
    L_0x0008:
        r2 = r0;
    L_0x0009:
        if (r3 != r2) goto L_0x001e;
    L_0x000b:
        com.google.android.gms.common.internal.C3234c.m16051b(r0);
        r1 = r4.f5645n;
        monitor-enter(r1);
        r4.f5651t = r5;	 Catch:{ all -> 0x0024 }
        r4.f5648q = r6;	 Catch:{ all -> 0x0024 }
        switch(r5) {
            case 1: goto L_0x002b;
            case 2: goto L_0x0020;
            case 3: goto L_0x0027;
            default: goto L_0x0018;
        };	 Catch:{ all -> 0x0024 }
    L_0x0018:
        monitor-exit(r1);	 Catch:{ all -> 0x0024 }
        return;
    L_0x001a:
        r3 = r1;
        goto L_0x0006;
    L_0x001c:
        r2 = r1;
        goto L_0x0009;
    L_0x001e:
        r0 = r1;
        goto L_0x000b;
    L_0x0020:
        r4.m9239e();	 Catch:{ all -> 0x0024 }
        goto L_0x0018;
    L_0x0024:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x0024 }
        throw r0;
    L_0x0027:
        r4.m9245a(r6);	 Catch:{ all -> 0x0024 }
        goto L_0x0018;
    L_0x002b:
        r4.m9240y();	 Catch:{ all -> 0x0024 }
        goto L_0x0018;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.common.internal.o.a(int, android.os.IInterface):void");
    }

    private boolean m9234a(int i, int i2, T t) {
        boolean z;
        synchronized (this.f5645n) {
            if (this.f5651t != i) {
                z = false;
            } else {
                m9232a(i2, (IInterface) t);
                z = true;
            }
        }
        return z;
    }

    private void m9239e() {
        if (this.f5650s != null) {
            String valueOf = String.valueOf(m9241a());
            String valueOf2 = String.valueOf(f_());
            Log.e("GmsClient", new StringBuilder((String.valueOf(valueOf).length() + 70) + String.valueOf(valueOf2).length()).append("Calling connect() while still connected, missing disconnect() for ").append(valueOf).append(" on ").append(valueOf2).toString());
            this.f5643l.m16215b(m9241a(), f_(), this.f5650s, m9262m());
            this.f5635c.incrementAndGet();
        }
        this.f5650s = new C3250h(this, this.f5635c.get());
        if (!this.f5643l.m16213a(m9241a(), f_(), this.f5650s, m9262m())) {
            valueOf = String.valueOf(m9241a());
            valueOf2 = String.valueOf(f_());
            Log.e("GmsClient", new StringBuilder((String.valueOf(valueOf).length() + 34) + String.valueOf(valueOf2).length()).append("unable to connect to service: ").append(valueOf).append(" on ").append(valueOf2).toString());
            m9243a(16, null, this.f5635c.get());
        }
    }

    private void m9240y() {
        if (this.f5650s != null) {
            this.f5643l.m16215b(m9241a(), f_(), this.f5650s, m9262m());
            this.f5650s = null;
        }
    }

    protected abstract String m9241a();

    protected void m9242a(int i) {
        this.f5636e = i;
        this.f5637f = System.currentTimeMillis();
    }

    protected void m9243a(int i, Bundle bundle, int i2) {
        this.f5633a.sendMessage(this.f5633a.obtainMessage(5, i2, -1, new C3253k(this, i, bundle)));
    }

    protected void m9244a(int i, IBinder iBinder, Bundle bundle, int i2) {
        this.f5633a.sendMessage(this.f5633a.obtainMessage(1, i2, -1, new C3252j(this, i, iBinder, bundle)));
    }

    protected void m9245a(T t) {
        this.f5638g = System.currentTimeMillis();
    }

    protected void m9246a(C3181a c3181a) {
        this.f5639h = c3181a.m15879c();
        this.f5640i = System.currentTimeMillis();
    }

    public void m9247a(aa aaVar, Set<Scope> set) {
        Throwable e;
        C3261s a = new C3261s(this.f5654w).m16129a(this.f5641j.getPackageName()).m16127a(m9268s());
        if (set != null) {
            a.m16130a((Collection) set);
        }
        if (m9259i()) {
            a.m16126a(m9267r()).m16128a(aaVar);
        } else if (m9272w()) {
            a.m16126a(m9265p());
        }
        a.m16131a(m9266q());
        try {
            synchronized (this.f5646o) {
                if (this.f5647p != null) {
                    this.f5647p.m16017a(new C3249g(this, this.f5635c.get()), a);
                } else {
                    Log.w("GmsClient", "mServiceBroker is null, client disconnected");
                }
            }
        } catch (Throwable e2) {
            Log.w("GmsClient", "IGmsServiceBroker.getService failed", e2);
            m9253b(1);
        } catch (SecurityException e3) {
            throw e3;
        } catch (RemoteException e4) {
            e2 = e4;
            Log.w("GmsClient", "IGmsServiceBroker.getService failed", e2);
            m9244a(8, null, null, this.f5635c.get());
        } catch (RuntimeException e5) {
            e2 = e5;
            Log.w("GmsClient", "IGmsServiceBroker.getService failed", e2);
            m9244a(8, null, null, this.f5635c.get());
        }
    }

    public void m9248a(C2930f c2930f) {
        this.f5634b = (C2930f) C3234c.m16043a((Object) c2930f, (Object) "Connection progress callbacks cannot be null.");
        m9232a(2, null);
    }

    public void m9249a(C2930f c2930f, int i, PendingIntent pendingIntent) {
        this.f5634b = (C2930f) C3234c.m16043a((Object) c2930f, (Object) "Connection progress callbacks cannot be null.");
        this.f5633a.sendMessage(this.f5633a.obtainMessage(3, this.f5635c.get(), i, pendingIntent));
    }

    public void m9250a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        synchronized (this.f5645n) {
            int i = this.f5651t;
            IInterface iInterface = this.f5648q;
        }
        synchronized (this.f5646o) {
            ae aeVar = this.f5647p;
        }
        printWriter.append(str).append("mConnectState=");
        switch (i) {
            case C5538a.ExpandableLayout_el_duration /*1*/:
                printWriter.print("DISCONNECTED");
                break;
            case C5538a.ExpandableLayout_el_expanded /*2*/:
                printWriter.print("CONNECTING");
                break;
            case C5538a.ExpandableLayout_layout_expandable /*3*/:
                printWriter.print("CONNECTED");
                break;
            case C5500d.ProperRatingBar_prb_clickable /*4*/:
                printWriter.print("DISCONNECTING");
                break;
            default:
                printWriter.print("UNKNOWN");
                break;
        }
        printWriter.append(" mService=");
        if (iInterface == null) {
            printWriter.append("null");
        } else {
            printWriter.append(m9252b()).append("@").append(Integer.toHexString(System.identityHashCode(iInterface.asBinder())));
        }
        printWriter.append(" mServiceBroker=");
        if (aeVar == null) {
            printWriter.println("null");
        } else {
            printWriter.append("IGmsServiceBroker@").println(Integer.toHexString(System.identityHashCode(aeVar.asBinder())));
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US);
        if (this.f5638g > 0) {
            PrintWriter append = printWriter.append(str).append("lastConnectedTime=");
            long j = this.f5638g;
            String valueOf = String.valueOf(simpleDateFormat.format(new Date(this.f5638g)));
            append.println(new StringBuilder(String.valueOf(valueOf).length() + 21).append(j).append(" ").append(valueOf).toString());
        }
        if (this.f5637f > 0) {
            printWriter.append(str).append("lastSuspendedCause=");
            switch (this.f5636e) {
                case C5538a.ExpandableLayout_el_duration /*1*/:
                    printWriter.append("CAUSE_SERVICE_DISCONNECTED");
                    break;
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    printWriter.append("CAUSE_NETWORK_LOST");
                    break;
                default:
                    printWriter.append(String.valueOf(this.f5636e));
                    break;
            }
            append = printWriter.append(" lastSuspendedTime=");
            j = this.f5637f;
            valueOf = String.valueOf(simpleDateFormat.format(new Date(this.f5637f)));
            append.println(new StringBuilder(String.valueOf(valueOf).length() + 21).append(j).append(" ").append(valueOf).toString());
        }
        if (this.f5640i > 0) {
            printWriter.append(str).append("lastFailedStatus=").append(C3189b.m15902a(this.f5639h));
            append = printWriter.append(" lastFailedTime=");
            j = this.f5640i;
            String valueOf2 = String.valueOf(simpleDateFormat.format(new Date(this.f5640i)));
            append.println(new StringBuilder(String.valueOf(valueOf2).length() + 21).append(j).append(" ").append(valueOf2).toString());
        }
    }

    protected abstract T m9251b(IBinder iBinder);

    protected abstract String m9252b();

    public void m9253b(int i) {
        this.f5633a.sendMessage(this.f5633a.obtainMessage(4, this.f5635c.get(), i));
    }

    public boolean m9254c() {
        return false;
    }

    public Intent m9255d() {
        throw new UnsupportedOperationException("Not a sign in API");
    }

    public void m9256f() {
        this.f5635c.incrementAndGet();
        synchronized (this.f5649r) {
            int size = this.f5649r.size();
            for (int i = 0; i < size; i++) {
                ((C3246e) this.f5649r.get(i)).m16083d();
            }
            this.f5649r.clear();
        }
        synchronized (this.f5646o) {
            this.f5647p = null;
        }
        m9232a(1, null);
    }

    protected String f_() {
        return GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE;
    }

    public boolean m9257g() {
        boolean z;
        synchronized (this.f5645n) {
            z = this.f5651t == 3;
        }
        return z;
    }

    public boolean m9258h() {
        boolean z;
        synchronized (this.f5645n) {
            z = this.f5651t == 2;
        }
        return z;
    }

    public boolean m9259i() {
        return false;
    }

    public boolean m9260j() {
        return true;
    }

    public IBinder m9261k() {
        IBinder iBinder;
        synchronized (this.f5646o) {
            if (this.f5647p == null) {
                iBinder = null;
            } else {
                iBinder = this.f5647p.asBinder();
            }
        }
        return iBinder;
    }

    protected final String m9262m() {
        return this.f5655x == null ? this.f5641j.getClass().getName() : this.f5655x;
    }

    public void m9263n() {
        int a = this.f5644m.m15933a(this.f5641j);
        if (a != 0) {
            m9232a(1, null);
            m9249a(new C3251i(this), a, null);
            return;
        }
        m9248a(new C3251i(this));
    }

    public final Context m9264o() {
        return this.f5641j;
    }

    public Account m9265p() {
        return null;
    }

    public C3276j[] m9266q() {
        return new C3276j[0];
    }

    public final Account m9267r() {
        return m9265p() != null ? m9265p() : new Account("<<default account>>", "com.google");
    }

    protected Bundle m9268s() {
        return new Bundle();
    }

    protected final void m9269t() {
        if (!m9257g()) {
            throw new IllegalStateException("Not connected. Call connect() and wait for onConnected() to be called.");
        }
    }

    public Bundle m9270u() {
        return null;
    }

    public final T m9271v() {
        T t;
        synchronized (this.f5645n) {
            if (this.f5651t == 4) {
                throw new DeadObjectException();
            }
            m9269t();
            C3234c.m16048a(this.f5648q != null, (Object) "Client is connected but service is null");
            t = this.f5648q;
        }
        return t;
    }

    public boolean m9272w() {
        return false;
    }

    protected Set<Scope> m9273x() {
        return Collections.EMPTY_SET;
    }
}
