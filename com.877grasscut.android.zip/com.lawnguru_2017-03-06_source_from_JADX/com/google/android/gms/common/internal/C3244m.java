package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.C2149a;

/* renamed from: com.google.android.gms.common.internal.m */
public class C3244m extends C2149a {
    public static final Creator<C3244m> CREATOR;
    final int f9852a;
    final IBinder f9853b;
    final Scope[] f9854c;
    Integer f9855d;
    Integer f9856e;

    static {
        CREATOR = new C3245n();
    }

    C3244m(int i, IBinder iBinder, Scope[] scopeArr, Integer num, Integer num2) {
        this.f9852a = i;
        this.f9853b = iBinder;
        this.f9854c = scopeArr;
        this.f9855d = num;
        this.f9856e = num2;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C3245n.m16077a(this, parcel, i);
    }
}
