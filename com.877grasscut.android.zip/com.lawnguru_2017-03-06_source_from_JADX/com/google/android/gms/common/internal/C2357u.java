package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.content.Context;
import android.os.Bundle;
import android.os.IInterface;
import android.os.Looper;
import com.google.android.gms.common.C3181a;
import com.google.android.gms.common.C3205c;
import com.google.android.gms.common.C3276j;
import com.google.android.gms.common.api.C2854c.C2420b;
import com.google.android.gms.common.api.C2854c.C2421c;
import com.google.android.gms.common.api.C3188a.C2355f;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.C2353o.C2477b;
import com.google.android.gms.common.internal.C2353o.C2478c;
import com.google.android.gms.common.internal.C3269v.C2356a;
import java.util.Set;

/* renamed from: com.google.android.gms.common.internal.u */
public abstract class C2357u<T extends IInterface> extends C2353o<T> implements C2355f, C2356a {
    private final C3255p f5656e;
    private final Set<Scope> f5657f;
    private final Account f5658g;

    /* renamed from: com.google.android.gms.common.internal.u.1 */
    class C32671 implements C2477b {
        final /* synthetic */ C2420b f9902a;

        C32671(C2420b c2420b) {
            this.f9902a = c2420b;
        }

        public void m16197a(int i) {
            this.f9902a.m9661a(i);
        }

        public void m16198a(Bundle bundle) {
            this.f9902a.m9662a(bundle);
        }
    }

    /* renamed from: com.google.android.gms.common.internal.u.2 */
    class C32682 implements C2478c {
        final /* synthetic */ C2421c f9903a;

        C32682(C2421c c2421c) {
            this.f9903a = c2421c;
        }

        public void m16199a(C3181a c3181a) {
            this.f9903a.m9663a(c3181a);
        }
    }

    protected C2357u(Context context, Looper looper, int i, C3255p c3255p, C2420b c2420b, C2421c c2421c) {
        this(context, looper, C3271w.m16211a(context), C3205c.m15944a(), i, c3255p, (C2420b) C3234c.m16042a((Object) c2420b), (C2421c) C3234c.m16042a((Object) c2421c));
    }

    protected C2357u(Context context, Looper looper, C3271w c3271w, C3205c c3205c, int i, C3255p c3255p, C2420b c2420b, C2421c c2421c) {
        super(context, looper, c3271w, c3205c, i, C2357u.m9287a(c2420b), C2357u.m9288a(c2421c), c3255p.m16107h());
        this.f5656e = c3255p;
        this.f5658g = c3255p.m16101b();
        this.f5657f = m9289b(c3255p.m16104e());
    }

    private static C2477b m9287a(C2420b c2420b) {
        return c2420b == null ? null : new C32671(c2420b);
    }

    private static C2478c m9288a(C2421c c2421c) {
        return c2421c == null ? null : new C32682(c2421c);
    }

    private Set<Scope> m9289b(Set<Scope> set) {
        Set<Scope> a = m9290a((Set) set);
        for (Scope contains : a) {
            if (!set.contains(contains)) {
                throw new IllegalStateException("Expanding scopes is not permitted, use implied scopes instead");
            }
        }
        return a;
    }

    protected Set<Scope> m9290a(Set<Scope> set) {
        return set;
    }

    public final Account m9291p() {
        return this.f5658g;
    }

    public C3276j[] m9292q() {
        return new C3276j[0];
    }

    protected final Set<Scope> m9293x() {
        return this.f5657f;
    }

    protected final C3255p m9294y() {
        return this.f5656e;
    }
}
