package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.C3204l;
import com.google.android.gms.common.C3276j;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.aa.C3219a;
import com.google.android.gms.common.internal.safeparcel.C2149a;
import java.util.Collection;

/* renamed from: com.google.android.gms.common.internal.s */
public class C3261s extends C2149a {
    public static final Creator<C3261s> CREATOR;
    final int f9893a;
    final int f9894b;
    int f9895c;
    String f9896d;
    IBinder f9897e;
    Scope[] f9898f;
    Bundle f9899g;
    Account f9900h;
    C3276j[] f9901i;

    static {
        CREATOR = new C3266t();
    }

    public C3261s(int i) {
        this.f9893a = 3;
        this.f9895c = C3204l.f9789b;
        this.f9894b = i;
    }

    C3261s(int i, int i2, int i3, String str, IBinder iBinder, Scope[] scopeArr, Bundle bundle, Account account, C3276j[] c3276jArr) {
        this.f9893a = i;
        this.f9894b = i2;
        this.f9895c = i3;
        if (GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE.equals(str)) {
            this.f9896d = GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE;
        } else {
            this.f9896d = str;
        }
        if (i < 2) {
            this.f9900h = m16125a(iBinder);
        } else {
            this.f9897e = iBinder;
            this.f9900h = account;
        }
        this.f9898f = scopeArr;
        this.f9899g = bundle;
        this.f9901i = c3276jArr;
    }

    private Account m16125a(IBinder iBinder) {
        return iBinder != null ? C3220a.m16006a(C3219a.m16005a(iBinder)) : null;
    }

    public C3261s m16126a(Account account) {
        this.f9900h = account;
        return this;
    }

    public C3261s m16127a(Bundle bundle) {
        this.f9899g = bundle;
        return this;
    }

    public C3261s m16128a(aa aaVar) {
        if (aaVar != null) {
            this.f9897e = aaVar.asBinder();
        }
        return this;
    }

    public C3261s m16129a(String str) {
        this.f9896d = str;
        return this;
    }

    public C3261s m16130a(Collection<Scope> collection) {
        this.f9898f = (Scope[]) collection.toArray(new Scope[collection.size()]);
        return this;
    }

    public C3261s m16131a(C3276j[] c3276jArr) {
        this.f9901i = c3276jArr;
        return this;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C3266t.m16194a(this, parcel, i);
    }
}
