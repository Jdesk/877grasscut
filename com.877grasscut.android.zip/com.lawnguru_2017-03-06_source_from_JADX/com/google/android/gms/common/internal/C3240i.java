package com.google.android.gms.common.internal;

import android.content.Context;
import android.content.res.Resources;
import com.google.android.gms.C2063a.C2044b;

/* renamed from: com.google.android.gms.common.internal.i */
public class C3240i {
    private final Resources f9849a;
    private final String f9850b;

    public C3240i(Context context) {
        C3234c.m16042a((Object) context);
        this.f9849a = context.getResources();
        this.f9850b = this.f9849a.getResourcePackageName(C2044b.common_google_play_services_unknown_issue);
    }

    public String m16072a(String str) {
        int identifier = this.f9849a.getIdentifier(str, "string", this.f9850b);
        return identifier == 0 ? null : this.f9849a.getString(identifier);
    }
}
