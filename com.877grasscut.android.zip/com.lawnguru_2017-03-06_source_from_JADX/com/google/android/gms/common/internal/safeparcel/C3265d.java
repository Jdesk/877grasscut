package com.google.android.gms.common.internal.safeparcel;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.C3234c;

/* renamed from: com.google.android.gms.common.internal.safeparcel.d */
public final class C3265d {
    public static <T extends SafeParcelable> T m16193a(byte[] bArr, Creator<T> creator) {
        C3234c.m16042a((Object) creator);
        Parcel obtain = Parcel.obtain();
        obtain.unmarshall(bArr, 0, bArr.length);
        obtain.setDataPosition(0);
        SafeParcelable safeParcelable = (SafeParcelable) creator.createFromParcel(obtain);
        obtain.recycle();
        return safeParcelable;
    }
}
