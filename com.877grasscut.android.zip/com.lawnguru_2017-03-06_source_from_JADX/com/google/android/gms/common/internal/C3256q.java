package com.google.android.gms.common.internal;

import android.content.Context;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Resources;
import android.support.v4.util.SimpleArrayMap;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.C2063a.C2044b;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.util.C3296f;
import com.google.android.gms.p095b.bn;
import com.zopim.android.sdk.api.C5264R;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.common.internal.q */
public final class C3256q {
    private static final SimpleArrayMap<String, String> f9883a;

    static {
        f9883a = new SimpleArrayMap();
    }

    public static String m16110a(Context context) {
        String str = context.getApplicationInfo().name;
        if (TextUtils.isEmpty(str)) {
            str = context.getPackageName();
            try {
                str = bn.m9791b(context).m9790b(context.getPackageName()).toString();
            } catch (NameNotFoundException e) {
            }
        }
        return str;
    }

    public static String m16111a(Context context, int i) {
        Resources resources = context.getResources();
        switch (i) {
            case C5538a.ExpandableLayout_el_duration /*1*/:
                return resources.getString(C2044b.common_google_play_services_install_title);
            case C5538a.ExpandableLayout_el_expanded /*2*/:
                return resources.getString(C2044b.common_google_play_services_update_title);
            case C5538a.ExpandableLayout_layout_expandable /*3*/:
                return resources.getString(C2044b.common_google_play_services_enable_title);
            case C5500d.ProperRatingBar_prb_clickable /*4*/:
            case C5500d.ProperRatingBar_prb_symbolicTickNormalColor /*6*/:
            case C5264R.styleable.Toolbar_titleMarginBottom /*18*/:
                return null;
            case C5500d.ProperRatingBar_prb_symbolicTick /*5*/:
                Log.e("GoogleApiAvailability", "An invalid account was specified when connecting. Please provide a valid account.");
                return C3256q.m16112a(context, "common_google_play_services_invalid_account_title");
            case C5500d.ProperRatingBar_prb_symbolicTickSelectedColor /*7*/:
                Log.e("GoogleApiAvailability", "Network error occurred. Please retry request later.");
                return C3256q.m16112a(context, "common_google_play_services_network_error_title");
            case C5500d.ProperRatingBar_prb_tickNormalDrawable /*8*/:
                Log.e("GoogleApiAvailability", "Internal error occurred. Please see logs for detailed information");
                return null;
            case C5500d.ProperRatingBar_prb_tickSelectedDrawable /*9*/:
                Log.e("GoogleApiAvailability", "Google Play services is invalid. Cannot recover.");
                return null;
            case C5500d.ProperRatingBar_prb_tickSpacing /*10*/:
                Log.e("GoogleApiAvailability", "Developer error occurred. Please see logs for detailed information");
                return null;
            case C5264R.styleable.Toolbar_popupTheme /*11*/:
                Log.e("GoogleApiAvailability", "The application is not licensed to the user.");
                return null;
            case C5264R.styleable.Toolbar_titleMarginEnd /*16*/:
                Log.e("GoogleApiAvailability", "One of the API components you attempted to connect to is not available.");
                return null;
            case C5264R.styleable.Toolbar_titleMarginTop /*17*/:
                Log.e("GoogleApiAvailability", "The specified account could not be signed in.");
                return C3256q.m16112a(context, "common_google_play_services_sign_in_failed_title");
            case C5264R.styleable.Toolbar_maxButtonHeight /*20*/:
                Log.e("GoogleApiAvailability", "The current user profile is restricted and could not use authenticated features.");
                return C3256q.m16112a(context, "common_google_play_services_restricted_profile_title");
            default:
                Log.e("GoogleApiAvailability", "Unexpected error code " + i);
                return null;
        }
    }

    private static String m16112a(Context context, String str) {
        synchronized (f9883a) {
            String str2 = (String) f9883a.get(str);
            if (str2 != null) {
                return str2;
            }
            Resources remoteResource = GooglePlayServicesUtil.getRemoteResource(context);
            if (remoteResource == null) {
                return null;
            }
            int identifier = remoteResource.getIdentifier(str, "string", GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE);
            if (identifier == 0) {
                String str3 = "GoogleApiAvailability";
                String str4 = "Missing resource: ";
                str2 = String.valueOf(str);
                Log.w(str3, str2.length() != 0 ? str4.concat(str2) : new String(str4));
                return null;
            }
            Object string = remoteResource.getString(identifier);
            if (TextUtils.isEmpty(string)) {
                str3 = "GoogleApiAvailability";
                str4 = "Got empty resource: ";
                str2 = String.valueOf(str);
                Log.w(str3, str2.length() != 0 ? str4.concat(str2) : new String(str4));
                return null;
            }
            f9883a.put(str, string);
            return string;
        }
    }

    private static String m16113a(Context context, String str, String str2) {
        Resources resources = context.getResources();
        String a = C3256q.m16112a(context, str);
        if (a == null) {
            a = resources.getString(C2044b.common_google_play_services_unknown_issue);
        }
        return String.format(resources.getConfiguration().locale, a, new Object[]{str2});
    }

    public static String m16114b(Context context, int i) {
        String a = i == 6 ? C3256q.m16112a(context, "common_google_play_services_resolution_required_title") : C3256q.m16111a(context, i);
        return a == null ? context.getResources().getString(C2044b.common_google_play_services_notification_ticker) : a;
    }

    public static String m16115c(Context context, int i) {
        Resources resources = context.getResources();
        String a = C3256q.m16110a(context);
        switch (i) {
            case C5538a.ExpandableLayout_el_duration /*1*/:
                return resources.getString(C2044b.common_google_play_services_install_text, new Object[]{a});
            case C5538a.ExpandableLayout_el_expanded /*2*/:
                if (C3296f.m16322b(context)) {
                    return resources.getString(C2044b.common_google_play_services_wear_update_text);
                }
                return resources.getString(C2044b.common_google_play_services_update_text, new Object[]{a});
            case C5538a.ExpandableLayout_layout_expandable /*3*/:
                return resources.getString(C2044b.common_google_play_services_enable_text, new Object[]{a});
            case C5500d.ProperRatingBar_prb_symbolicTick /*5*/:
                return C3256q.m16113a(context, "common_google_play_services_invalid_account_text", a);
            case C5500d.ProperRatingBar_prb_symbolicTickSelectedColor /*7*/:
                return C3256q.m16113a(context, "common_google_play_services_network_error_text", a);
            case C5500d.ProperRatingBar_prb_tickSelectedDrawable /*9*/:
                return resources.getString(C2044b.common_google_play_services_unsupported_text, new Object[]{a});
            case C5264R.styleable.Toolbar_titleMarginEnd /*16*/:
                return C3256q.m16113a(context, "common_google_play_services_api_unavailable_text", a);
            case C5264R.styleable.Toolbar_titleMarginTop /*17*/:
                return C3256q.m16113a(context, "common_google_play_services_sign_in_failed_text", a);
            case C5264R.styleable.Toolbar_titleMarginBottom /*18*/:
                return resources.getString(C2044b.common_google_play_services_updating_text, new Object[]{a});
            case C5264R.styleable.Toolbar_maxButtonHeight /*20*/:
                return C3256q.m16113a(context, "common_google_play_services_restricted_profile_text", a);
            default:
                return resources.getString(C2044b.common_google_play_services_unknown_issue, new Object[]{a});
        }
    }

    public static String m16116d(Context context, int i) {
        return i == 6 ? C3256q.m16113a(context, "common_google_play_services_resolution_required_text", C3256q.m16110a(context)) : C3256q.m16115c(context, i);
    }

    public static String m16117e(Context context, int i) {
        Resources resources = context.getResources();
        switch (i) {
            case C5538a.ExpandableLayout_el_duration /*1*/:
                return resources.getString(C2044b.common_google_play_services_install_button);
            case C5538a.ExpandableLayout_el_expanded /*2*/:
                return resources.getString(C2044b.common_google_play_services_update_button);
            case C5538a.ExpandableLayout_layout_expandable /*3*/:
                return resources.getString(C2044b.common_google_play_services_enable_button);
            default:
                return resources.getString(17039370);
        }
    }
}
