package com.google.android.gms.common.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C2149a;

@Deprecated
/* renamed from: com.google.android.gms.common.internal.j */
public class C3241j extends C2149a {
    public static final Creator<C3241j> CREATOR;
    final int f9851a;

    static {
        CREATOR = new C3242k();
    }

    C3241j(int i) {
        this.f9851a = i;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C3242k.m16073a(this, parcel, i);
    }
}
