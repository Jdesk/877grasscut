package com.google.android.gms.common.internal;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.support.v4.app.Fragment;
import android.util.Log;
import com.google.android.gms.p095b.ag;

/* renamed from: com.google.android.gms.common.internal.r */
public abstract class C3257r implements OnClickListener {

    /* renamed from: com.google.android.gms.common.internal.r.1 */
    class C32581 extends C3257r {
        final /* synthetic */ Intent f9884a;
        final /* synthetic */ Activity f9885b;
        final /* synthetic */ int f9886c;

        C32581(Intent intent, Activity activity, int i) {
            this.f9884a = intent;
            this.f9885b = activity;
            this.f9886c = i;
        }

        public void m16122a() {
            if (this.f9884a != null) {
                this.f9885b.startActivityForResult(this.f9884a, this.f9886c);
            }
        }
    }

    /* renamed from: com.google.android.gms.common.internal.r.2 */
    class C32592 extends C3257r {
        final /* synthetic */ Intent f9887a;
        final /* synthetic */ Fragment f9888b;
        final /* synthetic */ int f9889c;

        C32592(Intent intent, Fragment fragment, int i) {
            this.f9887a = intent;
            this.f9888b = fragment;
            this.f9889c = i;
        }

        public void m16123a() {
            if (this.f9887a != null) {
                this.f9888b.startActivityForResult(this.f9887a, this.f9889c);
            }
        }
    }

    /* renamed from: com.google.android.gms.common.internal.r.3 */
    class C32603 extends C3257r {
        final /* synthetic */ Intent f9890a;
        final /* synthetic */ ag f9891b;
        final /* synthetic */ int f9892c;

        C32603(Intent intent, ag agVar, int i) {
            this.f9890a = intent;
            this.f9891b = agVar;
            this.f9892c = i;
        }

        public void m16124a() {
            if (this.f9890a != null) {
                this.f9891b.startActivityForResult(this.f9890a, this.f9892c);
            }
        }
    }

    public static C3257r m16118a(Activity activity, Intent intent, int i) {
        return new C32581(intent, activity, i);
    }

    public static C3257r m16119a(Fragment fragment, Intent intent, int i) {
        return new C32592(intent, fragment, i);
    }

    public static C3257r m16120a(ag agVar, Intent intent, int i) {
        return new C32603(intent, agVar, i);
    }

    protected abstract void m16121a();

    public void onClick(DialogInterface dialogInterface, int i) {
        try {
            m16121a();
        } catch (Throwable e) {
            Log.e("DialogRedirect", "Failed to start resolution intent", e);
        } finally {
            dialogInterface.dismiss();
        }
    }
}
