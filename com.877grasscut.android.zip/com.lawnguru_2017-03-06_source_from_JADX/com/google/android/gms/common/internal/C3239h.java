package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.IInterface;
import com.google.android.gms.common.api.C3188a.C3185h;

/* renamed from: com.google.android.gms.common.internal.h */
public class C3239h<T extends IInterface> extends C2357u<T> {
    private final C3185h<T> f9848e;

    protected String m16068a() {
        return this.f9848e.m15896a();
    }

    protected T m16069b(IBinder iBinder) {
        return this.f9848e.m15895a(iBinder);
    }

    protected String m16070b() {
        return this.f9848e.m15897b();
    }

    public C3185h<T> m16071e() {
        return this.f9848e;
    }
}
