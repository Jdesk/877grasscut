package com.google.android.gms.common.internal.safeparcel;

/* renamed from: com.google.android.gms.common.internal.safeparcel.a */
public abstract class C2149a implements SafeParcelable {
    public final int describeContents() {
        return 0;
    }
}
