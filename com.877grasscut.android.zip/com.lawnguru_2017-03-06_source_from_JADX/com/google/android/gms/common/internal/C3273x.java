package com.google.android.gms.common.internal;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.common.internal.C3271w.C3270a;
import com.google.android.gms.common.stats.C3286a;
import com.stripe.android.model.Card;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.common.internal.x */
final class C3273x extends C3271w implements Callback {
    private final HashMap<C3270a, C3272a> f9925a;
    private final Context f9926b;
    private final Handler f9927c;
    private final C3286a f9928d;
    private final long f9929e;
    private final long f9930f;

    /* renamed from: com.google.android.gms.common.internal.x.a */
    private final class C3272a implements ServiceConnection {
        final /* synthetic */ C3273x f9918a;
        private final Set<ServiceConnection> f9919b;
        private int f9920c;
        private boolean f9921d;
        private IBinder f9922e;
        private final C3270a f9923f;
        private ComponentName f9924g;

        public C3272a(C3273x c3273x, C3270a c3270a) {
            this.f9918a = c3273x;
            this.f9923f = c3270a;
            this.f9919b = new HashSet();
            this.f9920c = 2;
        }

        public void m16216a(ServiceConnection serviceConnection, String str) {
            this.f9918a.f9928d.m16285a(this.f9918a.f9926b, serviceConnection, str, this.f9923f.m16210c());
            this.f9919b.add(serviceConnection);
        }

        public void m16217a(String str) {
            this.f9920c = 3;
            this.f9921d = this.f9918a.f9928d.m16287a(this.f9918a.f9926b, str, this.f9923f.m16210c(), this, 129);
            if (this.f9921d) {
                this.f9918a.f9927c.sendMessageDelayed(this.f9918a.f9927c.obtainMessage(1, this.f9923f), this.f9918a.f9930f);
                return;
            }
            this.f9920c = 2;
            try {
                this.f9918a.f9928d.m16284a(this.f9918a.f9926b, (ServiceConnection) this);
            } catch (IllegalArgumentException e) {
            }
        }

        public boolean m16218a() {
            return this.f9921d;
        }

        public boolean m16219a(ServiceConnection serviceConnection) {
            return this.f9919b.contains(serviceConnection);
        }

        public int m16220b() {
            return this.f9920c;
        }

        public void m16221b(ServiceConnection serviceConnection, String str) {
            this.f9918a.f9928d.m16288b(this.f9918a.f9926b, serviceConnection);
            this.f9919b.remove(serviceConnection);
        }

        public void m16222b(String str) {
            this.f9918a.f9927c.removeMessages(1, this.f9923f);
            this.f9918a.f9928d.m16284a(this.f9918a.f9926b, (ServiceConnection) this);
            this.f9921d = false;
            this.f9920c = 2;
        }

        public boolean m16223c() {
            return this.f9919b.isEmpty();
        }

        public IBinder m16224d() {
            return this.f9922e;
        }

        public ComponentName m16225e() {
            return this.f9924g;
        }

        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            synchronized (this.f9918a.f9925a) {
                this.f9918a.f9927c.removeMessages(1, this.f9923f);
                this.f9922e = iBinder;
                this.f9924g = componentName;
                for (ServiceConnection onServiceConnected : this.f9919b) {
                    onServiceConnected.onServiceConnected(componentName, iBinder);
                }
                this.f9920c = 1;
            }
        }

        public void onServiceDisconnected(ComponentName componentName) {
            synchronized (this.f9918a.f9925a) {
                this.f9918a.f9927c.removeMessages(1, this.f9923f);
                this.f9922e = null;
                this.f9924g = componentName;
                for (ServiceConnection onServiceDisconnected : this.f9919b) {
                    onServiceDisconnected.onServiceDisconnected(componentName);
                }
                this.f9920c = 2;
            }
        }
    }

    C3273x(Context context) {
        this.f9925a = new HashMap();
        this.f9926b = context.getApplicationContext();
        this.f9927c = new Handler(context.getMainLooper(), this);
        this.f9928d = C3286a.m16282a();
        this.f9929e = 5000;
        this.f9930f = 300000;
    }

    protected boolean m16231a(C3270a c3270a, ServiceConnection serviceConnection, String str) {
        boolean a;
        C3234c.m16043a((Object) serviceConnection, (Object) "ServiceConnection must not be null");
        synchronized (this.f9925a) {
            C3272a c3272a = (C3272a) this.f9925a.get(c3270a);
            if (c3272a != null) {
                this.f9927c.removeMessages(0, c3270a);
                if (!c3272a.m16219a(serviceConnection)) {
                    c3272a.m16216a(serviceConnection, str);
                    switch (c3272a.m16220b()) {
                        case C5538a.ExpandableLayout_el_duration /*1*/:
                            serviceConnection.onServiceConnected(c3272a.m16225e(), c3272a.m16224d());
                            break;
                        case C5538a.ExpandableLayout_el_expanded /*2*/:
                            c3272a.m16217a(str);
                            break;
                        default:
                            break;
                    }
                }
                String valueOf = String.valueOf(c3270a);
                throw new IllegalStateException(new StringBuilder(String.valueOf(valueOf).length() + 81).append("Trying to bind a GmsServiceConnection that was already connected before.  config=").append(valueOf).toString());
            }
            c3272a = new C3272a(this, c3270a);
            c3272a.m16216a(serviceConnection, str);
            c3272a.m16217a(str);
            this.f9925a.put(c3270a, c3272a);
            a = c3272a.m16218a();
        }
        return a;
    }

    protected void m16232b(C3270a c3270a, ServiceConnection serviceConnection, String str) {
        C3234c.m16043a((Object) serviceConnection, (Object) "ServiceConnection must not be null");
        synchronized (this.f9925a) {
            C3272a c3272a = (C3272a) this.f9925a.get(c3270a);
            String valueOf;
            if (c3272a == null) {
                valueOf = String.valueOf(c3270a);
                throw new IllegalStateException(new StringBuilder(String.valueOf(valueOf).length() + 50).append("Nonexistent connection status for service config: ").append(valueOf).toString());
            } else if (c3272a.m16219a(serviceConnection)) {
                c3272a.m16221b(serviceConnection, str);
                if (c3272a.m16223c()) {
                    this.f9927c.sendMessageDelayed(this.f9927c.obtainMessage(0, c3270a), this.f9929e);
                }
            } else {
                valueOf = String.valueOf(c3270a);
                throw new IllegalStateException(new StringBuilder(String.valueOf(valueOf).length() + 76).append("Trying to unbind a GmsServiceConnection  that was not bound before.  config=").append(valueOf).toString());
            }
        }
    }

    public boolean handleMessage(Message message) {
        C3270a c3270a;
        C3272a c3272a;
        switch (message.what) {
            case C5538a.ExpandableLayout_android_orientation /*0*/:
                synchronized (this.f9925a) {
                    c3270a = (C3270a) message.obj;
                    c3272a = (C3272a) this.f9925a.get(c3270a);
                    if (c3272a != null && c3272a.m16223c()) {
                        if (c3272a.m16218a()) {
                            c3272a.m16222b("GmsClientSupervisor");
                        }
                        this.f9925a.remove(c3270a);
                    }
                    break;
                }
                return true;
            case C5538a.ExpandableLayout_el_duration /*1*/:
                synchronized (this.f9925a) {
                    c3270a = (C3270a) message.obj;
                    c3272a = (C3272a) this.f9925a.get(c3270a);
                    if (c3272a != null && c3272a.m16220b() == 3) {
                        String valueOf = String.valueOf(c3270a);
                        Log.wtf("GmsClientSupervisor", new StringBuilder(String.valueOf(valueOf).length() + 47).append("Timeout waiting for ServiceConnection callback ").append(valueOf).toString(), new Exception());
                        ComponentName e = c3272a.m16225e();
                        if (e == null) {
                            e = c3270a.m16209b();
                        }
                        c3272a.onServiceDisconnected(e == null ? new ComponentName(c3270a.m16208a(), Card.FUNDING_UNKNOWN) : e);
                    }
                    break;
                }
                return true;
            default:
                return false;
        }
    }
}
