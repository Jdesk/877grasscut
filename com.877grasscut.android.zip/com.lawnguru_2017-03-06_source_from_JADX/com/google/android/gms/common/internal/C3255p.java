package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.view.View;
import com.google.android.gms.common.api.C3188a;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.p095b.fu;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/* renamed from: com.google.android.gms.common.internal.p */
public final class C3255p {
    private final Account f9873a;
    private final Set<Scope> f9874b;
    private final Set<Scope> f9875c;
    private final Map<C3188a<?>, C3254a> f9876d;
    private final int f9877e;
    private final View f9878f;
    private final String f9879g;
    private final String f9880h;
    private final fu f9881i;
    private Integer f9882j;

    /* renamed from: com.google.android.gms.common.internal.p.a */
    public static final class C3254a {
        public final Set<Scope> f9872a;
    }

    public C3255p(Account account, Set<Scope> set, Map<C3188a<?>, C3254a> map, int i, View view, String str, String str2, fu fuVar) {
        Map map2;
        this.f9873a = account;
        this.f9874b = set == null ? Collections.EMPTY_SET : Collections.unmodifiableSet(set);
        if (map == null) {
            map2 = Collections.EMPTY_MAP;
        }
        this.f9876d = map2;
        this.f9878f = view;
        this.f9877e = i;
        this.f9879g = str;
        this.f9880h = str2;
        this.f9881i = fuVar;
        Set hashSet = new HashSet(this.f9874b);
        for (C3254a c3254a : this.f9876d.values()) {
            hashSet.addAll(c3254a.f9872a);
        }
        this.f9875c = Collections.unmodifiableSet(hashSet);
    }

    @Deprecated
    public String m16098a() {
        return this.f9873a != null ? this.f9873a.name : null;
    }

    public Set<Scope> m16099a(C3188a<?> c3188a) {
        C3254a c3254a = (C3254a) this.f9876d.get(c3188a);
        if (c3254a == null || c3254a.f9872a.isEmpty()) {
            return this.f9874b;
        }
        Set<Scope> hashSet = new HashSet(this.f9874b);
        hashSet.addAll(c3254a.f9872a);
        return hashSet;
    }

    public void m16100a(Integer num) {
        this.f9882j = num;
    }

    public Account m16101b() {
        return this.f9873a;
    }

    public Account m16102c() {
        return this.f9873a != null ? this.f9873a : new Account("<<default account>>", "com.google");
    }

    public Set<Scope> m16103d() {
        return this.f9874b;
    }

    public Set<Scope> m16104e() {
        return this.f9875c;
    }

    public Map<C3188a<?>, C3254a> m16105f() {
        return this.f9876d;
    }

    public String m16106g() {
        return this.f9879g;
    }

    public String m16107h() {
        return this.f9880h;
    }

    public fu m16108i() {
        return this.f9881i;
    }

    public Integer m16109j() {
        return this.f9882j;
    }
}
