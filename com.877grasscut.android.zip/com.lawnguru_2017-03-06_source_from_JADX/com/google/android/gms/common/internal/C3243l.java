package com.google.android.gms.common.internal;

/* renamed from: com.google.android.gms.common.internal.l */
public final class C3243l {
    public static void m16076a(Object obj) {
        if (obj == null) {
            throw new IllegalArgumentException("null reference");
        }
    }
}
