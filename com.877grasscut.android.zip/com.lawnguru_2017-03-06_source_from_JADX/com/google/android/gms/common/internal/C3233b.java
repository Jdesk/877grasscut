package com.google.android.gms.common.internal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/* renamed from: com.google.android.gms.common.internal.b */
public final class C3233b {

    /* renamed from: com.google.android.gms.common.internal.b.a */
    public static final class C3232a {
        private final List<String> f9837a;
        private final Object f9838b;

        private C3232a(Object obj) {
            this.f9838b = C3234c.m16042a(obj);
            this.f9837a = new ArrayList();
        }

        public C3232a m16037a(String str, Object obj) {
            List list = this.f9837a;
            String str2 = (String) C3234c.m16042a((Object) str);
            String valueOf = String.valueOf(String.valueOf(obj));
            list.add(new StringBuilder((String.valueOf(str2).length() + 1) + String.valueOf(valueOf).length()).append(str2).append("=").append(valueOf).toString());
            return this;
        }

        public String toString() {
            StringBuilder append = new StringBuilder(100).append(this.f9838b.getClass().getSimpleName()).append('{');
            int size = this.f9837a.size();
            for (int i = 0; i < size; i++) {
                append.append((String) this.f9837a.get(i));
                if (i < size - 1) {
                    append.append(", ");
                }
            }
            return append.append('}').toString();
        }
    }

    public static int m16038a(Object... objArr) {
        return Arrays.hashCode(objArr);
    }

    public static C3232a m16039a(Object obj) {
        return new C3232a(null);
    }

    public static boolean m16040a(Object obj, Object obj2) {
        return obj == obj2 || (obj != null && obj.equals(obj2));
    }
}
