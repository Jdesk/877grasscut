package com.google.android.gms.common.data;

import android.database.CursorWindow;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.common.data.g */
public class C3213g implements Creator<DataHolder> {
    static void m15996a(DataHolder dataHolder, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16184a(parcel, 1, dataHolder.m15981b(), false);
        C3264c.m16183a(parcel, 2, dataHolder.m15983c(), i, false);
        C3264c.m16168a(parcel, 3, dataHolder.m15984d());
        C3264c.m16170a(parcel, 4, dataHolder.m15985e(), false);
        C3264c.m16168a(parcel, 1000, dataHolder.f9806a);
        C3264c.m16164a(parcel, a);
    }

    public DataHolder m15997a(Parcel parcel) {
        int i = 0;
        Bundle bundle = null;
        int b = C3263b.m16139b(parcel);
        CursorWindow[] cursorWindowArr = null;
        String[] strArr = null;
        int i2 = 0;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_duration /*1*/:
                    strArr = C3263b.m16160t(parcel, a);
                    break;
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    cursorWindowArr = (CursorWindow[]) C3263b.m16141b(parcel, a, CursorWindow.CREATOR);
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    i = C3263b.m16146f(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    bundle = C3263b.m16156p(parcel, a);
                    break;
                case 1000:
                    i2 = C3263b.m16146f(parcel, a);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() != b) {
            throw new C3262a("Overread allowed size end=" + b, parcel);
        }
        DataHolder dataHolder = new DataHolder(i2, strArr, cursorWindowArr, i, bundle);
        dataHolder.m15978a();
        return dataHolder;
    }

    public DataHolder[] m15998a(int i) {
        return new DataHolder[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m15997a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m15998a(i);
    }
}
