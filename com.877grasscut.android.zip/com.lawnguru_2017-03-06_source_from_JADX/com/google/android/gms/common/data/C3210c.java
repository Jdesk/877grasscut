package com.google.android.gms.common.data;

import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.common.data.c */
public class C3210c implements Creator<BitmapTeleporter> {
    static void m15988a(BitmapTeleporter bitmapTeleporter, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16168a(parcel, 1, bitmapTeleporter.f9793a);
        C3264c.m16172a(parcel, 2, bitmapTeleporter.f9794b, i, false);
        C3264c.m16168a(parcel, 3, bitmapTeleporter.f9795c);
        C3264c.m16164a(parcel, a);
    }

    public BitmapTeleporter m15989a(Parcel parcel) {
        int i = 0;
        int b = C3263b.m16139b(parcel);
        ParcelFileDescriptor parcelFileDescriptor = null;
        int i2 = 0;
        while (parcel.dataPosition() < b) {
            ParcelFileDescriptor parcelFileDescriptor2;
            int f;
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_duration /*1*/:
                    int i3 = i;
                    parcelFileDescriptor2 = parcelFileDescriptor;
                    f = C3263b.m16146f(parcel, a);
                    a = i3;
                    break;
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    f = i2;
                    ParcelFileDescriptor parcelFileDescriptor3 = (ParcelFileDescriptor) C3263b.m16135a(parcel, a, ParcelFileDescriptor.CREATOR);
                    a = i;
                    parcelFileDescriptor2 = parcelFileDescriptor3;
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    a = C3263b.m16146f(parcel, a);
                    parcelFileDescriptor2 = parcelFileDescriptor;
                    f = i2;
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    a = i;
                    parcelFileDescriptor2 = parcelFileDescriptor;
                    f = i2;
                    break;
            }
            i2 = f;
            parcelFileDescriptor = parcelFileDescriptor2;
            i = a;
        }
        if (parcel.dataPosition() == b) {
            return new BitmapTeleporter(i2, parcelFileDescriptor, i);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public BitmapTeleporter[] m15990a(int i) {
        return new BitmapTeleporter[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m15989a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m15990a(i);
    }
}
