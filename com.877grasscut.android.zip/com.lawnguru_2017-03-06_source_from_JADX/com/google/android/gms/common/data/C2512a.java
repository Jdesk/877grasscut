package com.google.android.gms.common.data;

import java.util.Iterator;

/* renamed from: com.google.android.gms.common.data.a */
public abstract class C2512a<T> implements C2511b<T> {
    protected final DataHolder f6198a;

    protected C2512a(DataHolder dataHolder) {
        this.f6198a = dataHolder;
    }

    public int m10154b() {
        return this.f6198a == null ? 0 : this.f6198a.m15986f();
    }

    public void e_() {
        if (this.f6198a != null) {
            this.f6198a.close();
        }
    }

    public Iterator<T> iterator() {
        return new C3211d(this);
    }
}
