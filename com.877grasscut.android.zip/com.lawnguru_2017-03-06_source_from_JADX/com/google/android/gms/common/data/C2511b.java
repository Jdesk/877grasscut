package com.google.android.gms.common.data;

import com.google.android.gms.common.api.C2510f;

/* renamed from: com.google.android.gms.common.data.b */
public interface C2511b<T> extends C2510f, Iterable<T> {
    T m10152a(int i);

    int m10153b();
}
