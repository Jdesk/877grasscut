package com.google.android.gms.common.data;

import com.google.android.gms.common.internal.C3234c;
import java.util.Iterator;
import java.util.NoSuchElementException;

/* renamed from: com.google.android.gms.common.data.d */
public class C3211d<T> implements Iterator<T> {
    protected final C2511b<T> f9816a;
    protected int f9817b;

    public C3211d(C2511b<T> c2511b) {
        this.f9816a = (C2511b) C3234c.m16042a((Object) c2511b);
        this.f9817b = -1;
    }

    public boolean hasNext() {
        return this.f9817b < this.f9816a.m10153b() + -1;
    }

    public T next() {
        if (hasNext()) {
            C2511b c2511b = this.f9816a;
            int i = this.f9817b + 1;
            this.f9817b = i;
            return c2511b.m10152a(i);
        }
        throw new NoSuchElementException("Cannot advance the iterator beyond " + this.f9817b);
    }

    public void remove() {
        throw new UnsupportedOperationException("Cannot remove elements from a DataBufferIterator");
    }
}
