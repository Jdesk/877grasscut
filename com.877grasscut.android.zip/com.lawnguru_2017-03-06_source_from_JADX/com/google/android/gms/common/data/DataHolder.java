package com.google.android.gms.common.data;

import android.database.CursorIndexOutOfBoundsException;
import android.database.CursorWindow;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.util.Log;
import com.google.android.gms.common.annotation.KeepName;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.common.internal.safeparcel.C2149a;
import java.io.Closeable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@KeepName
public final class DataHolder extends C2149a implements Closeable {
    public static final Creator<DataHolder> CREATOR;
    private static final C3207a f9805k;
    final int f9806a;
    Bundle f9807b;
    int[] f9808c;
    int f9809d;
    boolean f9810e;
    private final String[] f9811f;
    private final CursorWindow[] f9812g;
    private final int f9813h;
    private final Bundle f9814i;
    private boolean f9815j;

    /* renamed from: com.google.android.gms.common.data.DataHolder.a */
    public static class C3207a {
        private final String[] f9799a;
        private final ArrayList<HashMap<String, Object>> f9800b;
        private final String f9801c;
        private final HashMap<Object, Integer> f9802d;
        private boolean f9803e;
        private String f9804f;

        private C3207a(String[] strArr, String str) {
            this.f9799a = (String[]) C3234c.m16042a((Object) strArr);
            this.f9800b = new ArrayList();
            this.f9801c = str;
            this.f9802d = new HashMap();
            this.f9803e = false;
            this.f9804f = null;
        }
    }

    /* renamed from: com.google.android.gms.common.data.DataHolder.1 */
    class C32081 extends C3207a {
        C32081(String[] strArr, String str) {
            super(str, null);
        }
    }

    /* renamed from: com.google.android.gms.common.data.DataHolder.b */
    public static class C3209b extends RuntimeException {
        public C3209b(String str) {
            super(str);
        }
    }

    static {
        CREATOR = new C3213g();
        f9805k = new C32081(new String[0], null);
    }

    DataHolder(int i, String[] strArr, CursorWindow[] cursorWindowArr, int i2, Bundle bundle) {
        this.f9810e = false;
        this.f9815j = true;
        this.f9806a = i;
        this.f9811f = strArr;
        this.f9812g = cursorWindowArr;
        this.f9813h = i2;
        this.f9814i = bundle;
    }

    private DataHolder(C3207a c3207a, int i, Bundle bundle) {
        this(c3207a.f9799a, m15974a(c3207a, -1), i, bundle);
    }

    public DataHolder(String[] strArr, CursorWindow[] cursorWindowArr, int i, Bundle bundle) {
        this.f9810e = false;
        this.f9815j = true;
        this.f9806a = 1;
        this.f9811f = (String[]) C3234c.m16042a((Object) strArr);
        this.f9812g = (CursorWindow[]) C3234c.m16042a((Object) cursorWindowArr);
        this.f9813h = i;
        this.f9814i = bundle;
        m15978a();
    }

    public static DataHolder m15972a(int i, Bundle bundle) {
        return new DataHolder(f9805k, i, bundle);
    }

    private void m15973a(String str, int i) {
        if (this.f9807b == null || !this.f9807b.containsKey(str)) {
            String str2 = "No such column: ";
            String valueOf = String.valueOf(str);
            throw new IllegalArgumentException(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
        } else if (m15987g()) {
            throw new IllegalArgumentException("Buffer is closed.");
        } else if (i < 0 || i >= this.f9809d) {
            throw new CursorIndexOutOfBoundsException(i, this.f9809d);
        }
    }

    private static CursorWindow[] m15974a(C3207a c3207a, int i) {
        int i2 = 0;
        if (c3207a.f9799a.length == 0) {
            return new CursorWindow[0];
        }
        List b = (i < 0 || i >= c3207a.f9800b.size()) ? c3207a.f9800b : c3207a.f9800b.subList(0, i);
        int size = b.size();
        CursorWindow cursorWindow = new CursorWindow(false);
        ArrayList arrayList = new ArrayList();
        arrayList.add(cursorWindow);
        cursorWindow.setNumColumns(c3207a.f9799a.length);
        int i3 = 0;
        int i4 = 0;
        while (i3 < size) {
            try {
                int i5;
                int i6;
                CursorWindow cursorWindow2;
                if (!cursorWindow.allocRow()) {
                    Log.d("DataHolder", "Allocating additional cursor window for large data set (row " + i3 + ")");
                    cursorWindow = new CursorWindow(false);
                    cursorWindow.setStartPosition(i3);
                    cursorWindow.setNumColumns(c3207a.f9799a.length);
                    arrayList.add(cursorWindow);
                    if (!cursorWindow.allocRow()) {
                        Log.e("DataHolder", "Unable to allocate row to hold data.");
                        arrayList.remove(cursorWindow);
                        return (CursorWindow[]) arrayList.toArray(new CursorWindow[arrayList.size()]);
                    }
                }
                Map map = (Map) b.get(i3);
                boolean z = true;
                for (int i7 = 0; i7 < c3207a.f9799a.length && z; i7++) {
                    String str = c3207a.f9799a[i7];
                    Object obj = map.get(str);
                    if (obj == null) {
                        z = cursorWindow.putNull(i3, i7);
                    } else if (obj instanceof String) {
                        z = cursorWindow.putString((String) obj, i3, i7);
                    } else if (obj instanceof Long) {
                        z = cursorWindow.putLong(((Long) obj).longValue(), i3, i7);
                    } else if (obj instanceof Integer) {
                        z = cursorWindow.putLong((long) ((Integer) obj).intValue(), i3, i7);
                    } else if (obj instanceof Boolean) {
                        z = cursorWindow.putLong(((Boolean) obj).booleanValue() ? 1 : 0, i3, i7);
                    } else if (obj instanceof byte[]) {
                        z = cursorWindow.putBlob((byte[]) obj, i3, i7);
                    } else if (obj instanceof Double) {
                        z = cursorWindow.putDouble(((Double) obj).doubleValue(), i3, i7);
                    } else if (obj instanceof Float) {
                        z = cursorWindow.putDouble((double) ((Float) obj).floatValue(), i3, i7);
                    } else {
                        String valueOf = String.valueOf(obj);
                        throw new IllegalArgumentException(new StringBuilder((String.valueOf(str).length() + 32) + String.valueOf(valueOf).length()).append("Unsupported object for column ").append(str).append(": ").append(valueOf).toString());
                    }
                }
                if (z) {
                    i5 = i3;
                    i6 = 0;
                    cursorWindow2 = cursorWindow;
                } else if (i4 != 0) {
                    throw new C3209b("Could not add the value to a new CursorWindow. The size of value may be larger than what a CursorWindow can handle.");
                } else {
                    Log.d("DataHolder", "Couldn't populate window data for row " + i3 + " - allocating new window.");
                    cursorWindow.freeLastRow();
                    CursorWindow cursorWindow3 = new CursorWindow(false);
                    cursorWindow3.setStartPosition(i3);
                    cursorWindow3.setNumColumns(c3207a.f9799a.length);
                    arrayList.add(cursorWindow3);
                    i5 = i3 - 1;
                    cursorWindow2 = cursorWindow3;
                    i6 = 1;
                }
                i4 = i6;
                cursorWindow = cursorWindow2;
                i3 = i5 + 1;
            } catch (RuntimeException e) {
                RuntimeException runtimeException = e;
                int size2 = arrayList.size();
                while (i2 < size2) {
                    ((CursorWindow) arrayList.get(i2)).close();
                    i2++;
                }
                throw runtimeException;
            }
        }
        return (CursorWindow[]) arrayList.toArray(new CursorWindow[arrayList.size()]);
    }

    public static DataHolder m15975b(int i) {
        return m15972a(i, null);
    }

    public int m15976a(int i) {
        int i2 = 0;
        boolean z = i >= 0 && i < this.f9809d;
        C3234c.m16047a(z);
        while (i2 < this.f9808c.length) {
            if (i < this.f9808c[i2]) {
                i2--;
                break;
            }
            i2++;
        }
        return i2 == this.f9808c.length ? i2 - 1 : i2;
    }

    public String m15977a(String str, int i, int i2) {
        m15973a(str, i);
        return this.f9812g[i2].getString(i, this.f9807b.getInt(str));
    }

    public void m15978a() {
        int i;
        int i2 = 0;
        this.f9807b = new Bundle();
        for (i = 0; i < this.f9811f.length; i++) {
            this.f9807b.putInt(this.f9811f[i], i);
        }
        this.f9808c = new int[this.f9812g.length];
        i = 0;
        while (i2 < this.f9812g.length) {
            this.f9808c[i2] = i;
            i += this.f9812g[i2].getNumRows() - (i - this.f9812g[i2].getStartPosition());
            i2++;
        }
        this.f9809d = i;
    }

    public boolean m15979a(String str) {
        return this.f9807b.containsKey(str);
    }

    public byte[] m15980b(String str, int i, int i2) {
        m15973a(str, i);
        return this.f9812g[i2].getBlob(i, this.f9807b.getInt(str));
    }

    String[] m15981b() {
        return this.f9811f;
    }

    public boolean m15982c(String str, int i, int i2) {
        m15973a(str, i);
        return this.f9812g[i2].isNull(i, this.f9807b.getInt(str));
    }

    CursorWindow[] m15983c() {
        return this.f9812g;
    }

    public void close() {
        synchronized (this) {
            if (!this.f9810e) {
                this.f9810e = true;
                for (CursorWindow close : this.f9812g) {
                    close.close();
                }
            }
        }
    }

    public int m15984d() {
        return this.f9813h;
    }

    public Bundle m15985e() {
        return this.f9814i;
    }

    public int m15986f() {
        return this.f9809d;
    }

    protected void finalize() {
        try {
            if (this.f9815j && this.f9812g.length > 0 && !m15987g()) {
                close();
                String valueOf = String.valueOf(toString());
                Log.e("DataBuffer", new StringBuilder(String.valueOf(valueOf).length() + 178).append("Internal data leak within a DataBuffer object detected!  Be sure to explicitly call release() on all DataBuffer extending objects when you are done with them. (internal object: ").append(valueOf).append(")").toString());
            }
            super.finalize();
        } catch (Throwable th) {
            super.finalize();
        }
    }

    public boolean m15987g() {
        boolean z;
        synchronized (this) {
            z = this.f9810e;
        }
        return z;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C3213g.m15996a(this, parcel, i);
    }
}
