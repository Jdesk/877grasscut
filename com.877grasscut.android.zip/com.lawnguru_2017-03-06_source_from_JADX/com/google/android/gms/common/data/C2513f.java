package com.google.android.gms.common.data;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

/* renamed from: com.google.android.gms.common.data.f */
public class C2513f<T extends SafeParcelable> extends C2512a<T> {
    private static final String[] f6199b;
    private final Creator<T> f6200c;

    static {
        f6199b = new String[]{"data"};
    }

    public C2513f(DataHolder dataHolder, Creator<T> creator) {
        super(dataHolder);
        this.f6200c = creator;
    }

    public /* synthetic */ Object m10155a(int i) {
        return m10156b(i);
    }

    public T m10156b(int i) {
        byte[] b = this.a.m15980b("data", i, this.a.m15976a(i));
        Parcel obtain = Parcel.obtain();
        obtain.unmarshall(b, 0, b.length);
        obtain.setDataPosition(0);
        SafeParcelable safeParcelable = (SafeParcelable) this.f6200c.createFromParcel(obtain);
        obtain.recycle();
        return safeParcelable;
    }
}
