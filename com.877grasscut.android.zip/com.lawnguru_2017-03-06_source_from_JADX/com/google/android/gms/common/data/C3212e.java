package com.google.android.gms.common.data;

import com.google.android.gms.common.internal.C3233b;
import com.google.android.gms.common.internal.C3234c;

/* renamed from: com.google.android.gms.common.data.e */
public abstract class C3212e {
    protected final DataHolder f9818a;
    protected int f9819b;
    private int f9820c;

    public C3212e(DataHolder dataHolder, int i) {
        this.f9818a = (DataHolder) C3234c.m16042a((Object) dataHolder);
        m15991a(i);
    }

    protected void m15991a(int i) {
        boolean z = i >= 0 && i < this.f9818a.m15986f();
        C3234c.m16047a(z);
        this.f9819b = i;
        this.f9820c = this.f9818a.m15976a(this.f9819b);
    }

    public boolean m15992a(String str) {
        return this.f9818a.m15979a(str);
    }

    protected String m15993b(String str) {
        return this.f9818a.m15977a(str, this.f9819b, this.f9820c);
    }

    protected byte[] m15994c(String str) {
        return this.f9818a.m15980b(str, this.f9819b, this.f9820c);
    }

    protected boolean m15995d(String str) {
        return this.f9818a.m15982c(str, this.f9819b, this.f9820c);
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof C3212e)) {
            return false;
        }
        C3212e c3212e = (C3212e) obj;
        return C3233b.m16040a(Integer.valueOf(c3212e.f9819b), Integer.valueOf(this.f9819b)) && C3233b.m16040a(Integer.valueOf(c3212e.f9820c), Integer.valueOf(this.f9820c)) && c3212e.f9818a == this.f9818a;
    }

    public int hashCode() {
        return C3233b.m16038a(Integer.valueOf(this.f9819b), Integer.valueOf(this.f9820c), this.f9818a);
    }
}
