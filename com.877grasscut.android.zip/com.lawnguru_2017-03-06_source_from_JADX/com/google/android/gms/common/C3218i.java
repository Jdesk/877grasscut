package com.google.android.gms.common;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.common.i */
public class C3218i implements Creator<C3181a> {
    static void m16001a(C3181a c3181a, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16168a(parcel, 1, c3181a.f9732b);
        C3264c.m16168a(parcel, 2, c3181a.m15879c());
        C3264c.m16172a(parcel, 3, c3181a.m15880d(), i, false);
        C3264c.m16177a(parcel, 4, c3181a.m15881e(), false);
        C3264c.m16164a(parcel, a);
    }

    public C3181a m16002a(Parcel parcel) {
        String str = null;
        int i = 0;
        int b = C3263b.m16139b(parcel);
        PendingIntent pendingIntent = null;
        int i2 = 0;
        while (parcel.dataPosition() < b) {
            PendingIntent pendingIntent2;
            int i3;
            String str2;
            int a = C3263b.m16133a(parcel);
            String str3;
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_duration /*1*/:
                    str3 = str;
                    pendingIntent2 = pendingIntent;
                    i3 = i;
                    i = C3263b.m16146f(parcel, a);
                    str2 = str3;
                    break;
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    i = i2;
                    PendingIntent pendingIntent3 = pendingIntent;
                    i3 = C3263b.m16146f(parcel, a);
                    str2 = str;
                    pendingIntent2 = pendingIntent3;
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    i3 = i;
                    i = i2;
                    str3 = str;
                    pendingIntent2 = (PendingIntent) C3263b.m16135a(parcel, a, PendingIntent.CREATOR);
                    str2 = str3;
                    break;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    str2 = C3263b.m16154n(parcel, a);
                    pendingIntent2 = pendingIntent;
                    i3 = i;
                    i = i2;
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    str2 = str;
                    pendingIntent2 = pendingIntent;
                    i3 = i;
                    i = i2;
                    break;
            }
            i2 = i;
            i = i3;
            pendingIntent = pendingIntent2;
            str = str2;
        }
        if (parcel.dataPosition() == b) {
            return new C3181a(i2, i, pendingIntent, str);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public C3181a[] m16003a(int i) {
        return new C3181a[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m16002a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m16003a(i);
    }
}
