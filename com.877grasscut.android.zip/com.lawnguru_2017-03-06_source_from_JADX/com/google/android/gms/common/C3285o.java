package com.google.android.gms.common;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.util.Log;
import com.google.android.gms.common.C3284m.C3278a;
import com.google.android.gms.common.C3284m.C3279b;
import com.google.android.gms.common.C3284m.C3283d;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.p095b.bm;
import com.google.android.gms.p095b.bn;

/* renamed from: com.google.android.gms.common.o */
public class C3285o {
    private static C3285o f9947a;
    private final Context f9948b;
    private final bm f9949c;

    private C3285o(Context context) {
        this.f9948b = context.getApplicationContext();
        this.f9949c = bn.m9791b(this.f9948b);
    }

    public static C3285o m16253a(Context context) {
        C3234c.m16042a((Object) context);
        synchronized (C3285o.class) {
            if (f9947a == null) {
                C3284m.m16249a(context);
                f9947a = new C3285o(context);
            }
        }
        return f9947a;
    }

    C3278a m16254a(PackageInfo packageInfo, C3278a... c3278aArr) {
        int i = 0;
        if (packageInfo.signatures == null) {
            return null;
        }
        if (packageInfo.signatures.length != 1) {
            Log.w("GoogleSignatureVerifier", "Package has more than one signature.");
            return null;
        }
        C3279b c3279b = new C3279b(packageInfo.signatures[0].toByteArray());
        while (i < c3278aArr.length) {
            if (c3278aArr[i].equals(c3279b)) {
                return c3278aArr[i];
            }
            i++;
        }
        return null;
    }

    public boolean m16255a(int i) {
        String[] a = this.f9949c.m9788a(i);
        if (a == null || a.length == 0) {
            return false;
        }
        for (String a2 : a) {
            if (m16260a(a2)) {
                return true;
            }
        }
        return false;
    }

    public boolean m16256a(PackageInfo packageInfo) {
        if (packageInfo == null) {
            return false;
        }
        if (C3180n.zzaJ(this.f9948b)) {
            return m16262b(packageInfo, true);
        }
        boolean b = m16262b(packageInfo, false);
        if (b || !m16262b(packageInfo, true)) {
            return b;
        }
        Log.w("GoogleSignatureVerifier", "Test-keys aren't accepted on this build.");
        return b;
    }

    public boolean m16257a(PackageInfo packageInfo, boolean z) {
        if (!(packageInfo == null || packageInfo.signatures == null)) {
            C3278a a;
            if (z) {
                a = m16254a(packageInfo, C3283d.f9943a);
            } else {
                a = m16254a(packageInfo, C3283d.f9943a[0]);
            }
            if (a != null) {
                return true;
            }
        }
        return false;
    }

    @Deprecated
    public boolean m16258a(PackageManager packageManager, int i) {
        return m16255a(i);
    }

    @Deprecated
    public boolean m16259a(PackageManager packageManager, PackageInfo packageInfo) {
        return m16261b(packageInfo);
    }

    public boolean m16260a(String str) {
        try {
            return m16256a(this.f9949c.m9789b(str, 64));
        } catch (NameNotFoundException e) {
            return false;
        }
    }

    public boolean m16261b(PackageInfo packageInfo) {
        if (packageInfo == null) {
            return false;
        }
        if (m16257a(packageInfo, false)) {
            return true;
        }
        if (!m16257a(packageInfo, true)) {
            return false;
        }
        if (C3180n.zzaJ(this.f9948b)) {
            return true;
        }
        Log.w("GoogleSignatureVerifier", "Test-keys aren't accepted on this build.");
        return false;
    }

    boolean m16262b(PackageInfo packageInfo, boolean z) {
        boolean z2 = false;
        if (packageInfo.signatures.length != 1) {
            Log.w("GoogleSignatureVerifier", "Package has more than one signature.");
        } else {
            C3278a c3279b = new C3279b(packageInfo.signatures[0].toByteArray());
            String str = packageInfo.packageName;
            z2 = z ? C3284m.m16252b(str, c3279b) : C3284m.m16251a(str, c3279b);
            if (!z2) {
                Log.d("GoogleSignatureVerifier", "Cert not in list. atk=" + z);
            }
        }
        return z2;
    }
}
