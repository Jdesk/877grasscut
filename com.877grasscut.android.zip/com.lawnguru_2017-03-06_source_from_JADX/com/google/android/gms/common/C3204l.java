package com.google.android.gms.common;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.text.TextUtils;
import com.google.android.gms.common.internal.C3274y;
import com.google.android.gms.common.util.C3296f;
import com.google.android.gms.p095b.bn;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.common.l */
public class C3204l {
    private static final C3204l f9788a;
    public static final int f9789b;

    static {
        f9789b = C3180n.GOOGLE_PLAY_SERVICES_VERSION_CODE;
        f9788a = new C3204l();
    }

    C3204l() {
    }

    public static C3204l m15931b() {
        return f9788a;
    }

    static String m15932b(Context context, String str) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("gcore_");
        stringBuilder.append(f9789b);
        stringBuilder.append("-");
        if (!TextUtils.isEmpty(str)) {
            stringBuilder.append(str);
        }
        stringBuilder.append("-");
        if (context != null) {
            stringBuilder.append(context.getPackageName());
        }
        stringBuilder.append("-");
        if (context != null) {
            try {
                stringBuilder.append(bn.m9791b(context).m9789b(context.getPackageName(), 0).versionCode);
            } catch (NameNotFoundException e) {
            }
        }
        return stringBuilder.toString();
    }

    public int m15933a(Context context) {
        int isGooglePlayServicesAvailable = C3180n.isGooglePlayServicesAvailable(context);
        return C3180n.zzd(context, isGooglePlayServicesAvailable) ? 18 : isGooglePlayServicesAvailable;
    }

    public PendingIntent m15934a(Context context, int i, int i2) {
        return m15935a(context, i, i2, null);
    }

    public PendingIntent m15935a(Context context, int i, int i2, String str) {
        Intent b = m15940b(context, i, str);
        return b == null ? null : PendingIntent.getActivity(context, i2, b, 268435456);
    }

    public boolean m15936a(int i) {
        return C3180n.isUserRecoverableError(i);
    }

    public boolean m15937a(Context context, String str) {
        return C3180n.zzz(context, str);
    }

    public int m15938b(Context context) {
        return C3180n.zzaC(context);
    }

    @Deprecated
    public Intent m15939b(int i) {
        return m15940b(null, i, null);
    }

    public Intent m15940b(Context context, int i, String str) {
        switch (i) {
            case C5538a.ExpandableLayout_el_duration /*1*/:
            case C5538a.ExpandableLayout_el_expanded /*2*/:
                return (context == null || !C3296f.m16322b(context)) ? C3274y.m16235a(GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE, C3204l.m15932b(context, str)) : C3274y.m16233a();
            case C5538a.ExpandableLayout_layout_expandable /*3*/:
                return C3274y.m16234a(GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE);
            default:
                return null;
        }
    }

    public boolean m15941b(Context context, int i) {
        return C3180n.zzd(context, i);
    }

    public String m15942c(int i) {
        return C3180n.getErrorString(i);
    }

    public void m15943d(Context context) {
        C3180n.zzaF(context);
    }
}
