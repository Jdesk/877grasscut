package com.google.android.gms.common;

import android.app.Dialog;
import android.app.DialogFragment;
import android.app.FragmentManager;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.os.Bundle;
import com.google.android.gms.common.internal.C3234c;

/* renamed from: com.google.android.gms.common.b */
public class C3202b extends DialogFragment {
    private Dialog f9784a;
    private OnCancelListener f9785b;

    public C3202b() {
        this.f9784a = null;
        this.f9785b = null;
    }

    public static C3202b m15930a(Dialog dialog, OnCancelListener onCancelListener) {
        C3202b c3202b = new C3202b();
        Dialog dialog2 = (Dialog) C3234c.m16043a((Object) dialog, (Object) "Cannot display null dialog");
        dialog2.setOnCancelListener(null);
        dialog2.setOnDismissListener(null);
        c3202b.f9784a = dialog2;
        if (onCancelListener != null) {
            c3202b.f9785b = onCancelListener;
        }
        return c3202b;
    }

    public void onCancel(DialogInterface dialogInterface) {
        if (this.f9785b != null) {
            this.f9785b.onCancel(dialogInterface);
        }
    }

    public Dialog onCreateDialog(Bundle bundle) {
        if (this.f9784a == null) {
            setShowsDialog(false);
        }
        return this.f9784a;
    }

    public void show(FragmentManager fragmentManager, String str) {
        super.show(fragmentManager, str);
    }
}
