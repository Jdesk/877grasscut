package com.google.android.gms.common;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.Notification;
import android.app.Notification.BigTextStyle;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.ad.C0275c;
import android.support.v4.app.ad.C0276d;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.ProgressBar;
import com.google.android.gms.C2063a.C2043a;
import com.google.android.gms.C2063a.C2044b;
import com.google.android.gms.common.api.GoogleApiActivity;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.common.internal.C3256q;
import com.google.android.gms.common.internal.C3257r;
import com.google.android.gms.common.util.C3296f;
import com.google.android.gms.common.util.C3303m;
import com.google.android.gms.p095b.C3157z;
import com.google.android.gms.p095b.C3157z.C2621a;
import com.google.android.gms.p095b.ag;
import io.card.payment.BuildConfig;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.common.c */
public class C3205c extends C3204l {
    public static final int f9790a;
    private static final C3205c f9791c;

    @SuppressLint({"HandlerLeak"})
    /* renamed from: com.google.android.gms.common.c.a */
    private class C3203a extends Handler {
        final /* synthetic */ C3205c f9786a;
        private final Context f9787b;

        public C3203a(C3205c c3205c, Context context) {
            this.f9786a = c3205c;
            super(Looper.myLooper() == null ? Looper.getMainLooper() : Looper.myLooper());
            this.f9787b = context.getApplicationContext();
        }

        public void handleMessage(Message message) {
            switch (message.what) {
                case C5538a.ExpandableLayout_el_duration /*1*/:
                    int a = this.f9786a.m15945a(this.f9787b);
                    if (this.f9786a.m15957a(a)) {
                        this.f9786a.m15954a(this.f9787b, a);
                    }
                default:
                    Log.w("GoogleApiAvailability", "Don't know how to handle this message: " + message.what);
            }
        }
    }

    static {
        f9791c = new C3205c();
        f9790a = C3204l.f9789b;
    }

    C3205c() {
    }

    public static C3205c m15944a() {
        return f9791c;
    }

    public int m15945a(Context context) {
        return super.m15933a(context);
    }

    public Dialog m15946a(Activity activity, int i, int i2, OnCancelListener onCancelListener) {
        return m15948a((Context) activity, i, C3257r.m16118a(activity, m15962b(activity, i, "d"), i2), onCancelListener);
    }

    public Dialog m15947a(Activity activity, OnCancelListener onCancelListener) {
        View progressBar = new ProgressBar(activity, null, 16842874);
        progressBar.setIndeterminate(true);
        progressBar.setVisibility(0);
        Builder builder = new Builder(activity);
        builder.setView(progressBar);
        builder.setMessage(C3256q.m16115c(activity, 18));
        builder.setPositiveButton(BuildConfig.FLAVOR, null);
        Dialog create = builder.create();
        m15953a(activity, create, "GooglePlayServicesUpdatingDialog", onCancelListener);
        return create;
    }

    Dialog m15948a(Context context, int i, C3257r c3257r, OnCancelListener onCancelListener) {
        Builder builder = null;
        if (i == 0) {
            return null;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(16843529, typedValue, true);
        if ("Theme.Dialog.Alert".equals(context.getResources().getResourceEntryName(typedValue.resourceId))) {
            builder = new Builder(context, 5);
        }
        if (builder == null) {
            builder = new Builder(context);
        }
        builder.setMessage(C3256q.m16115c(context, i));
        if (onCancelListener != null) {
            builder.setOnCancelListener(onCancelListener);
        }
        CharSequence e = C3256q.m16117e(context, i);
        if (e != null) {
            builder.setPositiveButton(e, c3257r);
        }
        e = C3256q.m16111a(context, i);
        if (e != null) {
            builder.setTitle(e);
        }
        return builder.create();
    }

    public PendingIntent m15949a(Context context, int i, int i2) {
        return super.m15934a(context, i, i2);
    }

    public PendingIntent m15950a(Context context, int i, int i2, String str) {
        return super.m15935a(context, i, i2, str);
    }

    public PendingIntent m15951a(Context context, C3181a c3181a) {
        return c3181a.m15877a() ? c3181a.m15880d() : m15949a(context, c3181a.m15879c(), 0);
    }

    public C3157z m15952a(Context context, C2621a c2621a) {
        IntentFilter intentFilter = new IntentFilter("android.intent.action.PACKAGE_ADDED");
        intentFilter.addDataScheme("package");
        BroadcastReceiver c3157z = new C3157z(c2621a);
        context.registerReceiver(c3157z, intentFilter);
        c3157z.m15682a(context);
        if (m15937a(context, GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE)) {
            return c3157z;
        }
        c2621a.m11464a();
        c3157z.m15681a();
        return null;
    }

    void m15953a(Activity activity, Dialog dialog, String str, OnCancelListener onCancelListener) {
        boolean z;
        try {
            z = activity instanceof FragmentActivity;
        } catch (NoClassDefFoundError e) {
            z = false;
        }
        if (z) {
            C3216f.m15999a(dialog, onCancelListener).show(((FragmentActivity) activity).getSupportFragmentManager(), str);
            return;
        }
        C3202b.m15930a(dialog, onCancelListener).show(activity.getFragmentManager(), str);
    }

    public void m15954a(Context context, int i) {
        m15955a(context, i, null);
    }

    public void m15955a(Context context, int i, String str) {
        m15956a(context, i, str, m15950a(context, i, 0, "n"));
    }

    @TargetApi(20)
    void m15956a(Context context, int i, String str, PendingIntent pendingIntent) {
        if (i == 18) {
            m15966c(context);
        } else if (pendingIntent != null) {
            Notification build;
            int i2;
            CharSequence b = C3256q.m16114b(context, i);
            CharSequence d = C3256q.m16116d(context, i);
            Resources resources = context.getResources();
            if (C3296f.m16322b(context)) {
                C3234c.m16047a(C3303m.m16344h());
                build = new Notification.Builder(context).setSmallIcon(context.getApplicationInfo().icon).setPriority(2).setAutoCancel(true).setContentTitle(b).setStyle(new BigTextStyle().bigText(d)).addAction(C2043a.common_full_open_on_phone, resources.getString(C2044b.common_open_on_phone), pendingIntent).build();
            } else {
                build = new C0276d(context).setSmallIcon(17301642).setTicker(resources.getString(C2044b.common_google_play_services_notification_ticker)).setWhen(System.currentTimeMillis()).setAutoCancel(true).setContentIntent(pendingIntent).setContentTitle(b).setContentText(d).setLocalOnly(true).setStyle(new C0275c().m1222a(d)).build();
            }
            switch (i) {
                case C5538a.ExpandableLayout_el_duration /*1*/:
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    C3180n.zzayB.set(false);
                    i2 = 10436;
                    break;
                default:
                    i2 = 39789;
                    break;
            }
            NotificationManager notificationManager = (NotificationManager) context.getSystemService("notification");
            if (str == null) {
                notificationManager.notify(i2, build);
            } else {
                notificationManager.notify(str, i2, build);
            }
        } else if (i == 6) {
            Log.w("GoogleApiAvailability", "Missing resolution for ConnectionResult.RESOLUTION_REQUIRED. Call GoogleApiAvailability#showErrorNotification(Context, ConnectionResult) instead.");
        }
    }

    public final boolean m15957a(int i) {
        return super.m15936a(i);
    }

    public boolean m15958a(Activity activity, ag agVar, int i, int i2, OnCancelListener onCancelListener) {
        Dialog a = m15948a((Context) activity, i, C3257r.m16120a(agVar, m15962b(activity, i, "d"), i2), onCancelListener);
        if (a == null) {
            return false;
        }
        m15953a(activity, a, GooglePlayServicesUtil.GMS_ERROR_DIALOG, onCancelListener);
        return true;
    }

    public boolean m15959a(Context context, C3181a c3181a, int i) {
        PendingIntent a = m15951a(context, c3181a);
        if (a == null) {
            return false;
        }
        m15956a(context, c3181a.m15879c(), null, GoogleApiActivity.m15882a(context, a, i));
        return true;
    }

    public int m15960b(Context context) {
        return super.m15938b(context);
    }

    @Deprecated
    public Intent m15961b(int i) {
        return super.m15939b(i);
    }

    public Intent m15962b(Context context, int i, String str) {
        return super.m15940b(context, i, str);
    }

    public boolean m15963b(Activity activity, int i, int i2, OnCancelListener onCancelListener) {
        Dialog a = m15946a(activity, i, i2, onCancelListener);
        if (a == null) {
            return false;
        }
        m15953a(activity, a, GooglePlayServicesUtil.GMS_ERROR_DIALOG, onCancelListener);
        return true;
    }

    public boolean m15964b(Context context, int i) {
        return super.m15941b(context, i);
    }

    public final String m15965c(int i) {
        return super.m15942c(i);
    }

    void m15966c(Context context) {
        new C3203a(this, context).sendEmptyMessageDelayed(1, 120000);
    }
}
