package com.google.android.gms.common;

import android.content.Intent;

/* renamed from: com.google.android.gms.common.g */
public class C3214g extends Exception {
    private final Intent f9821a;

    public C3214g(String str, Intent intent) {
        super(str);
        this.f9821a = intent;
    }
}
