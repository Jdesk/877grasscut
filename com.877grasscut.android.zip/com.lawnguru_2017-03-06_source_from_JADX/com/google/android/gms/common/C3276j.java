package com.google.android.gms.common;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C2149a;

/* renamed from: com.google.android.gms.common.j */
public class C3276j extends C2149a {
    public static final Creator<C3276j> CREATOR;
    public final String f9937a;
    public final int f9938b;

    static {
        CREATOR = new C3277k();
    }

    public C3276j(String str, int i) {
        this.f9937a = str;
        this.f9938b = i;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C3277k.m16237a(this, parcel, i);
    }
}
