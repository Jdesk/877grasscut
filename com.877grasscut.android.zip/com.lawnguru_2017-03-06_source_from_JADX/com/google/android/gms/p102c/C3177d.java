package com.google.android.gms.p102c;

import java.util.concurrent.Executor;

/* renamed from: com.google.android.gms.c.d */
class C3177d<TResult> implements C3176e<TResult> {
    private final Executor f9720a;
    private final Object f9721b;
    private C2752a<TResult> f9722c;

    /* renamed from: com.google.android.gms.c.d.1 */
    class C31751 implements Runnable {
        final /* synthetic */ C3173b f9718a;
        final /* synthetic */ C3177d f9719b;

        C31751(C3177d c3177d, C3173b c3173b) {
            this.f9719b = c3177d;
            this.f9718a = c3173b;
        }

        public void run() {
            synchronized (this.f9719b.f9721b) {
                if (this.f9719b.f9722c != null) {
                    this.f9719b.f9722c.m12593a(this.f9718a);
                }
            }
        }
    }

    public C3177d(Executor executor, C2752a<TResult> c2752a) {
        this.f9721b = new Object();
        this.f9720a = executor;
        this.f9722c = c2752a;
    }

    public void m15865a(C3173b<TResult> c3173b) {
        synchronized (this.f9721b) {
            if (this.f9722c == null) {
                return;
            }
            this.f9720a.execute(new C31751(this, c3173b));
        }
    }
}
