package com.google.android.gms.p102c;

import java.util.concurrent.Executor;

/* renamed from: com.google.android.gms.c.b */
public abstract class C3173b<TResult> {
    public C3173b<TResult> m15855a(Executor executor, C2752a<TResult> c2752a) {
        throw new UnsupportedOperationException("addOnCompleteListener is not implemented");
    }

    public abstract boolean m15856a();

    public abstract Exception m15857b();
}
