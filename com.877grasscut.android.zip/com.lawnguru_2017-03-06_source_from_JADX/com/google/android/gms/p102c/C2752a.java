package com.google.android.gms.p102c;

/* renamed from: com.google.android.gms.c.a */
public interface C2752a<TResult> {
    void m12593a(C3173b<TResult> c3173b);
}
