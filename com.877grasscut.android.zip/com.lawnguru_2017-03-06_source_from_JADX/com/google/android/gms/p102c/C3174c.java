package com.google.android.gms.p102c;

/* renamed from: com.google.android.gms.c.c */
public class C3174c<TResult> {
    private final C3179g<TResult> f9717a;

    public C3174c() {
        this.f9717a = new C3179g();
    }

    public C3173b<TResult> m15858a() {
        return this.f9717a;
    }

    public void m15859a(Exception exception) {
        this.f9717a.m15871a(exception);
    }

    public void m15860a(TResult tResult) {
        this.f9717a.m15872a((Object) tResult);
    }

    public boolean m15861b(Exception exception) {
        return this.f9717a.m15875b(exception);
    }
}
