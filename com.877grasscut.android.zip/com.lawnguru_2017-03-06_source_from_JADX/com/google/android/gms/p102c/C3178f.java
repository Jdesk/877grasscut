package com.google.android.gms.p102c;

import java.util.ArrayDeque;
import java.util.Queue;

/* renamed from: com.google.android.gms.c.f */
class C3178f<TResult> {
    private final Object f9723a;
    private Queue<C3176e<TResult>> f9724b;
    private boolean f9725c;

    C3178f() {
        this.f9723a = new Object();
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void m15866a(com.google.android.gms.p102c.C3173b<TResult> r3) {
        /*
        r2 = this;
        r1 = r2.f9723a;
        monitor-enter(r1);
        r0 = r2.f9724b;	 Catch:{ all -> 0x0026 }
        if (r0 == 0) goto L_0x000b;
    L_0x0007:
        r0 = r2.f9725c;	 Catch:{ all -> 0x0026 }
        if (r0 == 0) goto L_0x000d;
    L_0x000b:
        monitor-exit(r1);	 Catch:{ all -> 0x0026 }
    L_0x000c:
        return;
    L_0x000d:
        r0 = 1;
        r2.f9725c = r0;	 Catch:{ all -> 0x0026 }
        monitor-exit(r1);	 Catch:{ all -> 0x0026 }
    L_0x0011:
        r1 = r2.f9723a;
        monitor-enter(r1);
        r0 = r2.f9724b;	 Catch:{ all -> 0x0023 }
        r0 = r0.poll();	 Catch:{ all -> 0x0023 }
        r0 = (com.google.android.gms.p102c.C3176e) r0;	 Catch:{ all -> 0x0023 }
        if (r0 != 0) goto L_0x0029;
    L_0x001e:
        r0 = 0;
        r2.f9725c = r0;	 Catch:{ all -> 0x0023 }
        monitor-exit(r1);	 Catch:{ all -> 0x0023 }
        goto L_0x000c;
    L_0x0023:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x0023 }
        throw r0;
    L_0x0026:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x0026 }
        throw r0;
    L_0x0029:
        monitor-exit(r1);	 Catch:{ all -> 0x0023 }
        r0.m15862a(r3);
        goto L_0x0011;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.c.f.a(com.google.android.gms.c.b):void");
    }

    public void m15867a(C3176e<TResult> c3176e) {
        synchronized (this.f9723a) {
            if (this.f9724b == null) {
                this.f9724b = new ArrayDeque();
            }
            this.f9724b.add(c3176e);
        }
    }
}
