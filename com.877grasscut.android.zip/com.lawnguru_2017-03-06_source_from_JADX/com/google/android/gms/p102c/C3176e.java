package com.google.android.gms.p102c;

/* renamed from: com.google.android.gms.c.e */
interface C3176e<TResult> {
    void m15862a(C3173b<TResult> c3173b);
}
