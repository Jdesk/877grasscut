package com.google.android.gms.p102c;

import com.google.android.gms.common.internal.C3234c;
import java.util.concurrent.Executor;

/* renamed from: com.google.android.gms.c.g */
final class C3179g<TResult> extends C3173b<TResult> {
    private final Object f9726a;
    private final C3178f<TResult> f9727b;
    private boolean f9728c;
    private TResult f9729d;
    private Exception f9730e;

    C3179g() {
        this.f9726a = new Object();
        this.f9727b = new C3178f();
    }

    private void m15868c() {
        C3234c.m16048a(!this.f9728c, (Object) "Task is already complete");
    }

    private void m15869d() {
        synchronized (this.f9726a) {
            if (this.f9728c) {
                this.f9727b.m15866a((C3173b) this);
                return;
            }
        }
    }

    public C3173b<TResult> m15870a(Executor executor, C2752a<TResult> c2752a) {
        this.f9727b.m15867a(new C3177d(executor, c2752a));
        m15869d();
        return this;
    }

    public void m15871a(Exception exception) {
        C3234c.m16043a((Object) exception, (Object) "Exception must not be null");
        synchronized (this.f9726a) {
            m15868c();
            this.f9728c = true;
            this.f9730e = exception;
        }
        this.f9727b.m15866a((C3173b) this);
    }

    public void m15872a(TResult tResult) {
        synchronized (this.f9726a) {
            m15868c();
            this.f9728c = true;
            this.f9729d = tResult;
        }
        this.f9727b.m15866a((C3173b) this);
    }

    public boolean m15873a() {
        boolean z;
        synchronized (this.f9726a) {
            z = this.f9728c && this.f9730e == null;
        }
        return z;
    }

    public Exception m15874b() {
        Exception exception;
        synchronized (this.f9726a) {
            exception = this.f9730e;
        }
        return exception;
    }

    public boolean m15875b(Exception exception) {
        boolean z = true;
        C3234c.m16043a((Object) exception, (Object) "Exception must not be null");
        synchronized (this.f9726a) {
            if (this.f9728c) {
                z = false;
            } else {
                this.f9728c = true;
                this.f9730e = exception;
                this.f9727b.m15866a((C3173b) this);
            }
        }
        return z;
    }
}
