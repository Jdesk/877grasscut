package com.google.android.gms.p095b;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@sc
/* renamed from: com.google.android.gms.b.lv */
public class lv {
    private final Collection<lt> f7555a;
    private final Collection<lt<String>> f7556b;
    private final Collection<lt<String>> f7557c;

    public lv() {
        this.f7555a = new ArrayList();
        this.f7556b = new ArrayList();
        this.f7557c = new ArrayList();
    }

    public List<String> m12575a() {
        List<String> arrayList = new ArrayList();
        for (lt c : this.f7556b) {
            String str = (String) c.m12563c();
            if (str != null) {
                arrayList.add(str);
            }
        }
        return arrayList;
    }

    public void m12576a(lt ltVar) {
        this.f7555a.add(ltVar);
    }

    public List<String> m12577b() {
        List<String> a = m12575a();
        for (lt c : this.f7557c) {
            String str = (String) c.m12563c();
            if (str != null) {
                a.add(str);
            }
        }
        return a;
    }

    public void m12578b(lt<String> ltVar) {
        this.f7556b.add(ltVar);
    }

    public void m12579c(lt<String> ltVar) {
        this.f7557c.add(ltVar);
    }
}
