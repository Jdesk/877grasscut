package com.google.android.gms.p095b;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

@sc
/* renamed from: com.google.android.gms.b.tg */
class tg {
    private final List<String> f8790a;
    private final List<String> f8791b;
    private final String f8792c;
    private final String f8793d;
    private final String f8794e;
    private final String f8795f;
    private final boolean f8796g;
    private final boolean f8797h;
    private final String f8798i;
    private final String f8799j;
    private String f8800k;
    private int f8801l;

    public tg(int i, Map<String, String> map) {
        this.f8800k = (String) map.get("url");
        this.f8793d = (String) map.get("base_uri");
        this.f8794e = (String) map.get("post_parameters");
        this.f8796g = tg.m14257b((String) map.get("drt_include"));
        this.f8797h = tg.m14257b((String) map.get("pan_include"));
        this.f8792c = (String) map.get("activation_overlay_url");
        this.f8791b = m14258c((String) map.get("check_packages"));
        this.f8798i = (String) map.get("request_id");
        this.f8795f = (String) map.get("type");
        this.f8790a = m14258c((String) map.get("errors"));
        this.f8801l = i;
        this.f8799j = (String) map.get("fetched_ad");
    }

    private static boolean m14257b(String str) {
        return str != null && (str.equals("1") || str.equals("true"));
    }

    private List<String> m14258c(String str) {
        return str == null ? null : Arrays.asList(str.split(","));
    }

    public int m14259a() {
        return this.f8801l;
    }

    public void m14260a(String str) {
        this.f8800k = str;
    }

    public List<String> m14261b() {
        return this.f8790a;
    }

    public String m14262c() {
        return this.f8793d;
    }

    public String m14263d() {
        return this.f8794e;
    }

    public String m14264e() {
        return this.f8800k;
    }

    public String m14265f() {
        return this.f8795f;
    }

    public boolean m14266g() {
        return this.f8796g;
    }

    public String m14267h() {
        return this.f8798i;
    }

    public String m14268i() {
        return this.f8799j;
    }
}
