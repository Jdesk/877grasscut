package com.google.android.gms.p095b;

import com.google.android.gms.p095b.bq.C2452a;

/* renamed from: com.google.android.gms.b.hd */
public class hd extends C2630if {
    private static volatile String f6978i;
    private static final Object f6979j;

    static {
        f6978i = null;
        f6979j = new Object();
    }

    public hd(gm gmVar, String str, String str2, C2452a c2452a, int i, int i2) {
        super(gmVar, str, str2, c2452a, i, i2);
    }

    protected void m11623a() {
        this.e.f5973a = "E";
        if (f6978i == null) {
            synchronized (f6979j) {
                if (f6978i == null) {
                    f6978i = (String) this.f.invoke(null, new Object[0]);
                }
            }
        }
        synchronized (this.e) {
            this.e.f5973a = f6978i;
        }
    }
}
