package com.google.android.gms.p095b;

import android.os.Bundle;
import android.view.View;
import com.google.android.gms.p095b.mw.C2768b;
import com.google.android.gms.p095b.nh.C2769a;
import com.google.android.gms.p097a.C2046a;
import com.google.android.gms.p097a.C2060d;
import io.card.payment.BuildConfig;
import java.util.List;

@sc
/* renamed from: com.google.android.gms.b.mr */
public class mr extends C2769a implements C2768b {
    private String f7711a;
    private List<mp> f7712b;
    private String f7713c;
    private nb f7714d;
    private String f7715e;
    private String f7716f;
    private mn f7717g;
    private Bundle f7718h;
    private kz f7719i;
    private View f7720j;
    private Object f7721k;
    private mw f7722l;

    public mr(String str, List list, String str2, nb nbVar, String str3, String str4, mn mnVar, Bundle bundle, kz kzVar, View view) {
        this.f7721k = new Object();
        this.f7711a = str;
        this.f7712b = list;
        this.f7713c = str2;
        this.f7714d = nbVar;
        this.f7715e = str3;
        this.f7716f = str4;
        this.f7717g = mnVar;
        this.f7718h = bundle;
        this.f7719i = kzVar;
        this.f7720j = view;
    }

    public String m12763a() {
        return this.f7711a;
    }

    public void m12764a(mw mwVar) {
        synchronized (this.f7721k) {
            this.f7722l = mwVar;
        }
    }

    public List m12765b() {
        return this.f7712b;
    }

    public String m12766c() {
        return this.f7713c;
    }

    public nb m12767d() {
        return this.f7714d;
    }

    public String m12768e() {
        return this.f7715e;
    }

    public String m12769f() {
        return this.f7716f;
    }

    public kz m12770g() {
        return this.f7719i;
    }

    public C2046a m12771h() {
        return C2060d.m7973a(this.f7722l);
    }

    public Bundle m12772i() {
        return this.f7718h;
    }

    public void m12773j() {
        this.f7711a = null;
        this.f7712b = null;
        this.f7713c = null;
        this.f7714d = null;
        this.f7715e = null;
        this.f7716f = null;
        this.f7717g = null;
        this.f7718h = null;
        this.f7721k = null;
        this.f7722l = null;
        this.f7719i = null;
        this.f7720j = null;
    }

    public String m12774k() {
        return "1";
    }

    public String m12775l() {
        return BuildConfig.FLAVOR;
    }

    public mn m12776m() {
        return this.f7717g;
    }

    public View m12777o() {
        return this.f7720j;
    }
}
