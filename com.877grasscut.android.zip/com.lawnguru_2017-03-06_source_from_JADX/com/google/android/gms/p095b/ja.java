package com.google.android.gms.p095b;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Application;
import android.app.Application.ActivityLifecycleCallbacks;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import com.google.android.gms.common.util.C3303m;
import java.util.ArrayList;
import java.util.List;

@sc
/* renamed from: com.google.android.gms.b.ja */
public class ja {
    private final Object f7248a;
    private C2684a f7249b;
    private boolean f7250c;

    @TargetApi(14)
    /* renamed from: com.google.android.gms.b.ja.a */
    static class C2684a implements ActivityLifecycleCallbacks {
        private Activity f7239a;
        private Context f7240b;
        private final Object f7241c;
        private boolean f7242d;
        private boolean f7243e;
        private List<C2685b> f7244f;
        private Runnable f7245g;
        private boolean f7246h;
        private long f7247i;

        /* renamed from: com.google.android.gms.b.ja.a.1 */
        class C26831 implements Runnable {
            final /* synthetic */ C2684a f7238a;

            C26831(C2684a c2684a) {
                this.f7238a = c2684a;
            }

            public void run() {
                synchronized (this.f7238a.f7241c) {
                    if (this.f7238a.f7242d && this.f7238a.f7243e) {
                        this.f7238a.f7242d = false;
                        wg.m14615b("App went background");
                        for (C2685b a : this.f7238a.f7244f) {
                            try {
                                a.m12064a(false);
                            } catch (Throwable e) {
                                wg.m14616b("OnForegroundStateChangedListener threw exception.", e);
                            }
                        }
                    } else {
                        wg.m14615b("App is still foreground");
                    }
                }
            }
        }

        C2684a() {
            this.f7241c = new Object();
            this.f7242d = true;
            this.f7243e = false;
            this.f7244f = new ArrayList();
            this.f7246h = false;
        }

        private void m12055a(Activity activity) {
            synchronized (this.f7241c) {
                if (!activity.getClass().getName().startsWith("com.google.android.gms.ads")) {
                    this.f7239a = activity;
                }
            }
        }

        public Activity m12060a() {
            return this.f7239a;
        }

        public void m12061a(Application application, Context context) {
            if (!this.f7246h) {
                application.registerActivityLifecycleCallbacks(this);
                if (context instanceof Activity) {
                    m12055a((Activity) context);
                }
                this.f7240b = context;
                this.f7247i = ((Long) ly.aK.m12563c()).longValue();
                this.f7246h = true;
            }
        }

        public void m12062a(C2685b c2685b) {
            this.f7244f.add(c2685b);
        }

        public Context m12063b() {
            return this.f7240b;
        }

        public void onActivityCreated(Activity activity, Bundle bundle) {
        }

        public void onActivityDestroyed(Activity activity) {
            synchronized (this.f7241c) {
                if (this.f7239a == null) {
                    return;
                }
                if (this.f7239a.equals(activity)) {
                    this.f7239a = null;
                }
            }
        }

        public void onActivityPaused(Activity activity) {
            m12055a(activity);
            this.f7243e = true;
            if (this.f7245g != null) {
                vo.f9130a.removeCallbacks(this.f7245g);
            }
            Handler handler = vo.f9130a;
            Runnable c26831 = new C26831(this);
            this.f7245g = c26831;
            handler.postDelayed(c26831, this.f7247i);
        }

        public void onActivityResumed(Activity activity) {
            boolean z = false;
            m12055a(activity);
            this.f7243e = false;
            if (!this.f7242d) {
                z = true;
            }
            this.f7242d = true;
            if (this.f7245g != null) {
                vo.f9130a.removeCallbacks(this.f7245g);
            }
            synchronized (this.f7241c) {
                if (z) {
                    for (C2685b a : this.f7244f) {
                        try {
                            a.m12064a(true);
                        } catch (Throwable e) {
                            wg.m14616b("OnForegroundStateChangedListener threw exception.", e);
                        }
                    }
                } else {
                    wg.m14615b("App is still foreground.");
                }
            }
        }

        public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
        }

        public void onActivityStarted(Activity activity) {
            m12055a(activity);
        }

        public void onActivityStopped(Activity activity) {
        }
    }

    /* renamed from: com.google.android.gms.b.ja.b */
    public interface C2685b {
        void m12064a(boolean z);
    }

    public ja() {
        this.f7248a = new Object();
        this.f7249b = null;
        this.f7250c = false;
    }

    public Activity m12065a() {
        Activity a;
        synchronized (this.f7248a) {
            C3303m.m16338b();
            if (this.f7249b != null) {
                a = this.f7249b.m12060a();
            } else {
                a = null;
            }
        }
        return a;
    }

    public void m12066a(Context context) {
        synchronized (this.f7248a) {
            if (!this.f7250c) {
                C3303m.m16338b();
                if (((Boolean) ly.aJ.m12563c()).booleanValue()) {
                    Context applicationContext = context.getApplicationContext();
                    if (applicationContext == null) {
                        applicationContext = context;
                    }
                    Application application = applicationContext instanceof Application ? (Application) applicationContext : null;
                    if (application == null) {
                        wg.m14620e("Can not cast Context to Application");
                        return;
                    }
                    if (this.f7249b == null) {
                        this.f7249b = new C2684a();
                    }
                    this.f7249b.m12061a(application, context);
                    this.f7250c = true;
                } else {
                    return;
                }
            }
        }
    }

    public void m12067a(C2685b c2685b) {
        synchronized (this.f7248a) {
            C3303m.m16338b();
            if (((Boolean) ly.aJ.m12563c()).booleanValue()) {
                if (this.f7249b == null) {
                    this.f7249b = new C2684a();
                }
                this.f7249b.m12062a(c2685b);
                return;
            }
        }
    }

    public Context m12068b() {
        Context b;
        synchronized (this.f7248a) {
            C3303m.m16338b();
            if (this.f7249b != null) {
                b = this.f7249b.m12063b();
            } else {
                b = null;
            }
        }
        return b;
    }
}
