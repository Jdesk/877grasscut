package com.google.android.gms.p095b;

import com.google.android.gms.p095b.bq.C2452a;

/* renamed from: com.google.android.gms.b.hg */
public class hg extends C2630if {
    private final StackTraceElement[] f6982i;

    public hg(gm gmVar, String str, String str2, C2452a c2452a, int i, int i2, StackTraceElement[] stackTraceElementArr) {
        super(gmVar, str, str2, c2452a, i, i2);
        this.f6982i = stackTraceElementArr;
    }

    protected void m11627a() {
        if (this.f6982i != null) {
            gk gkVar = new gk((String) this.f.invoke(null, new Object[]{this.f6982i}));
            synchronized (this.e) {
                this.e.f5958L = gkVar.f6901a;
                if (gkVar.f6902b.booleanValue()) {
                    this.e.f5968V = Integer.valueOf(gkVar.f6903c.booleanValue() ? 0 : 1);
                }
            }
        }
    }
}
