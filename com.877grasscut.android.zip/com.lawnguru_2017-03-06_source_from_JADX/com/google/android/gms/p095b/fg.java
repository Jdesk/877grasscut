package com.google.android.gms.p095b;

import com.google.android.gms.common.internal.C3234c;

/* renamed from: com.google.android.gms.b.fg */
class fg {
    final String f6718a;
    final String f6719b;
    final String f6720c;
    final long f6721d;
    final Object f6722e;

    fg(String str, String str2, String str3, long j, Object obj) {
        C3234c.m16044a(str);
        C3234c.m16044a(str3);
        C3234c.m16042a(obj);
        this.f6718a = str;
        this.f6719b = str2;
        this.f6720c = str3;
        this.f6721d = j;
        this.f6722e = obj;
    }
}
