package com.google.android.gms.p095b;

import java.util.AbstractMap.SimpleEntry;
import java.util.HashSet;
import java.util.Iterator;
import org.json.JSONObject;

@sc
/* renamed from: com.google.android.gms.b.pg */
public class pg implements pf {
    private final pe f8046a;
    private final HashSet<SimpleEntry<String, nx>> f8047b;

    public pg(pe peVar) {
        this.f8046a = peVar;
        this.f8047b = new HashSet();
    }

    public void m13351a() {
        Iterator it = this.f8047b.iterator();
        while (it.hasNext()) {
            SimpleEntry simpleEntry = (SimpleEntry) it.next();
            String str = "Unregistering eventhandler: ";
            String valueOf = String.valueOf(((nx) simpleEntry.getValue()).toString());
            vk.m14621a(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
            this.f8046a.m13268b((String) simpleEntry.getKey(), (nx) simpleEntry.getValue());
        }
        this.f8047b.clear();
    }

    public void m13352a(String str, nx nxVar) {
        this.f8046a.m13265a(str, nxVar);
        this.f8047b.add(new SimpleEntry(str, nxVar));
    }

    public void m13353a(String str, String str2) {
        this.f8046a.m13266a(str, str2);
    }

    public void m13354a(String str, JSONObject jSONObject) {
        this.f8046a.m13267a(str, jSONObject);
    }

    public void m13355b(String str, nx nxVar) {
        this.f8046a.m13268b(str, nxVar);
        this.f8047b.remove(new SimpleEntry(str, nxVar));
    }

    public void m13356b(String str, JSONObject jSONObject) {
        this.f8046a.m13269b(str, jSONObject);
    }
}
