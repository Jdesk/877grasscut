package com.google.android.gms.p095b;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.android.gms.ads.internal.C2114u;
import com.google.android.gms.ads.internal.C2124e;
import com.google.android.gms.ads.internal.overlay.C2179g;
import com.google.android.gms.p095b.iu.C2673b;
import java.util.Map;
import org.json.JSONObject;

@sc
/* renamed from: com.google.android.gms.b.wx */
public interface wx extends C2114u, C2673b, pe {
    boolean m14951A();

    void m14952B();

    void m14953C();

    OnClickListener m14954D();

    mt m14955E();

    void m14956F();

    WebView m14957a();

    void m14958a(int i);

    void m14959a(Context context);

    void m14960a(Context context, ke keVar, mg mgVar);

    void m14961a(C2179g c2179g);

    void m14962a(ke keVar);

    void m14963a(mt mtVar);

    void m14964a(xd xdVar);

    void m14965a(String str);

    void m14966a(String str, String str2);

    void m14967a(String str, Map<String, ?> map);

    void m14968a(String str, JSONObject jSONObject);

    void m14969a(boolean z);

    View m14970b();

    void m14971b(int i);

    void m14972b(C2179g c2179g);

    void m14973b(String str);

    void m14974b(boolean z);

    void m14975c();

    void m14976c(boolean z);

    void m14977d();

    void m14978d(boolean z);

    void destroy();

    void m14979e();

    Activity m14980f();

    Context m14981g();

    Context getContext();

    LayoutParams getLayoutParams();

    void getLocationOnScreen(int[] iArr);

    int getMeasuredHeight();

    int getMeasuredWidth();

    ViewParent getParent();

    C2124e m14982h();

    C2179g m14983i();

    C2179g m14984j();

    ke m14985k();

    wy m14986l();

    void loadData(String str, String str2, String str3);

    void loadDataWithBaseURL(String str, String str2, String str3, String str4, String str5);

    void loadUrl(String str);

    boolean m14987m();

    void measure(int i, int i2);

    fm m14988n();

    wi m14989o();

    void onPause();

    void onResume();

    boolean m14990p();

    int m14991q();

    boolean m14992r();

    void m14993s();

    void setBackgroundColor(int i);

    void setOnClickListener(OnClickListener onClickListener);

    void setOnTouchListener(OnTouchListener onTouchListener);

    void setWebChromeClient(WebChromeClient webChromeClient);

    void setWebViewClient(WebViewClient webViewClient);

    void stopLoading();

    boolean m14994t();

    boolean m14995u();

    String m14996v();

    ww m14997w();

    me m14998x();

    mf m14999y();

    xd m15000z();
}
