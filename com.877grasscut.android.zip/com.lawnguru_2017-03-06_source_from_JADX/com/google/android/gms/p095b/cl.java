package com.google.android.gms.p095b;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.C2487g;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.safeparcel.C2149a;

/* renamed from: com.google.android.gms.b.cl */
public final class cl extends C2149a implements C2487g {
    public static final Creator<cl> CREATOR;
    public static final cl f6127a;
    private final Status f6128b;

    static {
        f6127a = new cl(Status.f9739a);
        CREATOR = new cn();
    }

    public cl(Status status) {
        this.f6128b = status;
    }

    public Status m9975a() {
        return this.f6128b;
    }

    public void writeToParcel(Parcel parcel, int i) {
        cn.m9990a(this, parcel, i);
    }
}
