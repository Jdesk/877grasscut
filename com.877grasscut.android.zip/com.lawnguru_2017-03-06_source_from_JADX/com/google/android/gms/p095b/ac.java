package com.google.android.gms.p095b;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.common.api.Status;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.b.ac */
public interface ac extends IInterface {

    /* renamed from: com.google.android.gms.b.ac.a */
    public static abstract class C2411a extends Binder implements ac {

        /* renamed from: com.google.android.gms.b.ac.a.a */
        private static class C2410a implements ac {
            private IBinder f5805a;

            C2410a(IBinder iBinder) {
                this.f5805a = iBinder;
            }

            public void m9599a(Status status) {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.api.internal.IStatusCallback");
                    if (status != null) {
                        obtain.writeInt(1);
                        status.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.f5805a.transact(1, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public IBinder asBinder() {
                return this.f5805a;
            }
        }

        public static ac m9600a(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.common.api.internal.IStatusCallback");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof ac)) ? new C2410a(iBinder) : (ac) queryLocalInterface;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
            switch (i) {
                case C5538a.ExpandableLayout_el_duration /*1*/:
                    parcel.enforceInterface("com.google.android.gms.common.api.internal.IStatusCallback");
                    m9598a(parcel.readInt() != 0 ? (Status) Status.CREATOR.createFromParcel(parcel) : null);
                    return true;
                case 1598968902:
                    parcel2.writeString("com.google.android.gms.common.api.internal.IStatusCallback");
                    return true;
                default:
                    return super.onTransact(i, parcel, parcel2, i2);
            }
        }
    }

    void m9598a(Status status);
}
