package com.google.android.gms.p095b;

import java.io.IOException;

/* renamed from: com.google.android.gms.b.hs */
public class hs extends IOException {
    public hs(String str) {
        super(str);
    }

    static hs m11756a() {
        return new hs("While parsing a protocol message, the input ended unexpectedly in the middle of a field.  This could mean either than the input has been truncated or that an embedded message misreported its own length.");
    }

    static hs m11757b() {
        return new hs("CodedInputStream encountered an embedded string or message which claimed to have negative size.");
    }

    static hs m11758c() {
        return new hs("CodedInputStream encountered a malformed varint.");
    }

    static hs m11759d() {
        return new hs("Protocol message contained an invalid tag (zero).");
    }

    static hs m11760e() {
        return new hs("Protocol message end-group tag did not match expected tag.");
    }

    static hs m11761f() {
        return new hs("Protocol message tag had invalid wire type.");
    }

    static hs m11762g() {
        return new hs("Protocol message had too many levels of nesting.  May be malicious.  Use CodedInputStream.setRecursionLimit() to increase the depth limit.");
    }
}
