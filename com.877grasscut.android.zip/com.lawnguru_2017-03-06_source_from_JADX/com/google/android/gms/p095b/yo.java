package com.google.android.gms.p095b;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

/* renamed from: com.google.android.gms.b.yo */
public class yo implements Parcelable {
    @Deprecated
    public static final Creator<yo> CREATOR;
    private String f9568a;
    private String f9569b;
    private String f9570c;

    /* renamed from: com.google.android.gms.b.yo.1 */
    class C31531 implements Creator<yo> {
        C31531() {
        }

        @Deprecated
        public yo m15612a(Parcel parcel) {
            return new yo(parcel);
        }

        @Deprecated
        public yo[] m15613a(int i) {
            return new yo[i];
        }

        @Deprecated
        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m15612a(parcel);
        }

        @Deprecated
        public /* synthetic */ Object[] newArray(int i) {
            return m15613a(i);
        }
    }

    static {
        CREATOR = new C31531();
    }

    @Deprecated
    yo(Parcel parcel) {
        m15614a(parcel);
    }

    @Deprecated
    private void m15614a(Parcel parcel) {
        this.f9568a = parcel.readString();
        this.f9569b = parcel.readString();
        this.f9570c = parcel.readString();
    }

    public String m15615a() {
        return this.f9568a;
    }

    public String m15616b() {
        return this.f9570c;
    }

    @Deprecated
    public int describeContents() {
        return 0;
    }

    @Deprecated
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.f9568a);
        parcel.writeString(this.f9569b);
        parcel.writeString(this.f9570c);
    }
}
