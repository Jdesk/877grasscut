package com.google.android.gms.p095b;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import com.google.android.gms.common.internal.C3234c;

/* renamed from: com.google.android.gms.b.fa */
public final class fa {
    private final Handler f6691a;
    private final Context f6692b;
    private final C2591a f6693c;

    /* renamed from: com.google.android.gms.b.fa.1 */
    class C25901 implements Runnable {
        final /* synthetic */ es f6687a;
        final /* synthetic */ int f6688b;
        final /* synthetic */ ek f6689c;
        final /* synthetic */ fa f6690d;

        /* renamed from: com.google.android.gms.b.fa.1.1 */
        class C25891 implements Runnable {
            final /* synthetic */ C25901 f6686a;

            C25891(C25901 c25901) {
                this.f6686a = c25901;
            }

            public void run() {
                if (this.f6686a.f6690d.f6693c.m11105a(this.f6686a.f6688b)) {
                    this.f6686a.f6687a.m10876d().m10332V();
                    this.f6686a.f6689c.m10636D().m10624a("Local AppMeasurementService processed last upload request");
                }
            }
        }

        C25901(fa faVar, es esVar, int i, ek ekVar) {
            this.f6690d = faVar;
            this.f6687a = esVar;
            this.f6688b = i;
            this.f6689c = ekVar;
        }

        public void run() {
            this.f6687a.m10843M();
            this.f6687a.m10841K();
            this.f6690d.f6691a.post(new C25891(this));
        }
    }

    /* renamed from: com.google.android.gms.b.fa.a */
    public interface C2591a {
        Context m11104a();

        boolean m11105a(int i);
    }

    public fa(C2591a c2591a) {
        this.f6692b = c2591a.m11104a();
        C3234c.m16042a(this.f6692b);
        this.f6693c = c2591a;
        this.f6691a = new Handler();
    }

    public static boolean m11107a(Context context, boolean z) {
        C3234c.m16042a((Object) context);
        return fh.m11203a(context, z ? "com.google.android.gms.measurement.PackageMeasurementService" : "com.google.android.gms.measurement.AppMeasurementService");
    }

    private ek m11109c() {
        return es.m10824a(this.f6692b).m10879f();
    }

    public int m11110a(Intent intent, int i, int i2) {
        es a = es.m10824a(this.f6692b);
        ek f = a.m10879f();
        if (intent == null) {
            f.m10667z().m10624a("AppMeasurementService started with null intent");
        } else {
            String action = intent.getAction();
            a.m10876d().m10332V();
            f.m10636D().m10626a("Local AppMeasurementService called. startId, action", Integer.valueOf(i2), action);
            if ("com.google.android.gms.measurement.UPLOAD".equals(action)) {
                a.m10881h().m10787a(new C25901(this, a, i2, f));
            }
        }
        return 2;
    }

    public IBinder m11111a(Intent intent) {
        if (intent == null) {
            m11109c().m10665x().m10624a("onBind called with null intent");
            return null;
        }
        String action = intent.getAction();
        if ("com.google.android.gms.measurement.START".equals(action)) {
            return new et(es.m10824a(this.f6692b));
        }
        m11109c().m10667z().m10625a("onBind received unknown action", action);
        return null;
    }

    public void m11112a() {
        es a = es.m10824a(this.f6692b);
        ek f = a.m10879f();
        a.m10876d().m10332V();
        f.m10636D().m10624a("Local AppMeasurementService is starting up");
    }

    public void m11113b() {
        es a = es.m10824a(this.f6692b);
        ek f = a.m10879f();
        a.m10876d().m10332V();
        f.m10636D().m10624a("Local AppMeasurementService is shutting down");
    }

    public boolean m11114b(Intent intent) {
        if (intent == null) {
            m11109c().m10665x().m10624a("onUnbind called with null intent");
        } else {
            m11109c().m10636D().m10625a("onUnbind called for intent. action", intent.getAction());
        }
        return true;
    }

    public void m11115c(Intent intent) {
        if (intent == null) {
            m11109c().m10665x().m10624a("onRebind called with null intent");
            return;
        }
        m11109c().m10636D().m10625a("onRebind called. action", intent.getAction());
    }
}
