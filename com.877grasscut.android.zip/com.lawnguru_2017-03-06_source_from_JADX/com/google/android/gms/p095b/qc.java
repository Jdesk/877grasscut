package com.google.android.gms.p095b;

import android.location.Location;
import com.google.android.gms.ads.mediation.C2250a;
import java.util.Date;
import java.util.Set;

@sc
/* renamed from: com.google.android.gms.b.qc */
public final class qc implements C2250a {
    private final Date f8155a;
    private final int f8156b;
    private final Set<String> f8157c;
    private final boolean f8158d;
    private final Location f8159e;
    private final int f8160f;
    private final boolean f8161g;

    public qc(Date date, int i, Set<String> set, Location location, boolean z, int i2, boolean z2) {
        this.f8155a = date;
        this.f8156b = i;
        this.f8157c = set;
        this.f8159e = location;
        this.f8158d = z;
        this.f8160f = i2;
        this.f8161g = z2;
    }

    public Date m13586a() {
        return this.f8155a;
    }

    public int m13587b() {
        return this.f8156b;
    }

    public Set<String> m13588c() {
        return this.f8157c;
    }

    public Location m13589d() {
        return this.f8159e;
    }

    public int m13590e() {
        return this.f8160f;
    }

    public boolean m13591f() {
        return this.f8158d;
    }

    public boolean m13592g() {
        return this.f8161g;
    }
}
