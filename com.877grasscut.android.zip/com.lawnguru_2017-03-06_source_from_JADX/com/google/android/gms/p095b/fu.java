package com.google.android.gms.p095b;

import com.google.android.gms.common.api.C3188a.C2312a.C2315d;

/* renamed from: com.google.android.gms.b.fu */
public final class fu implements C2315d {
    public static final fu f6855a;
    private final boolean f6856b;
    private final boolean f6857c;
    private final String f6858d;
    private final boolean f6859e;
    private final String f6860f;
    private final boolean f6861g;
    private final Long f6862h;
    private final Long f6863i;

    /* renamed from: com.google.android.gms.b.fu.a */
    public static final class C2619a {
        public fu m11446a() {
            return new fu(false, null, false, null, false, null, null, null);
        }
    }

    static {
        f6855a = new C2619a().m11446a();
    }

    private fu(boolean z, boolean z2, String str, boolean z3, String str2, boolean z4, Long l, Long l2) {
        this.f6856b = z;
        this.f6857c = z2;
        this.f6858d = str;
        this.f6859e = z3;
        this.f6861g = z4;
        this.f6860f = str2;
        this.f6862h = l;
        this.f6863i = l2;
    }

    public boolean m11447a() {
        return this.f6856b;
    }

    public boolean m11448b() {
        return this.f6857c;
    }

    public String m11449c() {
        return this.f6858d;
    }

    public boolean m11450d() {
        return this.f6859e;
    }

    public String m11451e() {
        return this.f6860f;
    }

    public boolean m11452f() {
        return this.f6861g;
    }

    public Long m11453g() {
        return this.f6862h;
    }

    public Long m11454h() {
        return this.f6863i;
    }
}
