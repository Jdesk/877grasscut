package com.google.android.gms.p095b;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.auth.api.credentials.Credential;
import com.google.android.gms.common.internal.safeparcel.C2149a;

/* renamed from: com.google.android.gms.b.aab */
public final class aab extends C2149a {
    public static final Creator<aab> CREATOR;
    final int f5697a;
    private final Credential f5698b;

    static {
        CREATOR = new aac();
    }

    aab(int i, Credential credential) {
        this.f5697a = i;
        this.f5698b = credential;
    }

    public Credential m9385a() {
        return this.f5698b;
    }

    public void writeToParcel(Parcel parcel, int i) {
        aac.m9386a(this, parcel, i);
    }
}
