package com.google.android.gms.p095b;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import com.google.android.gms.b.vm.AnonymousClass10;
import com.google.android.gms.b.vm.AnonymousClass11;
import com.google.android.gms.b.vm.AnonymousClass12;
import com.google.android.gms.b.vm.AnonymousClass13;
import com.google.android.gms.b.vm.AnonymousClass14;
import com.google.android.gms.b.vm.AnonymousClass15;
import com.google.android.gms.b.vm.AnonymousClass16;
import com.google.android.gms.b.vm.AnonymousClass17;
import com.google.android.gms.b.vm.AnonymousClass18;
import com.google.android.gms.p095b.vm.C3050b;
import com.google.android.gms.p095b.vm.C3052a;
import io.card.payment.BuildConfig;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Future;

@sc
/* renamed from: com.google.android.gms.b.vm */
public final class vm {

    /* renamed from: com.google.android.gms.b.vm.b */
    public interface C3050b {
        void m14548a(Bundle bundle);
    }

    /* renamed from: com.google.android.gms.b.vm.a */
    private static abstract class C3052a extends vj {
        private C3052a() {
        }

        public void m14624b() {
        }
    }

    /* renamed from: com.google.android.gms.b.vm.10 */
    class AnonymousClass10 extends C3052a {
        final /* synthetic */ Context f9075a;
        final /* synthetic */ C3050b f9076b;

        AnonymousClass10(Context context, C3050b c3050b) {
            this.f9075a = context;
            this.f9076b = c3050b;
            super();
        }

        public void m14625a() {
            SharedPreferences a = com.google.android.gms.p095b.vm.m14643a(this.f9075a);
            Bundle bundle = new Bundle();
            bundle.putString("content_url_hashes", a.getString("content_url_hashes", BuildConfig.FLAVOR));
            if (this.f9076b != null) {
                this.f9076b.m14548a(bundle);
            }
        }
    }

    /* renamed from: com.google.android.gms.b.vm.11 */
    class AnonymousClass11 extends C3052a {
        final /* synthetic */ Context f9077a;
        final /* synthetic */ String f9078b;

        AnonymousClass11(Context context, String str) {
            this.f9077a = context;
            this.f9078b = str;
            super();
        }

        public void m14626a() {
            Editor edit = com.google.android.gms.p095b.vm.m14643a(this.f9077a).edit();
            edit.putString("content_vertical_hashes", this.f9078b);
            edit.apply();
        }
    }

    /* renamed from: com.google.android.gms.b.vm.12 */
    class AnonymousClass12 extends C3052a {
        final /* synthetic */ Context f9079a;
        final /* synthetic */ boolean f9080b;

        AnonymousClass12(Context context, boolean z) {
            this.f9079a = context;
            this.f9080b = z;
            super();
        }

        public void m14627a() {
            Editor edit = com.google.android.gms.p095b.vm.m14643a(this.f9079a).edit();
            edit.putBoolean("auto_collect_location", this.f9080b);
            edit.apply();
        }
    }

    /* renamed from: com.google.android.gms.b.vm.13 */
    class AnonymousClass13 extends C3052a {
        final /* synthetic */ Context f9081a;
        final /* synthetic */ C3050b f9082b;

        AnonymousClass13(Context context, C3050b c3050b) {
            this.f9081a = context;
            this.f9082b = c3050b;
            super();
        }

        public void m14628a() {
            SharedPreferences a = com.google.android.gms.p095b.vm.m14643a(this.f9081a);
            Bundle bundle = new Bundle();
            bundle.putBoolean("auto_collect_location", a.getBoolean("auto_collect_location", false));
            if (this.f9082b != null) {
                this.f9082b.m14548a(bundle);
            }
        }
    }

    /* renamed from: com.google.android.gms.b.vm.14 */
    class AnonymousClass14 extends C3052a {
        final /* synthetic */ Context f9083a;
        final /* synthetic */ String f9084b;
        final /* synthetic */ long f9085c;

        AnonymousClass14(Context context, String str, long j) {
            this.f9083a = context;
            this.f9084b = str;
            this.f9085c = j;
            super();
        }

        public void m14629a() {
            Editor edit = com.google.android.gms.p095b.vm.m14643a(this.f9083a).edit();
            edit.putString("app_settings_json", this.f9084b);
            edit.putLong("app_settings_last_update_ms", this.f9085c);
            edit.apply();
        }
    }

    /* renamed from: com.google.android.gms.b.vm.15 */
    class AnonymousClass15 extends C3052a {
        final /* synthetic */ Context f9086a;
        final /* synthetic */ C3050b f9087b;

        AnonymousClass15(Context context, C3050b c3050b) {
            this.f9086a = context;
            this.f9087b = c3050b;
            super();
        }

        public void m14630a() {
            SharedPreferences a = com.google.android.gms.p095b.vm.m14643a(this.f9086a);
            Bundle bundle = new Bundle();
            bundle.putString("app_settings_json", a.getString("app_settings_json", BuildConfig.FLAVOR));
            bundle.putLong("app_settings_last_update_ms", a.getLong("app_settings_last_update_ms", 0));
            if (this.f9087b != null) {
                this.f9087b.m14548a(bundle);
            }
        }
    }

    /* renamed from: com.google.android.gms.b.vm.16 */
    class AnonymousClass16 extends C3052a {
        final /* synthetic */ Context f9088a;
        final /* synthetic */ long f9089b;

        AnonymousClass16(Context context, long j) {
            this.f9088a = context;
            this.f9089b = j;
            super();
        }

        public void m14631a() {
            Editor edit = com.google.android.gms.p095b.vm.m14643a(this.f9088a).edit();
            edit.putLong("app_last_background_time_ms", this.f9089b);
            edit.apply();
        }
    }

    /* renamed from: com.google.android.gms.b.vm.17 */
    class AnonymousClass17 extends C3052a {
        final /* synthetic */ Context f9090a;
        final /* synthetic */ C3050b f9091b;

        AnonymousClass17(Context context, C3050b c3050b) {
            this.f9090a = context;
            this.f9091b = c3050b;
            super();
        }

        public void m14632a() {
            SharedPreferences a = com.google.android.gms.p095b.vm.m14643a(this.f9090a);
            Bundle bundle = new Bundle();
            bundle.putLong("app_last_background_time_ms", a.getLong("app_last_background_time_ms", 0));
            if (this.f9091b != null) {
                this.f9091b.m14548a(bundle);
            }
        }
    }

    /* renamed from: com.google.android.gms.b.vm.18 */
    class AnonymousClass18 extends C3052a {
        final /* synthetic */ Context f9092a;
        final /* synthetic */ int f9093b;

        AnonymousClass18(Context context, int i) {
            this.f9092a = context;
            this.f9093b = i;
            super();
        }

        public void m14633a() {
            Editor edit = com.google.android.gms.p095b.vm.m14643a(this.f9092a).edit();
            edit.putInt("request_in_session_count", this.f9093b);
            edit.apply();
        }
    }

    /* renamed from: com.google.android.gms.b.vm.1 */
    class C30531 extends C3052a {
        final /* synthetic */ Context f9094a;
        final /* synthetic */ boolean f9095b;

        C30531(Context context, boolean z) {
            this.f9094a = context;
            this.f9095b = z;
            super();
        }

        public void m14634a() {
            Editor edit = vm.m14643a(this.f9094a).edit();
            edit.putBoolean("use_https", this.f9095b);
            edit.apply();
        }
    }

    /* renamed from: com.google.android.gms.b.vm.2 */
    class C30542 extends C3052a {
        final /* synthetic */ Context f9096a;
        final /* synthetic */ C3050b f9097b;

        C30542(Context context, C3050b c3050b) {
            this.f9096a = context;
            this.f9097b = c3050b;
            super();
        }

        public void m14635a() {
            SharedPreferences a = vm.m14643a(this.f9096a);
            Bundle bundle = new Bundle();
            bundle.putBoolean("use_https", a.getBoolean("use_https", true));
            if (this.f9097b != null) {
                this.f9097b.m14548a(bundle);
            }
        }
    }

    /* renamed from: com.google.android.gms.b.vm.3 */
    class C30553 extends C3052a {
        final /* synthetic */ Context f9098a;
        final /* synthetic */ C3050b f9099b;

        C30553(Context context, C3050b c3050b) {
            this.f9098a = context;
            this.f9099b = c3050b;
            super();
        }

        public void m14636a() {
            SharedPreferences a = vm.m14643a(this.f9098a);
            Bundle bundle = new Bundle();
            bundle.putInt("request_in_session_count", a.getInt("request_in_session_count", -1));
            if (this.f9099b != null) {
                this.f9099b.m14548a(bundle);
            }
        }
    }

    /* renamed from: com.google.android.gms.b.vm.4 */
    class C30564 extends C3052a {
        final /* synthetic */ Context f9100a;
        final /* synthetic */ long f9101b;

        C30564(Context context, long j) {
            this.f9100a = context;
            this.f9101b = j;
            super();
        }

        public void m14637a() {
            Editor edit = vm.m14643a(this.f9100a).edit();
            edit.putLong("first_ad_req_time_ms", this.f9101b);
            edit.apply();
        }
    }

    /* renamed from: com.google.android.gms.b.vm.5 */
    class C30575 extends C3052a {
        final /* synthetic */ Context f9102a;
        final /* synthetic */ C3050b f9103b;

        C30575(Context context, C3050b c3050b) {
            this.f9102a = context;
            this.f9103b = c3050b;
            super();
        }

        public void m14638a() {
            SharedPreferences a = vm.m14643a(this.f9102a);
            Bundle bundle = new Bundle();
            bundle.putLong("first_ad_req_time_ms", a.getLong("first_ad_req_time_ms", 0));
            if (this.f9103b != null) {
                this.f9103b.m14548a(bundle);
            }
        }
    }

    /* renamed from: com.google.android.gms.b.vm.6 */
    class C30586 extends C3052a {
        final /* synthetic */ Context f9104a;
        final /* synthetic */ C3050b f9105b;

        C30586(Context context, C3050b c3050b) {
            this.f9104a = context;
            this.f9105b = c3050b;
            super();
        }

        public void m14639a() {
            SharedPreferences a = vm.m14643a(this.f9104a);
            Bundle bundle = new Bundle();
            bundle.putInt("webview_cache_version", a.getInt("webview_cache_version", 0));
            if (this.f9105b != null) {
                this.f9105b.m14548a(bundle);
            }
        }
    }

    /* renamed from: com.google.android.gms.b.vm.7 */
    class C30597 extends C3052a {
        final /* synthetic */ Context f9106a;
        final /* synthetic */ boolean f9107b;

        C30597(Context context, boolean z) {
            this.f9106a = context;
            this.f9107b = z;
            super();
        }

        public void m14640a() {
            Editor edit = vm.m14643a(this.f9106a).edit();
            edit.putBoolean("content_url_opted_out", this.f9107b);
            edit.apply();
        }
    }

    /* renamed from: com.google.android.gms.b.vm.8 */
    class C30608 extends C3052a {
        final /* synthetic */ Context f9108a;
        final /* synthetic */ C3050b f9109b;

        C30608(Context context, C3050b c3050b) {
            this.f9108a = context;
            this.f9109b = c3050b;
            super();
        }

        public void m14641a() {
            SharedPreferences a = vm.m14643a(this.f9108a);
            Bundle bundle = new Bundle();
            bundle.putBoolean("content_url_opted_out", a.getBoolean("content_url_opted_out", true));
            if (this.f9109b != null) {
                this.f9109b.m14548a(bundle);
            }
        }
    }

    /* renamed from: com.google.android.gms.b.vm.9 */
    class C30619 extends C3052a {
        final /* synthetic */ Context f9110a;
        final /* synthetic */ String f9111b;

        C30619(Context context, String str) {
            this.f9110a = context;
            this.f9111b = str;
            super();
        }

        public void m14642a() {
            Editor edit = vm.m14643a(this.f9110a).edit();
            edit.putString("content_url_hashes", this.f9111b);
            edit.apply();
        }
    }

    public static SharedPreferences m14643a(Context context) {
        return context.getSharedPreferences("admob", 0);
    }

    public static Future m14644a(Context context, int i) {
        return (Future) new AnonymousClass18(context, i).m8331d();
    }

    public static Future m14645a(Context context, long j) {
        return (Future) new AnonymousClass16(context, j).m8331d();
    }

    public static Future m14646a(Context context, C3050b c3050b) {
        return (Future) new C30542(context, c3050b).m8331d();
    }

    public static Future m14647a(Context context, String str) {
        return (Future) new C30619(context, str).m8331d();
    }

    public static Future m14648a(Context context, String str, long j) {
        return (Future) new AnonymousClass14(context, str, j).m8331d();
    }

    public static Future m14649a(Context context, boolean z) {
        return (Future) new C30531(context, z).m8331d();
    }

    public static Future m14650b(Context context, long j) {
        return (Future) new C30564(context, j).m8331d();
    }

    public static Future m14651b(Context context, C3050b c3050b) {
        return (Future) new C30586(context, c3050b).m8331d();
    }

    public static Future m14652b(Context context, String str) {
        return (Future) new AnonymousClass11(context, str).m8331d();
    }

    public static Future m14653b(Context context, boolean z) {
        return (Future) new C30597(context, z).m8331d();
    }

    public static Future m14654c(Context context, C3050b c3050b) {
        return (Future) new C30608(context, c3050b).m8331d();
    }

    public static Future m14655c(Context context, boolean z) {
        return (Future) new AnonymousClass12(context, z).m8331d();
    }

    public static void m14656c(Context context, String str) {
        SharedPreferences a = vm.m14643a(context);
        Collection stringSet = a.getStringSet("never_pool_slots", Collections.emptySet());
        if (!stringSet.contains(str)) {
            Set hashSet = new HashSet(stringSet);
            hashSet.add(str);
            Editor edit = a.edit();
            edit.putStringSet("never_pool_slots", hashSet);
            edit.apply();
        }
    }

    public static Future m14657d(Context context, C3050b c3050b) {
        return (Future) new AnonymousClass10(context, c3050b).m8331d();
    }

    public static void m14658d(Context context, String str) {
        SharedPreferences a = vm.m14643a(context);
        Collection stringSet = a.getStringSet("never_pool_slots", Collections.emptySet());
        if (stringSet.contains(str)) {
            Set hashSet = new HashSet(stringSet);
            hashSet.remove(str);
            Editor edit = a.edit();
            edit.putStringSet("never_pool_slots", hashSet);
            edit.apply();
        }
    }

    public static Future m14659e(Context context, C3050b c3050b) {
        return (Future) new AnonymousClass13(context, c3050b).m8331d();
    }

    public static boolean m14660e(Context context, String str) {
        return vm.m14643a(context).getStringSet("never_pool_slots", Collections.emptySet()).contains(str);
    }

    public static Future m14661f(Context context, C3050b c3050b) {
        return (Future) new AnonymousClass15(context, c3050b).m8331d();
    }

    public static Future m14662g(Context context, C3050b c3050b) {
        return (Future) new AnonymousClass17(context, c3050b).m8331d();
    }

    public static Future m14663h(Context context, C3050b c3050b) {
        return (Future) new C30553(context, c3050b).m8331d();
    }

    public static Future m14664i(Context context, C3050b c3050b) {
        return (Future) new C30575(context, c3050b).m8331d();
    }
}
