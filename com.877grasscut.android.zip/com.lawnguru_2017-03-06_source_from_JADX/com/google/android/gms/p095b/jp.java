package com.google.android.gms.p095b;

import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.ads.internal.C2243w;
import com.google.android.gms.common.internal.safeparcel.C2149a;
import io.card.payment.BuildConfig;
import java.util.List;

@sc
/* renamed from: com.google.android.gms.b.jp */
public class jp extends C2149a {
    public static final Creator<jp> CREATOR;
    public final String f7316a;
    public final long f7317b;
    public final String f7318c;
    public final String f7319d;
    public final String f7320e;
    public final Bundle f7321f;
    public final boolean f7322g;

    static {
        CREATOR = new jq();
    }

    jp(String str, long j, String str2, String str3, String str4, Bundle bundle, boolean z) {
        this.f7316a = str;
        this.f7317b = j;
        if (str2 == null) {
            str2 = BuildConfig.FLAVOR;
        }
        this.f7318c = str2;
        if (str3 == null) {
            str3 = BuildConfig.FLAVOR;
        }
        this.f7319d = str3;
        if (str4 == null) {
            str4 = BuildConfig.FLAVOR;
        }
        this.f7320e = str4;
        if (bundle == null) {
            bundle = new Bundle();
        }
        this.f7321f = bundle;
        this.f7322g = z;
    }

    public static jp m12146a(Uri uri) {
        Throwable e;
        try {
            if (!"gcache".equals(uri.getScheme())) {
                return null;
            }
            List pathSegments = uri.getPathSegments();
            if (pathSegments.size() != 2) {
                wg.m14620e("Expected 2 path parts for namespace and id, found :" + pathSegments.size());
                return null;
            }
            String str = (String) pathSegments.get(0);
            String str2 = (String) pathSegments.get(1);
            String host = uri.getHost();
            String queryParameter = uri.getQueryParameter("url");
            boolean equals = "1".equals(uri.getQueryParameter("read_only"));
            String queryParameter2 = uri.getQueryParameter("expiration");
            long parseLong = queryParameter2 == null ? 0 : Long.parseLong(queryParameter2);
            Bundle bundle = new Bundle();
            for (String queryParameter22 : C2243w.m8788g().m14765a(uri)) {
                if (queryParameter22.startsWith("tag.")) {
                    bundle.putString(queryParameter22.substring("tag.".length()), uri.getQueryParameter(queryParameter22));
                }
            }
            return new jp(queryParameter, parseLong, host, str, str2, bundle, equals);
        } catch (NullPointerException e2) {
            e = e2;
            wg.m14618c("Unable to parse Uri into cache offering.", e);
            return null;
        } catch (NumberFormatException e3) {
            e = e3;
            wg.m14618c("Unable to parse Uri into cache offering.", e);
            return null;
        }
    }

    public static jp m12147a(String str) {
        return jp.m12146a(Uri.parse(str));
    }

    public void writeToParcel(Parcel parcel, int i) {
        jq.m12148a(this, parcel, i);
    }
}
