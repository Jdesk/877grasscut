package com.google.android.gms.p095b;

import com.google.android.gms.p095b.kv.C2714a;

@sc
/* renamed from: com.google.android.gms.b.kk */
public class kk extends C2714a {
    private long f7432a;

    public long m12299a() {
        return this.f7432a;
    }
}
