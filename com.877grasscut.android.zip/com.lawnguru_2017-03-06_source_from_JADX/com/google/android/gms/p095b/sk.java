package com.google.android.gms.p095b;

import com.google.android.gms.p095b.sf.C2984a;
import com.google.android.gms.p095b.ss.C2992a;
import java.lang.ref.WeakReference;

@sc
/* renamed from: com.google.android.gms.b.sk */
public final class sk extends C2992a {
    private final WeakReference<C2984a> f8581a;

    public sk(C2984a c2984a) {
        this.f8581a = new WeakReference(c2984a);
    }

    public void m14069a(sl slVar) {
        C2984a c2984a = (C2984a) this.f8581a.get();
        if (c2984a != null) {
            c2984a.m14022a(slVar);
        }
    }
}
