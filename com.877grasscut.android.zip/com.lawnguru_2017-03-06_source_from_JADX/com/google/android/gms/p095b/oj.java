package com.google.android.gms.p095b;

import android.text.TextUtils;
import com.google.android.gms.ads.internal.C2243w;
import java.util.Map;

@sc
/* renamed from: com.google.android.gms.b.oj */
class oj implements nx {
    oj() {
    }

    private int m13078a(Map<String, String> map) {
        int parseInt = Integer.parseInt((String) map.get("playbackState"));
        return (parseInt < 0 || 3 < parseInt) ? 0 : parseInt;
    }

    public void m13079a(wx wxVar, Map<String, String> map) {
        Throwable e;
        if (((Boolean) ly.by.m12563c()).booleanValue()) {
            xd xdVar;
            xd z = wxVar.m15000z();
            if (z == null) {
                try {
                    z = new xd(wxVar, Float.parseFloat((String) map.get("duration")));
                    wxVar.m14964a(z);
                    xdVar = z;
                } catch (NullPointerException e2) {
                    e = e2;
                    wg.m14616b("Unable to parse videoMeta message.", e);
                    C2243w.m8790i().m14562a(e, "VideoMetaGmsgHandler.onGmsg");
                    return;
                } catch (NumberFormatException e3) {
                    e = e3;
                    wg.m14616b("Unable to parse videoMeta message.", e);
                    C2243w.m8790i().m14562a(e, "VideoMetaGmsgHandler.onGmsg");
                    return;
                }
            }
            xdVar = z;
            boolean equals = "1".equals(map.get("muted"));
            float parseFloat = Float.parseFloat((String) map.get("currentTime"));
            int a = m13078a(map);
            String str = (String) map.get("aspectRatio");
            float parseFloat2 = TextUtils.isEmpty(str) ? 0.0f : Float.parseFloat(str);
            if (wg.m14614a(3)) {
                wg.m14615b(new StringBuilder(String.valueOf(str).length() + 79).append("Video Meta GMSG: isMuted : ").append(equals).append(" , playbackState : ").append(a).append(" , aspectRatio : ").append(str).toString());
            }
            xdVar.m15271a(parseFloat, a, equals, parseFloat2);
        }
    }
}
