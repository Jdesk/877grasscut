package com.google.android.gms.p095b;

import android.util.Log;
import com.google.android.gms.common.internal.C3275z;
import io.card.payment.BuildConfig;

/* renamed from: com.google.android.gms.b.bg */
public class bg {
    private final String f5897a;
    private final String f5898b;
    private final C3275z f5899c;
    private final int f5900d;

    private bg(String str, String str2) {
        this.f5898b = str2;
        this.f5897a = str;
        this.f5899c = new C3275z(str);
        this.f5900d = m9775a();
    }

    public bg(String str, String... strArr) {
        this(str, bg.m9776a(strArr));
    }

    private int m9775a() {
        int i = 2;
        while (7 >= i && !Log.isLoggable(this.f5897a, i)) {
            i++;
        }
        return i;
    }

    private static String m9776a(String... strArr) {
        if (strArr.length == 0) {
            return BuildConfig.FLAVOR;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append('[');
        for (String str : strArr) {
            if (stringBuilder.length() > 1) {
                stringBuilder.append(",");
            }
            stringBuilder.append(str);
        }
        stringBuilder.append(']').append(' ');
        return stringBuilder.toString();
    }

    public void m9777a(String str, Object... objArr) {
        if (m9778a(3)) {
            Log.d(this.f5897a, m9779b(str, objArr));
        }
    }

    public boolean m9778a(int i) {
        return this.f5900d <= i;
    }

    protected String m9779b(String str, Object... objArr) {
        if (objArr != null && objArr.length > 0) {
            str = String.format(str, objArr);
        }
        return this.f5898b.concat(str);
    }
}
