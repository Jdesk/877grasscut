package com.google.android.gms.p095b;

import android.os.Process;
import com.google.android.gms.ads.internal.C2243w;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

@sc
/* renamed from: com.google.android.gms.b.vn */
public final class vn {
    private static final ThreadPoolExecutor f9120a;
    private static final ThreadPoolExecutor f9121b;

    /* renamed from: com.google.android.gms.b.vn.1 */
    class C30621 implements Callable<Void> {
        final /* synthetic */ Runnable f9112a;

        C30621(Runnable runnable) {
            this.f9112a = runnable;
        }

        public Void m14665a() {
            this.f9112a.run();
            return null;
        }

        public /* synthetic */ Object call() {
            return m14665a();
        }
    }

    /* renamed from: com.google.android.gms.b.vn.2 */
    class C30632 implements Callable<Void> {
        final /* synthetic */ Runnable f9113a;

        C30632(Runnable runnable) {
            this.f9113a = runnable;
        }

        public Void m14666a() {
            this.f9113a.run();
            return null;
        }

        public /* synthetic */ Object call() {
            return m14666a();
        }
    }

    /* renamed from: com.google.android.gms.b.vn.3 */
    class C30643 implements Runnable {
        final /* synthetic */ wk f9114a;
        final /* synthetic */ Callable f9115b;

        C30643(wk wkVar, Callable callable) {
            this.f9114a = wkVar;
            this.f9115b = callable;
        }

        public void run() {
            try {
                Process.setThreadPriority(10);
                this.f9114a.m13283b(this.f9115b.call());
            } catch (Throwable e) {
                C2243w.m8790i().m14562a(e, "AdThreadPool.submit");
                this.f9114a.m13282a(e);
            }
        }
    }

    /* renamed from: com.google.android.gms.b.vn.4 */
    class C30654 implements Runnable {
        final /* synthetic */ wk f9116a;
        final /* synthetic */ Future f9117b;

        C30654(wk wkVar, Future future) {
            this.f9116a = wkVar;
            this.f9117b = future;
        }

        public void run() {
            if (this.f9116a.isCancelled()) {
                this.f9117b.cancel(true);
            }
        }
    }

    /* renamed from: com.google.android.gms.b.vn.5 */
    class C30665 implements ThreadFactory {
        final /* synthetic */ String f9118a;
        private final AtomicInteger f9119b;

        C30665(String str) {
            this.f9118a = str;
            this.f9119b = new AtomicInteger(1);
        }

        public Thread newThread(Runnable runnable) {
            String str = this.f9118a;
            return new Thread(runnable, new StringBuilder(String.valueOf(str).length() + 23).append("AdWorker(").append(str).append(") #").append(this.f9119b.getAndIncrement()).toString());
        }
    }

    static {
        f9120a = new ThreadPoolExecutor(10, 10, 1, TimeUnit.MINUTES, new LinkedBlockingQueue(), vn.m14671a("Default"));
        f9121b = new ThreadPoolExecutor(5, 5, 1, TimeUnit.MINUTES, new LinkedBlockingQueue(), vn.m14671a("Loader"));
        f9120a.allowCoreThreadTimeOut(true);
        f9121b.allowCoreThreadTimeOut(true);
    }

    public static wn<Void> m14667a(int i, Runnable runnable) {
        return i == 1 ? vn.m14670a(f9121b, new C30621(runnable)) : vn.m14670a(f9120a, new C30632(runnable));
    }

    public static wn<Void> m14668a(Runnable runnable) {
        return vn.m14667a(0, runnable);
    }

    public static <T> wn<T> m14669a(Callable<T> callable) {
        return vn.m14670a(f9120a, (Callable) callable);
    }

    public static <T> wn<T> m14670a(ExecutorService executorService, Callable<T> callable) {
        Object wkVar = new wk();
        try {
            wkVar.m13284b(new C30654(wkVar, executorService.submit(new C30643(wkVar, callable))));
        } catch (Throwable e) {
            wg.m14618c("Thread execution is rejected.", e);
            wkVar.cancel(true);
        }
        return wkVar;
    }

    private static ThreadFactory m14671a(String str) {
        return new C30665(str);
    }
}
