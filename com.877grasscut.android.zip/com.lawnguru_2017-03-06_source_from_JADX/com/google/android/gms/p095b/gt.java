package com.google.android.gms.p095b;

import com.google.android.gms.p095b.bo.C2446a;
import com.google.android.gms.p095b.bq.C2452a;
import io.techery.properratingbar.C5501a.C5500d;
import java.lang.reflect.Method;
import java.util.concurrent.ExecutionException;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.b.gt */
public class gt extends C2630if {
    private static volatile bt f6954i;
    private static final Object f6955j;
    private C2446a f6956k;

    static {
        f6954i = null;
        f6955j = new Object();
    }

    public gt(gm gmVar, String str, String str2, C2452a c2452a, int i, int i2, C2446a c2446a) {
        super(gmVar, str, str2, c2452a, i, i2);
        this.f6956k = null;
        this.f6956k = c2446a;
    }

    public static Boolean m11586a(C2446a c2446a) {
        boolean z = false;
        if (!go.m11578b(gt.m11588b(c2446a))) {
            return Boolean.valueOf(false);
        }
        if (!(c2446a == null || c2446a.f5913a == null || c2446a.f5913a.f5915a.intValue() != 3)) {
            z = true;
        }
        return Boolean.valueOf(z);
    }

    private void m11587a(int i) {
        boolean z = false;
        Method method = this.f;
        Object[] objArr = new Object[2];
        objArr[0] = this.b.m11552a();
        if (i == 2) {
            z = true;
        }
        objArr[1] = Boolean.valueOf(z);
        f6954i = new bt((String) method.invoke(null, objArr));
        if (go.m11578b(f6954i.f6018a) || f6954i.f6018a.equals("E")) {
            switch (i) {
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    String f = m11592f();
                    if (!go.m11578b(f)) {
                        f6954i.f6018a = f;
                    }
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    f6954i.f6018a = this.f6956k.f5914b.f5916a;
                default:
            }
        }
    }

    public static String m11588b(C2446a c2446a) {
        return (c2446a == null || c2446a.f5914b == null || go.m11578b(c2446a.f5914b.f5916a)) ? null : c2446a.f5914b.f5916a;
    }

    private boolean m11589c() {
        return f6954i == null || go.m11578b(f6954i.f6018a) || f6954i.f6018a.equals("E");
    }

    private int m11590d() {
        return !go.m11578b(gt.m11588b(this.f6956k)) ? 4 : (gt.m11586a(this.f6956k).booleanValue() && m11591e()) ? 3 : 2;
    }

    private boolean m11591e() {
        return this.b.m11564k() && ((Boolean) ly.bQ.m12563c()).booleanValue() && ((Boolean) ly.bR.m12563c()).booleanValue() && ((Boolean) ly.bP.m12563c()).booleanValue();
    }

    private String m11592f() {
        try {
            if (this.b.m11566m() != null) {
                this.b.m11566m().get();
            }
            C2452a l = this.b.m11565l();
            if (!(l == null || l.f5995w == null)) {
                return l.f5995w;
            }
        } catch (InterruptedException e) {
        } catch (ExecutionException e2) {
        }
        return null;
    }

    protected void m11593a() {
        if (m11589c()) {
            synchronized (f6955j) {
                int d = m11590d();
                if (d == 3) {
                    this.b.m11567n();
                }
                m11587a(d);
            }
        }
        synchronized (this.e) {
            if (f6954i != null) {
                this.e.f5995w = f6954i.f6018a;
                this.e.f5949C = Long.valueOf(f6954i.f6019b);
                this.e.f5948B = f6954i.f6020c;
                this.e.f5959M = f6954i.f6021d;
                this.e.f5960N = f6954i.f6022e;
            }
        }
    }
}
