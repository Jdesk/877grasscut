package com.google.android.gms.p095b;

/* renamed from: com.google.android.gms.b.tf */
public interface tf {
}
