package com.google.android.gms.p095b;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.C2233s;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.common.util.C3303m;
import com.google.android.gms.p095b.mw.C2767a;
import com.google.android.gms.p095b.rt.C2772a;
import com.google.android.gms.p095b.vb.C3048a;
import com.google.android.gms.p095b.vv.C2966a;
import com.google.android.gms.p095b.wm.C2964a;
import com.google.android.gms.p097a.C2060d;
import com.zopim.android.sdk.api.C5264R;
import io.card.payment.BuildConfig;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@sc
/* renamed from: com.google.android.gms.b.ru */
public class ru implements Callable<vb> {
    static long f8398a;
    private final Context f8399b;
    private final vv f8400c;
    private final C2233s f8401d;
    private final fm f8402e;
    private final rt f8403f;
    private final Object f8404g;
    private final C3048a f8405h;
    private final mg f8406i;
    private boolean f8407j;
    private int f8408k;
    private List<String> f8409l;
    private JSONObject f8410m;
    private String f8411n;

    /* renamed from: com.google.android.gms.b.ru.1 */
    class C29601 extends C2772a {
        final /* synthetic */ String f8374a;
        final /* synthetic */ C2969b f8375b;
        final /* synthetic */ wk f8376c;
        final /* synthetic */ ru f8377d;

        /* renamed from: com.google.android.gms.b.ru.1.1 */
        class C29591 implements nx {
            final /* synthetic */ pe f8372a;
            final /* synthetic */ C29601 f8373b;

            C29591(C29601 c29601, pe peVar) {
                this.f8373b = c29601;
                this.f8372a = peVar;
            }

            public void m13927a(wx wxVar, Map<String, String> map) {
                try {
                    JSONObject jSONObject;
                    int i;
                    String str = (String) map.get("success");
                    String str2 = (String) map.get("failure");
                    if (TextUtils.isEmpty(str2)) {
                        jSONObject = new JSONObject(str);
                        i = 1;
                    } else {
                        jSONObject = new JSONObject(str2);
                        i = 0;
                    }
                    if (this.f8373b.f8374a.equals(jSONObject.optString("ads_id", BuildConfig.FLAVOR))) {
                        this.f8372a.m13268b("/nativeAdPreProcess", this.f8373b.f8375b.f8397a);
                        if (i != 0) {
                            JSONArray optJSONArray = jSONObject.optJSONArray("ads");
                            if (optJSONArray == null || optJSONArray.length() <= 0) {
                                this.f8373b.f8377d.m13964a(3);
                                this.f8373b.f8376c.m13283b(null);
                                return;
                            }
                            this.f8373b.f8376c.m13283b(optJSONArray.getJSONObject(0));
                            return;
                        }
                        this.f8373b.f8377d.m13964a(0);
                        C3234c.m16048a(this.f8373b.f8377d.m13967b(), (Object) "Unable to set the ad state error!");
                        this.f8373b.f8376c.m13283b(null);
                    }
                } catch (Throwable e) {
                    wg.m14616b("Malformed native JSON response.", e);
                }
            }
        }

        C29601(ru ruVar, String str, C2969b c2969b, wk wkVar) {
            this.f8377d = ruVar;
            this.f8374a = str;
            this.f8375b = c2969b;
            this.f8376c = wkVar;
        }

        public void m13928a() {
            this.f8376c.m13283b(null);
        }

        public void m13929a(pe peVar) {
            nx c29591 = new C29591(this, peVar);
            this.f8375b.f8397a = c29591;
            peVar.m13265a("/nativeAdPreProcess", c29591);
            try {
                JSONObject jSONObject = new JSONObject(this.f8377d.f8405h.f8964b.f8601c);
                jSONObject.put("ads_id", this.f8374a);
                peVar.m13267a("google.afma.nativeAds.preProcessJsonGmsg", jSONObject);
            } catch (Throwable e) {
                wg.m14618c("Exception occurred while invoking javascript", e);
                this.f8376c.m13283b(null);
            }
        }
    }

    /* renamed from: com.google.android.gms.b.ru.2 */
    class C29612 implements Runnable {
        final /* synthetic */ wk f8378a;
        final /* synthetic */ String f8379b;
        final /* synthetic */ ru f8380c;

        C29612(ru ruVar, wk wkVar, String str) {
            this.f8380c = ruVar;
            this.f8378a = wkVar;
            this.f8379b = str;
        }

        public void run() {
            this.f8378a.m13283b((nn) this.f8380c.f8401d.m8692M().get(this.f8379b));
        }
    }

    /* renamed from: com.google.android.gms.b.ru.3 */
    class C29623 implements nx {
        final /* synthetic */ ms f8381a;
        final /* synthetic */ ru f8382b;

        C29623(ru ruVar, ms msVar) {
            this.f8382b = ruVar;
            this.f8381a = msVar;
        }

        public void m13930a(wx wxVar, Map<String, String> map) {
            this.f8382b.m13949a(this.f8381a, (String) map.get("asset"));
        }
    }

    /* renamed from: com.google.android.gms.b.ru.4 */
    class C29634 extends C2772a {
        final /* synthetic */ nx f8383a;

        C29634(ru ruVar, nx nxVar) {
            this.f8383a = nxVar;
        }

        public void m13931a(pe peVar) {
            peVar.m13265a("/nativeAdCustomClick", this.f8383a);
        }
    }

    /* renamed from: com.google.android.gms.b.ru.5 */
    class C29655 implements C2964a<List<mp>, mn> {
        final /* synthetic */ String f8384a;
        final /* synthetic */ Integer f8385b;
        final /* synthetic */ Integer f8386c;
        final /* synthetic */ int f8387d;
        final /* synthetic */ int f8388e;
        final /* synthetic */ int f8389f;
        final /* synthetic */ int f8390g;
        final /* synthetic */ boolean f8391h;

        C29655(ru ruVar, String str, Integer num, Integer num2, int i, int i2, int i3, int i4, boolean z) {
            this.f8384a = str;
            this.f8385b = num;
            this.f8386c = num2;
            this.f8387d = i;
            this.f8388e = i2;
            this.f8389f = i3;
            this.f8390g = i4;
            this.f8391h = z;
        }

        public mn m13933a(List<mp> list) {
            mn mnVar;
            if (list != null) {
                try {
                    if (!list.isEmpty()) {
                        mnVar = new mn(this.f8384a, ru.m13954b((List) list), this.f8385b, this.f8386c, this.f8387d > 0 ? Integer.valueOf(this.f8387d) : null, this.f8388e + this.f8389f, this.f8390g, this.f8391h);
                        return mnVar;
                    }
                } catch (Throwable e) {
                    wg.m14616b("Could not get attribution icon", e);
                    return null;
                }
            }
            mnVar = null;
            return mnVar;
        }

        public /* synthetic */ Object m13934a(Object obj) {
            return m13933a((List) obj);
        }
    }

    /* renamed from: com.google.android.gms.b.ru.6 */
    class C29676 implements C2966a<mp> {
        final /* synthetic */ boolean f8392a;
        final /* synthetic */ double f8393b;
        final /* synthetic */ boolean f8394c;
        final /* synthetic */ String f8395d;
        final /* synthetic */ ru f8396e;

        C29676(ru ruVar, boolean z, double d, boolean z2, String str) {
            this.f8396e = ruVar;
            this.f8392a = z;
            this.f8393b = d;
            this.f8394c = z2;
            this.f8395d = str;
        }

        public mp m13937a() {
            this.f8396e.m13965a(2, this.f8392a);
            return null;
        }

        @TargetApi(19)
        public mp m13938a(InputStream inputStream) {
            Bitmap decodeStream;
            Options options = new Options();
            options.inDensity = (int) (160.0d * this.f8393b);
            if (!this.f8394c) {
                options.inPreferredConfig = Config.RGB_565;
            }
            long uptimeMillis = SystemClock.uptimeMillis();
            try {
                decodeStream = BitmapFactory.decodeStream(inputStream, null, options);
            } catch (Throwable e) {
                wg.m14616b("Error grabbing image.", e);
                decodeStream = null;
            }
            if (decodeStream == null) {
                this.f8396e.m13965a(2, this.f8392a);
                return null;
            }
            long uptimeMillis2 = SystemClock.uptimeMillis();
            if (C3303m.m16343g() && vk.m14623b()) {
                int width = decodeStream.getWidth();
                int height = decodeStream.getHeight();
                vk.m14621a(new StringBuilder(C5264R.styleable.AppCompatTheme_ratingBarStyle).append("Decoded image w: ").append(width).append(" h:").append(height).append(" bytes: ").append(decodeStream.getAllocationByteCount()).append(" time: ").append(uptimeMillis2 - uptimeMillis).append(" on ui thread: ").append(Looper.getMainLooper().getThread() == Thread.currentThread()).toString());
            }
            return new mp(new BitmapDrawable(Resources.getSystem(), decodeStream), Uri.parse(this.f8395d), this.f8393b);
        }

        public /* synthetic */ Object m13939b() {
            return m13937a();
        }

        @TargetApi(19)
        public /* synthetic */ Object m13940b(InputStream inputStream) {
            return m13938a(inputStream);
        }
    }

    /* renamed from: com.google.android.gms.b.ru.a */
    public interface C2968a<T extends C2767a> {
        T m13941a(ru ruVar, JSONObject jSONObject);
    }

    /* renamed from: com.google.android.gms.b.ru.b */
    class C2969b {
        public nx f8397a;

        C2969b(ru ruVar) {
        }
    }

    static {
        f8398a = TimeUnit.SECONDS.toMillis(60);
    }

    public ru(Context context, C2233s c2233s, vv vvVar, fm fmVar, C3048a c3048a, mg mgVar) {
        this.f8404g = new Object();
        this.f8399b = context;
        this.f8401d = c2233s;
        this.f8400c = vvVar;
        this.f8405h = c3048a;
        this.f8402e = fmVar;
        this.f8406i = mgVar;
        this.f8403f = m13956a(context, c3048a, c2233s, fmVar);
        this.f8403f.m13920a();
        this.f8407j = false;
        this.f8408k = -2;
        this.f8409l = null;
        this.f8411n = null;
    }

    private C2767a m13942a(C2968a c2968a, JSONObject jSONObject, String str) {
        if (m13967b() || c2968a == null || jSONObject == null) {
            return null;
        }
        JSONObject jSONObject2 = jSONObject.getJSONObject("tracking_urls_and_actions");
        String[] c = m13955c(jSONObject2, "impression_tracking_urls");
        this.f8409l = c == null ? null : Arrays.asList(c);
        this.f8410m = jSONObject2.optJSONObject("active_view");
        this.f8411n = jSONObject.optString("debug_signals");
        C2767a a = c2968a.m13941a(this, jSONObject);
        if (a == null) {
            wg.m14617c("Failed to retrieve ad assets.");
            return null;
        }
        a.m12729a(new mx(this.f8399b, this.f8401d, this.f8403f, this.f8402e, jSONObject, a, this.f8405h.f8963a.f8565k, str));
        return a;
    }

    private wn<mp> m13944a(JSONObject jSONObject, boolean z, boolean z2) {
        String string = z ? jSONObject.getString("url") : jSONObject.optString("url");
        double optDouble = jSONObject.optDouble("scale", 1.0d);
        boolean optBoolean = jSONObject.optBoolean("is_transparent", true);
        if (!TextUtils.isEmpty(string)) {
            return z2 ? new wl(new mp(null, Uri.parse(string), optDouble)) : this.f8400c.m14865a(string, new C29676(this, z, optDouble, optBoolean, string));
        } else {
            m13965a(0, z);
            return new wl(null);
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static com.google.android.gms.p095b.wx m13945a(com.google.android.gms.p095b.wn<com.google.android.gms.p095b.wx> r3) {
        /*
        r0 = com.google.android.gms.p095b.ly.cm;	 Catch:{ InterruptedException -> 0x0016, ExecutionException -> 0x0025, TimeoutException -> 0x002e, CancellationException -> 0x002c }
        r0 = r0.m12563c();	 Catch:{ InterruptedException -> 0x0016, ExecutionException -> 0x0025, TimeoutException -> 0x002e, CancellationException -> 0x002c }
        r0 = (java.lang.Integer) r0;	 Catch:{ InterruptedException -> 0x0016, ExecutionException -> 0x0025, TimeoutException -> 0x002e, CancellationException -> 0x002c }
        r0 = r0.intValue();	 Catch:{ InterruptedException -> 0x0016, ExecutionException -> 0x0025, TimeoutException -> 0x002e, CancellationException -> 0x002c }
        r0 = (long) r0;	 Catch:{ InterruptedException -> 0x0016, ExecutionException -> 0x0025, TimeoutException -> 0x002e, CancellationException -> 0x002c }
        r2 = java.util.concurrent.TimeUnit.SECONDS;	 Catch:{ InterruptedException -> 0x0016, ExecutionException -> 0x0025, TimeoutException -> 0x002e, CancellationException -> 0x002c }
        r0 = r3.get(r0, r2);	 Catch:{ InterruptedException -> 0x0016, ExecutionException -> 0x0025, TimeoutException -> 0x002e, CancellationException -> 0x002c }
        r0 = (com.google.android.gms.p095b.wx) r0;	 Catch:{ InterruptedException -> 0x0016, ExecutionException -> 0x0025, TimeoutException -> 0x002e, CancellationException -> 0x002c }
    L_0x0015:
        return r0;
    L_0x0016:
        r0 = move-exception;
        r1 = "InterruptedException occurred while waiting for video to load";
        com.google.android.gms.p095b.wg.m14618c(r1, r0);
        r0 = java.lang.Thread.currentThread();
        r0.interrupt();
    L_0x0023:
        r0 = 0;
        goto L_0x0015;
    L_0x0025:
        r0 = move-exception;
    L_0x0026:
        r1 = "Exception occurred while waiting for video to load";
        com.google.android.gms.p095b.wg.m14618c(r1, r0);
        goto L_0x0023;
    L_0x002c:
        r0 = move-exception;
        goto L_0x0026;
    L_0x002e:
        r0 = move-exception;
        goto L_0x0026;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.b.ru.a(com.google.android.gms.b.wn):com.google.android.gms.b.wx");
    }

    private JSONObject m13947a(String str) {
        if (m13967b()) {
            return null;
        }
        wk wkVar = new wk();
        this.f8403f.m13921a(new C29601(this, str, new C2969b(this), wkVar));
        return (JSONObject) wkVar.get(f8398a, TimeUnit.MILLISECONDS);
    }

    private void m13948a(C2767a c2767a) {
        if (c2767a instanceof ms) {
            ms msVar = (ms) c2767a;
            C2969b c2969b = new C2969b(this);
            nx c29623 = new C29623(this, msVar);
            c2969b.f8397a = c29623;
            this.f8403f.m13921a(new C29634(this, c29623));
        }
    }

    private void m13949a(nj njVar, String str) {
        try {
            nm c = this.f8401d.m8711c(njVar.m12791l());
            if (c != null) {
                c.m12994a(njVar, str);
            }
        } catch (Throwable e) {
            wg.m14618c(new StringBuilder(String.valueOf(str).length() + 40).append("Failed to call onCustomClick for asset ").append(str).append(".").toString(), e);
        }
    }

    private vb m13952b(C2767a c2767a) {
        int i;
        synchronized (this.f8404g) {
            i = this.f8408k;
            if (c2767a == null && this.f8408k == -2) {
                i = 0;
            }
        }
        return new vb(this.f8405h.f8963a.f8557c, null, this.f8405h.f8964b.f8602d, i, this.f8405h.f8964b.f8604f, this.f8409l, this.f8405h.f8964b.f8610l, this.f8405h.f8964b.f8609k, this.f8405h.f8963a.f8563i, false, null, null, null, null, null, 0, this.f8405h.f8966d, this.f8405h.f8964b.f8605g, this.f8405h.f8968f, this.f8405h.f8969g, this.f8405h.f8964b.f8613o, this.f8410m, i != -2 ? null : c2767a, null, null, null, this.f8405h.f8964b.f8587F, this.f8405h.f8964b.f8588G, null, this.f8405h.f8964b.f8591J, this.f8411n);
    }

    private Integer m13953b(JSONObject jSONObject, String str) {
        try {
            JSONObject jSONObject2 = jSONObject.getJSONObject(str);
            return Integer.valueOf(Color.rgb(jSONObject2.getInt("r"), jSONObject2.getInt("g"), jSONObject2.getInt("b")));
        } catch (JSONException e) {
            return null;
        }
    }

    private static List<Drawable> m13954b(List<mp> list) {
        List<Drawable> arrayList = new ArrayList();
        for (mp a : list) {
            arrayList.add((Drawable) C2060d.m7974a(a.m12713a()));
        }
        return arrayList;
    }

    private String[] m13955c(JSONObject jSONObject, String str) {
        JSONArray optJSONArray = jSONObject.optJSONArray(str);
        if (optJSONArray == null) {
            return null;
        }
        String[] strArr = new String[optJSONArray.length()];
        for (int i = 0; i < optJSONArray.length(); i++) {
            strArr[i] = optJSONArray.getString(i);
        }
        return strArr;
    }

    rt m13956a(Context context, C3048a c3048a, C2233s c2233s, fm fmVar) {
        return new rt(context, c3048a, c2233s, fmVar);
    }

    protected C2968a m13957a(JSONObject jSONObject) {
        if (m13967b() || jSONObject == null) {
            return null;
        }
        String string = jSONObject.getString("template_id");
        boolean z = this.f8405h.f8963a.f8579y != null ? this.f8405h.f8963a.f8579y.f7771b : false;
        boolean z2 = this.f8405h.f8963a.f8579y != null ? this.f8405h.f8963a.f8579y.f7773d : false;
        if ("2".equals(string)) {
            return new rw(z, z2);
        }
        if ("1".equals(string)) {
            return new ry(z, z2);
        }
        if ("3".equals(string)) {
            String string2 = jSONObject.getString("custom_template_id");
            wk wkVar = new wk();
            vo.f9130a.post(new C29612(this, wkVar, string2));
            if (wkVar.get(f8398a, TimeUnit.MILLISECONDS) != null) {
                return new rz(z);
            }
            string2 = "No handler for custom template: ";
            String valueOf = String.valueOf(jSONObject.getString("custom_template_id"));
            wg.m14617c(valueOf.length() != 0 ? string2.concat(valueOf) : new String(string2));
        } else {
            m13964a(0);
        }
        return null;
    }

    rv m13958a(Context context, fm fmVar, C3048a c3048a, mg mgVar, C2233s c2233s) {
        return new rv(context, fmVar, c3048a, mgVar, c2233s);
    }

    public vb m13959a() {
        try {
            this.f8403f.m13922b();
            String c = m13968c();
            JSONObject a = m13947a(c);
            C2767a a2 = m13942a(m13957a(a), a, c);
            m13948a(a2);
            return m13952b(a2);
        } catch (CancellationException e) {
            if (!this.f8407j) {
                m13964a(0);
            }
            return m13952b(null);
        } catch (ExecutionException e2) {
            if (this.f8407j) {
                m13964a(0);
            }
            return m13952b(null);
        } catch (InterruptedException e3) {
            if (this.f8407j) {
                m13964a(0);
            }
            return m13952b(null);
        } catch (Throwable e4) {
            wg.m14618c("Malformed native JSON response.", e4);
            if (this.f8407j) {
                m13964a(0);
            }
            return m13952b(null);
        } catch (Throwable e42) {
            wg.m14618c("Timeout when loading native ad.", e42);
            if (this.f8407j) {
                m13964a(0);
            }
            return m13952b(null);
        }
    }

    public wn<wx> m13960a(JSONObject jSONObject, String str) {
        JSONObject optJSONObject = jSONObject.optJSONObject(str);
        if (optJSONObject == null) {
            return new wl(null);
        }
        if (!TextUtils.isEmpty(optJSONObject.optString("vast_xml"))) {
            return m13958a(this.f8399b, this.f8402e, this.f8405h, this.f8406i, this.f8401d).m13982a(optJSONObject);
        }
        wg.m14620e("Required field 'vast_xml' is missing");
        return new wl(null);
    }

    public wn<mp> m13961a(JSONObject jSONObject, String str, boolean z, boolean z2) {
        JSONObject jSONObject2 = z ? jSONObject.getJSONObject(str) : jSONObject.optJSONObject(str);
        if (jSONObject2 == null) {
            jSONObject2 = new JSONObject();
        }
        return m13944a(jSONObject2, z, z2);
    }

    public List<wn<mp>> m13962a(JSONObject jSONObject, String str, boolean z, boolean z2, boolean z3) {
        JSONArray jSONArray = z ? jSONObject.getJSONArray(str) : jSONObject.optJSONArray(str);
        List<wn<mp>> arrayList = new ArrayList();
        if (jSONArray == null || jSONArray.length() == 0) {
            m13965a(0, z);
            return arrayList;
        }
        int length = z3 ? jSONArray.length() : 1;
        for (int i = 0; i < length; i++) {
            JSONObject jSONObject2 = jSONArray.getJSONObject(i);
            if (jSONObject2 == null) {
                jSONObject2 = new JSONObject();
            }
            arrayList.add(m13944a(jSONObject2, z, z2));
        }
        return arrayList;
    }

    public Future<mp> m13963a(JSONObject jSONObject, String str, boolean z) {
        JSONObject jSONObject2 = jSONObject.getJSONObject(str);
        boolean optBoolean = jSONObject2.optBoolean("require", true);
        if (jSONObject2 == null) {
            jSONObject2 = new JSONObject();
        }
        return m13944a(jSONObject2, optBoolean, z);
    }

    public void m13964a(int i) {
        synchronized (this.f8404g) {
            this.f8407j = true;
            this.f8408k = i;
        }
    }

    public void m13965a(int i, boolean z) {
        if (z) {
            m13964a(i);
        }
    }

    public wn<mn> m13966b(JSONObject jSONObject) {
        JSONObject optJSONObject = jSONObject.optJSONObject("attribution");
        if (optJSONObject == null) {
            return new wl(null);
        }
        String optString = optJSONObject.optString("text");
        int optInt = optJSONObject.optInt("text_size", -1);
        Integer b = m13953b(optJSONObject, "text_color");
        Integer b2 = m13953b(optJSONObject, "bg_color");
        int optInt2 = optJSONObject.optInt("animation_ms", 1000);
        int optInt3 = optJSONObject.optInt("presentation_ms", 4000);
        int i = (this.f8405h.f8963a.f8579y == null || this.f8405h.f8963a.f8579y.f7770a < 2) ? 1 : this.f8405h.f8963a.f8579y.f7774e;
        boolean optBoolean = optJSONObject.optBoolean("allow_pub_rendering");
        List arrayList = new ArrayList();
        if (optJSONObject.optJSONArray("images") != null) {
            arrayList = m13962a(optJSONObject, "images", false, false, true);
        } else {
            arrayList.add(m13961a(optJSONObject, "image", false, false));
        }
        return wm.m14923a(wm.m14924a(arrayList), new C29655(this, optString, b2, b, optInt, optInt3, optInt2, i, optBoolean));
    }

    public boolean m13967b() {
        boolean z;
        synchronized (this.f8404g) {
            z = this.f8407j;
        }
        return z;
    }

    String m13968c() {
        return UUID.randomUUID().toString();
    }

    public /* synthetic */ Object call() {
        return m13959a();
    }
}
