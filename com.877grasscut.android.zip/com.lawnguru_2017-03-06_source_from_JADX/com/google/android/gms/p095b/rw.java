package com.google.android.gms.p095b;

import android.os.Bundle;
import com.google.android.gms.p095b.mw.C2767a;
import com.google.android.gms.p095b.ru.C2968a;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;
import org.json.JSONObject;

@sc
/* renamed from: com.google.android.gms.b.rw */
public class rw implements C2968a<mq> {
    private final boolean f8434a;
    private final boolean f8435b;

    public rw(boolean z, boolean z2) {
        this.f8434a = z;
        this.f8435b = z2;
    }

    public /* synthetic */ C2767a m13984a(ru ruVar, JSONObject jSONObject) {
        return m13985b(ruVar, jSONObject);
    }

    public mq m13985b(ru ruVar, JSONObject jSONObject) {
        List<wn> a = ruVar.m13962a(jSONObject, "images", true, this.f8434a, this.f8435b);
        Future a2 = ruVar.m13961a(jSONObject, "app_icon", true, this.f8434a);
        wn a3 = ruVar.m13960a(jSONObject, "video");
        Future b = ruVar.m13966b(jSONObject);
        List arrayList = new ArrayList();
        for (wn wnVar : a) {
            arrayList.add((mp) wnVar.get());
        }
        wx a4 = ru.m13945a(a3);
        return new mq(jSONObject.getString("headline"), arrayList, jSONObject.getString("body"), (nb) a2.get(), jSONObject.getString("call_to_action"), jSONObject.optDouble("rating", -1.0d), jSONObject.optString("store"), jSONObject.optString("price"), (mn) b.get(), new Bundle(), a4 != null ? a4.m15000z() : null, a4 != null ? a4.m14970b() : null);
    }
}
