package com.google.android.gms.p095b;

import android.app.PendingIntent;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C2149a;
import com.google.android.gms.location.C2499u;
import com.google.android.gms.location.C2499u.C2500a;
import com.google.android.gms.location.C2503v;
import com.google.android.gms.location.C2503v.C2504a;
import com.google.android.gms.p095b.cp.C2490a;

/* renamed from: com.google.android.gms.b.cx */
public class cx extends C2149a {
    public static final Creator<cx> CREATOR;
    int f6164a;
    cv f6165b;
    C2503v f6166c;
    PendingIntent f6167d;
    C2499u f6168e;
    cp f6169f;

    static {
        CREATOR = new cy();
    }

    cx(int i, cv cvVar, IBinder iBinder, PendingIntent pendingIntent, IBinder iBinder2, IBinder iBinder3) {
        cp cpVar = null;
        this.f6164a = i;
        this.f6165b = cvVar;
        this.f6166c = iBinder == null ? null : C2504a.m10088a(iBinder);
        this.f6167d = pendingIntent;
        this.f6168e = iBinder2 == null ? null : C2500a.m10081a(iBinder2);
        if (iBinder3 != null) {
            cpVar = C2490a.m9995a(iBinder3);
        }
        this.f6169f = cpVar;
    }

    public static cx m10099a(C2499u c2499u, cp cpVar) {
        return new cx(2, null, null, null, c2499u.asBinder(), cpVar != null ? cpVar.asBinder() : null);
    }

    public static cx m10100a(C2503v c2503v, cp cpVar) {
        return new cx(2, null, c2503v.asBinder(), null, null, cpVar != null ? cpVar.asBinder() : null);
    }

    IBinder m10101a() {
        return this.f6166c == null ? null : this.f6166c.asBinder();
    }

    IBinder m10102b() {
        return this.f6168e == null ? null : this.f6168e.asBinder();
    }

    IBinder m10103c() {
        return this.f6169f == null ? null : this.f6169f.asBinder();
    }

    public void writeToParcel(Parcel parcel, int i) {
        cy.m10104a(this, parcel, i);
    }
}
