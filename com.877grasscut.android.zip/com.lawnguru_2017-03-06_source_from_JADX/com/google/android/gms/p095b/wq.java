package com.google.android.gms.p095b;

/* renamed from: com.google.android.gms.b.wq */
public interface wq<T> {

    /* renamed from: com.google.android.gms.b.wq.c */
    public interface C2134c<T> {
        void m8266a(T t);
    }

    /* renamed from: com.google.android.gms.b.wq.a */
    public interface C2662a {
        void m11992a();
    }

    /* renamed from: com.google.android.gms.b.wq.b */
    public static class C3107b implements C2662a {
        public void m14934a() {
        }
    }

    void m13316a(C2134c<T> c2134c, C2662a c2662a);

    void m13317a(T t);
}
