package com.google.android.gms.p095b;

import com.google.android.gms.ads.p096b.C2077e.C2022a;
import com.google.android.gms.p095b.nk.C2796a;

@sc
/* renamed from: com.google.android.gms.b.np */
public class np extends C2796a {
    private final C2022a f7817a;

    public np(C2022a c2022a) {
        this.f7817a = c2022a;
    }

    public void m13002a(nf nfVar) {
        this.f7817a.m7888a(m13003b(nfVar));
    }

    ng m13003b(nf nfVar) {
        return new ng(nfVar);
    }
}
