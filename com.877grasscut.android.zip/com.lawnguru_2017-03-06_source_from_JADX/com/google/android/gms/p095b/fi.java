package com.google.android.gms.p095b;

import com.zopim.android.sdk.C5240R;
import com.zopim.android.sdk.api.C5264R;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.b.fi */
public interface fi {

    /* renamed from: com.google.android.gms.b.fi.a */
    public static final class C2597a extends hn<C2597a> {
        private static volatile C2597a[] f6725d;
        public Integer f6726a;
        public C2601e[] f6727b;
        public C2598b[] f6728c;

        public C2597a() {
            m11287c();
        }

        public static C2597a[] m11282b() {
            if (f6725d == null) {
                synchronized (hr.f7013c) {
                    if (f6725d == null) {
                        f6725d = new C2597a[0];
                    }
                }
            }
            return f6725d;
        }

        protected int m11283a() {
            int i = 0;
            int a = super.m9804a();
            if (this.f6726a != null) {
                a += hm.m11672b(1, this.f6726a.intValue());
            }
            if (this.f6727b != null && this.f6727b.length > 0) {
                int i2 = a;
                for (ht htVar : this.f6727b) {
                    if (htVar != null) {
                        i2 += hm.m11679c(2, htVar);
                    }
                }
                a = i2;
            }
            if (this.f6728c != null && this.f6728c.length > 0) {
                while (i < this.f6728c.length) {
                    ht htVar2 = this.f6728c[i];
                    if (htVar2 != null) {
                        a += hm.m11679c(3, htVar2);
                    }
                    i++;
                }
            }
            return a;
        }

        public C2597a m11284a(hl hlVar) {
            while (true) {
                int a = hlVar.m11636a();
                int a2;
                Object obj;
                switch (a) {
                    case C5538a.ExpandableLayout_android_orientation /*0*/:
                        break;
                    case C5500d.ProperRatingBar_prb_tickNormalDrawable /*8*/:
                        this.f6726a = Integer.valueOf(hlVar.m11650g());
                        continue;
                    case C5264R.styleable.Toolbar_titleMarginBottom /*18*/:
                        a2 = hw.m11773a(hlVar, 18);
                        a = this.f6727b == null ? 0 : this.f6727b.length;
                        obj = new C2601e[(a2 + a)];
                        if (a != 0) {
                            System.arraycopy(this.f6727b, 0, obj, 0, a);
                        }
                        while (a < obj.length - 1) {
                            obj[a] = new C2601e();
                            hlVar.m11638a(obj[a]);
                            hlVar.m11636a();
                            a++;
                        }
                        obj[a] = new C2601e();
                        hlVar.m11638a(obj[a]);
                        this.f6727b = obj;
                        continue;
                    case C5264R.styleable.Toolbar_logoDescription /*26*/:
                        a2 = hw.m11773a(hlVar, 26);
                        a = this.f6728c == null ? 0 : this.f6728c.length;
                        obj = new C2598b[(a2 + a)];
                        if (a != 0) {
                            System.arraycopy(this.f6728c, 0, obj, 0, a);
                        }
                        while (a < obj.length - 1) {
                            obj[a] = new C2598b();
                            hlVar.m11638a(obj[a]);
                            hlVar.m11636a();
                            a++;
                        }
                        obj[a] = new C2598b();
                        hlVar.m11638a(obj[a]);
                        this.f6728c = obj;
                        continue;
                    default:
                        if (!super.m9806a(hlVar, a)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public void m11285a(hm hmVar) {
            int i = 0;
            if (this.f6726a != null) {
                hmVar.m11700a(1, this.f6726a.intValue());
            }
            if (this.f6727b != null && this.f6727b.length > 0) {
                for (ht htVar : this.f6727b) {
                    if (htVar != null) {
                        hmVar.m11702a(2, htVar);
                    }
                }
            }
            if (this.f6728c != null && this.f6728c.length > 0) {
                while (i < this.f6728c.length) {
                    ht htVar2 = this.f6728c[i];
                    if (htVar2 != null) {
                        hmVar.m11702a(3, htVar2);
                    }
                    i++;
                }
            }
            super.m9805a(hmVar);
        }

        public /* synthetic */ ht m11286b(hl hlVar) {
            return m11284a(hlVar);
        }

        public C2597a m11287c() {
            this.f6726a = null;
            this.f6727b = C2601e.m11305b();
            this.f6728c = C2598b.m11288b();
            this.ag = null;
            this.ah = -1;
            return this;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof C2597a)) {
                return false;
            }
            C2597a c2597a = (C2597a) obj;
            if (this.f6726a == null) {
                if (c2597a.f6726a != null) {
                    return false;
                }
            } else if (!this.f6726a.equals(c2597a.f6726a)) {
                return false;
            }
            return (hr.m11754a(this.f6727b, c2597a.f6727b) && hr.m11754a(this.f6728c, c2597a.f6728c)) ? (this.ag == null || this.ag.m11740b()) ? c2597a.ag == null || c2597a.ag.m11740b() : this.ag.equals(c2597a.ag) : false;
        }

        public int hashCode() {
            int i = 0;
            int hashCode = ((((((this.f6726a == null ? 0 : this.f6726a.hashCode()) + ((getClass().getName().hashCode() + 527) * 31)) * 31) + hr.m11749a(this.f6727b)) * 31) + hr.m11749a(this.f6728c)) * 31;
            if (!(this.ag == null || this.ag.m11740b())) {
                i = this.ag.hashCode();
            }
            return hashCode + i;
        }
    }

    /* renamed from: com.google.android.gms.b.fi.b */
    public static final class C2598b extends hn<C2598b> {
        private static volatile C2598b[] f6729f;
        public Integer f6730a;
        public String f6731b;
        public C2599c[] f6732c;
        public Boolean f6733d;
        public C2600d f6734e;

        public C2598b() {
            m11293c();
        }

        public static C2598b[] m11288b() {
            if (f6729f == null) {
                synchronized (hr.f7013c) {
                    if (f6729f == null) {
                        f6729f = new C2598b[0];
                    }
                }
            }
            return f6729f;
        }

        protected int m11289a() {
            int a = super.m9804a();
            if (this.f6730a != null) {
                a += hm.m11672b(1, this.f6730a.intValue());
            }
            if (this.f6731b != null) {
                a += hm.m11674b(2, this.f6731b);
            }
            if (this.f6732c != null && this.f6732c.length > 0) {
                int i = a;
                for (ht htVar : this.f6732c) {
                    if (htVar != null) {
                        i += hm.m11679c(3, htVar);
                    }
                }
                a = i;
            }
            if (this.f6733d != null) {
                a += hm.m11675b(4, this.f6733d.booleanValue());
            }
            return this.f6734e != null ? a + hm.m11679c(5, this.f6734e) : a;
        }

        public C2598b m11290a(hl hlVar) {
            while (true) {
                int a = hlVar.m11636a();
                switch (a) {
                    case C5538a.ExpandableLayout_android_orientation /*0*/:
                        break;
                    case C5500d.ProperRatingBar_prb_tickNormalDrawable /*8*/:
                        this.f6730a = Integer.valueOf(hlVar.m11650g());
                        continue;
                    case C5264R.styleable.Toolbar_titleMarginBottom /*18*/:
                        this.f6731b = hlVar.m11652i();
                        continue;
                    case C5264R.styleable.Toolbar_logoDescription /*26*/:
                        int a2 = hw.m11773a(hlVar, 26);
                        a = this.f6732c == null ? 0 : this.f6732c.length;
                        Object obj = new C2599c[(a2 + a)];
                        if (a != 0) {
                            System.arraycopy(this.f6732c, 0, obj, 0, a);
                        }
                        while (a < obj.length - 1) {
                            obj[a] = new C2599c();
                            hlVar.m11638a(obj[a]);
                            hlVar.m11636a();
                            a++;
                        }
                        obj[a] = new C2599c();
                        hlVar.m11638a(obj[a]);
                        this.f6732c = obj;
                        continue;
                    case C5264R.styleable.AppCompatTheme_actionModeCutDrawable /*32*/:
                        this.f6733d = Boolean.valueOf(hlVar.m11651h());
                        continue;
                    case C5240R.styleable.AppCompatTheme_textAppearancePopupMenuHeader /*42*/:
                        if (this.f6734e == null) {
                            this.f6734e = new C2600d();
                        }
                        hlVar.m11638a(this.f6734e);
                        continue;
                    default:
                        if (!super.m9806a(hlVar, a)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public void m11291a(hm hmVar) {
            if (this.f6730a != null) {
                hmVar.m11700a(1, this.f6730a.intValue());
            }
            if (this.f6731b != null) {
                hmVar.m11703a(2, this.f6731b);
            }
            if (this.f6732c != null && this.f6732c.length > 0) {
                for (ht htVar : this.f6732c) {
                    if (htVar != null) {
                        hmVar.m11702a(3, htVar);
                    }
                }
            }
            if (this.f6733d != null) {
                hmVar.m11704a(4, this.f6733d.booleanValue());
            }
            if (this.f6734e != null) {
                hmVar.m11702a(5, this.f6734e);
            }
            super.m9805a(hmVar);
        }

        public /* synthetic */ ht m11292b(hl hlVar) {
            return m11290a(hlVar);
        }

        public C2598b m11293c() {
            this.f6730a = null;
            this.f6731b = null;
            this.f6732c = C2599c.m11294b();
            this.f6733d = null;
            this.f6734e = null;
            this.ag = null;
            this.ah = -1;
            return this;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof C2598b)) {
                return false;
            }
            C2598b c2598b = (C2598b) obj;
            if (this.f6730a == null) {
                if (c2598b.f6730a != null) {
                    return false;
                }
            } else if (!this.f6730a.equals(c2598b.f6730a)) {
                return false;
            }
            if (this.f6731b == null) {
                if (c2598b.f6731b != null) {
                    return false;
                }
            } else if (!this.f6731b.equals(c2598b.f6731b)) {
                return false;
            }
            if (!hr.m11754a(this.f6732c, c2598b.f6732c)) {
                return false;
            }
            if (this.f6733d == null) {
                if (c2598b.f6733d != null) {
                    return false;
                }
            } else if (!this.f6733d.equals(c2598b.f6733d)) {
                return false;
            }
            if (this.f6734e == null) {
                if (c2598b.f6734e != null) {
                    return false;
                }
            } else if (!this.f6734e.equals(c2598b.f6734e)) {
                return false;
            }
            return (this.ag == null || this.ag.m11740b()) ? c2598b.ag == null || c2598b.ag.m11740b() : this.ag.equals(c2598b.ag);
        }

        public int hashCode() {
            int i = 0;
            int hashCode = ((this.f6734e == null ? 0 : this.f6734e.hashCode()) + (((this.f6733d == null ? 0 : this.f6733d.hashCode()) + (((((this.f6731b == null ? 0 : this.f6731b.hashCode()) + (((this.f6730a == null ? 0 : this.f6730a.hashCode()) + ((getClass().getName().hashCode() + 527) * 31)) * 31)) * 31) + hr.m11749a(this.f6732c)) * 31)) * 31)) * 31;
            if (!(this.ag == null || this.ag.m11740b())) {
                i = this.ag.hashCode();
            }
            return hashCode + i;
        }
    }

    /* renamed from: com.google.android.gms.b.fi.c */
    public static final class C2599c extends hn<C2599c> {
        private static volatile C2599c[] f6735e;
        public C2602f f6736a;
        public C2600d f6737b;
        public Boolean f6738c;
        public String f6739d;

        public C2599c() {
            m11299c();
        }

        public static C2599c[] m11294b() {
            if (f6735e == null) {
                synchronized (hr.f7013c) {
                    if (f6735e == null) {
                        f6735e = new C2599c[0];
                    }
                }
            }
            return f6735e;
        }

        protected int m11295a() {
            int a = super.m9804a();
            if (this.f6736a != null) {
                a += hm.m11679c(1, this.f6736a);
            }
            if (this.f6737b != null) {
                a += hm.m11679c(2, this.f6737b);
            }
            if (this.f6738c != null) {
                a += hm.m11675b(3, this.f6738c.booleanValue());
            }
            return this.f6739d != null ? a + hm.m11674b(4, this.f6739d) : a;
        }

        public C2599c m11296a(hl hlVar) {
            while (true) {
                int a = hlVar.m11636a();
                switch (a) {
                    case C5538a.ExpandableLayout_android_orientation /*0*/:
                        break;
                    case C5500d.ProperRatingBar_prb_tickSpacing /*10*/:
                        if (this.f6736a == null) {
                            this.f6736a = new C2602f();
                        }
                        hlVar.m11638a(this.f6736a);
                        continue;
                    case C5264R.styleable.Toolbar_titleMarginBottom /*18*/:
                        if (this.f6737b == null) {
                            this.f6737b = new C2600d();
                        }
                        hlVar.m11638a(this.f6737b);
                        continue;
                    case C5264R.styleable.Toolbar_navigationIcon /*24*/:
                        this.f6738c = Boolean.valueOf(hlVar.m11651h());
                        continue;
                    case C5264R.styleable.AppCompatTheme_actionModePasteDrawable /*34*/:
                        this.f6739d = hlVar.m11652i();
                        continue;
                    default:
                        if (!super.m9806a(hlVar, a)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public void m11297a(hm hmVar) {
            if (this.f6736a != null) {
                hmVar.m11702a(1, this.f6736a);
            }
            if (this.f6737b != null) {
                hmVar.m11702a(2, this.f6737b);
            }
            if (this.f6738c != null) {
                hmVar.m11704a(3, this.f6738c.booleanValue());
            }
            if (this.f6739d != null) {
                hmVar.m11703a(4, this.f6739d);
            }
            super.m9805a(hmVar);
        }

        public /* synthetic */ ht m11298b(hl hlVar) {
            return m11296a(hlVar);
        }

        public C2599c m11299c() {
            this.f6736a = null;
            this.f6737b = null;
            this.f6738c = null;
            this.f6739d = null;
            this.ag = null;
            this.ah = -1;
            return this;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof C2599c)) {
                return false;
            }
            C2599c c2599c = (C2599c) obj;
            if (this.f6736a == null) {
                if (c2599c.f6736a != null) {
                    return false;
                }
            } else if (!this.f6736a.equals(c2599c.f6736a)) {
                return false;
            }
            if (this.f6737b == null) {
                if (c2599c.f6737b != null) {
                    return false;
                }
            } else if (!this.f6737b.equals(c2599c.f6737b)) {
                return false;
            }
            if (this.f6738c == null) {
                if (c2599c.f6738c != null) {
                    return false;
                }
            } else if (!this.f6738c.equals(c2599c.f6738c)) {
                return false;
            }
            if (this.f6739d == null) {
                if (c2599c.f6739d != null) {
                    return false;
                }
            } else if (!this.f6739d.equals(c2599c.f6739d)) {
                return false;
            }
            return (this.ag == null || this.ag.m11740b()) ? c2599c.ag == null || c2599c.ag.m11740b() : this.ag.equals(c2599c.ag);
        }

        public int hashCode() {
            int i = 0;
            int hashCode = ((this.f6739d == null ? 0 : this.f6739d.hashCode()) + (((this.f6738c == null ? 0 : this.f6738c.hashCode()) + (((this.f6737b == null ? 0 : this.f6737b.hashCode()) + (((this.f6736a == null ? 0 : this.f6736a.hashCode()) + ((getClass().getName().hashCode() + 527) * 31)) * 31)) * 31)) * 31)) * 31;
            if (!(this.ag == null || this.ag.m11740b())) {
                i = this.ag.hashCode();
            }
            return hashCode + i;
        }
    }

    /* renamed from: com.google.android.gms.b.fi.d */
    public static final class C2600d extends hn<C2600d> {
        public Integer f6740a;
        public Boolean f6741b;
        public String f6742c;
        public String f6743d;
        public String f6744e;

        public C2600d() {
            m11303b();
        }

        protected int m11300a() {
            int a = super.m9804a();
            if (this.f6740a != null) {
                a += hm.m11672b(1, this.f6740a.intValue());
            }
            if (this.f6741b != null) {
                a += hm.m11675b(2, this.f6741b.booleanValue());
            }
            if (this.f6742c != null) {
                a += hm.m11674b(3, this.f6742c);
            }
            if (this.f6743d != null) {
                a += hm.m11674b(4, this.f6743d);
            }
            return this.f6744e != null ? a + hm.m11674b(5, this.f6744e) : a;
        }

        public C2600d m11301a(hl hlVar) {
            while (true) {
                int a = hlVar.m11636a();
                switch (a) {
                    case C5538a.ExpandableLayout_android_orientation /*0*/:
                        break;
                    case C5500d.ProperRatingBar_prb_tickNormalDrawable /*8*/:
                        a = hlVar.m11650g();
                        switch (a) {
                            case C5538a.ExpandableLayout_android_orientation /*0*/:
                            case C5538a.ExpandableLayout_el_duration /*1*/:
                            case C5538a.ExpandableLayout_el_expanded /*2*/:
                            case C5538a.ExpandableLayout_layout_expandable /*3*/:
                            case C5500d.ProperRatingBar_prb_clickable /*4*/:
                                this.f6740a = Integer.valueOf(a);
                                break;
                            default:
                                continue;
                        }
                    case C5264R.styleable.Toolbar_titleMarginEnd /*16*/:
                        this.f6741b = Boolean.valueOf(hlVar.m11651h());
                        continue;
                    case C5264R.styleable.Toolbar_logoDescription /*26*/:
                        this.f6742c = hlVar.m11652i();
                        continue;
                    case C5264R.styleable.AppCompatTheme_actionModePasteDrawable /*34*/:
                        this.f6743d = hlVar.m11652i();
                        continue;
                    case C5240R.styleable.AppCompatTheme_textAppearancePopupMenuHeader /*42*/:
                        this.f6744e = hlVar.m11652i();
                        continue;
                    default:
                        if (!super.m9806a(hlVar, a)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public void m11302a(hm hmVar) {
            if (this.f6740a != null) {
                hmVar.m11700a(1, this.f6740a.intValue());
            }
            if (this.f6741b != null) {
                hmVar.m11704a(2, this.f6741b.booleanValue());
            }
            if (this.f6742c != null) {
                hmVar.m11703a(3, this.f6742c);
            }
            if (this.f6743d != null) {
                hmVar.m11703a(4, this.f6743d);
            }
            if (this.f6744e != null) {
                hmVar.m11703a(5, this.f6744e);
            }
            super.m9805a(hmVar);
        }

        public C2600d m11303b() {
            this.f6741b = null;
            this.f6742c = null;
            this.f6743d = null;
            this.f6744e = null;
            this.ag = null;
            this.ah = -1;
            return this;
        }

        public /* synthetic */ ht m11304b(hl hlVar) {
            return m11301a(hlVar);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof C2600d)) {
                return false;
            }
            C2600d c2600d = (C2600d) obj;
            if (this.f6740a == null) {
                if (c2600d.f6740a != null) {
                    return false;
                }
            } else if (!this.f6740a.equals(c2600d.f6740a)) {
                return false;
            }
            if (this.f6741b == null) {
                if (c2600d.f6741b != null) {
                    return false;
                }
            } else if (!this.f6741b.equals(c2600d.f6741b)) {
                return false;
            }
            if (this.f6742c == null) {
                if (c2600d.f6742c != null) {
                    return false;
                }
            } else if (!this.f6742c.equals(c2600d.f6742c)) {
                return false;
            }
            if (this.f6743d == null) {
                if (c2600d.f6743d != null) {
                    return false;
                }
            } else if (!this.f6743d.equals(c2600d.f6743d)) {
                return false;
            }
            if (this.f6744e == null) {
                if (c2600d.f6744e != null) {
                    return false;
                }
            } else if (!this.f6744e.equals(c2600d.f6744e)) {
                return false;
            }
            return (this.ag == null || this.ag.m11740b()) ? c2600d.ag == null || c2600d.ag.m11740b() : this.ag.equals(c2600d.ag);
        }

        public int hashCode() {
            int i = 0;
            int hashCode = ((this.f6744e == null ? 0 : this.f6744e.hashCode()) + (((this.f6743d == null ? 0 : this.f6743d.hashCode()) + (((this.f6742c == null ? 0 : this.f6742c.hashCode()) + (((this.f6741b == null ? 0 : this.f6741b.hashCode()) + (((this.f6740a == null ? 0 : this.f6740a.intValue()) + ((getClass().getName().hashCode() + 527) * 31)) * 31)) * 31)) * 31)) * 31)) * 31;
            if (!(this.ag == null || this.ag.m11740b())) {
                i = this.ag.hashCode();
            }
            return hashCode + i;
        }
    }

    /* renamed from: com.google.android.gms.b.fi.e */
    public static final class C2601e extends hn<C2601e> {
        private static volatile C2601e[] f6745d;
        public Integer f6746a;
        public String f6747b;
        public C2599c f6748c;

        public C2601e() {
            m11310c();
        }

        public static C2601e[] m11305b() {
            if (f6745d == null) {
                synchronized (hr.f7013c) {
                    if (f6745d == null) {
                        f6745d = new C2601e[0];
                    }
                }
            }
            return f6745d;
        }

        protected int m11306a() {
            int a = super.m9804a();
            if (this.f6746a != null) {
                a += hm.m11672b(1, this.f6746a.intValue());
            }
            if (this.f6747b != null) {
                a += hm.m11674b(2, this.f6747b);
            }
            return this.f6748c != null ? a + hm.m11679c(3, this.f6748c) : a;
        }

        public C2601e m11307a(hl hlVar) {
            while (true) {
                int a = hlVar.m11636a();
                switch (a) {
                    case C5538a.ExpandableLayout_android_orientation /*0*/:
                        break;
                    case C5500d.ProperRatingBar_prb_tickNormalDrawable /*8*/:
                        this.f6746a = Integer.valueOf(hlVar.m11650g());
                        continue;
                    case C5264R.styleable.Toolbar_titleMarginBottom /*18*/:
                        this.f6747b = hlVar.m11652i();
                        continue;
                    case C5264R.styleable.Toolbar_logoDescription /*26*/:
                        if (this.f6748c == null) {
                            this.f6748c = new C2599c();
                        }
                        hlVar.m11638a(this.f6748c);
                        continue;
                    default:
                        if (!super.m9806a(hlVar, a)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public void m11308a(hm hmVar) {
            if (this.f6746a != null) {
                hmVar.m11700a(1, this.f6746a.intValue());
            }
            if (this.f6747b != null) {
                hmVar.m11703a(2, this.f6747b);
            }
            if (this.f6748c != null) {
                hmVar.m11702a(3, this.f6748c);
            }
            super.m9805a(hmVar);
        }

        public /* synthetic */ ht m11309b(hl hlVar) {
            return m11307a(hlVar);
        }

        public C2601e m11310c() {
            this.f6746a = null;
            this.f6747b = null;
            this.f6748c = null;
            this.ag = null;
            this.ah = -1;
            return this;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof C2601e)) {
                return false;
            }
            C2601e c2601e = (C2601e) obj;
            if (this.f6746a == null) {
                if (c2601e.f6746a != null) {
                    return false;
                }
            } else if (!this.f6746a.equals(c2601e.f6746a)) {
                return false;
            }
            if (this.f6747b == null) {
                if (c2601e.f6747b != null) {
                    return false;
                }
            } else if (!this.f6747b.equals(c2601e.f6747b)) {
                return false;
            }
            if (this.f6748c == null) {
                if (c2601e.f6748c != null) {
                    return false;
                }
            } else if (!this.f6748c.equals(c2601e.f6748c)) {
                return false;
            }
            return (this.ag == null || this.ag.m11740b()) ? c2601e.ag == null || c2601e.ag.m11740b() : this.ag.equals(c2601e.ag);
        }

        public int hashCode() {
            int i = 0;
            int hashCode = ((this.f6748c == null ? 0 : this.f6748c.hashCode()) + (((this.f6747b == null ? 0 : this.f6747b.hashCode()) + (((this.f6746a == null ? 0 : this.f6746a.hashCode()) + ((getClass().getName().hashCode() + 527) * 31)) * 31)) * 31)) * 31;
            if (!(this.ag == null || this.ag.m11740b())) {
                i = this.ag.hashCode();
            }
            return hashCode + i;
        }
    }

    /* renamed from: com.google.android.gms.b.fi.f */
    public static final class C2602f extends hn<C2602f> {
        public Integer f6749a;
        public String f6750b;
        public Boolean f6751c;
        public String[] f6752d;

        public C2602f() {
            m11314b();
        }

        protected int m11311a() {
            int i = 0;
            int a = super.m9804a();
            if (this.f6749a != null) {
                a += hm.m11672b(1, this.f6749a.intValue());
            }
            if (this.f6750b != null) {
                a += hm.m11674b(2, this.f6750b);
            }
            if (this.f6751c != null) {
                a += hm.m11675b(3, this.f6751c.booleanValue());
            }
            if (this.f6752d == null || this.f6752d.length <= 0) {
                return a;
            }
            int i2 = 0;
            int i3 = 0;
            while (i < this.f6752d.length) {
                String str = this.f6752d[i];
                if (str != null) {
                    i3++;
                    i2 += hm.m11677b(str);
                }
                i++;
            }
            return (a + i2) + (i3 * 1);
        }

        public C2602f m11312a(hl hlVar) {
            while (true) {
                int a = hlVar.m11636a();
                switch (a) {
                    case C5538a.ExpandableLayout_android_orientation /*0*/:
                        break;
                    case C5500d.ProperRatingBar_prb_tickNormalDrawable /*8*/:
                        a = hlVar.m11650g();
                        switch (a) {
                            case C5538a.ExpandableLayout_android_orientation /*0*/:
                            case C5538a.ExpandableLayout_el_duration /*1*/:
                            case C5538a.ExpandableLayout_el_expanded /*2*/:
                            case C5538a.ExpandableLayout_layout_expandable /*3*/:
                            case C5500d.ProperRatingBar_prb_clickable /*4*/:
                            case C5500d.ProperRatingBar_prb_symbolicTick /*5*/:
                            case C5500d.ProperRatingBar_prb_symbolicTickNormalColor /*6*/:
                                this.f6749a = Integer.valueOf(a);
                                break;
                            default:
                                continue;
                        }
                    case C5264R.styleable.Toolbar_titleMarginBottom /*18*/:
                        this.f6750b = hlVar.m11652i();
                        continue;
                    case C5264R.styleable.Toolbar_navigationIcon /*24*/:
                        this.f6751c = Boolean.valueOf(hlVar.m11651h());
                        continue;
                    case C5264R.styleable.AppCompatTheme_actionModePasteDrawable /*34*/:
                        int a2 = hw.m11773a(hlVar, 34);
                        a = this.f6752d == null ? 0 : this.f6752d.length;
                        Object obj = new String[(a2 + a)];
                        if (a != 0) {
                            System.arraycopy(this.f6752d, 0, obj, 0, a);
                        }
                        while (a < obj.length - 1) {
                            obj[a] = hlVar.m11652i();
                            hlVar.m11636a();
                            a++;
                        }
                        obj[a] = hlVar.m11652i();
                        this.f6752d = obj;
                        continue;
                    default:
                        if (!super.m9806a(hlVar, a)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public void m11313a(hm hmVar) {
            if (this.f6749a != null) {
                hmVar.m11700a(1, this.f6749a.intValue());
            }
            if (this.f6750b != null) {
                hmVar.m11703a(2, this.f6750b);
            }
            if (this.f6751c != null) {
                hmVar.m11704a(3, this.f6751c.booleanValue());
            }
            if (this.f6752d != null && this.f6752d.length > 0) {
                for (String str : this.f6752d) {
                    if (str != null) {
                        hmVar.m11703a(4, str);
                    }
                }
            }
            super.m9805a(hmVar);
        }

        public C2602f m11314b() {
            this.f6750b = null;
            this.f6751c = null;
            this.f6752d = hw.f7025j;
            this.ag = null;
            this.ah = -1;
            return this;
        }

        public /* synthetic */ ht m11315b(hl hlVar) {
            return m11312a(hlVar);
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof C2602f)) {
                return false;
            }
            C2602f c2602f = (C2602f) obj;
            if (this.f6749a == null) {
                if (c2602f.f6749a != null) {
                    return false;
                }
            } else if (!this.f6749a.equals(c2602f.f6749a)) {
                return false;
            }
            if (this.f6750b == null) {
                if (c2602f.f6750b != null) {
                    return false;
                }
            } else if (!this.f6750b.equals(c2602f.f6750b)) {
                return false;
            }
            if (this.f6751c == null) {
                if (c2602f.f6751c != null) {
                    return false;
                }
            } else if (!this.f6751c.equals(c2602f.f6751c)) {
                return false;
            }
            return hr.m11754a(this.f6752d, c2602f.f6752d) ? (this.ag == null || this.ag.m11740b()) ? c2602f.ag == null || c2602f.ag.m11740b() : this.ag.equals(c2602f.ag) : false;
        }

        public int hashCode() {
            int i = 0;
            int hashCode = ((((this.f6751c == null ? 0 : this.f6751c.hashCode()) + (((this.f6750b == null ? 0 : this.f6750b.hashCode()) + (((this.f6749a == null ? 0 : this.f6749a.intValue()) + ((getClass().getName().hashCode() + 527) * 31)) * 31)) * 31)) * 31) + hr.m11749a(this.f6752d)) * 31;
            if (!(this.ag == null || this.ag.m11740b())) {
                i = this.ag.hashCode();
            }
            return hashCode + i;
        }
    }
}
