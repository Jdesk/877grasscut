package com.google.android.gms.p095b;

@sc
/* renamed from: com.google.android.gms.b.vq */
public interface vq<T> {
    void m8325c();

    T m8326d();
}
