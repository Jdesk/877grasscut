package com.google.android.gms.p095b;

import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.p099d.C2086a;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;

@sc
/* renamed from: com.google.android.gms.b.kd */
public class kd {
    public static final kd f7382a;

    static {
        f7382a = new kd();
    }

    protected kd() {
    }

    public static kd m12230a() {
        return f7382a;
    }

    public ka m12231a(Context context, ld ldVar) {
        Date a = ldVar.m12432a();
        long time = a != null ? a.getTime() : -1;
        String b = ldVar.m12434b();
        int c = ldVar.m12435c();
        Collection d = ldVar.m12436d();
        List unmodifiableList = !d.isEmpty() ? Collections.unmodifiableList(new ArrayList(d)) : null;
        boolean a2 = ldVar.m12433a(context);
        int l = ldVar.m12444l();
        Location e = ldVar.m12437e();
        Bundle a3 = ldVar.m12431a(AdMobAdapter.class);
        boolean f = ldVar.m12438f();
        String g = ldVar.m12439g();
        C2086a i = ldVar.m12441i();
        lj ljVar = i != null ? new lj(i) : null;
        String str = null;
        Context applicationContext = context.getApplicationContext();
        if (applicationContext != null) {
            str = kj.m12293a().m14900a(Thread.currentThread().getStackTrace(), applicationContext.getPackageName());
        }
        return new ka(7, time, a3, c, unmodifiableList, a2, l, f, g, ljVar, e, b, ldVar.m12443k(), ldVar.m12445m(), Collections.unmodifiableList(new ArrayList(ldVar.m12446n())), ldVar.m12440h(), str, ldVar.m12447o());
    }
}
