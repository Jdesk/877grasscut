package com.google.android.gms.p095b;

@sc
/* renamed from: com.google.android.gms.b.uk */
public class uk {
    private final px f8927a;
    private final uh f8928b;

    public uk(px pxVar, ug ugVar) {
        this.f8927a = pxVar;
        this.f8928b = new uh(ugVar);
    }

    public px m14444a() {
        return this.f8927a;
    }

    public uh m14445b() {
        return this.f8928b;
    }
}
