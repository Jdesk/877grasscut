package com.google.android.gms.p095b;

import com.google.android.gms.common.C3181a;
import com.google.android.gms.common.util.C3291a;

/* renamed from: com.google.android.gms.b.o */
public class C2818o extends C2481g {
    private final C3291a<abg<?>> f7862e;
    private C3121x f7863f;

    public void m13049a() {
        super.m9922a();
        if (!this.f7862e.isEmpty()) {
            this.f7863f.m15114a(this);
        }
    }

    protected void m13050a(C3181a c3181a, int i) {
        this.f7863f.m15119b(c3181a, i);
    }

    public void m13051b() {
        super.m9926b();
        this.f7863f.m15118b(this);
    }

    protected void m13052c() {
        this.f7863f.m15121d();
    }

    C3291a<abg<?>> m13053e() {
        return this.f7862e;
    }
}
