package com.google.android.gms.p095b;

import android.app.Application;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.database.sqlite.SQLiteException;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.provider.Settings.Secure;
import android.support.v4.app.ad;
import android.support.v4.util.C0511a;
import android.support.v7.widget.helper.ItemTouchHelper.Callback;
import android.text.TextUtils;
import android.util.Pair;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.common.util.C3293c;
import com.google.android.gms.measurement.AppMeasurement;
import com.google.android.gms.p095b.dw.C2518a;
import com.google.android.gms.p095b.dw.C2519b;
import com.google.android.gms.p095b.ek.C2530a;
import com.google.android.gms.p095b.el.C2533a;
import com.google.android.gms.p095b.fj.C2604b;
import com.google.android.gms.p095b.fk.C2606a;
import com.google.android.gms.p095b.fk.C2607b;
import com.google.android.gms.p095b.fk.C2608c;
import com.google.android.gms.p095b.fk.C2609d;
import com.google.android.gms.p095b.fk.C2610e;
import com.google.android.gms.p095b.fk.C2612g;
import com.google.firebase.p105a.C3650a;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Callable;

/* renamed from: com.google.android.gms.b.es */
public class es {
    private static volatile es f6488b;
    private boolean f6489A;
    private Boolean f6490B;
    private long f6491C;
    private FileLock f6492D;
    private FileChannel f6493E;
    private List<Long> f6494F;
    private int f6495G;
    private int f6496H;
    private long f6497I;
    protected long f6498a;
    private final Context f6499c;
    private final dv f6500d;
    private final eo f6501e;
    private final ek f6502f;
    private final er f6503g;
    private final fb f6504h;
    private final eq f6505i;
    private final AppMeasurement f6506j;
    private final C3650a f6507k;
    private final fh f6508l;
    private final dw f6509m;
    private final ei f6510n;
    private final el f6511o;
    private final C3293c f6512p;
    private final ey f6513q;
    private final ez f6514r;
    private final dy f6515s;
    private final ex f6516t;
    private final eh f6517u;
    private final em f6518v;
    private final fd f6519w;
    private final ds f6520x;
    private final C2517do f6521y;
    private final boolean f6522z;

    /* renamed from: com.google.android.gms.b.es.1 */
    class C25471 implements Runnable {
        final /* synthetic */ es f6478a;

        C25471(es esVar) {
            this.f6478a = esVar;
        }

        public void run() {
            this.f6478a.m10874c();
        }
    }

    /* renamed from: com.google.android.gms.b.es.2 */
    class C25482 implements Callable<String> {
        final /* synthetic */ String f6479a;
        final /* synthetic */ es f6480b;

        C25482(es esVar, String str) {
            this.f6480b = esVar;
            this.f6479a = str;
        }

        public String m10814a() {
            dp b = this.f6480b.m10888o().m10432b(this.f6479a);
            return b == null ? null : b.m10245c();
        }

        public /* synthetic */ Object call() {
            return m10814a();
        }
    }

    /* renamed from: com.google.android.gms.b.es.3 */
    class C25493 implements C2533a {
        final /* synthetic */ es f6481a;

        C25493(es esVar) {
            this.f6481a = esVar;
        }

        public void m10815a(String str, int i, Throwable th, byte[] bArr, Map<String, List<String>> map) {
            this.f6481a.m10848a(i, th, bArr);
        }
    }

    /* renamed from: com.google.android.gms.b.es.4 */
    class C25504 implements C2533a {
        final /* synthetic */ es f6482a;

        C25504(es esVar) {
            this.f6482a = esVar;
        }

        public void m10816a(String str, int i, Throwable th, byte[] bArr, Map<String, List<String>> map) {
            this.f6482a.m10859a(str, i, th, bArr, map);
        }
    }

    /* renamed from: com.google.android.gms.b.es.a */
    private class C2551a implements C2519b {
        C2610e f6483a;
        List<Long> f6484b;
        List<C2607b> f6485c;
        long f6486d;
        final /* synthetic */ es f6487e;

        private C2551a(es esVar) {
            this.f6487e = esVar;
        }

        private long m10817a(C2607b c2607b) {
            return ((c2607b.f6774c.longValue() / 1000) / 60) / 60;
        }

        public void m10818a(C2610e c2610e) {
            C3234c.m16042a((Object) c2610e);
            this.f6483a = c2610e;
        }

        boolean m10819a() {
            return this.f6485c == null || this.f6485c.isEmpty();
        }

        public boolean m10820a(long j, C2607b c2607b) {
            C3234c.m16042a((Object) c2607b);
            if (this.f6485c == null) {
                this.f6485c = new ArrayList();
            }
            if (this.f6484b == null) {
                this.f6484b = new ArrayList();
            }
            if (this.f6485c.size() > 0 && m10817a((C2607b) this.f6485c.get(0)) != m10817a(c2607b)) {
                return false;
            }
            long g = this.f6486d + ((long) c2607b.m9802g());
            if (g >= ((long) this.f6487e.m10876d().af())) {
                return false;
            }
            this.f6486d = g;
            this.f6485c.add(c2607b);
            this.f6484b.add(Long.valueOf(j));
            return this.f6485c.size() < this.f6487e.m10876d().ag();
        }
    }

    es(ew ewVar) {
        C3234c.m16042a((Object) ewVar);
        this.f6499c = ewVar.f6578a;
        this.f6497I = -1;
        this.f6512p = ewVar.m10939n(this);
        this.f6500d = ewVar.m10925a(this);
        eo b = ewVar.m10927b(this);
        b.m10292S();
        this.f6501e = b;
        ek c = ewVar.m10928c(this);
        c.m10292S();
        this.f6502f = c;
        m10879f().m10634B().m10625a("App measurement is starting up, version", Long.valueOf(m10876d().m10331U()));
        m10876d().m10332V();
        m10879f().m10634B().m10624a("To enable debug logging run: adb shell setprop log.tag.FA VERBOSE");
        fh j = ewVar.m10935j(this);
        j.m10292S();
        this.f6508l = j;
        dy q = ewVar.m10942q(this);
        q.m10292S();
        this.f6515s = q;
        eh r = ewVar.m10943r(this);
        r.m10292S();
        this.f6517u = r;
        m10876d().m10332V();
        String x = r.m10586x();
        if (m10887n().m11265k(x)) {
            m10879f().m10634B().m10624a("Faster debug mode event logging enabled. To disable, run:\n  adb shell setprop debug.firebase.analytics.app .none.");
        } else {
            C2530a B = m10879f().m10634B();
            String str = "To enable faster debug mode event logging run:\n  adb shell setprop debug.firebase.analytics.app ";
            x = String.valueOf(x);
            B.m10624a(x.length() != 0 ? str.concat(x) : new String(str));
        }
        m10879f().m10635C().m10624a("Debug-level message logging enabled");
        dw k = ewVar.m10936k(this);
        k.m10292S();
        this.f6509m = k;
        ei l = ewVar.m10937l(this);
        l.m10292S();
        this.f6510n = l;
        ds u = ewVar.m10946u(this);
        u.m10292S();
        this.f6520x = u;
        this.f6521y = ewVar.m10947v(this);
        el m = ewVar.m10938m(this);
        m.m10292S();
        this.f6511o = m;
        ey o = ewVar.m10940o(this);
        o.m10292S();
        this.f6513q = o;
        ez p = ewVar.m10941p(this);
        p.m10292S();
        this.f6514r = p;
        ex i = ewVar.m10934i(this);
        i.m10292S();
        this.f6516t = i;
        fd t = ewVar.m10945t(this);
        t.m10292S();
        this.f6519w = t;
        this.f6518v = ewVar.m10944s(this);
        this.f6506j = ewVar.m10933h(this);
        this.f6507k = ewVar.m10932g(this);
        fb e = ewVar.m10930e(this);
        e.m10292S();
        this.f6504h = e;
        eq f = ewVar.m10931f(this);
        f.m10292S();
        this.f6505i = f;
        er d = ewVar.m10929d(this);
        d.m10292S();
        this.f6503g = d;
        if (this.f6495G != this.f6496H) {
            m10879f().m10665x().m10626a("Not all components initialized", Integer.valueOf(this.f6495G), Integer.valueOf(this.f6496H));
        }
        this.f6522z = true;
        this.f6500d.m10332V();
        if (this.f6499c.getApplicationContext() instanceof Application) {
            int i2 = VERSION.SDK_INT;
            m10885l().m11005x();
        } else {
            m10879f().m10667z().m10624a("Application context is not an Application");
        }
        this.f6503g.m10787a(new C25471(this));
    }

    private boolean m10821O() {
        m10832B();
        m10847a();
        return m10888o().m10404I() || !TextUtils.isEmpty(m10888o().m10398C());
    }

    private void m10822P() {
        m10832B();
        m10847a();
        if (m10844N()) {
            long abs;
            if (this.f6498a > 0) {
                abs = 3600000 - Math.abs(m10892s().m16302b() - this.f6498a);
                if (abs > 0) {
                    m10879f().m10636D().m10625a("Upload has been suspended. Will update scheduling later in approximately ms", Long.valueOf(abs));
                    m10897x().m10702b();
                    m10898y().m11183x();
                    return;
                }
                this.f6498a = 0;
            }
            if (m10872b() && m10821O()) {
                abs = m10823Q();
                if (abs == 0) {
                    m10897x().m10702b();
                    m10898y().m11183x();
                    return;
                } else if (m10890q().m10697x()) {
                    long a = m10878e().f6433e.m10708a();
                    long ak = m10876d().ak();
                    if (!m10887n().m11228a(a, ak)) {
                        abs = Math.max(abs, a + ak);
                    }
                    m10897x().m10702b();
                    abs -= m10892s().m16301a();
                    if (abs <= 0) {
                        abs = m10876d().ao();
                        m10878e().f6431c.m10709a(m10892s().m16301a());
                    }
                    m10879f().m10636D().m10625a("Upload scheduled in approximately ms", Long.valueOf(abs));
                    m10898y().m11160a(abs);
                    return;
                } else {
                    m10897x().m10701a();
                    m10898y().m11183x();
                    return;
                }
            }
            m10897x().m10702b();
            m10898y().m11183x();
        }
    }

    private long m10823Q() {
        long am;
        long a = m10892s().m16301a();
        long ar = m10876d().ar();
        Object obj = (m10888o().m10405J() || m10888o().m10399D()) ? 1 : null;
        if (obj != null) {
            CharSequence au = m10876d().au();
            am = (TextUtils.isEmpty(au) || ".none.".equals(au)) ? m10876d().am() : m10876d().an();
        } else {
            am = m10876d().al();
        }
        long a2 = m10878e().f6431c.m10708a();
        long a3 = m10878e().f6432d.m10708a();
        long max = Math.max(m10888o().m10402G(), m10888o().m10403H());
        if (max == 0) {
            return 0;
        }
        max = a - Math.abs(max - a);
        a3 = a - Math.abs(a3 - a);
        a2 = Math.max(a - Math.abs(a2 - a), a3);
        a = max + ar;
        if (obj != null && a2 > 0) {
            a = Math.min(max, a2) + am;
        }
        if (!m10887n().m11228a(a2, am)) {
            a = a2 + am;
        }
        if (a3 == 0 || a3 < max) {
            return a;
        }
        for (int i = 0; i < m10876d().at(); i++) {
            a += ((long) (1 << i)) * m10876d().as();
            if (a > a3) {
                return a;
            }
        }
        return 0;
    }

    public static es m10824a(Context context) {
        C3234c.m16042a((Object) context);
        C3234c.m16042a(context.getApplicationContext());
        if (f6488b == null) {
            synchronized (es.class) {
                if (f6488b == null) {
                    f6488b = new ew(context).m10926a();
                }
            }
        }
        return f6488b;
    }

    private void m10825a(eu euVar) {
        if (euVar == null) {
            throw new IllegalStateException("Component not created");
        }
    }

    private boolean m10826a(dz dzVar) {
        if (dzVar.f6305f == null) {
            return false;
        }
        Iterator it = dzVar.f6305f.iterator();
        while (it.hasNext()) {
            if ("_r".equals((String) it.next())) {
                return true;
            }
        }
        return m10883j().m10751c(dzVar.f6300a, dzVar.f6301b) && m10888o().m10408a(m10837G(), dzVar.f6300a, false, false, false, false, false).f6282e < ((long) m10876d().m10344c(dzVar.f6300a));
    }

    private boolean m10827a(String str, long j) {
        m10888o().m10453x();
        try {
            es esVar = this;
            C2551a c2551a = new C2551a();
            m10888o().m10423a(str, j, this.f6497I, c2551a);
            if (c2551a.m10819a()) {
                m10888o().m10454y();
                m10888o().m10455z();
                return false;
            }
            int i;
            boolean z = false;
            C2610e c2610e = c2551a.f6483a;
            c2610e.f6794b = new C2607b[c2551a.f6485c.size()];
            int i2 = 0;
            int i3 = 0;
            while (i3 < c2551a.f6485c.size()) {
                boolean z2;
                Object obj;
                if (m10883j().m10748b(c2551a.f6483a.f6807o, ((C2607b) c2551a.f6485c.get(i3)).f6773b)) {
                    m10879f().m10667z().m10626a("Dropping blacklisted raw event. appId", ek.m10629a(c2551a.f6483a.f6807o), ((C2607b) c2551a.f6485c.get(i3)).f6773b);
                    obj = (m10887n().m11268m(c2551a.f6483a.f6807o) || m10887n().m11270n(c2551a.f6483a.f6807o)) ? 1 : null;
                    if (obj != null || "_err".equals(((C2607b) c2551a.f6485c.get(i3)).f6773b)) {
                        i = i2;
                        z2 = z;
                    } else {
                        m10887n().m11222a(11, "_ev", ((C2607b) c2551a.f6485c.get(i3)).f6773b, 0);
                        i = i2;
                        z2 = z;
                    }
                } else {
                    int i4;
                    boolean z3;
                    boolean c = m10883j().m10751c(c2551a.f6483a.f6807o, ((C2607b) c2551a.f6485c.get(i3)).f6773b);
                    if (c || m10887n().m11272o(((C2607b) c2551a.f6485c.get(i3)).f6773b)) {
                        C2608c[] c2608cArr;
                        C2608c c2608c;
                        C2607b c2607b;
                        Object obj2 = null;
                        Object obj3 = null;
                        if (((C2607b) c2551a.f6485c.get(i3)).f6772a == null) {
                            ((C2607b) c2551a.f6485c.get(i3)).f6772a = new C2608c[0];
                        }
                        C2608c[] c2608cArr2 = ((C2607b) c2551a.f6485c.get(i3)).f6772a;
                        int length = c2608cArr2.length;
                        int i5 = 0;
                        while (i5 < length) {
                            C2608c c2608c2 = c2608cArr2[i5];
                            if ("_c".equals(c2608c2.f6778a)) {
                                c2608c2.f6780c = Long.valueOf(1);
                                obj2 = 1;
                                obj = obj3;
                            } else if ("_r".equals(c2608c2.f6778a)) {
                                c2608c2.f6780c = Long.valueOf(1);
                                obj = 1;
                            } else {
                                obj = obj3;
                            }
                            i5++;
                            obj3 = obj;
                        }
                        if (obj2 == null && c) {
                            m10879f().m10636D().m10625a("Marking event as conversion", ((C2607b) c2551a.f6485c.get(i3)).f6773b);
                            c2608cArr = (C2608c[]) Arrays.copyOf(((C2607b) c2551a.f6485c.get(i3)).f6772a, ((C2607b) c2551a.f6485c.get(i3)).f6772a.length + 1);
                            c2608c = new C2608c();
                            c2608c.f6778a = "_c";
                            c2608c.f6780c = Long.valueOf(1);
                            c2608cArr[c2608cArr.length - 1] = c2608c;
                            ((C2607b) c2551a.f6485c.get(i3)).f6772a = c2608cArr;
                        }
                        if (obj3 == null) {
                            m10879f().m10636D().m10625a("Marking event as real-time", ((C2607b) c2551a.f6485c.get(i3)).f6773b);
                            c2608cArr = (C2608c[]) Arrays.copyOf(((C2607b) c2551a.f6485c.get(i3)).f6772a, ((C2607b) c2551a.f6485c.get(i3)).f6772a.length + 1);
                            c2608c = new C2608c();
                            c2608c.f6778a = "_r";
                            c2608c.f6780c = Long.valueOf(1);
                            c2608cArr[c2608cArr.length - 1] = c2608c;
                            ((C2607b) c2551a.f6485c.get(i3)).f6772a = c2608cArr;
                        }
                        boolean z4 = true;
                        if (m10888o().m10408a(m10837G(), c2551a.f6483a.f6807o, false, false, false, false, true).f6282e > ((long) m10876d().m10344c(c2551a.f6483a.f6807o))) {
                            c2607b = (C2607b) c2551a.f6485c.get(i3);
                            i4 = 0;
                            while (i4 < c2607b.f6772a.length) {
                                if ("_r".equals(c2607b.f6772a[i4].f6778a)) {
                                    obj3 = new C2608c[(c2607b.f6772a.length - 1)];
                                    if (i4 > 0) {
                                        System.arraycopy(c2607b.f6772a, 0, obj3, 0, i4);
                                    }
                                    if (i4 < obj3.length) {
                                        System.arraycopy(c2607b.f6772a, i4 + 1, obj3, i4, obj3.length - i4);
                                    }
                                    c2607b.f6772a = obj3;
                                    z4 = z;
                                } else {
                                    i4++;
                                }
                            }
                            z4 = z;
                        }
                        if (fh.m11205a(((C2607b) c2551a.f6485c.get(i3)).f6773b) && c && m10888o().m10408a(m10837G(), c2551a.f6483a.f6807o, false, false, true, false, false).f6280c > ((long) m10876d().m10341b(c2551a.f6483a.f6807o))) {
                            m10879f().m10667z().m10625a("Too many conversions. Not logging as conversion. appId", ek.m10629a(c2551a.f6483a.f6807o));
                            c2607b = (C2607b) c2551a.f6485c.get(i3);
                            Object obj4 = null;
                            C2608c c2608c3 = null;
                            C2608c[] c2608cArr3 = c2607b.f6772a;
                            int length2 = c2608cArr3.length;
                            int i6 = 0;
                            while (i6 < length2) {
                                c2608c = c2608cArr3[i6];
                                if ("_c".equals(c2608c.f6778a)) {
                                    obj3 = obj4;
                                } else if ("_err".equals(c2608c.f6778a)) {
                                    C2608c c2608c4 = c2608c3;
                                    int i7 = 1;
                                    c2608c = c2608c4;
                                } else {
                                    c2608c = c2608c3;
                                    obj3 = obj4;
                                }
                                i6++;
                                obj4 = obj3;
                                c2608c3 = c2608c;
                            }
                            if (obj4 != null && c2608c3 != null) {
                                c2608cArr3 = new C2608c[(c2607b.f6772a.length - 1)];
                                int i8 = 0;
                                C2608c[] c2608cArr4 = c2607b.f6772a;
                                int length3 = c2608cArr4.length;
                                i6 = 0;
                                while (i6 < length3) {
                                    C2608c c2608c5 = c2608cArr4[i6];
                                    if (c2608c5 != c2608c3) {
                                        i4 = i8 + 1;
                                        c2608cArr3[i8] = c2608c5;
                                    } else {
                                        i4 = i8;
                                    }
                                    i6++;
                                    i8 = i4;
                                }
                                c2607b.f6772a = c2608cArr3;
                                z3 = z4;
                            } else if (c2608c3 != null) {
                                c2608c3.f6778a = "_err";
                                c2608c3.f6780c = Long.valueOf(10);
                                z3 = z4;
                            } else {
                                m10879f().m10665x().m10625a("Did not find conversion parameter. appId", ek.m10629a(c2551a.f6483a.f6807o));
                            }
                        }
                        z3 = z4;
                    } else {
                        z3 = z;
                    }
                    i4 = i2 + 1;
                    c2610e.f6794b[i2] = (C2607b) c2551a.f6485c.get(i3);
                    i = i4;
                    z2 = z3;
                }
                i3++;
                i2 = i;
                z = z2;
            }
            if (i2 < c2551a.f6485c.size()) {
                c2610e.f6794b = (C2607b[]) Arrays.copyOf(c2610e.f6794b, i2);
            }
            c2610e.f6785A = m10828a(c2551a.f6483a.f6807o, c2551a.f6483a.f6795c, c2610e.f6794b);
            c2610e.f6797e = Long.valueOf(Long.MAX_VALUE);
            c2610e.f6798f = Long.valueOf(Long.MIN_VALUE);
            for (C2607b c2607b2 : c2610e.f6794b) {
                if (c2607b2.f6774c.longValue() < c2610e.f6797e.longValue()) {
                    c2610e.f6797e = c2607b2.f6774c;
                }
                if (c2607b2.f6774c.longValue() > c2610e.f6798f.longValue()) {
                    c2610e.f6798f = c2607b2.f6774c;
                }
            }
            String str2 = c2551a.f6483a.f6807o;
            dp b = m10888o().m10432b(str2);
            if (b == null) {
                m10879f().m10665x().m10625a("Bundling raw events w/o app info. appId", ek.m10629a(c2551a.f6483a.f6807o));
            } else if (c2610e.f6794b.length > 0) {
                long h = b.m10260h();
                c2610e.f6800h = h != 0 ? Long.valueOf(h) : null;
                long g = b.m10257g();
                if (g != 0) {
                    h = g;
                }
                c2610e.f6799g = h != 0 ? Long.valueOf(h) : null;
                b.m10278r();
                c2610e.f6815w = Integer.valueOf((int) b.m10274o());
                b.m10239a(c2610e.f6797e.longValue());
                b.m10243b(c2610e.f6798f.longValue());
                c2610e.f6816x = b.m10286z();
                m10888o().m10419a(b);
            }
            if (c2610e.f6794b.length > 0) {
                m10876d().m10332V();
                C2604b a = m10883j().m10742a(c2551a.f6483a.f6807o);
                if (a != null && a.f6757a != null) {
                    c2610e.f6791G = a.f6757a;
                } else if (TextUtils.isEmpty(c2551a.f6483a.f6817y)) {
                    c2610e.f6791G = Long.valueOf(-1);
                } else {
                    m10879f().m10667z().m10625a("Did not find measurement config or missing version info. appId", ek.m10629a(c2551a.f6483a.f6807o));
                }
                m10888o().m10430a(c2610e, z);
            }
            m10888o().m10426a(c2551a.f6484b);
            m10888o().m10451i(str2);
            m10888o().m10454y();
            boolean z5 = c2610e.f6794b.length > 0;
            m10888o().m10455z();
            return z5;
        } catch (Throwable th) {
            m10888o().m10455z();
        }
    }

    private C2606a[] m10828a(String str, C2612g[] c2612gArr, C2607b[] c2607bArr) {
        C3234c.m16044a(str);
        return m10899z().m10307a(str, c2607bArr, c2612gArr);
    }

    private void m10829b(ev evVar) {
        if (evVar == null) {
            throw new IllegalStateException("Component not created");
        } else if (!evVar.m10290Q()) {
            throw new IllegalStateException("Component not initialized");
        }
    }

    private void m10830c(dq dqVar) {
        Object obj = 1;
        m10832B();
        m10847a();
        C3234c.m16042a((Object) dqVar);
        C3234c.m16044a(dqVar.f6251a);
        dp b = m10888o().m10432b(dqVar.f6251a);
        String b2 = m10878e().m10728b(dqVar.f6251a);
        Object obj2 = null;
        if (b == null) {
            dp dpVar = new dp(this, dqVar.f6251a);
            dpVar.m10240a(m10878e().m10732x());
            dpVar.m10247c(b2);
            b = dpVar;
            obj2 = 1;
        } else if (!b2.equals(b.m10251e())) {
            b.m10247c(b2);
            b.m10240a(m10878e().m10732x());
            int i = 1;
        }
        if (!(TextUtils.isEmpty(dqVar.f6252b) || dqVar.f6252b.equals(b.m10248d()))) {
            b.m10244b(dqVar.f6252b);
            obj2 = 1;
        }
        if (!(TextUtils.isEmpty(dqVar.f6261k) || dqVar.f6261k.equals(b.m10254f()))) {
            b.m10250d(dqVar.f6261k);
            obj2 = 1;
        }
        if (!(dqVar.f6255e == 0 || dqVar.f6255e == b.m10268l())) {
            b.m10249d(dqVar.f6255e);
            obj2 = 1;
        }
        if (!(TextUtils.isEmpty(dqVar.f6253c) || dqVar.f6253c.equals(b.m10262i()))) {
            b.m10253e(dqVar.f6253c);
            obj2 = 1;
        }
        if (dqVar.f6260j != b.m10264j()) {
            b.m10246c(dqVar.f6260j);
            obj2 = 1;
        }
        if (!(dqVar.f6254d == null || dqVar.f6254d.equals(b.m10266k()))) {
            b.m10256f(dqVar.f6254d);
            obj2 = 1;
        }
        if (dqVar.f6256f != b.m10270m()) {
            b.m10252e(dqVar.f6256f);
            obj2 = 1;
        }
        if (dqVar.f6258h != b.m10273n()) {
            b.m10241a(dqVar.f6258h);
            obj2 = 1;
        }
        if (!(TextUtils.isEmpty(dqVar.f6257g) || dqVar.f6257g.equals(b.m10285y()))) {
            b.m10259g(dqVar.f6257g);
            obj2 = 1;
        }
        if (dqVar.f6262l != b.m10237A()) {
            b.m10275o(dqVar.f6262l);
        } else {
            obj = obj2;
        }
        if (obj != null) {
            m10888o().m10419a(b);
        }
    }

    public C2517do m10831A() {
        m10825a(this.f6521y);
        return this.f6521y;
    }

    public void m10832B() {
        m10881h().m10793e();
    }

    FileChannel m10833C() {
        return this.f6493E;
    }

    void m10834D() {
        m10832B();
        m10847a();
        if (m10844N() && m10835E()) {
            m10862a(m10845a(m10833C()), m10896w().m10556A());
        }
    }

    boolean m10835E() {
        m10832B();
        try {
            this.f6493E = new RandomAccessFile(new File(m10891r().getFilesDir(), this.f6509m.m10397B()), "rw").getChannel();
            this.f6492D = this.f6493E.tryLock();
            if (this.f6492D != null) {
                m10879f().m10636D().m10624a("Storage concurrent access okay");
                return true;
            }
            m10879f().m10665x().m10624a("Storage concurrent data access panic");
            return false;
        } catch (FileNotFoundException e) {
            m10879f().m10665x().m10625a("Failed to acquire storage lock", e);
        } catch (IOException e2) {
            m10879f().m10665x().m10625a("Failed to access storage lock file", e2);
        }
    }

    public boolean m10836F() {
        boolean z = false;
        m10832B();
        m10847a();
        if (m10876d().m10334X()) {
            return false;
        }
        Boolean Y = m10876d().m10335Y();
        if (Y != null) {
            z = Y.booleanValue();
        } else if (!m10876d().m10336Z()) {
            z = true;
        }
        return m10878e().m10731c(z);
    }

    long m10837G() {
        return ((((m10892s().m16301a() + m10878e().m10734z()) / 1000) / 60) / 60) / 24;
    }

    void m10838H() {
        m10876d().m10332V();
    }

    void m10839I() {
        m10876d().m10332V();
        throw new IllegalStateException("Unexpected call on client side");
    }

    protected boolean m10840J() {
        m10832B();
        return this.f6494F != null;
    }

    public void m10841K() {
        int i = 0;
        m10832B();
        m10847a();
        m10876d().m10332V();
        Boolean B = m10878e().m10722B();
        if (B == null) {
            m10879f().m10667z().m10624a("Upload data called on the client side before use of service was decided");
        } else if (B.booleanValue()) {
            m10879f().m10665x().m10624a("Upload called in the client side when service should be used");
        } else if (this.f6498a > 0) {
            m10822P();
        } else if (m10840J()) {
            m10879f().m10667z().m10624a("Uploading requested multiple times");
        } else if (m10890q().m10697x()) {
            long a = m10892s().m16301a();
            m10864a(a - m10876d().aj());
            long a2 = m10878e().f6431c.m10708a();
            if (a2 != 0) {
                m10879f().m10635C().m10625a("Uploading events. Elapsed time since last upload attempt (ms)", Long.valueOf(Math.abs(a - a2)));
            }
            String C = m10888o().m10398C();
            if (TextUtils.isEmpty(C)) {
                this.f6497I = -1;
                String b = m10888o().m10434b(a - m10876d().aj());
                if (!TextUtils.isEmpty(b)) {
                    dp b2 = m10888o().m10432b(b);
                    if (b2 != null) {
                        m10849a(b2);
                        return;
                    }
                    return;
                }
                return;
            }
            if (this.f6497I == -1) {
                this.f6497I = m10888o().m10406K();
            }
            List<Pair> a3 = m10888o().m10411a(C, m10876d().m10354h(C), m10876d().m10356i(C));
            if (!a3.isEmpty()) {
                C2610e c2610e;
                Object obj;
                List subList;
                for (Pair pair : a3) {
                    c2610e = (C2610e) pair.first;
                    if (!TextUtils.isEmpty(c2610e.f6811s)) {
                        obj = c2610e.f6811s;
                        break;
                    }
                }
                obj = null;
                if (obj != null) {
                    for (int i2 = 0; i2 < a3.size(); i2++) {
                        c2610e = (C2610e) ((Pair) a3.get(i2)).first;
                        if (!TextUtils.isEmpty(c2610e.f6811s) && !c2610e.f6811s.equals(obj)) {
                            subList = a3.subList(0, i2);
                            break;
                        }
                    }
                }
                subList = a3;
                C2609d c2609d = new C2609d();
                c2609d.f6783a = new C2610e[subList.size()];
                List arrayList = new ArrayList(subList.size());
                while (i < c2609d.f6783a.length) {
                    c2609d.f6783a[i] = (C2610e) ((Pair) subList.get(i)).first;
                    arrayList.add((Long) ((Pair) subList.get(i)).second);
                    c2609d.f6783a[i].f6810r = Long.valueOf(m10876d().m10331U());
                    c2609d.f6783a[i].f6796d = Long.valueOf(a);
                    c2609d.f6783a[i].f6818z = Boolean.valueOf(m10876d().m10332V());
                    i++;
                }
                Object b3 = m10879f().m10642a(2) ? fh.m11208b(c2609d) : null;
                byte[] a4 = m10887n().m11238a(c2609d);
                String ai = m10876d().ai();
                try {
                    URL url = new URL(ai);
                    m10860a(arrayList);
                    m10878e().f6432d.m10709a(a);
                    Object obj2 = "?";
                    if (c2609d.f6783a.length > 0) {
                        obj2 = c2609d.f6783a[0].f6807o;
                    }
                    m10879f().m10636D().m10627a("Uploading data. app, uncompressed size, data", obj2, Integer.valueOf(a4.length), b3);
                    m10890q().m10674a(C, url, a4, null, new C25493(this));
                } catch (MalformedURLException e) {
                    m10879f().m10665x().m10626a("Failed to parse upload URL. Not uploading. appId", ek.m10629a(C), ai);
                }
            }
        } else {
            m10879f().m10667z().m10624a("Network not connected, ignoring upload request");
            m10822P();
        }
    }

    void m10842L() {
        this.f6496H++;
    }

    void m10843M() {
        m10832B();
        m10847a();
        if (!this.f6489A) {
            m10879f().m10634B().m10624a("This instance being marked as an uploader");
            m10834D();
        }
        this.f6489A = true;
    }

    boolean m10844N() {
        m10832B();
        m10847a();
        return this.f6489A;
    }

    int m10845a(FileChannel fileChannel) {
        int i = 0;
        m10832B();
        if (fileChannel == null || !fileChannel.isOpen()) {
            m10879f().m10665x().m10624a("Bad chanel to read from");
        } else {
            ByteBuffer allocate = ByteBuffer.allocate(4);
            try {
                fileChannel.position(0);
                int read = fileChannel.read(allocate);
                if (read == 4) {
                    allocate.flip();
                    i = allocate.getInt();
                } else if (read != -1) {
                    m10879f().m10667z().m10625a("Unexpected data length. Bytes read", Integer.valueOf(read));
                }
            } catch (IOException e) {
                m10879f().m10665x().m10625a("Failed to read from channel", e);
            }
        }
        return i;
    }

    dq m10846a(String str) {
        dp b = m10888o().m10432b(str);
        if (b == null || TextUtils.isEmpty(b.m10262i())) {
            m10879f().m10635C().m10625a("No app data available; dropping", str);
            return null;
        }
        try {
            String str2 = bn.m9791b(m10891r()).m9789b(str, 0).versionName;
            if (!(b.m10262i() == null || b.m10262i().equals(str2))) {
                m10879f().m10667z().m10625a("App version does not match; dropping. appId", ek.m10629a(str));
                return null;
            }
        } catch (NameNotFoundException e) {
        }
        return new dq(str, b.m10248d(), b.m10262i(), b.m10264j(), b.m10266k(), b.m10268l(), b.m10270m(), null, b.m10273n(), false, b.m10254f(), b.m10237A());
    }

    void m10847a() {
        if (!this.f6522z) {
            throw new IllegalStateException("AppMeasurement is not initialized");
        }
    }

    protected void m10848a(int i, Throwable th, byte[] bArr) {
        int i2 = 0;
        m10832B();
        m10847a();
        if (bArr == null) {
            bArr = new byte[0];
        }
        List<Long> list = this.f6494F;
        this.f6494F = null;
        if ((i == Callback.DEFAULT_DRAG_ANIMATION_DURATION || i == 204) && th == null) {
            try {
                m10878e().f6431c.m10709a(m10892s().m16301a());
                m10878e().f6432d.m10709a(0);
                m10822P();
                m10879f().m10636D().m10626a("Successful upload. Got network response. code, size", Integer.valueOf(i), Integer.valueOf(bArr.length));
                m10888o().m10453x();
                for (Long longValue : list) {
                    m10888o().m10417a(longValue.longValue());
                }
                m10888o().m10454y();
                m10888o().m10455z();
                if (m10890q().m10697x() && m10821O()) {
                    m10841K();
                } else {
                    this.f6497I = -1;
                    m10822P();
                }
                this.f6498a = 0;
                return;
            } catch (SQLiteException e) {
                m10879f().m10665x().m10625a("Database error while trying to delete uploaded bundles", e);
                this.f6498a = m10892s().m16302b();
                m10879f().m10636D().m10625a("Disable upload, time", Long.valueOf(this.f6498a));
                return;
            } catch (Throwable th2) {
                m10888o().m10455z();
            }
        }
        m10879f().m10636D().m10626a("Network upload failed. Will retry later. code, error", Integer.valueOf(i), th);
        m10878e().f6432d.m10709a(m10892s().m16301a());
        if (i == 503 || i == 429) {
            i2 = 1;
        }
        if (i2 != 0) {
            m10878e().f6433e.m10709a(m10892s().m16301a());
        }
        m10822P();
    }

    void m10849a(dp dpVar) {
        Map map = null;
        if (TextUtils.isEmpty(dpVar.m10248d())) {
            m10859a(dpVar.m10242b(), 204, null, null, null);
            return;
        }
        String a = m10876d().m10340a(dpVar.m10248d(), dpVar.m10245c());
        try {
            URL url = new URL(a);
            m10879f().m10636D().m10625a("Fetching remote configuration", dpVar.m10242b());
            C2604b a2 = m10883j().m10742a(dpVar.m10242b());
            CharSequence b = m10883j().m10746b(dpVar.m10242b());
            if (!(a2 == null || TextUtils.isEmpty(b))) {
                map = new C0511a();
                map.put("If-Modified-Since", b);
            }
            m10890q().m10673a(dpVar.m10242b(), url, map, new C25504(this));
        } catch (MalformedURLException e) {
            m10879f().m10665x().m10626a("Failed to parse config URL. Not fetching. appId", ek.m10629a(dpVar.m10242b()), a);
        }
    }

    void m10850a(dq dqVar) {
        m10832B();
        m10847a();
        C3234c.m16044a(dqVar.f6251a);
        m10830c(dqVar);
    }

    void m10851a(dq dqVar, long j) {
        dp b = m10888o().m10432b(dqVar.f6251a);
        if (!(b == null || b.m10248d() == null || b.m10248d().equals(dqVar.f6252b))) {
            m10879f().m10667z().m10625a("New GMP App Id passed in. Removing cached database data. appId", ek.m10629a(b.m10242b()));
            m10888o().m10448g(b.m10242b());
            b = null;
        }
        if (b != null && b.m10262i() != null && !b.m10262i().equals(dqVar.f6253c)) {
            Bundle bundle = new Bundle();
            bundle.putString("_pv", b.m10262i());
            m10855a(new ed("_au", new eb(bundle), "auto", j), dqVar);
        }
    }

    void m10852a(dt dtVar) {
        dq a = m10846a(dtVar.f6265b);
        if (a != null) {
            m10853a(dtVar, a);
        }
    }

    void m10853a(dt dtVar, dq dqVar) {
        C3234c.m16042a((Object) dtVar);
        C3234c.m16044a(dtVar.f6265b);
        C3234c.m16042a(dtVar.f6266c);
        C3234c.m16042a(dtVar.f6267d);
        C3234c.m16044a(dtVar.f6267d.f6711b);
        m10832B();
        m10847a();
        if (!TextUtils.isEmpty(dqVar.f6252b)) {
            if (dqVar.f6258h) {
                dt dtVar2 = new dt(dtVar);
                m10888o().m10453x();
                try {
                    Object obj;
                    dt d = m10888o().m10441d(dtVar2.f6265b, dtVar2.f6267d.f6711b);
                    if (d != null && d.f6269f) {
                        dtVar2.f6266c = d.f6266c;
                        dtVar2.f6268e = d.f6268e;
                        dtVar2.f6270g = d.f6270g;
                        dtVar2.f6273j = d.f6273j;
                        obj = null;
                    } else if (TextUtils.isEmpty(dtVar2.f6270g)) {
                        fe feVar = dtVar2.f6267d;
                        dtVar2.f6267d = new fe(feVar.f6711b, dtVar2.f6268e, feVar.m11184a(), feVar.f6716g);
                        dtVar2.f6269f = true;
                        int i = 1;
                    } else {
                        obj = null;
                    }
                    if (dtVar2.f6269f) {
                        fe feVar2 = dtVar2.f6267d;
                        fg fgVar = new fg(dtVar2.f6265b, dtVar2.f6266c, feVar2.f6711b, feVar2.f6712c, feVar2.m11184a());
                        if (m10888o().m10429a(fgVar)) {
                            m10879f().m10635C().m10627a("User property updated immediately", dtVar2.f6265b, fgVar.f6720c, fgVar.f6722e);
                        } else {
                            m10879f().m10665x().m10627a("(2)Too many active user properties, ignoring", ek.m10629a(dtVar2.f6265b), fgVar.f6720c, fgVar.f6722e);
                        }
                        if (!(obj == null || dtVar2.f6273j == null)) {
                            m10870b(new ed(dtVar2.f6273j, dtVar2.f6268e), dqVar);
                        }
                    }
                    if (m10888o().m10427a(dtVar2)) {
                        m10879f().m10635C().m10627a("Conditional property added", dtVar2.f6265b, dtVar2.f6267d.f6711b, dtVar2.f6267d.m11184a());
                    } else {
                        m10879f().m10665x().m10627a("Too many conditional properties, ignoring", ek.m10629a(dtVar2.f6265b), dtVar2.f6267d.f6711b, dtVar2.f6267d.m11184a());
                    }
                    m10888o().m10454y();
                } finally {
                    m10888o().m10455z();
                }
            } else {
                m10830c(dqVar);
            }
        }
    }

    void m10854a(dz dzVar, dq dqVar) {
        m10832B();
        m10847a();
        C3234c.m16042a((Object) dzVar);
        C3234c.m16042a((Object) dqVar);
        C3234c.m16044a(dzVar.f6300a);
        C3234c.m16051b(dzVar.f6300a.equals(dqVar.f6251a));
        C2610e c2610e = new C2610e();
        c2610e.f6793a = Integer.valueOf(1);
        c2610e.f6801i = "android";
        c2610e.f6807o = dqVar.f6251a;
        c2610e.f6806n = dqVar.f6254d;
        c2610e.f6808p = dqVar.f6253c;
        c2610e.f6787C = Integer.valueOf((int) dqVar.f6260j);
        c2610e.f6809q = Long.valueOf(dqVar.f6255e);
        c2610e.f6817y = dqVar.f6252b;
        c2610e.f6814v = dqVar.f6256f == 0 ? null : Long.valueOf(dqVar.f6256f);
        Pair a = m10878e().m10725a(dqVar.f6251a);
        if (!TextUtils.isEmpty((CharSequence) a.first)) {
            c2610e.f6811s = (String) a.first;
            c2610e.f6812t = (Boolean) a.second;
        } else if (!m10895v().m10466a(this.f6499c)) {
            String string = Secure.getString(this.f6499c.getContentResolver(), "android_id");
            if (string == null) {
                m10879f().m10667z().m10625a("null secure ID. appId", ek.m10629a(c2610e.f6807o));
                string = "null";
            } else if (string.isEmpty()) {
                m10879f().m10667z().m10625a("empty secure ID. appId", ek.m10629a(c2610e.f6807o));
            }
            c2610e.f6790F = string;
        }
        c2610e.f6803k = m10895v().m10489x();
        c2610e.f6802j = m10895v().m10490y();
        c2610e.f6805m = Integer.valueOf((int) m10895v().m10491z());
        c2610e.f6804l = m10895v().m10464A();
        c2610e.f6810r = null;
        c2610e.f6796d = null;
        c2610e.f6797e = null;
        c2610e.f6798f = null;
        c2610e.f6792H = Long.valueOf(dqVar.f6262l);
        dp b = m10888o().m10432b(dqVar.f6251a);
        if (b == null) {
            b = new dp(this, dqVar.f6251a);
            b.m10240a(m10878e().m10732x());
            b.m10250d(dqVar.f6261k);
            b.m10244b(dqVar.f6252b);
            b.m10247c(m10878e().m10728b(dqVar.f6251a));
            b.m10255f(0);
            b.m10239a(0);
            b.m10243b(0);
            b.m10253e(dqVar.f6253c);
            b.m10246c(dqVar.f6260j);
            b.m10256f(dqVar.f6254d);
            b.m10249d(dqVar.f6255e);
            b.m10252e(dqVar.f6256f);
            b.m10241a(dqVar.f6258h);
            b.m10275o(dqVar.f6262l);
            m10888o().m10419a(b);
        }
        c2610e.f6813u = b.m10245c();
        c2610e.f6786B = b.m10254f();
        List a2 = m10888o().m10410a(dqVar.f6251a);
        c2610e.f6795c = new C2612g[a2.size()];
        for (int i = 0; i < a2.size(); i++) {
            C2612g c2612g = new C2612g();
            c2610e.f6795c[i] = c2612g;
            c2612g.f6823b = ((fg) a2.get(i)).f6720c;
            c2612g.f6822a = Long.valueOf(((fg) a2.get(i)).f6721d);
            m10887n().m11226a(c2612g, ((fg) a2.get(i)).f6722e);
        }
        try {
            if (m10888o().m10428a(dzVar, m10888o().m10407a(c2610e), m10826a(dzVar))) {
                this.f6498a = 0;
            }
        } catch (IOException e) {
            m10879f().m10665x().m10626a("Data loss. Failed to insert raw event metadata. appId", ek.m10629a(c2610e.f6807o), e);
        }
    }

    void m10855a(ed edVar, dq dqVar) {
        C3234c.m16042a((Object) dqVar);
        C3234c.m16044a(dqVar.f6251a);
        m10832B();
        m10847a();
        String str = dqVar.f6251a;
        long j = edVar.f6322d;
        if (!m10887n().m11231a(edVar, dqVar)) {
            return;
        }
        if (dqVar.f6258h) {
            m10888o().m10453x();
            try {
                for (dt dtVar : m10888o().m10412a(str, j)) {
                    if (dtVar != null) {
                        m10879f().m10635C().m10627a("User property timed out", dtVar.f6265b, dtVar.f6267d.f6711b, dtVar.f6267d.m11184a());
                        if (dtVar.f6271h != null) {
                            m10870b(new ed(dtVar.f6271h, j), dqVar);
                        }
                        m10888o().m10443e(str, dtVar.f6267d.f6711b);
                    }
                }
                List<dt> b = m10888o().m10435b(str, j);
                List<ed> arrayList = new ArrayList(b.size());
                for (dt dtVar2 : b) {
                    if (dtVar2 != null) {
                        m10879f().m10635C().m10627a("User property expired", dtVar2.f6265b, dtVar2.f6267d.f6711b, dtVar2.f6267d.m11184a());
                        m10888o().m10438b(str, dtVar2.f6267d.f6711b);
                        if (dtVar2.f6275l != null) {
                            arrayList.add(dtVar2.f6275l);
                        }
                        m10888o().m10443e(str, dtVar2.f6267d.f6711b);
                    }
                }
                for (ed edVar2 : arrayList) {
                    m10870b(new ed(edVar2, j), dqVar);
                }
                b = m10888o().m10413a(str, edVar.f6319a, j);
                List<ed> arrayList2 = new ArrayList(b.size());
                for (dt dtVar3 : b) {
                    if (dtVar3 != null) {
                        fe feVar = dtVar3.f6267d;
                        fg fgVar = new fg(dtVar3.f6265b, dtVar3.f6266c, feVar.f6711b, j, feVar.m11184a());
                        if (m10888o().m10429a(fgVar)) {
                            m10879f().m10635C().m10627a("User property triggered", dtVar3.f6265b, fgVar.f6720c, fgVar.f6722e);
                        } else {
                            m10879f().m10665x().m10627a("Too many active user properties, ignoring", ek.m10629a(dtVar3.f6265b), fgVar.f6720c, fgVar.f6722e);
                        }
                        if (dtVar3.f6273j != null) {
                            arrayList2.add(dtVar3.f6273j);
                        }
                        dtVar3.f6267d = new fe(fgVar);
                        dtVar3.f6269f = true;
                        m10888o().m10427a(dtVar3);
                    }
                }
                m10870b(edVar, dqVar);
                for (ed edVar22 : arrayList2) {
                    m10870b(new ed(edVar22, j), dqVar);
                }
                m10888o().m10454y();
            } finally {
                m10888o().m10455z();
            }
        } else {
            m10830c(dqVar);
        }
    }

    void m10856a(ed edVar, String str) {
        dp b = m10888o().m10432b(str);
        if (b == null || TextUtils.isEmpty(b.m10262i())) {
            m10879f().m10635C().m10625a("No app data available; dropping event", str);
            return;
        }
        try {
            String str2 = bn.m9791b(m10891r()).m9789b(str, 0).versionName;
            if (!(b.m10262i() == null || b.m10262i().equals(str2))) {
                m10879f().m10667z().m10625a("App version does not match; dropping event. appId", ek.m10629a(str));
                return;
            }
        } catch (NameNotFoundException e) {
            if (!"_ui".equals(edVar.f6319a)) {
                m10879f().m10667z().m10625a("Could not find package. appId", ek.m10629a(str));
            }
        }
        ed edVar2 = edVar;
        m10855a(edVar2, new dq(str, b.m10248d(), b.m10262i(), b.m10264j(), b.m10266k(), b.m10268l(), b.m10270m(), null, b.m10273n(), false, b.m10254f(), b.m10237A()));
    }

    void m10857a(ev evVar) {
        this.f6495G++;
    }

    void m10858a(fe feVar, dq dqVar) {
        int i = 0;
        m10832B();
        m10847a();
        if (!TextUtils.isEmpty(dqVar.f6252b)) {
            if (dqVar.f6258h) {
                int c = m10887n().m11246c(feVar.f6711b);
                String a;
                if (c != 0) {
                    a = m10887n().m11220a(feVar.f6711b, m10876d().m10375z(), true);
                    if (feVar.f6711b != null) {
                        i = feVar.f6711b.length();
                    }
                    m10887n().m11222a(c, "_ev", a, i);
                    return;
                }
                c = m10887n().m11247c(feVar.f6711b, feVar.m11184a());
                if (c != 0) {
                    a = m10887n().m11220a(feVar.f6711b, m10876d().m10375z(), true);
                    Object a2 = feVar.m11184a();
                    if (a2 != null && ((a2 instanceof String) || (a2 instanceof CharSequence))) {
                        i = String.valueOf(a2).length();
                    }
                    m10887n().m11222a(c, "_ev", a, i);
                    return;
                }
                Object d = m10887n().m11252d(feVar.f6711b, feVar.m11184a());
                if (d != null) {
                    fg fgVar = new fg(dqVar.f6251a, feVar.f6716g, feVar.f6711b, feVar.f6712c, d);
                    m10879f().m10635C().m10626a("Setting user property", fgVar.f6720c, d);
                    m10888o().m10453x();
                    try {
                        m10830c(dqVar);
                        boolean a3 = m10888o().m10429a(fgVar);
                        m10888o().m10454y();
                        if (a3) {
                            m10879f().m10635C().m10626a("User property set", fgVar.f6720c, fgVar.f6722e);
                        } else {
                            m10879f().m10665x().m10626a("Too many unique user properties are set. Ignoring user property", fgVar.f6720c, fgVar.f6722e);
                            m10887n().m11222a(9, null, null, 0);
                        }
                        m10888o().m10455z();
                        return;
                    } catch (Throwable th) {
                        m10888o().m10455z();
                    }
                } else {
                    return;
                }
            }
            m10830c(dqVar);
        }
    }

    void m10859a(String str, int i, Throwable th, byte[] bArr, Map<String, List<String>> map) {
        int i2 = 0;
        m10832B();
        m10847a();
        C3234c.m16044a(str);
        if (bArr == null) {
            bArr = new byte[0];
        }
        m10888o().m10453x();
        try {
            dp b = m10888o().m10432b(str);
            int i3 = ((i == Callback.DEFAULT_DRAG_ANIMATION_DURATION || i == 204 || i == 304) && th == null) ? 1 : 0;
            if (b == null) {
                m10879f().m10667z().m10625a("App does not exist in onConfigFetched. appId", ek.m10629a(str));
            } else if (i3 != 0 || i == 404) {
                List list = map != null ? (List) map.get("Last-Modified") : null;
                String str2 = (list == null || list.size() <= 0) ? null : (String) list.get(0);
                if (i == 404 || i == 304) {
                    if (m10883j().m10742a(str) == null && !m10883j().m10745a(str, null, null)) {
                        m10888o().m10455z();
                        return;
                    }
                } else if (!m10883j().m10745a(str, bArr, str2)) {
                    m10888o().m10455z();
                    return;
                }
                b.m10258g(m10892s().m16301a());
                m10888o().m10419a(b);
                if (i == 404) {
                    m10879f().m10633A().m10625a("Config not found. Using empty config. appId", str);
                } else {
                    m10879f().m10636D().m10626a("Successfully fetched config. Got network response. code, size", Integer.valueOf(i), Integer.valueOf(bArr.length));
                }
                if (m10890q().m10697x() && m10821O()) {
                    m10841K();
                } else {
                    m10822P();
                }
            } else {
                b.m10261h(m10892s().m16301a());
                m10888o().m10419a(b);
                m10879f().m10636D().m10626a("Fetching config failed. code, error", Integer.valueOf(i), th);
                m10883j().m10750c(str);
                m10878e().f6432d.m10709a(m10892s().m16301a());
                if (i == 503 || i == 429) {
                    i2 = 1;
                }
                if (i2 != 0) {
                    m10878e().f6433e.m10709a(m10892s().m16301a());
                }
                m10822P();
            }
            m10888o().m10454y();
        } finally {
            m10888o().m10455z();
        }
    }

    protected void m10860a(List<Long> list) {
        C3234c.m16051b(!list.isEmpty());
        if (this.f6494F != null) {
            m10879f().m10665x().m10624a("Set uploading progress before finishing the previous upload");
        } else {
            this.f6494F = new ArrayList(list);
        }
    }

    public void m10861a(boolean z) {
        m10822P();
    }

    boolean m10862a(int i, int i2) {
        m10832B();
        if (i > i2) {
            m10879f().m10665x().m10626a("Panic: can't downgrade version. Previous, current version", Integer.valueOf(i), Integer.valueOf(i2));
            return false;
        }
        if (i < i2) {
            if (m10863a(i2, m10833C())) {
                m10879f().m10636D().m10626a("Storage version upgraded. Previous, current version", Integer.valueOf(i), Integer.valueOf(i2));
            } else {
                m10879f().m10665x().m10626a("Storage version upgrade failed. Previous, current version", Integer.valueOf(i), Integer.valueOf(i2));
                return false;
            }
        }
        return true;
    }

    boolean m10863a(int i, FileChannel fileChannel) {
        m10832B();
        if (fileChannel == null || !fileChannel.isOpen()) {
            m10879f().m10665x().m10624a("Bad chanel to read from");
            return false;
        }
        ByteBuffer allocate = ByteBuffer.allocate(4);
        allocate.putInt(i);
        allocate.flip();
        try {
            fileChannel.truncate(0);
            fileChannel.write(allocate);
            fileChannel.force(true);
            if (fileChannel.size() == 4) {
                return true;
            }
            m10879f().m10665x().m10625a("Error writing to channel. Bytes written", Long.valueOf(fileChannel.size()));
            return true;
        } catch (IOException e) {
            m10879f().m10665x().m10625a("Failed to write to channel", e);
            return false;
        }
    }

    boolean m10864a(long j) {
        return m10827a(null, j);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.String m10865b(java.lang.String r5) {
        /*
        r4 = this;
        r0 = r4.m10881h();
        r1 = new com.google.android.gms.b.es$2;
        r1.<init>(r4, r5);
        r0 = r0.m10785a(r1);
        r2 = 30000; // 0x7530 float:4.2039E-41 double:1.4822E-319;
        r1 = java.util.concurrent.TimeUnit.MILLISECONDS;	 Catch:{ TimeoutException -> 0x002e, InterruptedException -> 0x0018, ExecutionException -> 0x002c }
        r0 = r0.get(r2, r1);	 Catch:{ TimeoutException -> 0x002e, InterruptedException -> 0x0018, ExecutionException -> 0x002c }
        r0 = (java.lang.String) r0;	 Catch:{ TimeoutException -> 0x002e, InterruptedException -> 0x0018, ExecutionException -> 0x002c }
    L_0x0017:
        return r0;
    L_0x0018:
        r0 = move-exception;
    L_0x0019:
        r1 = r4.m10879f();
        r1 = r1.m10665x();
        r2 = "Failed to get app instance id. appId";
        r3 = com.google.android.gms.p095b.ek.m10629a(r5);
        r1.m10626a(r2, r3, r0);
        r0 = 0;
        goto L_0x0017;
    L_0x002c:
        r0 = move-exception;
        goto L_0x0019;
    L_0x002e:
        r0 = move-exception;
        goto L_0x0019;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.b.es.b(java.lang.String):java.lang.String");
    }

    public void m10866b(dq dqVar) {
        m10832B();
        m10847a();
        C3234c.m16042a((Object) dqVar);
        C3234c.m16044a(dqVar.f6251a);
        if (!TextUtils.isEmpty(dqVar.f6252b)) {
            if (dqVar.f6258h) {
                long a = m10892s().m16301a();
                m10888o().m10453x();
                try {
                    m10851a(dqVar, a);
                    m10830c(dqVar);
                    if (m10888o().m10409a(dqVar.f6251a, "_f") == null) {
                        m10858a(new fe("_fot", a, Long.valueOf((1 + (a / 3600000)) * 3600000), "auto"), dqVar);
                        m10867b(dqVar, a);
                        m10875c(dqVar, a);
                    } else if (dqVar.f6259i) {
                        m10877d(dqVar, a);
                    }
                    m10888o().m10454y();
                } finally {
                    m10888o().m10455z();
                }
            } else {
                m10830c(dqVar);
            }
        }
    }

    void m10867b(dq dqVar, long j) {
        m10832B();
        m10847a();
        dp b = m10888o().m10432b(dqVar.f6251a);
        if (!(b == null || !TextUtils.isEmpty(b.m10248d()) || dqVar == null || TextUtils.isEmpty(dqVar.f6252b))) {
            b.m10258g(0);
            m10888o().m10419a(b);
        }
        Bundle bundle = new Bundle();
        bundle.putLong("_c", 1);
        bundle.putLong("_r", 1);
        bundle.putLong("_uwa", 0);
        bundle.putLong("_pfo", 0);
        bundle.putLong("_sys", 0);
        bundle.putLong("_sysu", 0);
        if (m10891r().getPackageManager() == null) {
            m10879f().m10665x().m10625a("PackageManager is null, first open report might be inaccurate. appId", ek.m10629a(dqVar.f6251a));
        } else {
            PackageInfo b2;
            ApplicationInfo a;
            try {
                b2 = bn.m9791b(m10891r()).m9789b(dqVar.f6251a, 0);
            } catch (NameNotFoundException e) {
                m10879f().m10665x().m10626a("Package info is null, first open report might be inaccurate. appId", ek.m10629a(dqVar.f6251a), e);
                b2 = null;
            }
            if (!(b2 == null || b2.firstInstallTime == 0 || b2.firstInstallTime == b2.lastUpdateTime)) {
                bundle.putLong("_uwa", 1);
            }
            try {
                a = bn.m9791b(m10891r()).m9785a(dqVar.f6251a, 0);
            } catch (NameNotFoundException e2) {
                m10879f().m10665x().m10626a("Application info is null, first open report might be inaccurate. appId", ek.m10629a(dqVar.f6251a), e2);
                a = null;
            }
            if (a != null) {
                if ((a.flags & 1) != 0) {
                    bundle.putLong("_sys", 1);
                }
                if ((a.flags & ad.FLAG_HIGH_PRIORITY) != 0) {
                    bundle.putLong("_sysu", 1);
                }
            }
        }
        long h = m10888o().m10449h(dqVar.f6251a);
        if (h >= 0) {
            bundle.putLong("_pfo", h);
        }
        m10855a(new ed("_f", new eb(bundle), "auto", j), dqVar);
    }

    void m10868b(dt dtVar) {
        dq a = m10846a(dtVar.f6265b);
        if (a != null) {
            m10869b(dtVar, a);
        }
    }

    void m10869b(dt dtVar, dq dqVar) {
        C3234c.m16042a((Object) dtVar);
        C3234c.m16044a(dtVar.f6265b);
        C3234c.m16042a(dtVar.f6267d);
        C3234c.m16044a(dtVar.f6267d.f6711b);
        m10832B();
        m10847a();
        if (!TextUtils.isEmpty(dqVar.f6252b)) {
            if (dqVar.f6258h) {
                m10888o().m10453x();
                try {
                    m10830c(dqVar);
                    dt d = m10888o().m10441d(dtVar.f6265b, dtVar.f6267d.f6711b);
                    if (d != null) {
                        m10879f().m10635C().m10626a("Removing conditional user property", dtVar.f6265b, dtVar.f6267d.f6711b);
                        m10888o().m10443e(dtVar.f6265b, dtVar.f6267d.f6711b);
                        if (d.f6269f) {
                            m10888o().m10438b(dtVar.f6265b, dtVar.f6267d.f6711b);
                        }
                        if (dtVar.f6275l != null) {
                            Bundle bundle = null;
                            if (dtVar.f6275l.f6320b != null) {
                                bundle = dtVar.f6275l.f6320b.m10507b();
                            }
                            m10870b(m10887n().m11219a(dtVar.f6275l.f6319a, bundle, d.f6266c, dtVar.f6275l.f6322d, true, false), dqVar);
                        }
                    } else {
                        m10879f().m10667z().m10626a("Conditional user property doesn't exist", ek.m10629a(dtVar.f6265b), dtVar.f6267d.f6711b);
                    }
                    m10888o().m10454y();
                } finally {
                    m10888o().m10455z();
                }
            } else {
                m10830c(dqVar);
            }
        }
    }

    void m10870b(ed edVar, dq dqVar) {
        C3234c.m16042a((Object) dqVar);
        C3234c.m16044a(dqVar.f6251a);
        long nanoTime = System.nanoTime();
        m10832B();
        m10847a();
        String str = dqVar.f6251a;
        if (!m10887n().m11231a(edVar, dqVar)) {
            return;
        }
        if (!dqVar.f6258h) {
            m10830c(dqVar);
        } else if (m10883j().m10748b(str, edVar.f6319a)) {
            m10879f().m10667z().m10626a("Dropping blacklisted event. appId", ek.m10629a(str), edVar.f6319a);
            r2 = (m10887n().m11268m(str) || m10887n().m11270n(str)) ? 1 : null;
            if (r2 == null && !"_err".equals(edVar.f6319a)) {
                m10887n().m11222a(11, "_ev", edVar.f6319a, 0);
            }
            if (r2 != null) {
                dp b = m10888o().m10432b(str);
                if (b != null) {
                    if (Math.abs(m10892s().m16301a() - Math.max(b.m10277q(), b.m10276p())) > m10876d().ac()) {
                        m10879f().m10635C().m10624a("Fetching config for blacklisted app");
                        m10849a(b);
                    }
                }
            }
        } else {
            if (m10879f().m10642a(2)) {
                m10879f().m10636D().m10625a("Logging event", edVar);
            }
            m10888o().m10453x();
            try {
                Bundle b2 = edVar.f6320b.m10507b();
                m10830c(dqVar);
                if ("_iap".equals(edVar.f6319a) || "ecommerce_purchase".equals(edVar.f6319a)) {
                    long round;
                    r2 = b2.getString("currency");
                    if ("ecommerce_purchase".equals(edVar.f6319a)) {
                        double d = b2.getDouble("value") * 1000000.0d;
                        if (d == 0.0d) {
                            d = ((double) b2.getLong("value")) * 1000000.0d;
                        }
                        if (d > 9.223372036854776E18d || d < -9.223372036854776E18d) {
                            m10879f().m10667z().m10626a("Data lost. Currency value is too big. appId", ek.m10629a(str), Double.valueOf(d));
                            m10888o().m10454y();
                            m10888o().m10455z();
                            return;
                        }
                        round = Math.round(d);
                    } else {
                        round = b2.getLong("value");
                    }
                    if (!TextUtils.isEmpty(r2)) {
                        String toUpperCase = r2.toUpperCase(Locale.US);
                        if (toUpperCase.matches("[A-Z]{3}")) {
                            String valueOf = String.valueOf("_ltv_");
                            toUpperCase = String.valueOf(toUpperCase);
                            String concat = toUpperCase.length() != 0 ? valueOf.concat(toUpperCase) : new String(valueOf);
                            fg c = m10888o().m10440c(str, concat);
                            if (c == null || !(c.f6722e instanceof Long)) {
                                m10888o().m10421a(str, m10876d().m10348e(str) - 1);
                                c = new fg(str, edVar.f6321c, concat, m10892s().m16301a(), Long.valueOf(round));
                            } else {
                                c = new fg(str, edVar.f6321c, concat, m10892s().m16301a(), Long.valueOf(round + ((Long) c.f6722e).longValue()));
                            }
                            if (!m10888o().m10429a(c)) {
                                m10879f().m10665x().m10627a("Too many unique user properties are set. Ignoring user property. appId", ek.m10629a(str), c.f6720c, c.f6722e);
                                m10887n().m11222a(9, null, null, 0);
                            }
                        }
                    }
                }
                boolean a = fh.m11205a(edVar.f6319a);
                boolean equals = "_err".equals(edVar.f6319a);
                C2518a a2 = m10888o().m10408a(m10837G(), str, true, a, false, equals, false);
                long G = a2.f6279b - m10876d().m10317G();
                if (G > 0) {
                    if (G % 1000 == 1) {
                        m10879f().m10665x().m10626a("Data loss. Too many events logged. appId, count", ek.m10629a(str), Long.valueOf(a2.f6279b));
                    }
                    m10887n().m11222a(16, "_ev", edVar.f6319a, 0);
                    m10888o().m10454y();
                    return;
                }
                ea eaVar;
                if (a) {
                    G = a2.f6278a - m10876d().m10318H();
                    if (G > 0) {
                        if (G % 1000 == 1) {
                            m10879f().m10665x().m10626a("Data loss. Too many public events logged. appId, count", ek.m10629a(str), Long.valueOf(a2.f6278a));
                        }
                        m10887n().m11222a(16, "_ev", edVar.f6319a, 0);
                        m10888o().m10454y();
                        m10888o().m10455z();
                        return;
                    }
                }
                if (equals) {
                    G = a2.f6281d - ((long) m10876d().m10337a(dqVar.f6251a));
                    if (G > 0) {
                        if (G == 1) {
                            m10879f().m10665x().m10626a("Too many error events logged. appId, count", ek.m10629a(str), Long.valueOf(a2.f6281d));
                        }
                        m10888o().m10454y();
                        m10888o().m10455z();
                        return;
                    }
                }
                m10887n().m11224a(b2, "_o", edVar.f6321c);
                if (m10887n().m11265k(str)) {
                    m10887n().m11224a(b2, "_dbg", Long.valueOf(1));
                    m10887n().m11224a(b2, "_r", Long.valueOf(1));
                }
                G = m10888o().m10439c(str);
                if (G > 0) {
                    m10879f().m10667z().m10626a("Data lost. Too many events stored on disk, deleted. appId", ek.m10629a(str), Long.valueOf(G));
                }
                dz dzVar = new dz(this, edVar.f6321c, str, edVar.f6319a, edVar.f6322d, 0, b2);
                ea a3 = m10888o().m10409a(str, dzVar.f6301b);
                if (a3 == null) {
                    long j = m10888o().m10452j(str);
                    m10876d().m10316F();
                    if (j >= 500) {
                        m10879f().m10665x().m10627a("Too many event names used, ignoring event. appId, name, supported count", ek.m10629a(str), dzVar.f6301b, Integer.valueOf(m10876d().m10316F()));
                        m10887n().m11222a(8, null, null, 0);
                        m10888o().m10455z();
                        return;
                    }
                    eaVar = new ea(str, dzVar.f6301b, 0, 0, dzVar.f6303d);
                } else {
                    dzVar = dzVar.m10493a(this, a3.f6315e);
                    eaVar = a3.m10502a(dzVar.f6303d);
                }
                m10888o().m10420a(eaVar);
                m10854a(dzVar, dqVar);
                m10888o().m10454y();
                if (m10879f().m10642a(2)) {
                    m10879f().m10636D().m10625a("Event recorded", dzVar);
                }
                m10888o().m10455z();
                m10822P();
                m10879f().m10636D().m10625a("Background event processing time, ms", Long.valueOf(((System.nanoTime() - nanoTime) + 500000) / 1000000));
            } finally {
                m10888o().m10455z();
            }
        }
    }

    void m10871b(fe feVar, dq dqVar) {
        m10832B();
        m10847a();
        if (!TextUtils.isEmpty(dqVar.f6252b)) {
            if (dqVar.f6258h) {
                m10879f().m10635C().m10625a("Removing user property", feVar.f6711b);
                m10888o().m10453x();
                try {
                    m10830c(dqVar);
                    m10888o().m10438b(dqVar.f6251a, feVar.f6711b);
                    m10888o().m10454y();
                    m10879f().m10635C().m10625a("User property removed", feVar.f6711b);
                } finally {
                    m10888o().m10455z();
                }
            } else {
                m10830c(dqVar);
            }
        }
    }

    protected boolean m10872b() {
        boolean z = false;
        m10847a();
        m10832B();
        if (this.f6490B == null || this.f6491C == 0 || !(this.f6490B == null || this.f6490B.booleanValue() || Math.abs(m10892s().m16302b() - this.f6491C) <= 1000)) {
            this.f6491C = m10892s().m16302b();
            m10876d().m10332V();
            if (m10887n().m11262i("android.permission.INTERNET") && m10887n().m11262i("android.permission.ACCESS_NETWORK_STATE") && (bn.m9791b(m10891r()).m9786a() || (ep.m10736a(m10891r(), false) && fa.m11107a(m10891r(), false)))) {
                z = true;
            }
            this.f6490B = Boolean.valueOf(z);
            if (this.f6490B.booleanValue()) {
                this.f6490B = Boolean.valueOf(m10887n().m11257f(m10896w().m10587y()));
            }
        }
        return this.f6490B.booleanValue();
    }

    public byte[] m10873b(ed edVar, String str) {
        m10847a();
        m10832B();
        m10839I();
        C3234c.m16042a((Object) edVar);
        C3234c.m16044a(str);
        C2609d c2609d = new C2609d();
        m10888o().m10453x();
        try {
            dp b = m10888o().m10432b(str);
            byte[] bArr;
            if (b == null) {
                m10879f().m10635C().m10625a("Log and bundle not available. package_name", str);
                bArr = new byte[0];
                return bArr;
            } else if (b.m10273n()) {
                long j;
                C2610e c2610e = new C2610e();
                c2609d.f6783a = new C2610e[]{c2610e};
                c2610e.f6793a = Integer.valueOf(1);
                c2610e.f6801i = "android";
                c2610e.f6807o = b.m10242b();
                c2610e.f6806n = b.m10266k();
                c2610e.f6808p = b.m10262i();
                c2610e.f6787C = Integer.valueOf((int) b.m10264j());
                c2610e.f6809q = Long.valueOf(b.m10268l());
                c2610e.f6817y = b.m10248d();
                c2610e.f6814v = Long.valueOf(b.m10270m());
                Pair a = m10878e().m10725a(b.m10242b());
                if (!TextUtils.isEmpty((CharSequence) a.first)) {
                    c2610e.f6811s = (String) a.first;
                    c2610e.f6812t = (Boolean) a.second;
                }
                c2610e.f6803k = m10895v().m10489x();
                c2610e.f6802j = m10895v().m10490y();
                c2610e.f6805m = Integer.valueOf((int) m10895v().m10491z());
                c2610e.f6804l = m10895v().m10464A();
                c2610e.f6813u = b.m10245c();
                c2610e.f6786B = b.m10254f();
                List a2 = m10888o().m10410a(b.m10242b());
                c2610e.f6795c = new C2612g[a2.size()];
                for (int i = 0; i < a2.size(); i++) {
                    C2612g c2612g = new C2612g();
                    c2610e.f6795c[i] = c2612g;
                    c2612g.f6823b = ((fg) a2.get(i)).f6720c;
                    c2612g.f6822a = Long.valueOf(((fg) a2.get(i)).f6721d);
                    m10887n().m11226a(c2612g, ((fg) a2.get(i)).f6722e);
                }
                Bundle b2 = edVar.f6320b.m10507b();
                if ("_iap".equals(edVar.f6319a)) {
                    b2.putLong("_c", 1);
                    m10879f().m10635C().m10624a("Marking in-app purchase as real-time");
                    b2.putLong("_r", 1);
                }
                b2.putString("_o", edVar.f6321c);
                if (m10887n().m11265k(c2610e.f6807o)) {
                    m10887n().m11224a(b2, "_dbg", Long.valueOf(1));
                    m10887n().m11224a(b2, "_r", Long.valueOf(1));
                }
                ea a3 = m10888o().m10409a(str, edVar.f6319a);
                if (a3 == null) {
                    m10888o().m10420a(new ea(str, edVar.f6319a, 1, 0, edVar.f6322d));
                    j = 0;
                } else {
                    j = a3.f6315e;
                    m10888o().m10420a(a3.m10502a(edVar.f6322d).m10501a());
                }
                dz dzVar = new dz(this, edVar.f6321c, str, edVar.f6319a, edVar.f6322d, j, b2);
                C2607b c2607b = new C2607b();
                c2610e.f6794b = new C2607b[]{c2607b};
                c2607b.f6774c = Long.valueOf(dzVar.f6303d);
                c2607b.f6773b = dzVar.f6301b;
                c2607b.f6775d = Long.valueOf(dzVar.f6304e);
                c2607b.f6772a = new C2608c[dzVar.f6305f.m10505a()];
                Iterator it = dzVar.f6305f.iterator();
                int i2 = 0;
                while (it.hasNext()) {
                    String str2 = (String) it.next();
                    C2608c c2608c = new C2608c();
                    int i3 = i2 + 1;
                    c2607b.f6772a[i2] = c2608c;
                    c2608c.f6778a = str2;
                    m10887n().m11225a(c2608c, dzVar.f6305f.m10506a(str2));
                    i2 = i3;
                }
                c2610e.f6785A = m10828a(b.m10242b(), c2610e.f6795c, c2610e.f6794b);
                c2610e.f6797e = c2607b.f6774c;
                c2610e.f6798f = c2607b.f6774c;
                long h = b.m10260h();
                c2610e.f6800h = h != 0 ? Long.valueOf(h) : null;
                long g = b.m10257g();
                if (g != 0) {
                    h = g;
                }
                c2610e.f6799g = h != 0 ? Long.valueOf(h) : null;
                b.m10278r();
                c2610e.f6815w = Integer.valueOf((int) b.m10274o());
                c2610e.f6810r = Long.valueOf(m10876d().m10331U());
                c2610e.f6796d = Long.valueOf(m10892s().m16301a());
                c2610e.f6818z = Boolean.TRUE;
                b.m10239a(c2610e.f6797e.longValue());
                b.m10243b(c2610e.f6798f.longValue());
                m10888o().m10419a(b);
                m10888o().m10454y();
                m10888o().m10455z();
                try {
                    bArr = new byte[c2609d.m9802g()];
                    hm a4 = hm.m11666a(bArr);
                    c2609d.m11353a(a4);
                    a4.m11710b();
                    return m10887n().m11239a(bArr);
                } catch (IOException e) {
                    m10879f().m10665x().m10626a("Data loss. Failed to bundle and serialize. appId", ek.m10629a(str), e);
                    return null;
                }
            } else {
                m10879f().m10635C().m10625a("Log and bundle disabled. package_name", str);
                bArr = new byte[0];
                m10888o().m10455z();
                return bArr;
            }
        } finally {
            m10888o().m10455z();
        }
    }

    protected void m10874c() {
        m10832B();
        m10888o().m10400E();
        if (m10878e().f6431c.m10708a() == 0) {
            m10878e().f6431c.m10709a(m10892s().m16301a());
        }
        if (m10872b()) {
            m10876d().m10332V();
            if (!TextUtils.isEmpty(m10896w().m10587y())) {
                String A = m10878e().m10721A();
                if (A == null) {
                    m10878e().m10730c(m10896w().m10587y());
                } else if (!A.equals(m10896w().m10587y())) {
                    m10879f().m10634B().m10624a("Rechecking which service to use due to a GMP App Id change");
                    m10878e().m10723C();
                    this.f6514r.m11068C();
                    this.f6514r.m11066A();
                    m10878e().m10730c(m10896w().m10587y());
                }
            }
            m10876d().m10332V();
            if (!TextUtils.isEmpty(m10896w().m10587y())) {
                m10885l().m11006y();
            }
        } else if (m10836F()) {
            if (!m10887n().m11262i("android.permission.INTERNET")) {
                m10879f().m10665x().m10624a("App is missing INTERNET permission");
            }
            if (!m10887n().m11262i("android.permission.ACCESS_NETWORK_STATE")) {
                m10879f().m10665x().m10624a("App is missing ACCESS_NETWORK_STATE permission");
            }
            m10876d().m10332V();
            if (!bn.m9791b(m10891r()).m9786a()) {
                if (!ep.m10736a(m10891r(), false)) {
                    m10879f().m10665x().m10624a("AppMeasurementReceiver not registered/enabled");
                }
                if (!fa.m11107a(m10891r(), false)) {
                    m10879f().m10665x().m10624a("AppMeasurementService not registered/enabled");
                }
            }
            m10879f().m10665x().m10624a("Uploading is not possible. App measurement disabled");
        }
        m10822P();
    }

    void m10875c(dq dqVar, long j) {
        Bundle bundle = new Bundle();
        bundle.putLong("_et", 1);
        m10855a(new ed("_e", new eb(bundle), "auto", j), dqVar);
    }

    public dv m10876d() {
        return this.f6500d;
    }

    void m10877d(dq dqVar, long j) {
        m10855a(new ed("_cd", new eb(new Bundle()), "auto", j), dqVar);
    }

    public eo m10878e() {
        m10825a(this.f6501e);
        return this.f6501e;
    }

    public ek m10879f() {
        m10829b(this.f6502f);
        return this.f6502f;
    }

    public ek m10880g() {
        return (this.f6502f == null || !this.f6502f.m10290Q()) ? null : this.f6502f;
    }

    public er m10881h() {
        m10829b(this.f6503g);
        return this.f6503g;
    }

    public fb m10882i() {
        m10829b(this.f6504h);
        return this.f6504h;
    }

    public eq m10883j() {
        m10829b(this.f6505i);
        return this.f6505i;
    }

    er m10884k() {
        return this.f6503g;
    }

    public ex m10885l() {
        m10829b(this.f6516t);
        return this.f6516t;
    }

    public AppMeasurement m10886m() {
        return this.f6506j;
    }

    public fh m10887n() {
        m10825a(this.f6508l);
        return this.f6508l;
    }

    public dw m10888o() {
        m10829b(this.f6509m);
        return this.f6509m;
    }

    public ei m10889p() {
        m10829b(this.f6510n);
        return this.f6510n;
    }

    public el m10890q() {
        m10829b(this.f6511o);
        return this.f6511o;
    }

    public Context m10891r() {
        return this.f6499c;
    }

    public C3293c m10892s() {
        return this.f6512p;
    }

    public ey m10893t() {
        m10829b(this.f6513q);
        return this.f6513q;
    }

    public ez m10894u() {
        m10829b(this.f6514r);
        return this.f6514r;
    }

    public dy m10895v() {
        m10829b(this.f6515s);
        return this.f6515s;
    }

    public eh m10896w() {
        m10829b(this.f6517u);
        return this.f6517u;
    }

    public em m10897x() {
        if (this.f6518v != null) {
            return this.f6518v;
        }
        throw new IllegalStateException("Network broadcast receiver not created");
    }

    public fd m10898y() {
        m10829b(this.f6519w);
        return this.f6519w;
    }

    public ds m10899z() {
        m10829b(this.f6520x);
        return this.f6520x;
    }
}
