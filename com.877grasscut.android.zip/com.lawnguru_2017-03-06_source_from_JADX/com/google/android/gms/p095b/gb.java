package com.google.android.gms.p095b;

import android.accounts.Account;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.common.internal.C3235d;
import com.google.android.gms.common.internal.C3244m;
import com.google.android.gms.common.internal.aa;
import com.google.android.gms.common.internal.aa.C3219a;
import com.google.android.gms.common.internal.ag;
import com.google.android.gms.common.internal.ag.C3230a;
import com.google.android.gms.p095b.ga.C2419a;
import com.zopim.android.sdk.api.C5264R;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.b.gb */
public interface gb extends IInterface {

    /* renamed from: com.google.android.gms.b.gb.a */
    public static abstract class C2626a extends Binder implements gb {

        /* renamed from: com.google.android.gms.b.gb.a.a */
        private static class C2625a implements gb {
            private IBinder f6874a;

            C2625a(IBinder iBinder) {
                this.f6874a = iBinder;
            }

            public void m11482a(int i) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.signin.internal.ISignInService");
                    obtain.writeInt(i);
                    this.f6874a.transact(7, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m11483a(int i, Account account, ga gaVar) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.signin.internal.ISignInService");
                    obtain.writeInt(i);
                    if (account != null) {
                        obtain.writeInt(1);
                        account.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(gaVar != null ? gaVar.asBinder() : null);
                    this.f6874a.transact(8, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m11484a(fy fyVar) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.signin.internal.ISignInService");
                    if (fyVar != null) {
                        obtain.writeInt(1);
                        fyVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.f6874a.transact(3, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m11485a(ga gaVar) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.signin.internal.ISignInService");
                    obtain.writeStrongBinder(gaVar != null ? gaVar.asBinder() : null);
                    this.f6874a.transact(11, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m11486a(gc gcVar, ga gaVar) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.signin.internal.ISignInService");
                    if (gcVar != null) {
                        obtain.writeInt(1);
                        gcVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(gaVar != null ? gaVar.asBinder() : null);
                    this.f6874a.transact(10, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m11487a(gf gfVar, ga gaVar) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.signin.internal.ISignInService");
                    if (gfVar != null) {
                        obtain.writeInt(1);
                        gfVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(gaVar != null ? gaVar.asBinder() : null);
                    this.f6874a.transact(12, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m11488a(aa aaVar, int i, boolean z) {
                int i2 = 0;
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.signin.internal.ISignInService");
                    obtain.writeStrongBinder(aaVar != null ? aaVar.asBinder() : null);
                    obtain.writeInt(i);
                    if (z) {
                        i2 = 1;
                    }
                    obtain.writeInt(i2);
                    this.f6874a.transact(9, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m11489a(C3235d c3235d, ag agVar) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.signin.internal.ISignInService");
                    if (c3235d != null) {
                        obtain.writeInt(1);
                        c3235d.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(agVar != null ? agVar.asBinder() : null);
                    this.f6874a.transact(5, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m11490a(C3244m c3244m, ga gaVar) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.signin.internal.ISignInService");
                    if (c3244m != null) {
                        obtain.writeInt(1);
                        c3244m.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(gaVar != null ? gaVar.asBinder() : null);
                    this.f6874a.transact(2, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m11491a(boolean z) {
                int i = 0;
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.signin.internal.ISignInService");
                    if (z) {
                        i = 1;
                    }
                    obtain.writeInt(i);
                    this.f6874a.transact(4, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public IBinder asBinder() {
                return this.f6874a;
            }

            public void m11492b(boolean z) {
                int i = 0;
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.signin.internal.ISignInService");
                    if (z) {
                        i = 1;
                    }
                    obtain.writeInt(i);
                    this.f6874a.transact(13, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }

        public static gb m11493a(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.signin.internal.ISignInService");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof gb)) ? new C2625a(iBinder) : (gb) queryLocalInterface;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
            boolean z = false;
            gf gfVar = null;
            switch (i) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    C3244m c3244m;
                    parcel.enforceInterface("com.google.android.gms.signin.internal.ISignInService");
                    if (parcel.readInt() != 0) {
                        c3244m = (C3244m) C3244m.CREATOR.createFromParcel(parcel);
                    }
                    m11479a(c3244m, C2419a.m9655a(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    fy fyVar;
                    parcel.enforceInterface("com.google.android.gms.signin.internal.ISignInService");
                    if (parcel.readInt() != 0) {
                        fyVar = (fy) fy.CREATOR.createFromParcel(parcel);
                    }
                    m11473a(fyVar);
                    parcel2.writeNoException();
                    return true;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    parcel.enforceInterface("com.google.android.gms.signin.internal.ISignInService");
                    m11480a(parcel.readInt() != 0);
                    parcel2.writeNoException();
                    return true;
                case C5500d.ProperRatingBar_prb_symbolicTick /*5*/:
                    C3235d c3235d;
                    parcel.enforceInterface("com.google.android.gms.signin.internal.ISignInService");
                    if (parcel.readInt() != 0) {
                        c3235d = (C3235d) C3235d.CREATOR.createFromParcel(parcel);
                    }
                    m11478a(c3235d, C3230a.m16033a(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case C5500d.ProperRatingBar_prb_symbolicTickSelectedColor /*7*/:
                    parcel.enforceInterface("com.google.android.gms.signin.internal.ISignInService");
                    m11471a(parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case C5500d.ProperRatingBar_prb_tickNormalDrawable /*8*/:
                    Account account;
                    parcel.enforceInterface("com.google.android.gms.signin.internal.ISignInService");
                    int readInt = parcel.readInt();
                    if (parcel.readInt() != 0) {
                        account = (Account) Account.CREATOR.createFromParcel(parcel);
                    }
                    m11472a(readInt, account, C2419a.m9655a(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case C5500d.ProperRatingBar_prb_tickSelectedDrawable /*9*/:
                    parcel.enforceInterface("com.google.android.gms.signin.internal.ISignInService");
                    aa a = C3219a.m16005a(parcel.readStrongBinder());
                    int readInt2 = parcel.readInt();
                    if (parcel.readInt() != 0) {
                        z = true;
                    }
                    m11477a(a, readInt2, z);
                    parcel2.writeNoException();
                    return true;
                case C5500d.ProperRatingBar_prb_tickSpacing /*10*/:
                    gc gcVar;
                    parcel.enforceInterface("com.google.android.gms.signin.internal.ISignInService");
                    if (parcel.readInt() != 0) {
                        gcVar = (gc) gc.CREATOR.createFromParcel(parcel);
                    }
                    m11475a(gcVar, C2419a.m9655a(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case C5264R.styleable.Toolbar_popupTheme /*11*/:
                    parcel.enforceInterface("com.google.android.gms.signin.internal.ISignInService");
                    m11474a(C2419a.m9655a(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case C5264R.styleable.Toolbar_titleTextAppearance /*12*/:
                    parcel.enforceInterface("com.google.android.gms.signin.internal.ISignInService");
                    if (parcel.readInt() != 0) {
                        gfVar = (gf) gf.CREATOR.createFromParcel(parcel);
                    }
                    m11476a(gfVar, C2419a.m9655a(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case C5264R.styleable.Toolbar_subtitleTextAppearance /*13*/:
                    parcel.enforceInterface("com.google.android.gms.signin.internal.ISignInService");
                    if (parcel.readInt() != 0) {
                        z = true;
                    }
                    m11481b(z);
                    parcel2.writeNoException();
                    return true;
                case 1598968902:
                    parcel2.writeString("com.google.android.gms.signin.internal.ISignInService");
                    return true;
                default:
                    return super.onTransact(i, parcel, parcel2, i2);
            }
        }
    }

    void m11471a(int i);

    void m11472a(int i, Account account, ga gaVar);

    void m11473a(fy fyVar);

    void m11474a(ga gaVar);

    void m11475a(gc gcVar, ga gaVar);

    void m11476a(gf gfVar, ga gaVar);

    void m11477a(aa aaVar, int i, boolean z);

    void m11478a(C3235d c3235d, ag agVar);

    void m11479a(C3244m c3244m, ga gaVar);

    void m11480a(boolean z);

    void m11481b(boolean z);
}
