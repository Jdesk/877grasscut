package com.google.android.gms.p095b;

import org.json.JSONObject;

/* renamed from: com.google.android.gms.b.it */
public interface it {
    void m11981a(JSONObject jSONObject, boolean z);

    boolean m11982a();

    void m11983b();
}
