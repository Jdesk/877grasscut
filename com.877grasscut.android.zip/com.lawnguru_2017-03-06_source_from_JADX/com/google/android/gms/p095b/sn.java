package com.google.android.gms.p095b;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C2149a;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

@sc
/* renamed from: com.google.android.gms.b.sn */
public final class sn extends C2149a {
    public static final Creator<sn> CREATOR;
    public final boolean f8625a;
    public final List<String> f8626b;

    static {
        CREATOR = new so();
    }

    public sn() {
        this(false, Collections.emptyList());
    }

    public sn(boolean z) {
        this(z, Collections.emptyList());
    }

    public sn(boolean z, List<String> list) {
        this.f8625a = z;
        this.f8626b = list;
    }

    public static sn m14073a(JSONObject jSONObject) {
        if (jSONObject == null) {
            return new sn();
        }
        JSONArray optJSONArray = jSONObject.optJSONArray("reporting_urls");
        List arrayList = new ArrayList();
        if (optJSONArray != null) {
            for (int i = 0; i < optJSONArray.length(); i++) {
                try {
                    arrayList.add(optJSONArray.getString(i));
                } catch (Throwable e) {
                    wg.m14618c("Error grabbing url from json.", e);
                }
            }
        }
        return new sn(jSONObject.optBoolean("enable_protection"), arrayList);
    }

    public void writeToParcel(Parcel parcel, int i) {
        so.m14074a(this, parcel, i);
    }
}
