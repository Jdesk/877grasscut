package com.google.android.gms.p095b;

import com.google.android.gms.common.C3204l;

/* renamed from: com.google.android.gms.b.ye */
public class ye {
    public static final String f9492a;
    public static final String f9493b;

    static {
        f9492a = String.valueOf(C3204l.f9789b / 1000).replaceAll("(\\d+)(\\d)(\\d\\d)", "$1.$2.$3");
        String str = "ma";
        String valueOf = String.valueOf(f9492a);
        f9493b = valueOf.length() != 0 ? str.concat(valueOf) : new String(str);
    }
}
