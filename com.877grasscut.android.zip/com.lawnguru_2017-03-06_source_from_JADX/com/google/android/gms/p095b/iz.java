package com.google.android.gms.p095b;

import com.google.android.gms.ads.internal.C2243w;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

@sc
/* renamed from: com.google.android.gms.b.iz */
public class iz {
    private final Object f7235a;
    private int f7236b;
    private List<iy> f7237c;

    public iz() {
        this.f7235a = new Object();
        this.f7237c = new LinkedList();
    }

    public iy m12049a() {
        iy iyVar = null;
        int i = 0;
        synchronized (this.f7235a) {
            if (this.f7237c.size() == 0) {
                wg.m14615b("Queue empty");
                return null;
            } else if (this.f7237c.size() >= 2) {
                int i2 = RtlSpacingHelper.UNDEFINED;
                int i3 = 0;
                for (iy iyVar2 : this.f7237c) {
                    iy iyVar3;
                    int i4;
                    int i5 = iyVar2.m12047i();
                    if (i5 > i2) {
                        i = i5;
                        iyVar3 = iyVar2;
                        i4 = i3;
                    } else {
                        i4 = i;
                        iyVar3 = iyVar;
                        i = i2;
                    }
                    i3++;
                    i2 = i;
                    iyVar = iyVar3;
                    i = i4;
                }
                this.f7237c.remove(i);
                return iyVar;
            } else {
                iyVar2 = (iy) this.f7237c.get(0);
                iyVar2.m12043e();
                return iyVar2;
            }
        }
    }

    public boolean m12050a(iy iyVar) {
        boolean z;
        synchronized (this.f7235a) {
            if (this.f7237c.contains(iyVar)) {
                z = true;
            } else {
                z = false;
            }
        }
        return z;
    }

    public boolean m12051b(iy iyVar) {
        synchronized (this.f7235a) {
            Iterator it = this.f7237c.iterator();
            while (it.hasNext()) {
                iy iyVar2 = (iy) it.next();
                if (!((Boolean) ly.ac.m12563c()).booleanValue() || C2243w.m8790i().m14570b()) {
                    if (((Boolean) ly.ae.m12563c()).booleanValue() && !C2243w.m8790i().m14572c() && iyVar != iyVar2 && iyVar2.m12042d().equals(iyVar.m12042d())) {
                        it.remove();
                        return true;
                    }
                } else if (iyVar != iyVar2 && iyVar2.m12039b().equals(iyVar.m12039b())) {
                    it.remove();
                    return true;
                }
            }
            return false;
        }
    }

    public void m12052c(iy iyVar) {
        synchronized (this.f7235a) {
            if (this.f7237c.size() >= 10) {
                wg.m14615b("Queue is full, current size = " + this.f7237c.size());
                this.f7237c.remove(0);
            }
            int i = this.f7236b;
            this.f7236b = i + 1;
            iyVar.m12036a(i);
            this.f7237c.add(iyVar);
        }
    }
}
