package com.google.android.gms.p095b;

import android.accounts.Account;
import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.internal.C2378n;
import com.google.android.gms.common.api.C2854c.C2420b;
import com.google.android.gms.common.api.C2854c.C2421c;
import com.google.android.gms.common.internal.C2353o.C3251i;
import com.google.android.gms.common.internal.C2357u;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.common.internal.C3235d;
import com.google.android.gms.common.internal.C3255p;
import com.google.android.gms.common.internal.aa;
import com.google.android.gms.p095b.gb.C2626a;

/* renamed from: com.google.android.gms.b.ge */
public class ge extends C2357u<gb> implements ft {
    private final boolean f6879e;
    private final C3255p f6880f;
    private final Bundle f6881g;
    private Integer f6882h;

    public ge(Context context, Looper looper, boolean z, C3255p c3255p, Bundle bundle, C2420b c2420b, C2421c c2421c) {
        super(context, looper, 44, c3255p, c2420b, c2421c);
        this.f6879e = z;
        this.f6880f = c3255p;
        this.f6881g = bundle;
        this.f6882h = c3255p.m16109j();
    }

    public ge(Context context, Looper looper, boolean z, C3255p c3255p, fu fuVar, C2420b c2420b, C2421c c2421c) {
        this(context, looper, z, c3255p, ge.m11500a(c3255p), c2420b, c2421c);
    }

    public static Bundle m11500a(C3255p c3255p) {
        fu i = c3255p.m16108i();
        Integer j = c3255p.m16109j();
        Bundle bundle = new Bundle();
        bundle.putParcelable("com.google.android.gms.signin.internal.clientRequestedAccount", c3255p.m16101b());
        if (j != null) {
            bundle.putInt("com.google.android.gms.common.internal.ClientSettings.sessionId", j.intValue());
        }
        if (i != null) {
            bundle.putBoolean("com.google.android.gms.signin.internal.offlineAccessRequested", i.m11447a());
            bundle.putBoolean("com.google.android.gms.signin.internal.idTokenRequested", i.m11448b());
            bundle.putString("com.google.android.gms.signin.internal.serverClientId", i.m11449c());
            bundle.putBoolean("com.google.android.gms.signin.internal.usePromptModeForAuthCode", true);
            bundle.putBoolean("com.google.android.gms.signin.internal.forceCodeForRefreshToken", i.m11450d());
            bundle.putString("com.google.android.gms.signin.internal.hostedDomain", i.m11451e());
            bundle.putBoolean("com.google.android.gms.signin.internal.waitForAccessTokenRefresh", i.m11452f());
            if (i.m11453g() != null) {
                bundle.putLong("com.google.android.gms.signin.internal.authApiSignInModuleVersion", i.m11453g().longValue());
            }
            if (i.m11454h() != null) {
                bundle.putLong("com.google.android.gms.signin.internal.realClientLibraryVersion", i.m11454h().longValue());
            }
        }
        return bundle;
    }

    private C3235d m11501z() {
        Account c = this.f6880f.m16102c();
        GoogleSignInAccount googleSignInAccount = null;
        if ("<<default account>>".equals(c.name)) {
            googleSignInAccount = C2378n.m9365a(m9264o()).m9367a();
        }
        return new C3235d(c, this.f6882h.intValue(), googleSignInAccount);
    }

    protected gb m11502a(IBinder iBinder) {
        return C2626a.m11493a(iBinder);
    }

    protected String m11503a() {
        return "com.google.android.gms.signin.service.START";
    }

    public void m11504a(ga gaVar) {
        C3234c.m16043a((Object) gaVar, (Object) "Expecting a valid ISignInCallbacks");
        try {
            ((gb) m9271v()).m11476a(new gf(m11501z()), gaVar);
        } catch (Throwable e) {
            Log.w("SignInClientImpl", "Remote service probably died when signIn is called");
            try {
                gaVar.m9650a(new gh(8));
            } catch (RemoteException e2) {
                Log.wtf("SignInClientImpl", "ISignInCallbacks#onSignInComplete should be executed from the same process, unexpected RemoteException.", e);
            }
        }
    }

    public void m11505a(aa aaVar, boolean z) {
        try {
            ((gb) m9271v()).m11477a(aaVar, this.f6882h.intValue(), z);
        } catch (RemoteException e) {
            Log.w("SignInClientImpl", "Remote service probably died when saveDefaultAccount is called");
        }
    }

    protected /* synthetic */ IInterface m11506b(IBinder iBinder) {
        return m11502a(iBinder);
    }

    protected String m11507b() {
        return "com.google.android.gms.signin.internal.ISignInService";
    }

    public void m11508e() {
        try {
            ((gb) m9271v()).m11471a(this.f6882h.intValue());
        } catch (RemoteException e) {
            Log.w("SignInClientImpl", "Remote service probably died when clearAccountFromSessionStore is called");
        }
    }

    public boolean m11509i() {
        return this.f6879e;
    }

    public void m11510l() {
        m9248a(new C3251i(this));
    }

    protected Bundle m11511s() {
        if (!m9264o().getPackageName().equals(this.f6880f.m16106g())) {
            this.f6881g.putString("com.google.android.gms.signin.internal.realClientPackageName", this.f6880f.m16106g());
        }
        return this.f6881g;
    }
}
