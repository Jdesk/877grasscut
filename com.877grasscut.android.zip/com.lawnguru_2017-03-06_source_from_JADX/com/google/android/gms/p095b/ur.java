package com.google.android.gms.p095b;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import io.techery.properratingbar.C5501a.C5500d;
import java.util.List;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.b.ur */
public class ur implements Creator<uq> {
    static void m14471a(uq uqVar, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16177a(parcel, 2, uqVar.f8933a, false);
        C3264c.m16177a(parcel, 3, uqVar.f8934b, false);
        C3264c.m16180a(parcel, 4, uqVar.f8935c);
        C3264c.m16180a(parcel, 5, uqVar.f8936d);
        C3264c.m16189b(parcel, 6, uqVar.f8937e, false);
        C3264c.m16164a(parcel, a);
    }

    public uq m14472a(Parcel parcel) {
        boolean z = false;
        List list = null;
        int b = C3263b.m16139b(parcel);
        boolean z2 = false;
        String str = null;
        String str2 = null;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    str2 = C3263b.m16154n(parcel, a);
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    str = C3263b.m16154n(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    z2 = C3263b.m16143c(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTick /*5*/:
                    z = C3263b.m16143c(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickNormalColor /*6*/:
                    list = C3263b.m16162v(parcel, a);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new uq(str2, str, z2, z, list);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public uq[] m14473a(int i) {
        return new uq[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m14472a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m14473a(i);
    }
}
