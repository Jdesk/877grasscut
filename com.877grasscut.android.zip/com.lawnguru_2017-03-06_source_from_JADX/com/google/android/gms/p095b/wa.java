package com.google.android.gms.p095b;

/* renamed from: com.google.android.gms.b.wa */
public class wa extends yc {
    public wa(ou ouVar) {
        super(ouVar);
    }
}
