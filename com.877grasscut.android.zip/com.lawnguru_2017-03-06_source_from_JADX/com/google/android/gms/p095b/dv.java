package com.google.android.gms.p095b;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.Uri.Builder;
import android.support.v4.app.ad;
import android.support.v7.widget.RecyclerView.ItemAnimator;
import android.text.TextUtils;
import com.google.android.gms.common.C3204l;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.common.util.C3293c;
import com.google.android.gms.common.util.C3304n;
import com.google.android.gms.p095b.ef.C2525a;
import com.yalantis.ucrop.view.CropImageView;

/* renamed from: com.google.android.gms.b.dv */
public class dv extends eu {
    static final String f6276a;
    private Boolean f6277b;

    static {
        f6276a = String.valueOf(C3204l.f9789b / 1000).replaceAll("(\\d+)(\\d)(\\d\\d)", "$1.$2.$3");
    }

    dv(es esVar) {
        super(esVar);
    }

    int m10311A() {
        return 40;
    }

    int m10312B() {
        return 100;
    }

    int m10313C() {
        return ad.FLAG_LOCAL_ONLY;
    }

    public int m10314D() {
        return 36;
    }

    public int m10315E() {
        return ItemAnimator.FLAG_MOVED;
    }

    int m10316F() {
        return CropImageView.DEFAULT_IMAGE_TO_CROP_BOUNDS_ANIM_DURATION;
    }

    public long m10317G() {
        return (long) ((Integer) ef.f6355q.m10524b()).intValue();
    }

    public long m10318H() {
        return (long) ((Integer) ef.f6357s.m10524b()).intValue();
    }

    int m10319I() {
        return 25;
    }

    int m10320J() {
        return 1000;
    }

    int m10321K() {
        return 25;
    }

    int m10322L() {
        return 1000;
    }

    long m10323M() {
        return 15552000000L;
    }

    long m10324N() {
        return 15552000000L;
    }

    long m10325O() {
        return 3600000;
    }

    long m10326P() {
        return 60000;
    }

    long m10327Q() {
        return 61000;
    }

    long m10328R() {
        return ((Long) ef.f6338M.m10524b()).longValue();
    }

    public String m10329S() {
        return "google_app_measurement.db";
    }

    String m10330T() {
        return "google_app_measurement_local.db";
    }

    public long m10331U() {
        return 10298;
    }

    public boolean m10332V() {
        return false;
    }

    public boolean m10333W() {
        if (this.f6277b == null) {
            synchronized (this) {
                if (this.f6277b == null) {
                    ApplicationInfo applicationInfo = m10363n().getApplicationInfo();
                    String a = C3304n.m16349a();
                    if (applicationInfo != null) {
                        String str = applicationInfo.processName;
                        boolean z = str != null && str.equals(a);
                        this.f6277b = Boolean.valueOf(z);
                    }
                    if (this.f6277b == null) {
                        this.f6277b = Boolean.TRUE;
                        m10370u().m10665x().m10624a("My process not in the list of running processes");
                    }
                }
            }
        }
        return this.f6277b.booleanValue();
    }

    public boolean m10334X() {
        Boolean g = m10353g("firebase_analytics_collection_deactivated");
        return g != null && g.booleanValue();
    }

    public Boolean m10335Y() {
        return m10353g("firebase_analytics_collection_enabled");
    }

    public boolean m10336Z() {
        return ab.m9567b();
    }

    public int m10337a(String str) {
        return Math.max(0, Math.min(1000000, m10342b(str, ef.f6356r)));
    }

    public long m10338a(String str, C2525a<Long> c2525a) {
        if (str == null) {
            return ((Long) c2525a.m10524b()).longValue();
        }
        Object a = m10367r().m10743a(str, c2525a.m10523a());
        if (TextUtils.isEmpty(a)) {
            return ((Long) c2525a.m10524b()).longValue();
        }
        try {
            return ((Long) c2525a.m10522a(Long.valueOf(Long.valueOf(a).longValue()))).longValue();
        } catch (NumberFormatException e) {
            return ((Long) c2525a.m10524b()).longValue();
        }
    }

    String m10339a() {
        return (String) ef.f6345g.m10524b();
    }

    public String m10340a(String str, String str2) {
        Builder builder = new Builder();
        Builder encodedAuthority = builder.scheme((String) ef.f6349k.m10524b()).encodedAuthority((String) ef.f6350l.m10524b());
        String str3 = "config/app/";
        String valueOf = String.valueOf(str);
        encodedAuthority.path(valueOf.length() != 0 ? str3.concat(valueOf) : new String(str3)).appendQueryParameter("app_instance_id", str2).appendQueryParameter("platform", "android").appendQueryParameter("gmp_version", String.valueOf(10298));
        return builder.build().toString();
    }

    public long aa() {
        return ((Long) ef.f6335J.m10524b()).longValue();
    }

    public long ab() {
        return ((Long) ef.f6330E.m10524b()).longValue();
    }

    public long ac() {
        return ((Long) ef.f6331F.m10524b()).longValue();
    }

    public long ad() {
        return 1000;
    }

    public long ae() {
        return Math.max(0, ((Long) ef.f6347i.m10524b()).longValue());
    }

    public int af() {
        return Math.max(0, ((Integer) ef.f6353o.m10524b()).intValue());
    }

    public int ag() {
        return Math.max(1, ((Integer) ef.f6354p.m10524b()).intValue());
    }

    public int ah() {
        return 100000;
    }

    public String ai() {
        return (String) ef.f6361w.m10524b();
    }

    public long aj() {
        return ((Long) ef.f6348j.m10524b()).longValue();
    }

    public long ak() {
        return Math.max(0, ((Long) ef.f6362x.m10524b()).longValue());
    }

    public long al() {
        return Math.max(0, ((Long) ef.f6364z.m10524b()).longValue());
    }

    public long am() {
        return Math.max(0, ((Long) ef.f6326A.m10524b()).longValue());
    }

    public long an() {
        return Math.max(0, ((Long) ef.f6327B.m10524b()).longValue());
    }

    public long ao() {
        return Math.max(0, ((Long) ef.f6328C.m10524b()).longValue());
    }

    public long ap() {
        return Math.max(0, ((Long) ef.f6329D.m10524b()).longValue());
    }

    public long aq() {
        return ((Long) ef.f6363y.m10524b()).longValue();
    }

    public long ar() {
        return Math.max(0, ((Long) ef.f6332G.m10524b()).longValue());
    }

    public long as() {
        return Math.max(0, ((Long) ef.f6333H.m10524b()).longValue());
    }

    public int at() {
        return Math.min(20, Math.max(0, ((Integer) ef.f6334I.m10524b()).intValue()));
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.String au() {
        /*
        r5 = this;
        r0 = "android.os.SystemProperties";
        r0 = java.lang.Class.forName(r0);	 Catch:{ ClassNotFoundException -> 0x002e, NoSuchMethodException -> 0x003f, IllegalAccessException -> 0x004e, InvocationTargetException -> 0x005d }
        r1 = "get";
        r2 = 2;
        r2 = new java.lang.Class[r2];	 Catch:{ ClassNotFoundException -> 0x002e, NoSuchMethodException -> 0x003f, IllegalAccessException -> 0x004e, InvocationTargetException -> 0x005d }
        r3 = 0;
        r4 = java.lang.String.class;
        r2[r3] = r4;	 Catch:{ ClassNotFoundException -> 0x002e, NoSuchMethodException -> 0x003f, IllegalAccessException -> 0x004e, InvocationTargetException -> 0x005d }
        r3 = 1;
        r4 = java.lang.String.class;
        r2[r3] = r4;	 Catch:{ ClassNotFoundException -> 0x002e, NoSuchMethodException -> 0x003f, IllegalAccessException -> 0x004e, InvocationTargetException -> 0x005d }
        r0 = r0.getMethod(r1, r2);	 Catch:{ ClassNotFoundException -> 0x002e, NoSuchMethodException -> 0x003f, IllegalAccessException -> 0x004e, InvocationTargetException -> 0x005d }
        r1 = 0;
        r2 = 2;
        r2 = new java.lang.Object[r2];	 Catch:{ ClassNotFoundException -> 0x002e, NoSuchMethodException -> 0x003f, IllegalAccessException -> 0x004e, InvocationTargetException -> 0x005d }
        r3 = 0;
        r4 = "debug.firebase.analytics.app";
        r2[r3] = r4;	 Catch:{ ClassNotFoundException -> 0x002e, NoSuchMethodException -> 0x003f, IllegalAccessException -> 0x004e, InvocationTargetException -> 0x005d }
        r3 = 1;
        r4 = "";
        r2[r3] = r4;	 Catch:{ ClassNotFoundException -> 0x002e, NoSuchMethodException -> 0x003f, IllegalAccessException -> 0x004e, InvocationTargetException -> 0x005d }
        r0 = r0.invoke(r1, r2);	 Catch:{ ClassNotFoundException -> 0x002e, NoSuchMethodException -> 0x003f, IllegalAccessException -> 0x004e, InvocationTargetException -> 0x005d }
        r0 = (java.lang.String) r0;	 Catch:{ ClassNotFoundException -> 0x002e, NoSuchMethodException -> 0x003f, IllegalAccessException -> 0x004e, InvocationTargetException -> 0x005d }
    L_0x002d:
        return r0;
    L_0x002e:
        r0 = move-exception;
        r1 = r5.m10370u();
        r1 = r1.m10665x();
        r2 = "Could not find SystemProperties class";
        r1.m10625a(r2, r0);
    L_0x003c:
        r0 = "";
        goto L_0x002d;
    L_0x003f:
        r0 = move-exception;
        r1 = r5.m10370u();
        r1 = r1.m10665x();
        r2 = "Could not find SystemProperties.get() method";
        r1.m10625a(r2, r0);
        goto L_0x003c;
    L_0x004e:
        r0 = move-exception;
        r1 = r5.m10370u();
        r1 = r1.m10665x();
        r2 = "Could not access SystemProperties.get()";
        r1.m10625a(r2, r0);
        goto L_0x003c;
    L_0x005d:
        r0 = move-exception;
        r1 = r5.m10370u();
        r1 = r1.m10665x();
        r2 = "SystemProperties.get() threw an exception";
        r1.m10625a(r2, r0);
        goto L_0x003c;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.b.dv.au():java.lang.String");
    }

    public int m10341b(String str) {
        return m10342b(str, ef.f6358t);
    }

    public int m10342b(String str, C2525a<Integer> c2525a) {
        if (str == null) {
            return ((Integer) c2525a.m10524b()).intValue();
        }
        Object a = m10367r().m10743a(str, c2525a.m10523a());
        if (TextUtils.isEmpty(a)) {
            return ((Integer) c2525a.m10524b()).intValue();
        }
        try {
            return ((Integer) c2525a.m10522a(Integer.valueOf(Integer.valueOf(a).intValue()))).intValue();
        } catch (NumberFormatException e) {
            return ((Integer) c2525a.m10524b()).intValue();
        }
    }

    public /* bridge */ /* synthetic */ void m10343b() {
        super.m10181b();
    }

    public int m10344c(String str) {
        return m10342b(str, ef.f6359u);
    }

    public /* bridge */ /* synthetic */ void m10345c() {
        super.m10182c();
    }

    long m10346d(String str) {
        return m10338a(str, ef.f6346h);
    }

    public /* bridge */ /* synthetic */ void m10347d() {
        super.m10183d();
    }

    int m10348e(String str) {
        return m10342b(str, ef.f6336K);
    }

    public /* bridge */ /* synthetic */ void m10349e() {
        super.m10184e();
    }

    int m10350f(String str) {
        return Math.max(0, Math.min(2000, m10342b(str, ef.f6337L)));
    }

    public /* bridge */ /* synthetic */ C2517do m10351f() {
        return super.m10185f();
    }

    public /* bridge */ /* synthetic */ ds m10352g() {
        return super.m10186g();
    }

    Boolean m10353g(String str) {
        Boolean bool = null;
        C3234c.m16044a(str);
        try {
            if (m10363n().getPackageManager() == null) {
                m10370u().m10665x().m10624a("Failed to load metadata: PackageManager is null");
            } else {
                ApplicationInfo a = bn.m9791b(m10363n()).m9785a(m10363n().getPackageName(), (int) ad.FLAG_HIGH_PRIORITY);
                if (a == null) {
                    m10370u().m10665x().m10624a("Failed to load metadata: ApplicationInfo is null");
                } else if (a.metaData == null) {
                    m10370u().m10665x().m10624a("Failed to load metadata: Metadata bundle is null");
                } else if (a.metaData.containsKey(str)) {
                    bool = Boolean.valueOf(a.metaData.getBoolean(str));
                }
            }
        } catch (NameNotFoundException e) {
            m10370u().m10665x().m10625a("Failed to load metadata: Package name not found", e);
        }
        return bool;
    }

    public int m10354h(String str) {
        return m10342b(str, ef.f6351m);
    }

    public /* bridge */ /* synthetic */ ex m10355h() {
        return super.m10187h();
    }

    public int m10356i(String str) {
        return Math.max(0, m10342b(str, ef.f6352n));
    }

    public /* bridge */ /* synthetic */ eh m10357i() {
        return super.m10188i();
    }

    public int m10358j(String str) {
        return Math.max(0, Math.min(1000000, m10342b(str, ef.f6360v)));
    }

    public /* bridge */ /* synthetic */ dy m10359j() {
        return super.m10189j();
    }

    public /* bridge */ /* synthetic */ ez m10360k() {
        return super.m10190k();
    }

    public /* bridge */ /* synthetic */ ey m10361l() {
        return super.m10191l();
    }

    public /* bridge */ /* synthetic */ C3293c m10362m() {
        return super.m10192m();
    }

    public /* bridge */ /* synthetic */ Context m10363n() {
        return super.m10193n();
    }

    public /* bridge */ /* synthetic */ ei m10364o() {
        return super.m10194o();
    }

    public /* bridge */ /* synthetic */ dw m10365p() {
        return super.m10195p();
    }

    public /* bridge */ /* synthetic */ fh m10366q() {
        return super.m10196q();
    }

    public /* bridge */ /* synthetic */ eq m10367r() {
        return super.m10197r();
    }

    public /* bridge */ /* synthetic */ fb m10368s() {
        return super.m10198s();
    }

    public /* bridge */ /* synthetic */ er m10369t() {
        return super.m10199t();
    }

    public /* bridge */ /* synthetic */ ek m10370u() {
        return super.m10200u();
    }

    public /* bridge */ /* synthetic */ eo m10371v() {
        return super.m10201v();
    }

    public /* bridge */ /* synthetic */ dv m10372w() {
        return super.m10202w();
    }

    public int m10373x() {
        return 25;
    }

    public int m10374y() {
        return 40;
    }

    public int m10375z() {
        return 24;
    }
}
