package com.google.android.gms.p095b;

import java.util.HashMap;

/* renamed from: com.google.android.gms.b.bt */
public class bt extends br<Integer, Object> {
    public String f6018a;
    public long f6019b;
    public String f6020c;
    public String f6021d;
    public String f6022e;

    public bt() {
        this.f6018a = "E";
        this.f6019b = -1;
        this.f6020c = "E";
        this.f6021d = "E";
        this.f6022e = "E";
    }

    public bt(String str) {
        this();
        m9867a(str);
    }

    protected HashMap<Integer, Object> m9866a() {
        HashMap<Integer, Object> hashMap = new HashMap();
        hashMap.put(Integer.valueOf(0), this.f6018a);
        hashMap.put(Integer.valueOf(4), this.f6022e);
        hashMap.put(Integer.valueOf(3), this.f6021d);
        hashMap.put(Integer.valueOf(2), this.f6020c);
        hashMap.put(Integer.valueOf(1), Long.valueOf(this.f6019b));
        return hashMap;
    }

    protected void m9867a(String str) {
        HashMap b = br.m9861b(str);
        if (b != null) {
            this.f6018a = b.get(Integer.valueOf(0)) == null ? "E" : (String) b.get(Integer.valueOf(0));
            this.f6019b = b.get(Integer.valueOf(1)) == null ? -1 : ((Long) b.get(Integer.valueOf(1))).longValue();
            this.f6020c = b.get(Integer.valueOf(2)) == null ? "E" : (String) b.get(Integer.valueOf(2));
            this.f6021d = b.get(Integer.valueOf(3)) == null ? "E" : (String) b.get(Integer.valueOf(3));
            this.f6022e = b.get(Integer.valueOf(4)) == null ? "E" : (String) b.get(Integer.valueOf(4));
        }
    }
}
