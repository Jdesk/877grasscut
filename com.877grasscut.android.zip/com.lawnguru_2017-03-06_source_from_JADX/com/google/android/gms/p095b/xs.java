package com.google.android.gms.p095b;

import com.google.android.gms.analytics.C2300m;
import com.google.android.gms.analytics.p100a.C2276a;
import com.google.android.gms.analytics.p100a.C2277b;
import com.google.android.gms.analytics.p100a.C2278c;
import io.card.payment.BuildConfig;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/* renamed from: com.google.android.gms.b.xs */
public final class xs extends C2300m<xs> {
    private final List<C2276a> f9440a;
    private final List<C2278c> f9441b;
    private final Map<String, List<C2276a>> f9442c;
    private C2277b f9443d;

    public xs() {
        this.f9440a = new ArrayList();
        this.f9441b = new ArrayList();
        this.f9442c = new HashMap();
    }

    public C2277b m15347a() {
        return this.f9443d;
    }

    public void m15348a(C2276a c2276a, String str) {
        if (c2276a != null) {
            Object obj;
            if (str == null) {
                obj = BuildConfig.FLAVOR;
            }
            if (!this.f9442c.containsKey(obj)) {
                this.f9442c.put(obj, new ArrayList());
            }
            ((List) this.f9442c.get(obj)).add(c2276a);
        }
    }

    public /* synthetic */ void m15349a(C2300m c2300m) {
        m15350a((xs) c2300m);
    }

    public void m15350a(xs xsVar) {
        xsVar.f9440a.addAll(this.f9440a);
        xsVar.f9441b.addAll(this.f9441b);
        for (Entry entry : this.f9442c.entrySet()) {
            String str = (String) entry.getKey();
            for (C2276a a : (List) entry.getValue()) {
                xsVar.m15348a(a, str);
            }
        }
        if (this.f9443d != null) {
            xsVar.f9443d = this.f9443d;
        }
    }

    public List<C2276a> m15351b() {
        return Collections.unmodifiableList(this.f9440a);
    }

    public Map<String, List<C2276a>> m15352c() {
        return this.f9442c;
    }

    public List<C2278c> m15353d() {
        return Collections.unmodifiableList(this.f9441b);
    }

    public String toString() {
        Map hashMap = new HashMap();
        if (!this.f9440a.isEmpty()) {
            hashMap.put("products", this.f9440a);
        }
        if (!this.f9441b.isEmpty()) {
            hashMap.put("promotions", this.f9441b);
        }
        if (!this.f9442c.isEmpty()) {
            hashMap.put("impressions", this.f9442c);
        }
        hashMap.put("productAction", this.f9443d);
        return C2300m.m9055a((Object) hashMap);
    }
}
