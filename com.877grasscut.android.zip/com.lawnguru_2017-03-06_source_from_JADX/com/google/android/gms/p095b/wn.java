package com.google.android.gms.p095b;

import java.util.concurrent.Future;

/* renamed from: com.google.android.gms.b.wn */
public interface wn<A> extends Future<A> {
    void m13278a(Runnable runnable);

    void m13279b(Runnable runnable);
}
