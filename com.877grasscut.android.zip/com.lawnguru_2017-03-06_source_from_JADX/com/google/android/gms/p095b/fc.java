package com.google.android.gms.p095b;

import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.common.util.C3293c;

/* renamed from: com.google.android.gms.b.fc */
class fc {
    private final C3293c f6704a;
    private long f6705b;

    public fc(C3293c c3293c) {
        C3234c.m16042a((Object) c3293c);
        this.f6704a = c3293c;
    }

    public void m11152a() {
        this.f6705b = this.f6704a.m16302b();
    }

    public boolean m11153a(long j) {
        return this.f6705b == 0 || this.f6704a.m16302b() - this.f6705b >= j;
    }

    public void m11154b() {
        this.f6705b = 0;
    }
}
