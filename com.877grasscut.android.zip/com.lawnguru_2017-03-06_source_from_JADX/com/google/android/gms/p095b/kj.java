package com.google.android.gms.p095b;

@sc
/* renamed from: com.google.android.gms.b.kj */
public class kj {
    private static final Object f7428a;
    private static kj f7429b;
    private final wf f7430c;
    private final ki f7431d;

    static {
        f7428a = new Object();
        kj.m12294a(new kj());
    }

    protected kj() {
        this.f7430c = new wf();
        this.f7431d = new ki(new jz(), new jy(), new lg(), new no(), new tx(), new rh(), new qu());
    }

    public static wf m12293a() {
        return kj.m12296c().f7430c;
    }

    protected static void m12294a(kj kjVar) {
        synchronized (f7428a) {
            f7429b = kjVar;
        }
    }

    public static ki m12295b() {
        return kj.m12296c().f7431d;
    }

    private static kj m12296c() {
        kj kjVar;
        synchronized (f7428a) {
            kjVar = f7429b;
        }
        return kjVar;
    }
}
