package com.google.android.gms.p095b;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.ads.C2019a;
import com.google.android.gms.ads.C2088d;
import com.google.android.gms.ads.C2091g;
import com.google.android.gms.ads.C2094i;
import com.google.android.gms.ads.C2248j;
import com.google.android.gms.ads.p098a.C2064a;
import com.google.android.gms.ads.p098a.C2066c;
import com.google.android.gms.ads.purchase.C2269b;
import com.google.android.gms.ads.purchase.C2271d;
import com.google.android.gms.p097a.C2046a;
import com.google.android.gms.p097a.C2060d;
import java.util.concurrent.atomic.AtomicBoolean;

@sc
/* renamed from: com.google.android.gms.b.le */
public class le {
    final kl f7493a;
    private final pu f7494b;
    private final kd f7495c;
    private final AtomicBoolean f7496d;
    private final C2094i f7497e;
    private ju f7498f;
    private C2019a f7499g;
    private C2088d[] f7500h;
    private C2064a f7501i;
    private C2091g f7502j;
    private kr f7503k;
    private C2269b f7504l;
    private C2066c f7505m;
    private C2271d f7506n;
    private C2248j f7507o;
    private String f7508p;
    private String f7509q;
    private ViewGroup f7510r;
    private int f7511s;
    private boolean f7512t;

    /* renamed from: com.google.android.gms.b.le.1 */
    class C27381 extends kl {
        final /* synthetic */ le f7492a;

        C27381(le leVar) {
            this.f7492a = leVar;
        }

        public void m12448a() {
            this.f7492a.f7497e.m8084a(this.f7492a.m12480m());
            super.m12300a();
        }

        public void m12449a(int i) {
            this.f7492a.f7497e.m8084a(this.f7492a.m12480m());
            super.m12301a(i);
        }
    }

    public le(ViewGroup viewGroup, int i) {
        this(viewGroup, null, false, kd.m12230a(), i);
    }

    le(ViewGroup viewGroup, AttributeSet attributeSet, boolean z, kd kdVar, int i) {
        this(viewGroup, attributeSet, z, kdVar, null, i);
    }

    le(ViewGroup viewGroup, AttributeSet attributeSet, boolean z, kd kdVar, kr krVar, int i) {
        this.f7494b = new pu();
        this.f7497e = new C2094i();
        this.f7493a = new C27381(this);
        this.f7510r = viewGroup;
        this.f7495c = kdVar;
        this.f7503k = krVar;
        this.f7496d = new AtomicBoolean(false);
        this.f7511s = i;
        if (attributeSet != null) {
            Context context = viewGroup.getContext();
            try {
                kh khVar = new kh(context, attributeSet);
                this.f7500h = khVar.m12247a(z);
                this.f7508p = khVar.m12246a();
                if (viewGroup.isInEditMode()) {
                    kj.m12293a().m14903a(viewGroup, le.m12451a(context, this.f7500h[0], this.f7511s), "Ads by Google");
                }
            } catch (IllegalArgumentException e) {
                kj.m12293a().m14904a(viewGroup, new ke(context, C2088d.f4876a), e.getMessage(), e.getMessage());
            }
        }
    }

    private static ke m12451a(Context context, C2088d c2088d, int i) {
        ke keVar = new ke(context, c2088d);
        keVar.m12237a(le.m12453a(i));
        return keVar;
    }

    private static ke m12452a(Context context, C2088d[] c2088dArr, int i) {
        ke keVar = new ke(context, c2088dArr);
        keVar.m12237a(le.m12453a(i));
        return keVar;
    }

    private static boolean m12453a(int i) {
        return i == 1;
    }

    private void m12454q() {
        try {
            C2046a j = this.f7503k.m8106j();
            if (j != null) {
                this.f7510r.addView((View) C2060d.m7974a(j));
            }
        } catch (Throwable e) {
            wg.m14618c("Failed to get an ad frame.", e);
        }
    }

    public void m12455a() {
        try {
            if (this.f7503k != null) {
                this.f7503k.m8105i();
            }
        } catch (Throwable e) {
            wg.m14618c("Failed to destroy AdView.", e);
        }
    }

    public void m12456a(C2064a c2064a) {
        try {
            this.f7501i = c2064a;
            if (this.f7503k != null) {
                this.f7503k.m8094a(c2064a != null ? new kg(c2064a) : null);
            }
        } catch (Throwable e) {
            wg.m14618c("Failed to set the AppEventListener.", e);
        }
    }

    public void m12457a(C2066c c2066c) {
        this.f7505m = c2066c;
        try {
            if (this.f7503k != null) {
                this.f7503k.m8098a(c2066c != null ? new ml(c2066c) : null);
            }
        } catch (Throwable e) {
            wg.m14618c("Failed to set the onCustomRenderedAdLoadedListener.", e);
        }
    }

    public void m12458a(C2019a c2019a) {
        this.f7499g = c2019a;
        this.f7493a.m12302a(c2019a);
    }

    public void m12459a(C2091g c2091g) {
        this.f7502j = c2091g;
        try {
            if (this.f7503k != null) {
                this.f7503k.m8095a(this.f7502j == null ? null : this.f7502j.m8074a());
            }
        } catch (Throwable e) {
            wg.m14618c("Failed to set correlator.", e);
        }
    }

    public void m12460a(C2248j c2248j) {
        this.f7507o = c2248j;
        try {
            if (this.f7503k != null) {
                this.f7503k.m8097a(c2248j == null ? null : new ln(c2248j));
            }
        } catch (Throwable e) {
            wg.m14618c("Failed to set video options.", e);
        }
    }

    public void m12461a(C2269b c2269b) {
        if (this.f7506n != null) {
            throw new IllegalStateException("Play store purchase parameter has already been set.");
        }
        try {
            this.f7504l = c2269b;
            if (this.f7503k != null) {
                this.f7503k.m8099a(c2269b != null ? new rg(c2269b) : null);
            }
        } catch (Throwable e) {
            wg.m14618c("Failed to set the InAppPurchaseListener.", e);
        }
    }

    public void m12462a(ju juVar) {
        try {
            this.f7498f = juVar;
            if (this.f7503k != null) {
                this.f7503k.m8092a(juVar != null ? new jv(juVar) : null);
            }
        } catch (Throwable e) {
            wg.m14618c("Failed to set the AdClickListener.", e);
        }
    }

    public void m12463a(ld ldVar) {
        try {
            if (this.f7503k == null) {
                m12482o();
            }
            if (this.f7503k.m8104a(this.f7495c.m12231a(this.f7510r.getContext(), ldVar))) {
                this.f7494b.m13437a(ldVar.m12442j());
            }
        } catch (Throwable e) {
            wg.m14618c("Failed to load ad.", e);
        }
    }

    public void m12464a(String str) {
        if (this.f7508p != null) {
            throw new IllegalStateException("The ad unit ID can only be set once on AdView.");
        }
        this.f7508p = str;
    }

    public void m12465a(boolean z) {
        this.f7512t = z;
        try {
            if (this.f7503k != null) {
                this.f7503k.m8103a(this.f7512t);
            }
        } catch (Throwable e) {
            wg.m14618c("Failed to set manual impressions.", e);
        }
    }

    public void m12466a(C2088d... c2088dArr) {
        if (this.f7500h != null) {
            throw new IllegalStateException("The ad size can only be set once on AdView.");
        }
        m12469b(c2088dArr);
    }

    public boolean m12467a(ke keVar) {
        return "search_v2".equals(keVar.f7383a);
    }

    public C2019a m12468b() {
        return this.f7499g;
    }

    public void m12469b(C2088d... c2088dArr) {
        this.f7500h = c2088dArr;
        try {
            if (this.f7503k != null) {
                this.f7503k.m8091a(le.m12452a(this.f7510r.getContext(), this.f7500h, this.f7511s));
            }
        } catch (Throwable e) {
            wg.m14618c("Failed to set the ad size.", e);
        }
        this.f7510r.requestLayout();
    }

    public C2088d m12470c() {
        try {
            if (this.f7503k != null) {
                ke k = this.f7503k.m8107k();
                if (k != null) {
                    return k.m12238b();
                }
            }
        } catch (Throwable e) {
            wg.m14618c("Failed to get the current AdSize.", e);
        }
        return this.f7500h != null ? this.f7500h[0] : null;
    }

    public C2088d[] m12471d() {
        return this.f7500h;
    }

    public String m12472e() {
        return this.f7508p;
    }

    public C2064a m12473f() {
        return this.f7501i;
    }

    public C2269b m12474g() {
        return this.f7504l;
    }

    public C2066c m12475h() {
        return this.f7505m;
    }

    public void m12476i() {
        try {
            if (this.f7503k != null) {
                this.f7503k.m8110n();
            }
        } catch (Throwable e) {
            wg.m14618c("Failed to call pause.", e);
        }
    }

    public void m12477j() {
        try {
            if (this.f7503k != null) {
                this.f7503k.m8111o();
            }
        } catch (Throwable e) {
            wg.m14618c("Failed to call resume.", e);
        }
    }

    public String m12478k() {
        try {
            if (this.f7503k != null) {
                return this.f7503k.m8089G();
            }
        } catch (Throwable e) {
            wg.m14618c("Failed to get the mediation adapter class name.", e);
        }
        return null;
    }

    public C2094i m12479l() {
        return this.f7497e;
    }

    public kz m12480m() {
        kz kzVar = null;
        if (this.f7503k != null) {
            try {
                kzVar = this.f7503k.m8114r();
            } catch (Throwable e) {
                wg.m14618c("Failed to retrieve VideoController.", e);
            }
        }
        return kzVar;
    }

    public C2248j m12481n() {
        return this.f7507o;
    }

    void m12482o() {
        if ((this.f7500h == null || this.f7508p == null) && this.f7503k == null) {
            throw new IllegalStateException("The ad size and ad unit ID must be set before loadAd is called.");
        }
        this.f7503k = m12483p();
        this.f7503k.m8093a(new jw(this.f7493a));
        if (this.f7498f != null) {
            this.f7503k.m8092a(new jv(this.f7498f));
        }
        if (this.f7501i != null) {
            this.f7503k.m8094a(new kg(this.f7501i));
        }
        if (this.f7504l != null) {
            this.f7503k.m8099a(new rg(this.f7504l));
        }
        if (this.f7506n != null) {
            this.f7503k.m8100a(new rk(this.f7506n), this.f7509q);
        }
        if (this.f7505m != null) {
            this.f7503k.m8098a(new ml(this.f7505m));
        }
        if (this.f7502j != null) {
            this.f7503k.m8095a(this.f7502j.m8074a());
        }
        if (this.f7507o != null) {
            this.f7503k.m8097a(new ln(this.f7507o));
        }
        this.f7503k.m8103a(this.f7512t);
        m12454q();
    }

    protected kr m12483p() {
        Context context = this.f7510r.getContext();
        ke a = le.m12452a(context, this.f7500h, this.f7511s);
        return m12467a(a) ? kj.m12295b().m12287a(context, a, this.f7508p) : kj.m12295b().m12288a(context, a, this.f7508p, this.f7494b);
    }
}
