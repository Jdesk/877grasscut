package com.google.android.gms.p095b;

import android.text.TextUtils;
import com.google.android.gms.analytics.C2300m;
import java.util.HashMap;
import java.util.Map;

/* renamed from: com.google.android.gms.b.xy */
public final class xy extends C2300m<xy> {
    public String f9468a;
    public long f9469b;
    public String f9470c;
    public String f9471d;

    public String m15409a() {
        return this.f9468a;
    }

    public void m15410a(long j) {
        this.f9469b = j;
    }

    public /* synthetic */ void m15411a(C2300m c2300m) {
        m15412a((xy) c2300m);
    }

    public void m15412a(xy xyVar) {
        if (!TextUtils.isEmpty(this.f9468a)) {
            xyVar.m15413a(this.f9468a);
        }
        if (this.f9469b != 0) {
            xyVar.m15410a(this.f9469b);
        }
        if (!TextUtils.isEmpty(this.f9470c)) {
            xyVar.m15415b(this.f9470c);
        }
        if (!TextUtils.isEmpty(this.f9471d)) {
            xyVar.m15417c(this.f9471d);
        }
    }

    public void m15413a(String str) {
        this.f9468a = str;
    }

    public long m15414b() {
        return this.f9469b;
    }

    public void m15415b(String str) {
        this.f9470c = str;
    }

    public String m15416c() {
        return this.f9470c;
    }

    public void m15417c(String str) {
        this.f9471d = str;
    }

    public String m15418d() {
        return this.f9471d;
    }

    public String toString() {
        Map hashMap = new HashMap();
        hashMap.put("variableName", this.f9468a);
        hashMap.put("timeInMillis", Long.valueOf(this.f9469b));
        hashMap.put("category", this.f9470c);
        hashMap.put("label", this.f9471d);
        return C2300m.m9055a((Object) hashMap);
    }
}
