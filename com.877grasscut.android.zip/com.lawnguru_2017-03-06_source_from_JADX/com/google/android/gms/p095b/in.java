package com.google.android.gms.p095b;

import org.json.JSONObject;

@sc
/* renamed from: com.google.android.gms.b.in */
public final class in {
    private final String f7115a;
    private final JSONObject f7116b;
    private final String f7117c;
    private final String f7118d;
    private final boolean f7119e;
    private final boolean f7120f;

    public in(String str, wi wiVar, String str2, JSONObject jSONObject, boolean z, boolean z2) {
        this.f7118d = wiVar.f9227a;
        this.f7116b = jSONObject;
        this.f7117c = str;
        this.f7115a = str2;
        this.f7119e = z;
        this.f7120f = z2;
    }

    public String m11912a() {
        return this.f7115a;
    }

    public String m11913b() {
        return this.f7118d;
    }

    public JSONObject m11914c() {
        return this.f7116b;
    }

    public String m11915d() {
        return this.f7117c;
    }

    public boolean m11916e() {
        return this.f7119e;
    }

    public boolean m11917f() {
        return this.f7120f;
    }
}
