package com.google.android.gms.p095b;

import android.os.Bundle;
import android.view.View;
import com.google.android.gms.ads.mediation.C2015j;
import com.google.android.gms.ads.p096b.C2072b.C2071a;
import com.google.android.gms.p095b.qa.C2908a;
import com.google.android.gms.p097a.C2046a;
import com.google.android.gms.p097a.C2060d;
import java.util.ArrayList;
import java.util.List;

@sc
/* renamed from: com.google.android.gms.b.qf */
public class qf extends C2908a {
    private final C2015j f8166a;

    public qf(C2015j c2015j) {
        this.f8166a = c2015j;
    }

    public String m13636a() {
        return this.f8166a.m7845f();
    }

    public void m13637a(C2046a c2046a) {
        this.f8166a.m7833c((View) C2060d.m7974a(c2046a));
    }

    public List m13638b() {
        List<C2071a> g = this.f8166a.m7846g();
        if (g == null) {
            return null;
        }
        List arrayList = new ArrayList();
        for (C2071a c2071a : g) {
            arrayList.add(new mp(c2071a.m7985a(), c2071a.m7986b(), c2071a.m7987c()));
        }
        return arrayList;
    }

    public void m13639b(C2046a c2046a) {
        this.f8166a.m7826a((View) C2060d.m7974a(c2046a));
    }

    public String m13640c() {
        return this.f8166a.m7847h();
    }

    public void m13641c(C2046a c2046a) {
        this.f8166a.m7829b((View) C2060d.m7974a(c2046a));
    }

    public nb m13642d() {
        C2071a i = this.f8166a.m7848i();
        return i != null ? new mp(i.m7985a(), i.m7986b(), i.m7987c()) : null;
    }

    public String m13643e() {
        return this.f8166a.m7849j();
    }

    public double m13644f() {
        return this.f8166a.m7850k();
    }

    public String m13645g() {
        return this.f8166a.m7851l();
    }

    public String m13646h() {
        return this.f8166a.m7852m();
    }

    public void m13647i() {
        this.f8166a.m7835e();
    }

    public boolean m13648j() {
        return this.f8166a.m7828a();
    }

    public boolean m13649k() {
        return this.f8166a.m7831b();
    }

    public Bundle m13650l() {
        return this.f8166a.m7832c();
    }

    public kz m13651m() {
        return this.f8166a.m7853n() != null ? this.f8166a.m7853n().m8082a() : null;
    }

    public C2046a m13652n() {
        Object d = this.f8166a.m7834d();
        return d == null ? null : C2060d.m7973a(d);
    }
}
