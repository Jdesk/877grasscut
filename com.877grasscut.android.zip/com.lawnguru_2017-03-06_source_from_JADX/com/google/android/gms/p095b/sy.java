package com.google.android.gms.p095b;

import com.google.android.gms.p095b.fq.C2614a;

/* renamed from: com.google.android.gms.b.sy */
public class sy<T> {
    public final T f8658a;
    public final C2614a f8659b;
    public final yc f8660c;
    public boolean f8661d;

    /* renamed from: com.google.android.gms.b.sy.a */
    public interface C3005a {
        void m14115a(yc ycVar);
    }

    /* renamed from: com.google.android.gms.b.sy.b */
    public interface C3006b<T> {
        void m14116a(T t);
    }

    private sy(yc ycVar) {
        this.f8661d = false;
        this.f8658a = null;
        this.f8659b = null;
        this.f8660c = ycVar;
    }

    private sy(T t, C2614a c2614a) {
        this.f8661d = false;
        this.f8658a = t;
        this.f8659b = c2614a;
        this.f8660c = null;
    }

    public static <T> sy<T> m14117a(yc ycVar) {
        return new sy(ycVar);
    }

    public static <T> sy<T> m14118a(T t, C2614a c2614a) {
        return new sy(t, c2614a);
    }

    public boolean m14119a() {
        return this.f8660c == null;
    }
}
