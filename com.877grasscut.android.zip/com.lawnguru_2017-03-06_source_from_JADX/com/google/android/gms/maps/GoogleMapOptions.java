package com.google.android.gms.maps;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.util.AttributeSet;
import com.google.android.gms.C2063a.C2045c;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.C2149a;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.p103a.C3526l;

public final class GoogleMapOptions extends C2149a implements ReflectedParcelable {
    public static final Creator<GoogleMapOptions> CREATOR;
    private Boolean f10279a;
    private Boolean f10280b;
    private int f10281c;
    private CameraPosition f10282d;
    private Boolean f10283e;
    private Boolean f10284f;
    private Boolean f10285g;
    private Boolean f10286h;
    private Boolean f10287i;
    private Boolean f10288j;
    private Boolean f10289k;
    private Boolean f10290l;
    private Boolean f10291m;
    private Float f10292n;
    private Float f10293o;
    private LatLngBounds f10294p;

    static {
        CREATOR = new C3579g();
    }

    public GoogleMapOptions() {
        this.f10281c = -1;
        this.f10292n = null;
        this.f10293o = null;
        this.f10294p = null;
    }

    GoogleMapOptions(byte b, byte b2, int i, CameraPosition cameraPosition, byte b3, byte b4, byte b5, byte b6, byte b7, byte b8, byte b9, byte b10, byte b11, Float f, Float f2, LatLngBounds latLngBounds) {
        this.f10281c = -1;
        this.f10292n = null;
        this.f10293o = null;
        this.f10294p = null;
        this.f10279a = C3526l.m17305a(b);
        this.f10280b = C3526l.m17305a(b2);
        this.f10281c = i;
        this.f10282d = cameraPosition;
        this.f10283e = C3526l.m17305a(b3);
        this.f10284f = C3526l.m17305a(b4);
        this.f10285g = C3526l.m17305a(b5);
        this.f10286h = C3526l.m17305a(b6);
        this.f10287i = C3526l.m17305a(b7);
        this.f10288j = C3526l.m17305a(b8);
        this.f10289k = C3526l.m17305a(b9);
        this.f10290l = C3526l.m17305a(b10);
        this.f10291m = C3526l.m17305a(b11);
        this.f10292n = f;
        this.f10293o = f2;
        this.f10294p = latLngBounds;
    }

    public static GoogleMapOptions m16788a(Context context, AttributeSet attributeSet) {
        if (attributeSet == null) {
            return null;
        }
        TypedArray obtainAttributes = context.getResources().obtainAttributes(attributeSet, C2045c.MapAttrs);
        GoogleMapOptions googleMapOptions = new GoogleMapOptions();
        if (obtainAttributes.hasValue(C2045c.MapAttrs_mapType)) {
            googleMapOptions.m16791a(obtainAttributes.getInt(C2045c.MapAttrs_mapType, -1));
        }
        if (obtainAttributes.hasValue(C2045c.MapAttrs_zOrderOnTop)) {
            googleMapOptions.m16794a(obtainAttributes.getBoolean(C2045c.MapAttrs_zOrderOnTop, false));
        }
        if (obtainAttributes.hasValue(C2045c.MapAttrs_useViewLifecycle)) {
            googleMapOptions.m16797b(obtainAttributes.getBoolean(C2045c.MapAttrs_useViewLifecycle, false));
        }
        if (obtainAttributes.hasValue(C2045c.MapAttrs_uiCompass)) {
            googleMapOptions.m16801d(obtainAttributes.getBoolean(C2045c.MapAttrs_uiCompass, true));
        }
        if (obtainAttributes.hasValue(C2045c.MapAttrs_uiRotateGestures)) {
            googleMapOptions.m16809h(obtainAttributes.getBoolean(C2045c.MapAttrs_uiRotateGestures, true));
        }
        if (obtainAttributes.hasValue(C2045c.MapAttrs_uiScrollGestures)) {
            googleMapOptions.m16803e(obtainAttributes.getBoolean(C2045c.MapAttrs_uiScrollGestures, true));
        }
        if (obtainAttributes.hasValue(C2045c.MapAttrs_uiTiltGestures)) {
            googleMapOptions.m16807g(obtainAttributes.getBoolean(C2045c.MapAttrs_uiTiltGestures, true));
        }
        if (obtainAttributes.hasValue(C2045c.MapAttrs_uiZoomGestures)) {
            googleMapOptions.m16805f(obtainAttributes.getBoolean(C2045c.MapAttrs_uiZoomGestures, true));
        }
        if (obtainAttributes.hasValue(C2045c.MapAttrs_uiZoomControls)) {
            googleMapOptions.m16799c(obtainAttributes.getBoolean(C2045c.MapAttrs_uiZoomControls, true));
        }
        if (obtainAttributes.hasValue(C2045c.MapAttrs_liteMode)) {
            googleMapOptions.m16811i(obtainAttributes.getBoolean(C2045c.MapAttrs_liteMode, false));
        }
        if (obtainAttributes.hasValue(C2045c.MapAttrs_uiMapToolbar)) {
            googleMapOptions.m16813j(obtainAttributes.getBoolean(C2045c.MapAttrs_uiMapToolbar, true));
        }
        if (obtainAttributes.hasValue(C2045c.MapAttrs_ambientEnabled)) {
            googleMapOptions.m16815k(obtainAttributes.getBoolean(C2045c.MapAttrs_ambientEnabled, false));
        }
        if (obtainAttributes.hasValue(C2045c.MapAttrs_cameraMinZoomPreference)) {
            googleMapOptions.m16790a(obtainAttributes.getFloat(C2045c.MapAttrs_cameraMinZoomPreference, Float.NEGATIVE_INFINITY));
        }
        if (obtainAttributes.hasValue(C2045c.MapAttrs_cameraMinZoomPreference)) {
            googleMapOptions.m16796b(obtainAttributes.getFloat(C2045c.MapAttrs_cameraMaxZoomPreference, Float.POSITIVE_INFINITY));
        }
        googleMapOptions.m16793a(LatLngBounds.m17426a(context, attributeSet));
        googleMapOptions.m16792a(CameraPosition.m17421a(context, attributeSet));
        obtainAttributes.recycle();
        return googleMapOptions;
    }

    byte m16789a() {
        return C3526l.m17304a(this.f10279a);
    }

    public GoogleMapOptions m16790a(float f) {
        this.f10292n = Float.valueOf(f);
        return this;
    }

    public GoogleMapOptions m16791a(int i) {
        this.f10281c = i;
        return this;
    }

    public GoogleMapOptions m16792a(CameraPosition cameraPosition) {
        this.f10282d = cameraPosition;
        return this;
    }

    public GoogleMapOptions m16793a(LatLngBounds latLngBounds) {
        this.f10294p = latLngBounds;
        return this;
    }

    public GoogleMapOptions m16794a(boolean z) {
        this.f10279a = Boolean.valueOf(z);
        return this;
    }

    byte m16795b() {
        return C3526l.m17304a(this.f10280b);
    }

    public GoogleMapOptions m16796b(float f) {
        this.f10293o = Float.valueOf(f);
        return this;
    }

    public GoogleMapOptions m16797b(boolean z) {
        this.f10280b = Boolean.valueOf(z);
        return this;
    }

    byte m16798c() {
        return C3526l.m17304a(this.f10283e);
    }

    public GoogleMapOptions m16799c(boolean z) {
        this.f10283e = Boolean.valueOf(z);
        return this;
    }

    byte m16800d() {
        return C3526l.m17304a(this.f10284f);
    }

    public GoogleMapOptions m16801d(boolean z) {
        this.f10284f = Boolean.valueOf(z);
        return this;
    }

    byte m16802e() {
        return C3526l.m17304a(this.f10285g);
    }

    public GoogleMapOptions m16803e(boolean z) {
        this.f10285g = Boolean.valueOf(z);
        return this;
    }

    byte m16804f() {
        return C3526l.m17304a(this.f10286h);
    }

    public GoogleMapOptions m16805f(boolean z) {
        this.f10286h = Boolean.valueOf(z);
        return this;
    }

    byte m16806g() {
        return C3526l.m17304a(this.f10287i);
    }

    public GoogleMapOptions m16807g(boolean z) {
        this.f10287i = Boolean.valueOf(z);
        return this;
    }

    byte m16808h() {
        return C3526l.m17304a(this.f10288j);
    }

    public GoogleMapOptions m16809h(boolean z) {
        this.f10288j = Boolean.valueOf(z);
        return this;
    }

    byte m16810i() {
        return C3526l.m17304a(this.f10289k);
    }

    public GoogleMapOptions m16811i(boolean z) {
        this.f10289k = Boolean.valueOf(z);
        return this;
    }

    byte m16812j() {
        return C3526l.m17304a(this.f10290l);
    }

    public GoogleMapOptions m16813j(boolean z) {
        this.f10290l = Boolean.valueOf(z);
        return this;
    }

    byte m16814k() {
        return C3526l.m17304a(this.f10291m);
    }

    public GoogleMapOptions m16815k(boolean z) {
        this.f10291m = Boolean.valueOf(z);
        return this;
    }

    public int m16816l() {
        return this.f10281c;
    }

    public CameraPosition m16817m() {
        return this.f10282d;
    }

    public Float m16818n() {
        return this.f10292n;
    }

    public Float m16819o() {
        return this.f10293o;
    }

    public LatLngBounds m16820p() {
        return this.f10294p;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C3579g.m17409a(this, parcel, i);
    }
}
