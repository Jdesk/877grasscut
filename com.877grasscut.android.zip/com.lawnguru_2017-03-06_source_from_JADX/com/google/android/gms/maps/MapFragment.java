package com.google.android.gms.maps;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.RemoteException;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.common.C3206d;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.maps.model.C3625p;
import com.google.android.gms.maps.p103a.C3451k;
import com.google.android.gms.maps.p103a.C3499b;
import com.google.android.gms.maps.p103a.C3505d;
import com.google.android.gms.maps.p103a.C3548t;
import com.google.android.gms.maps.p103a.C3549u;
import com.google.android.gms.maps.p103a.an.C3449a;
import com.google.android.gms.p097a.C2046a;
import com.google.android.gms.p097a.C2050e;
import com.google.android.gms.p097a.C2059c;
import com.google.android.gms.p097a.C2060d;
import java.util.ArrayList;
import java.util.List;

@TargetApi(11)
public class MapFragment extends Fragment {
    private final C3453b f10302a;

    /* renamed from: com.google.android.gms.maps.MapFragment.a */
    static class C3452a implements C3451k {
        private final Fragment f10296a;
        private final C3505d f10297b;

        /* renamed from: com.google.android.gms.maps.MapFragment.a.1 */
        class C34501 extends C3449a {
            final /* synthetic */ C3577e f10295a;

            C34501(C3452a c3452a, C3577e c3577e) {
                this.f10295a = c3577e;
            }

            public void m16823a(C3499b c3499b) {
                this.f10295a.m17405a(new C3575c(c3499b));
            }
        }

        public C3452a(Fragment fragment, C3505d c3505d) {
            this.f10297b = (C3505d) C3234c.m16042a((Object) c3505d);
            this.f10296a = (Fragment) C3234c.m16042a((Object) fragment);
        }

        public View m16824a(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            try {
                Bundle bundle2 = new Bundle();
                C3548t.m17330a(bundle, bundle2);
                C2046a a = this.f10297b.m17113a(C2060d.m7973a((Object) layoutInflater), C2060d.m7973a((Object) viewGroup), bundle2);
                C3548t.m17330a(bundle2, bundle);
                return (View) C2060d.m7974a(a);
            } catch (RemoteException e) {
                throw new C3625p(e);
            }
        }

        public void m16825a() {
            try {
                this.f10297b.m17127i();
            } catch (RemoteException e) {
                throw new C3625p(e);
            }
        }

        public void m16826a(Activity activity, Bundle bundle, Bundle bundle2) {
            GoogleMapOptions googleMapOptions = (GoogleMapOptions) bundle.getParcelable("MapOptions");
            try {
                Bundle bundle3 = new Bundle();
                C3548t.m17330a(bundle2, bundle3);
                this.f10297b.m17116a(C2060d.m7973a((Object) activity), googleMapOptions, bundle3);
                C3548t.m17330a(bundle3, bundle2);
            } catch (RemoteException e) {
                throw new C3625p(e);
            }
        }

        public void m16827a(Bundle bundle) {
            try {
                Bundle bundle2 = new Bundle();
                C3548t.m17330a(bundle, bundle2);
                Bundle arguments = this.f10296a.getArguments();
                if (arguments != null && arguments.containsKey("MapOptions")) {
                    C3548t.m17331a(bundle2, "MapOptions", arguments.getParcelable("MapOptions"));
                }
                this.f10297b.m17115a(bundle2);
                C3548t.m17330a(bundle2, bundle);
            } catch (RemoteException e) {
                throw new C3625p(e);
            }
        }

        public void m16828a(C3577e c3577e) {
            try {
                this.f10297b.m17117a(new C34501(this, c3577e));
            } catch (RemoteException e) {
                throw new C3625p(e);
            }
        }

        public void m16829b() {
            try {
                this.f10297b.m17118b();
            } catch (RemoteException e) {
                throw new C3625p(e);
            }
        }

        public void m16830b(Bundle bundle) {
            try {
                Bundle bundle2 = new Bundle();
                C3548t.m17330a(bundle, bundle2);
                this.f10297b.m17119b(bundle2);
                C3548t.m17330a(bundle2, bundle);
            } catch (RemoteException e) {
                throw new C3625p(e);
            }
        }

        public void m16831c() {
            try {
                this.f10297b.m17120c();
            } catch (RemoteException e) {
                throw new C3625p(e);
            }
        }

        public void m16832d() {
            try {
                this.f10297b.m17128j();
            } catch (RemoteException e) {
                throw new C3625p(e);
            }
        }

        public void m16833e() {
            try {
                this.f10297b.m17122d();
            } catch (RemoteException e) {
                throw new C3625p(e);
            }
        }

        public void m16834f() {
            try {
                this.f10297b.m17123e();
            } catch (RemoteException e) {
                throw new C3625p(e);
            }
        }

        public void m16835g() {
            try {
                this.f10297b.m17124f();
            } catch (RemoteException e) {
                throw new C3625p(e);
            }
        }
    }

    /* renamed from: com.google.android.gms.maps.MapFragment.b */
    static class C3453b extends C2059c<C3452a> {
        protected C2050e<C3452a> f10298a;
        private final Fragment f10299b;
        private Activity f10300c;
        private final List<C3577e> f10301d;

        C3453b(Fragment fragment) {
            this.f10301d = new ArrayList();
            this.f10299b = fragment;
        }

        private void m16836a(Activity activity) {
            this.f10300c = activity;
            m16840i();
        }

        protected void m16838a(C2050e<C3452a> c2050e) {
            this.f10298a = c2050e;
            m16840i();
        }

        public void m16839a(C3577e c3577e) {
            if (m7960a() != null) {
                ((C3452a) m7960a()).m16828a(c3577e);
            } else {
                this.f10301d.add(c3577e);
            }
        }

        public void m16840i() {
            if (this.f10300c != null && this.f10298a != null && m7960a() == null) {
                try {
                    C3576d.m17403a(this.f10300c);
                    C3505d b = C3549u.m17332a(this.f10300c).m17348b(C2060d.m7973a(this.f10300c));
                    if (b != null) {
                        this.f10298a.m7937a(new C3452a(this.f10299b, b));
                        for (C3577e a : this.f10301d) {
                            ((C3452a) m7960a()).m16828a(a);
                        }
                        this.f10301d.clear();
                    }
                } catch (RemoteException e) {
                    throw new C3625p(e);
                } catch (C3206d e2) {
                }
            }
        }
    }

    public MapFragment() {
        this.f10302a = new C3453b(this);
    }

    public static MapFragment m16841a() {
        return new MapFragment();
    }

    public static MapFragment m16842a(GoogleMapOptions googleMapOptions) {
        MapFragment mapFragment = new MapFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelable("MapOptions", googleMapOptions);
        mapFragment.setArguments(bundle);
        return mapFragment;
    }

    public void m16843a(C3577e c3577e) {
        C3234c.m16050b("getMapAsync must be called on the main thread.");
        this.f10302a.m16839a(c3577e);
    }

    public void onActivityCreated(Bundle bundle) {
        if (bundle != null) {
            bundle.setClassLoader(MapFragment.class.getClassLoader());
        }
        super.onActivityCreated(bundle);
    }

    public void onAttach(Activity activity) {
        super.onAttach(activity);
        this.f10302a.m16836a(activity);
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f10302a.m7962a(bundle);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View a = this.f10302a.m7959a(layoutInflater, viewGroup, bundle);
        a.setClickable(true);
        return a;
    }

    public void onDestroy() {
        this.f10302a.m7971g();
        super.onDestroy();
    }

    public void onDestroyView() {
        this.f10302a.m7970f();
        super.onDestroyView();
    }

    @SuppressLint({"NewApi"})
    public void onInflate(Activity activity, AttributeSet attributeSet, Bundle bundle) {
        super.onInflate(activity, attributeSet, bundle);
        this.f10302a.m16836a(activity);
        Parcelable a = GoogleMapOptions.m16788a(activity, attributeSet);
        Bundle bundle2 = new Bundle();
        bundle2.putParcelable("MapOptions", a);
        this.f10302a.m7961a(activity, bundle2, bundle);
    }

    public void onLowMemory() {
        this.f10302a.m7972h();
        super.onLowMemory();
    }

    public void onPause() {
        this.f10302a.m7968d();
        super.onPause();
    }

    public void onResume() {
        super.onResume();
        this.f10302a.m7967c();
    }

    public void onSaveInstanceState(Bundle bundle) {
        if (bundle != null) {
            bundle.setClassLoader(MapFragment.class.getClassLoader());
        }
        super.onSaveInstanceState(bundle);
        this.f10302a.m7966b(bundle);
    }

    public void onStart() {
        super.onStart();
        this.f10302a.m7965b();
    }

    public void onStop() {
        this.f10302a.m7969e();
        super.onStop();
    }

    public void setArguments(Bundle bundle) {
        super.setArguments(bundle);
    }
}
