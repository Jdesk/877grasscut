package com.google.android.gms.maps;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.StreetViewPanoramaCamera;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.maps.h */
public class C3580h implements Creator<StreetViewPanoramaOptions> {
    static void m17412a(StreetViewPanoramaOptions streetViewPanoramaOptions, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16172a(parcel, 2, streetViewPanoramaOptions.m16849f(), i, false);
        C3264c.m16177a(parcel, 3, streetViewPanoramaOptions.m16852i(), false);
        C3264c.m16172a(parcel, 4, streetViewPanoramaOptions.m16850g(), i, false);
        C3264c.m16175a(parcel, 5, streetViewPanoramaOptions.m16851h(), false);
        C3264c.m16165a(parcel, 6, streetViewPanoramaOptions.m16844a());
        C3264c.m16165a(parcel, 7, streetViewPanoramaOptions.m16845b());
        C3264c.m16165a(parcel, 8, streetViewPanoramaOptions.m16846c());
        C3264c.m16165a(parcel, 9, streetViewPanoramaOptions.m16847d());
        C3264c.m16165a(parcel, 10, streetViewPanoramaOptions.m16848e());
        C3264c.m16164a(parcel, a);
    }

    public StreetViewPanoramaOptions m17413a(Parcel parcel) {
        Integer num = null;
        byte b = (byte) 0;
        int b2 = C3263b.m16139b(parcel);
        byte b3 = (byte) 0;
        byte b4 = (byte) 0;
        byte b5 = (byte) 0;
        byte b6 = (byte) 0;
        LatLng latLng = null;
        String str = null;
        StreetViewPanoramaCamera streetViewPanoramaCamera = null;
        while (parcel.dataPosition() < b2) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    streetViewPanoramaCamera = (StreetViewPanoramaCamera) C3263b.m16135a(parcel, a, StreetViewPanoramaCamera.CREATOR);
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    str = C3263b.m16154n(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    latLng = (LatLng) C3263b.m16135a(parcel, a, LatLng.CREATOR);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTick /*5*/:
                    num = C3263b.m16147g(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickNormalColor /*6*/:
                    b6 = C3263b.m16144d(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickSelectedColor /*7*/:
                    b5 = C3263b.m16144d(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickNormalDrawable /*8*/:
                    b4 = C3263b.m16144d(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickSelectedDrawable /*9*/:
                    b3 = C3263b.m16144d(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickSpacing /*10*/:
                    b = C3263b.m16144d(parcel, a);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b2) {
            return new StreetViewPanoramaOptions(streetViewPanoramaCamera, str, latLng, num, b6, b5, b4, b3, b);
        }
        throw new C3262a("Overread allowed size end=" + b2, parcel);
    }

    public StreetViewPanoramaOptions[] m17414a(int i) {
        return new StreetViewPanoramaOptions[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m17413a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m17414a(i);
    }
}
