package com.google.android.gms.maps.model;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

public class ao implements Creator<C3633u> {
    static void m17806a(C3633u c3633u, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16171a(parcel, 2, c3633u.m17900a(), false);
        C3264c.m16180a(parcel, 3, c3633u.m17902c());
        C3264c.m16167a(parcel, 4, c3633u.m17901b());
        C3264c.m16180a(parcel, 5, c3633u.m17903d());
        C3264c.m16167a(parcel, 6, c3633u.m17904e());
        C3264c.m16164a(parcel, a);
    }

    public C3633u m17807a(Parcel parcel) {
        float f = 0.0f;
        int b = C3263b.m16139b(parcel);
        IBinder iBinder = null;
        boolean z = false;
        boolean z2 = true;
        float f2 = 0.0f;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    iBinder = C3263b.m16155o(parcel, a);
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    z = C3263b.m16143c(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    f2 = C3263b.m16150j(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTick /*5*/:
                    z2 = C3263b.m16143c(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickNormalColor /*6*/:
                    f = C3263b.m16150j(parcel, a);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new C3633u(iBinder, z, f2, z2, f);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public C3633u[] m17808a(int i) {
        return new C3633u[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m17807a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m17808a(i);
    }
}
