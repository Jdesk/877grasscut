package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import com.zopim.android.sdk.api.C5264R;
import io.techery.properratingbar.C5501a.C5500d;
import java.util.ArrayList;
import java.util.List;
import net.cachapa.expandablelayout.C5541a.C5538a;

public class ah implements Creator<C3623n> {
    static void m17785a(C3623n c3623n, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16191c(parcel, 2, c3623n.m17875b(), false);
        C3264c.m16192d(parcel, 3, c3623n.m17873a(), false);
        C3264c.m16167a(parcel, 4, c3623n.m17876c());
        C3264c.m16168a(parcel, 5, c3623n.m17877d());
        C3264c.m16168a(parcel, 6, c3623n.m17880g());
        C3264c.m16167a(parcel, 7, c3623n.m17881h());
        C3264c.m16180a(parcel, 8, c3623n.m17882i());
        C3264c.m16180a(parcel, 9, c3623n.m17883j());
        C3264c.m16180a(parcel, 10, c3623n.m17884k());
        C3264c.m16168a(parcel, 11, c3623n.m17878e());
        C3264c.m16191c(parcel, 12, c3623n.m17879f(), false);
        C3264c.m16164a(parcel, a);
    }

    public C3623n m17786a(Parcel parcel) {
        List list = null;
        float f = 0.0f;
        int i = 0;
        int b = C3263b.m16139b(parcel);
        List arrayList = new ArrayList();
        boolean z = false;
        boolean z2 = false;
        boolean z3 = false;
        int i2 = 0;
        int i3 = 0;
        float f2 = 0.0f;
        List list2 = null;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    list2 = C3263b.m16142c(parcel, a, LatLng.CREATOR);
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    C3263b.m16138a(parcel, a, arrayList, getClass().getClassLoader());
                    break;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    f2 = C3263b.m16150j(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTick /*5*/:
                    i3 = C3263b.m16146f(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickNormalColor /*6*/:
                    i2 = C3263b.m16146f(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickSelectedColor /*7*/:
                    f = C3263b.m16150j(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickNormalDrawable /*8*/:
                    z3 = C3263b.m16143c(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickSelectedDrawable /*9*/:
                    z2 = C3263b.m16143c(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickSpacing /*10*/:
                    z = C3263b.m16143c(parcel, a);
                    break;
                case C5264R.styleable.Toolbar_popupTheme /*11*/:
                    i = C3263b.m16146f(parcel, a);
                    break;
                case C5264R.styleable.Toolbar_titleTextAppearance /*12*/:
                    list = C3263b.m16142c(parcel, a, C3620k.CREATOR);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new C3623n(list2, arrayList, f2, i3, i2, f, z3, z2, z, i, list);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public C3623n[] m17787a(int i) {
        return new C3623n[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m17786a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m17787a(i);
    }
}
