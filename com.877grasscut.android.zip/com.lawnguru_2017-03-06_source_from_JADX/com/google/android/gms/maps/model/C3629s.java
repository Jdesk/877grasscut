package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.C3233b;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.common.internal.safeparcel.C2149a;

/* renamed from: com.google.android.gms.maps.model.s */
public class C3629s extends C2149a {
    public static final Creator<C3629s> CREATOR;
    public final float f10484a;
    public final float f10485b;

    /* renamed from: com.google.android.gms.maps.model.s.a */
    public static final class C3628a {
        public float f10482a;
        public float f10483b;

        public C3628a m17896a(float f) {
            this.f10483b = f;
            return this;
        }

        public C3629s m17897a() {
            return new C3629s(this.f10483b, this.f10482a);
        }

        public C3628a m17898b(float f) {
            this.f10482a = f;
            return this;
        }
    }

    static {
        CREATOR = new am();
    }

    public C3629s(float f, float f2) {
        boolean z = -90.0f <= f && f <= 90.0f;
        C3234c.m16052b(z, "Tilt needs to be between -90 and 90 inclusive");
        this.f10484a = 0.0f + f;
        if (((double) f2) <= 0.0d) {
            f2 = (f2 % 360.0f) + 360.0f;
        }
        this.f10485b = f2 % 360.0f;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C3629s)) {
            return false;
        }
        C3629s c3629s = (C3629s) obj;
        return Float.floatToIntBits(this.f10484a) == Float.floatToIntBits(c3629s.f10484a) && Float.floatToIntBits(this.f10485b) == Float.floatToIntBits(c3629s.f10485b);
    }

    public int hashCode() {
        return C3233b.m16038a(Float.valueOf(this.f10484a), Float.valueOf(this.f10485b));
    }

    public String toString() {
        return C3233b.m16039a((Object) this).m16037a("tilt", Float.valueOf(this.f10484a)).m16037a("bearing", Float.valueOf(this.f10485b)).toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        am.m17800a(this, parcel, i);
    }
}
