package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import net.cachapa.expandablelayout.C5541a.C5538a;

public class ab implements Creator<LatLngBounds> {
    static void m17767a(LatLngBounds latLngBounds, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16172a(parcel, 2, latLngBounds.f10388a, i, false);
        C3264c.m16172a(parcel, 3, latLngBounds.f10389b, i, false);
        C3264c.m16164a(parcel, a);
    }

    public LatLngBounds m17768a(Parcel parcel) {
        LatLng latLng = null;
        int b = C3263b.m16139b(parcel);
        LatLng latLng2 = null;
        while (parcel.dataPosition() < b) {
            LatLng latLng3;
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    LatLng latLng4 = latLng;
                    latLng = (LatLng) C3263b.m16135a(parcel, a, LatLng.CREATOR);
                    latLng3 = latLng4;
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    latLng3 = (LatLng) C3263b.m16135a(parcel, a, LatLng.CREATOR);
                    latLng = latLng2;
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    latLng3 = latLng;
                    latLng = latLng2;
                    break;
            }
            latLng2 = latLng;
            latLng = latLng3;
        }
        if (parcel.dataPosition() == b) {
            return new LatLngBounds(latLng2, latLng);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public LatLngBounds[] m17769a(int i) {
        return new LatLngBounds[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m17768a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m17769a(i);
    }
}
