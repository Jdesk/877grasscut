package com.google.android.gms.maps.model;

import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.p097a.C2046a;

/* renamed from: com.google.android.gms.maps.model.a */
public final class C3610a {
    private final C2046a f10403a;

    public C3610a(C2046a c2046a) {
        this.f10403a = (C2046a) C3234c.m16042a((Object) c2046a);
    }

    public C2046a m17763a() {
        return this.f10403a;
    }
}
