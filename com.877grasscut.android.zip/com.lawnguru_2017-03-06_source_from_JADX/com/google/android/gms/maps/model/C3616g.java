package com.google.android.gms.maps.model;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C2149a;
import com.google.android.gms.p097a.C2046a.C2048a;

/* renamed from: com.google.android.gms.maps.model.g */
public final class C3616g extends C2149a {
    public static final Creator<C3616g> CREATOR;
    private C3610a f10419a;
    private LatLng f10420b;
    private float f10421c;
    private float f10422d;
    private LatLngBounds f10423e;
    private float f10424f;
    private float f10425g;
    private boolean f10426h;
    private float f10427i;
    private float f10428j;
    private float f10429k;
    private boolean f10430l;

    static {
        CREATOR = new aa();
    }

    public C3616g() {
        this.f10426h = true;
        this.f10427i = 0.0f;
        this.f10428j = 0.5f;
        this.f10429k = 0.5f;
        this.f10430l = false;
    }

    C3616g(IBinder iBinder, LatLng latLng, float f, float f2, LatLngBounds latLngBounds, float f3, float f4, boolean z, float f5, float f6, float f7, boolean z2) {
        this.f10426h = true;
        this.f10427i = 0.0f;
        this.f10428j = 0.5f;
        this.f10429k = 0.5f;
        this.f10430l = false;
        this.f10419a = new C3610a(C2048a.m7925a(iBinder));
        this.f10420b = latLng;
        this.f10421c = f;
        this.f10422d = f2;
        this.f10423e = latLngBounds;
        this.f10424f = f3;
        this.f10425g = f4;
        this.f10426h = z;
        this.f10427i = f5;
        this.f10428j = f6;
        this.f10429k = f7;
        this.f10430l = z2;
    }

    IBinder m17834a() {
        return this.f10419a.m17763a().asBinder();
    }

    public LatLng m17835b() {
        return this.f10420b;
    }

    public float m17836c() {
        return this.f10421c;
    }

    public float m17837d() {
        return this.f10422d;
    }

    public LatLngBounds m17838e() {
        return this.f10423e;
    }

    public float m17839f() {
        return this.f10424f;
    }

    public float m17840g() {
        return this.f10425g;
    }

    public float m17841h() {
        return this.f10427i;
    }

    public float m17842i() {
        return this.f10428j;
    }

    public float m17843j() {
        return this.f10429k;
    }

    public boolean m17844k() {
        return this.f10426h;
    }

    public boolean m17845l() {
        return this.f10430l;
    }

    public void writeToParcel(Parcel parcel, int i) {
        aa.m17764a(this, parcel, i);
    }
}
