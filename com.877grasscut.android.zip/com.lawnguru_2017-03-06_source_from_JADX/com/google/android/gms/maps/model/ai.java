package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import com.zopim.android.sdk.api.C5264R;
import io.techery.properratingbar.C5501a.C5500d;
import java.util.List;
import net.cachapa.expandablelayout.C5541a.C5538a;

public class ai implements Creator<C3624o> {
    static void m17788a(C3624o c3624o, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16191c(parcel, 2, c3624o.m17885a(), false);
        C3264c.m16167a(parcel, 3, c3624o.m17886b());
        C3264c.m16168a(parcel, 4, c3624o.m17887c());
        C3264c.m16167a(parcel, 5, c3624o.m17892h());
        C3264c.m16180a(parcel, 6, c3624o.m17893i());
        C3264c.m16180a(parcel, 7, c3624o.m17894j());
        C3264c.m16180a(parcel, 8, c3624o.m17895k());
        C3264c.m16172a(parcel, 9, c3624o.m17888d(), i, false);
        C3264c.m16172a(parcel, 10, c3624o.m17889e(), i, false);
        C3264c.m16168a(parcel, 11, c3624o.m17890f());
        C3264c.m16191c(parcel, 12, c3624o.m17891g(), false);
        C3264c.m16164a(parcel, a);
    }

    public C3624o m17789a(Parcel parcel) {
        float f = 0.0f;
        List list = null;
        int i = 0;
        int b = C3263b.m16139b(parcel);
        C3612d c3612d = null;
        C3612d c3612d2 = null;
        boolean z = false;
        boolean z2 = false;
        boolean z3 = false;
        int i2 = 0;
        float f2 = 0.0f;
        List list2 = null;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    list2 = C3263b.m16142c(parcel, a, LatLng.CREATOR);
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    f2 = C3263b.m16150j(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    i2 = C3263b.m16146f(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTick /*5*/:
                    f = C3263b.m16150j(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickNormalColor /*6*/:
                    z3 = C3263b.m16143c(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickSelectedColor /*7*/:
                    z2 = C3263b.m16143c(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickNormalDrawable /*8*/:
                    z = C3263b.m16143c(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickSelectedDrawable /*9*/:
                    c3612d2 = (C3612d) C3263b.m16135a(parcel, a, C3612d.CREATOR);
                    break;
                case C5500d.ProperRatingBar_prb_tickSpacing /*10*/:
                    c3612d = (C3612d) C3263b.m16135a(parcel, a, C3612d.CREATOR);
                    break;
                case C5264R.styleable.Toolbar_popupTheme /*11*/:
                    i = C3263b.m16146f(parcel, a);
                    break;
                case C5264R.styleable.Toolbar_titleTextAppearance /*12*/:
                    list = C3263b.m16142c(parcel, a, C3620k.CREATOR);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new C3624o(list2, f2, i2, f, z3, z2, z, c3612d2, c3612d, i, list);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public C3624o[] m17790a(int i) {
        return new C3624o[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m17789a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m17790a(i);
    }
}
