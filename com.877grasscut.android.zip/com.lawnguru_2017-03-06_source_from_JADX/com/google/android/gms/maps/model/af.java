package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import net.cachapa.expandablelayout.C5541a.C5538a;

public class af implements Creator<C3620k> {
    static void m17779a(C3620k c3620k, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16168a(parcel, 2, c3620k.m17868a());
        C3264c.m16174a(parcel, 3, c3620k.m17869b(), false);
        C3264c.m16164a(parcel, a);
    }

    public C3620k m17780a(Parcel parcel) {
        int b = C3263b.m16139b(parcel);
        int i = 0;
        Float f = null;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    i = C3263b.m16146f(parcel, a);
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    f = C3263b.m16151k(parcel, a);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new C3620k(i, f);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public C3620k[] m17781a(int i) {
        return new C3620k[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m17780a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m17781a(i);
    }
}
