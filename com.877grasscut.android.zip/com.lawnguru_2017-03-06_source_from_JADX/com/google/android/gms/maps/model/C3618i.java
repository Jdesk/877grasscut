package com.google.android.gms.maps.model;

import android.os.RemoteException;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.maps.model.p104a.C3598f;

/* renamed from: com.google.android.gms.maps.model.i */
public final class C3618i {
    private final C3598f f10433a;

    public C3618i(C3598f c3598f) {
        this.f10433a = (C3598f) C3234c.m16042a((Object) c3598f);
    }

    public LatLng m17847a() {
        try {
            return this.f10433a.m17629c();
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }

    public void m17848b() {
        try {
            this.f10433a.m17635g();
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof C3618i)) {
            return false;
        }
        try {
            return this.f10433a.m17622a(((C3618i) obj).f10433a);
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }

    public int hashCode() {
        try {
            return this.f10433a.m17639k();
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }
}
