package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

public class aj implements Creator<StreetViewPanoramaCamera> {
    static void m17791a(StreetViewPanoramaCamera streetViewPanoramaCamera, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16167a(parcel, 2, streetViewPanoramaCamera.f10390a);
        C3264c.m16167a(parcel, 3, streetViewPanoramaCamera.f10391b);
        C3264c.m16167a(parcel, 4, streetViewPanoramaCamera.f10392c);
        C3264c.m16164a(parcel, a);
    }

    public StreetViewPanoramaCamera m17792a(Parcel parcel) {
        float f = 0.0f;
        int b = C3263b.m16139b(parcel);
        float f2 = 0.0f;
        float f3 = 0.0f;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    f3 = C3263b.m16150j(parcel, a);
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    f2 = C3263b.m16150j(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    f = C3263b.m16150j(parcel, a);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new StreetViewPanoramaCamera(f3, f2, f);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public StreetViewPanoramaCamera[] m17793a(int i) {
        return new StreetViewPanoramaCamera[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m17792a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m17793a(i);
    }
}
