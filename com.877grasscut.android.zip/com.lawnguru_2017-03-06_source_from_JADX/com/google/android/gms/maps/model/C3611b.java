package com.google.android.gms.maps.model;

import android.os.RemoteException;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.maps.model.p104a.C3586b;

/* renamed from: com.google.android.gms.maps.model.b */
public final class C3611b {
    private static C3586b f10404a;

    private static C3586b m17812a() {
        return (C3586b) C3234c.m16043a(f10404a, (Object) "IBitmapDescriptorFactory is not initialized");
    }

    public static C3610a m17813a(int i) {
        try {
            return new C3610a(C3611b.m17812a().m17489a(i));
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }

    public static void m17814a(C3586b c3586b) {
        if (f10404a == null) {
            f10404a = (C3586b) C3234c.m16042a((Object) c3586b);
        }
    }
}
