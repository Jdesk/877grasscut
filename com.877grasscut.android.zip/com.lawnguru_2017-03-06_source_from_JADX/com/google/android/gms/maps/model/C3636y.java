package com.google.android.gms.maps.model;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.maps.model.y */
public class C3636y implements Creator<C3612d> {
    static void m17908a(C3612d c3612d, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16168a(parcel, 2, c3612d.m17816a());
        C3264c.m16171a(parcel, 3, c3612d.m17818c(), false);
        C3264c.m16174a(parcel, 4, c3612d.m17817b(), false);
        C3264c.m16164a(parcel, a);
    }

    public C3612d m17909a(Parcel parcel) {
        Float f = null;
        int b = C3263b.m16139b(parcel);
        int i = 0;
        IBinder iBinder = null;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    i = C3263b.m16146f(parcel, a);
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    iBinder = C3263b.m16155o(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    f = C3263b.m16151k(parcel, a);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new C3612d(i, iBinder, f);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public C3612d[] m17910a(int i) {
        return new C3612d[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m17909a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m17910a(i);
    }
}
