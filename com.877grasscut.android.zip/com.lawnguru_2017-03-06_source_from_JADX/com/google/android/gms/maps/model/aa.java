package com.google.android.gms.maps.model;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import com.zopim.android.sdk.api.C5264R;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

public class aa implements Creator<C3616g> {
    static void m17764a(C3616g c3616g, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16171a(parcel, 2, c3616g.m17834a(), false);
        C3264c.m16172a(parcel, 3, c3616g.m17835b(), i, false);
        C3264c.m16167a(parcel, 4, c3616g.m17836c());
        C3264c.m16167a(parcel, 5, c3616g.m17837d());
        C3264c.m16172a(parcel, 6, c3616g.m17838e(), i, false);
        C3264c.m16167a(parcel, 7, c3616g.m17839f());
        C3264c.m16167a(parcel, 8, c3616g.m17840g());
        C3264c.m16180a(parcel, 9, c3616g.m17844k());
        C3264c.m16167a(parcel, 10, c3616g.m17841h());
        C3264c.m16167a(parcel, 11, c3616g.m17842i());
        C3264c.m16167a(parcel, 12, c3616g.m17843j());
        C3264c.m16180a(parcel, 13, c3616g.m17845l());
        C3264c.m16164a(parcel, a);
    }

    public C3616g m17765a(Parcel parcel) {
        int b = C3263b.m16139b(parcel);
        IBinder iBinder = null;
        LatLng latLng = null;
        float f = 0.0f;
        float f2 = 0.0f;
        LatLngBounds latLngBounds = null;
        float f3 = 0.0f;
        float f4 = 0.0f;
        boolean z = false;
        float f5 = 0.0f;
        float f6 = 0.0f;
        float f7 = 0.0f;
        boolean z2 = false;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    iBinder = C3263b.m16155o(parcel, a);
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    latLng = (LatLng) C3263b.m16135a(parcel, a, LatLng.CREATOR);
                    break;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    f = C3263b.m16150j(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTick /*5*/:
                    f2 = C3263b.m16150j(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickNormalColor /*6*/:
                    latLngBounds = (LatLngBounds) C3263b.m16135a(parcel, a, LatLngBounds.CREATOR);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickSelectedColor /*7*/:
                    f3 = C3263b.m16150j(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickNormalDrawable /*8*/:
                    f4 = C3263b.m16150j(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickSelectedDrawable /*9*/:
                    z = C3263b.m16143c(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickSpacing /*10*/:
                    f5 = C3263b.m16150j(parcel, a);
                    break;
                case C5264R.styleable.Toolbar_popupTheme /*11*/:
                    f6 = C3263b.m16150j(parcel, a);
                    break;
                case C5264R.styleable.Toolbar_titleTextAppearance /*12*/:
                    f7 = C3263b.m16150j(parcel, a);
                    break;
                case C5264R.styleable.Toolbar_subtitleTextAppearance /*13*/:
                    z2 = C3263b.m16143c(parcel, a);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new C3616g(iBinder, latLng, f, f2, latLngBounds, f3, f4, z, f5, f6, f7, z2);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public C3616g[] m17766a(int i) {
        return new C3616g[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m17765a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m17766a(i);
    }
}
