package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.C2149a;

public final class LatLng extends C2149a implements ReflectedParcelable {
    public static final Creator<LatLng> CREATOR;
    public final double f10382a;
    public final double f10383b;

    static {
        CREATOR = new ac();
    }

    public LatLng(double d, double d2) {
        if (-180.0d > d2 || d2 >= 180.0d) {
            this.f10383b = ((((d2 - 180.0d) % 360.0d) + 360.0d) % 360.0d) - 180.0d;
        } else {
            this.f10383b = d2;
        }
        this.f10382a = Math.max(-90.0d, Math.min(90.0d, d));
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof LatLng)) {
            return false;
        }
        LatLng latLng = (LatLng) obj;
        return Double.doubleToLongBits(this.f10382a) == Double.doubleToLongBits(latLng.f10382a) && Double.doubleToLongBits(this.f10383b) == Double.doubleToLongBits(latLng.f10383b);
    }

    public int hashCode() {
        long doubleToLongBits = Double.doubleToLongBits(this.f10382a);
        int i = ((int) (doubleToLongBits ^ (doubleToLongBits >>> 32))) + 31;
        long doubleToLongBits2 = Double.doubleToLongBits(this.f10383b);
        return (i * 31) + ((int) (doubleToLongBits2 ^ (doubleToLongBits2 >>> 32)));
    }

    public String toString() {
        double d = this.f10382a;
        return "lat/lng: (" + d + "," + this.f10383b + ")";
    }

    public void writeToParcel(Parcel parcel, int i) {
        ac.m17770a(this, parcel, i);
    }
}
