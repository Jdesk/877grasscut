package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

public class ag implements Creator<C3621l> {
    static void m17782a(C3621l c3621l, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16172a(parcel, 2, c3621l.f10451a, i, false);
        C3264c.m16177a(parcel, 3, c3621l.f10452b, false);
        C3264c.m16177a(parcel, 4, c3621l.f10453c, false);
        C3264c.m16164a(parcel, a);
    }

    public C3621l m17783a(Parcel parcel) {
        String str = null;
        int b = C3263b.m16139b(parcel);
        String str2 = null;
        LatLng latLng = null;
        while (parcel.dataPosition() < b) {
            LatLng latLng2;
            String str3;
            int a = C3263b.m16133a(parcel);
            String str4;
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    str4 = str;
                    str = str2;
                    latLng2 = (LatLng) C3263b.m16135a(parcel, a, LatLng.CREATOR);
                    str3 = str4;
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    latLng2 = latLng;
                    str4 = C3263b.m16154n(parcel, a);
                    str3 = str;
                    str = str4;
                    break;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    str3 = C3263b.m16154n(parcel, a);
                    str = str2;
                    latLng2 = latLng;
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    str3 = str;
                    str = str2;
                    latLng2 = latLng;
                    break;
            }
            latLng = latLng2;
            str2 = str;
            str = str3;
        }
        if (parcel.dataPosition() == b) {
            return new C3621l(latLng, str2, str);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public C3621l[] m17784a(int i) {
        return new C3621l[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m17783a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m17784a(i);
    }
}
