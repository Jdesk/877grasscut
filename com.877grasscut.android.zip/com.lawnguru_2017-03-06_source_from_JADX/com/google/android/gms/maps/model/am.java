package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import net.cachapa.expandablelayout.C5541a.C5538a;

public class am implements Creator<C3629s> {
    static void m17800a(C3629s c3629s, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16167a(parcel, 2, c3629s.f10484a);
        C3264c.m16167a(parcel, 3, c3629s.f10485b);
        C3264c.m16164a(parcel, a);
    }

    public C3629s m17801a(Parcel parcel) {
        float f = 0.0f;
        int b = C3263b.m16139b(parcel);
        float f2 = 0.0f;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    f2 = C3263b.m16150j(parcel, a);
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    f = C3263b.m16150j(parcel, a);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new C3629s(f2, f);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public C3629s[] m17802a(int i) {
        return new C3629s[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m17801a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m17802a(i);
    }
}
