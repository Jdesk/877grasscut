package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.C3233b;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.C2149a;
import com.google.android.gms.maps.model.C3629s.C3628a;

public class StreetViewPanoramaCamera extends C2149a implements ReflectedParcelable {
    public static final Creator<StreetViewPanoramaCamera> CREATOR;
    public final float f10390a;
    public final float f10391b;
    public final float f10392c;
    private C3629s f10393d;

    static {
        CREATOR = new aj();
    }

    public StreetViewPanoramaCamera(float f, float f2, float f3) {
        boolean z = -90.0f <= f2 && f2 <= 90.0f;
        C3234c.m16052b(z, "Tilt needs to be between -90 and 90 inclusive");
        if (((double) f) <= 0.0d) {
            f = 0.0f;
        }
        this.f10390a = f;
        this.f10391b = f2 + 0.0f;
        this.f10392c = (((double) f3) <= 0.0d ? (f3 % 360.0f) + 360.0f : f3) % 360.0f;
        this.f10393d = new C3628a().m17896a(f2).m17898b(f3).m17897a();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof StreetViewPanoramaCamera)) {
            return false;
        }
        StreetViewPanoramaCamera streetViewPanoramaCamera = (StreetViewPanoramaCamera) obj;
        return Float.floatToIntBits(this.f10390a) == Float.floatToIntBits(streetViewPanoramaCamera.f10390a) && Float.floatToIntBits(this.f10391b) == Float.floatToIntBits(streetViewPanoramaCamera.f10391b) && Float.floatToIntBits(this.f10392c) == Float.floatToIntBits(streetViewPanoramaCamera.f10392c);
    }

    public int hashCode() {
        return C3233b.m16038a(Float.valueOf(this.f10390a), Float.valueOf(this.f10391b), Float.valueOf(this.f10392c));
    }

    public String toString() {
        return C3233b.m16039a((Object) this).m16037a("zoom", Float.valueOf(this.f10390a)).m16037a("tilt", Float.valueOf(this.f10391b)).m16037a("bearing", Float.valueOf(this.f10392c)).toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        aj.m17791a(this, parcel, i);
    }
}
