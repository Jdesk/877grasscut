package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C2149a;
import com.yalantis.ucrop.view.CropImageView;
import java.util.List;

/* renamed from: com.google.android.gms.maps.model.f */
public final class C3615f extends C2149a {
    public static final Creator<C3615f> CREATOR;
    private LatLng f10410a;
    private double f10411b;
    private float f10412c;
    private int f10413d;
    private int f10414e;
    private float f10415f;
    private boolean f10416g;
    private boolean f10417h;
    private List<C3620k> f10418i;

    static {
        CREATOR = new C3637z();
    }

    public C3615f() {
        this.f10410a = null;
        this.f10411b = 0.0d;
        this.f10412c = CropImageView.DEFAULT_MAX_SCALE_MULTIPLIER;
        this.f10413d = -16777216;
        this.f10414e = 0;
        this.f10415f = 0.0f;
        this.f10416g = true;
        this.f10417h = false;
        this.f10418i = null;
    }

    C3615f(LatLng latLng, double d, float f, int i, int i2, float f2, boolean z, boolean z2, List<C3620k> list) {
        this.f10410a = null;
        this.f10411b = 0.0d;
        this.f10412c = CropImageView.DEFAULT_MAX_SCALE_MULTIPLIER;
        this.f10413d = -16777216;
        this.f10414e = 0;
        this.f10415f = 0.0f;
        this.f10416g = true;
        this.f10417h = false;
        this.f10418i = null;
        this.f10410a = latLng;
        this.f10411b = d;
        this.f10412c = f;
        this.f10413d = i;
        this.f10414e = i2;
        this.f10415f = f2;
        this.f10416g = z;
        this.f10417h = z2;
        this.f10418i = list;
    }

    public LatLng m17820a() {
        return this.f10410a;
    }

    public C3615f m17821a(double d) {
        this.f10411b = d;
        return this;
    }

    public C3615f m17822a(float f) {
        this.f10412c = f;
        return this;
    }

    public C3615f m17823a(int i) {
        this.f10413d = i;
        return this;
    }

    public C3615f m17824a(LatLng latLng) {
        this.f10410a = latLng;
        return this;
    }

    public double m17825b() {
        return this.f10411b;
    }

    public C3615f m17826b(int i) {
        this.f10414e = i;
        return this;
    }

    public float m17827c() {
        return this.f10412c;
    }

    public int m17828d() {
        return this.f10413d;
    }

    public List<C3620k> m17829e() {
        return this.f10418i;
    }

    public int m17830f() {
        return this.f10414e;
    }

    public float m17831g() {
        return this.f10415f;
    }

    public boolean m17832h() {
        return this.f10416g;
    }

    public boolean m17833i() {
        return this.f10417h;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C3637z.m17911a(this, parcel, i);
    }
}
