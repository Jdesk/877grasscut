package com.google.android.gms.maps.model;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.util.AttributeSet;
import com.google.android.gms.C2063a.C2045c;
import com.google.android.gms.common.internal.C3233b;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.C2149a;

public final class CameraPosition extends C2149a implements ReflectedParcelable {
    public static final Creator<CameraPosition> CREATOR;
    public final LatLng f10378a;
    public final float f10379b;
    public final float f10380c;
    public final float f10381d;

    /* renamed from: com.google.android.gms.maps.model.CameraPosition.a */
    public static final class C3581a {
        private LatLng f10374a;
        private float f10375b;
        private float f10376c;
        private float f10377d;

        public C3581a m17415a(float f) {
            this.f10375b = f;
            return this;
        }

        public C3581a m17416a(LatLng latLng) {
            this.f10374a = latLng;
            return this;
        }

        public CameraPosition m17417a() {
            return new CameraPosition(this.f10374a, this.f10375b, this.f10376c, this.f10377d);
        }

        public C3581a m17418b(float f) {
            this.f10376c = f;
            return this;
        }

        public C3581a m17419c(float f) {
            this.f10377d = f;
            return this;
        }
    }

    static {
        CREATOR = new C3635x();
    }

    public CameraPosition(LatLng latLng, float f, float f2, float f3) {
        C3234c.m16043a((Object) latLng, (Object) "null camera target");
        boolean z = 0.0f <= f2 && f2 <= 90.0f;
        C3234c.m16053b(z, "Tilt needs to be between 0 and 90 inclusive: %s", Float.valueOf(f2));
        this.f10378a = latLng;
        this.f10379b = f;
        this.f10380c = f2 + 0.0f;
        if (((double) f3) <= 0.0d) {
            f3 = (f3 % 360.0f) + 360.0f;
        }
        this.f10381d = f3 % 360.0f;
    }

    public static C3581a m17420a() {
        return new C3581a();
    }

    public static CameraPosition m17421a(Context context, AttributeSet attributeSet) {
        if (attributeSet == null) {
            return null;
        }
        TypedArray obtainAttributes = context.getResources().obtainAttributes(attributeSet, C2045c.MapAttrs);
        LatLng latLng = new LatLng((double) (obtainAttributes.hasValue(C2045c.MapAttrs_cameraTargetLat) ? obtainAttributes.getFloat(C2045c.MapAttrs_cameraTargetLat, 0.0f) : 0.0f), (double) (obtainAttributes.hasValue(C2045c.MapAttrs_cameraTargetLng) ? obtainAttributes.getFloat(C2045c.MapAttrs_cameraTargetLng, 0.0f) : 0.0f));
        C3581a a = m17420a();
        a.m17416a(latLng);
        if (obtainAttributes.hasValue(C2045c.MapAttrs_cameraZoom)) {
            a.m17415a(obtainAttributes.getFloat(C2045c.MapAttrs_cameraZoom, 0.0f));
        }
        if (obtainAttributes.hasValue(C2045c.MapAttrs_cameraBearing)) {
            a.m17419c(obtainAttributes.getFloat(C2045c.MapAttrs_cameraBearing, 0.0f));
        }
        if (obtainAttributes.hasValue(C2045c.MapAttrs_cameraTilt)) {
            a.m17418b(obtainAttributes.getFloat(C2045c.MapAttrs_cameraTilt, 0.0f));
        }
        return a.m17417a();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof CameraPosition)) {
            return false;
        }
        CameraPosition cameraPosition = (CameraPosition) obj;
        return this.f10378a.equals(cameraPosition.f10378a) && Float.floatToIntBits(this.f10379b) == Float.floatToIntBits(cameraPosition.f10379b) && Float.floatToIntBits(this.f10380c) == Float.floatToIntBits(cameraPosition.f10380c) && Float.floatToIntBits(this.f10381d) == Float.floatToIntBits(cameraPosition.f10381d);
    }

    public int hashCode() {
        return C3233b.m16038a(this.f10378a, Float.valueOf(this.f10379b), Float.valueOf(this.f10380c), Float.valueOf(this.f10381d));
    }

    public String toString() {
        return C3233b.m16039a((Object) this).m16037a("target", this.f10378a).m16037a("zoom", Float.valueOf(this.f10379b)).m16037a("tilt", Float.valueOf(this.f10380c)).m16037a("bearing", Float.valueOf(this.f10381d)).toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C3635x.m17905a(this, parcel, i);
    }
}
