package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.C3233b;
import com.google.android.gms.common.internal.safeparcel.C2149a;

/* renamed from: com.google.android.gms.maps.model.r */
public class C3627r extends C2149a {
    public static final Creator<C3627r> CREATOR;
    public final C3626q[] f10479a;
    public final LatLng f10480b;
    public final String f10481c;

    static {
        CREATOR = new al();
    }

    public C3627r(C3626q[] c3626qArr, LatLng latLng, String str) {
        this.f10479a = c3626qArr;
        this.f10480b = latLng;
        this.f10481c = str;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C3627r)) {
            return false;
        }
        C3627r c3627r = (C3627r) obj;
        return this.f10481c.equals(c3627r.f10481c) && this.f10480b.equals(c3627r.f10480b);
    }

    public int hashCode() {
        return C3233b.m16038a(this.f10480b, this.f10481c);
    }

    public String toString() {
        return C3233b.m16039a((Object) this).m16037a("panoId", this.f10481c).m16037a("position", this.f10480b.toString()).toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        al.m17797a(this, parcel, i);
    }
}
