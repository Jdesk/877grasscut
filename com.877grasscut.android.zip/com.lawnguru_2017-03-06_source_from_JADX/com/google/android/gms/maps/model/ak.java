package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import net.cachapa.expandablelayout.C5541a.C5538a;

public class ak implements Creator<C3626q> {
    static void m17794a(C3626q c3626q, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16177a(parcel, 2, c3626q.f10477a, false);
        C3264c.m16167a(parcel, 3, c3626q.f10478b);
        C3264c.m16164a(parcel, a);
    }

    public C3626q m17795a(Parcel parcel) {
        int b = C3263b.m16139b(parcel);
        String str = null;
        float f = 0.0f;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    str = C3263b.m16154n(parcel, a);
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    f = C3263b.m16150j(parcel, a);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new C3626q(str, f);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public C3626q[] m17796a(int i) {
        return new C3626q[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m17795a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m17796a(i);
    }
}
