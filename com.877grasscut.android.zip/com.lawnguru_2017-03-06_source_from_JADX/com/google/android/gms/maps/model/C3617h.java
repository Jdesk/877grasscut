package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C2149a;

/* renamed from: com.google.android.gms.maps.model.h */
public final class C3617h extends C2149a {
    public static final Creator<C3617h> CREATOR;
    private static final String f10431a;
    private String f10432b;

    static {
        f10431a = C3617h.class.getSimpleName();
        CREATOR = new ad();
    }

    public C3617h(String str) {
        this.f10432b = str;
    }

    public String m17846a() {
        return this.f10432b;
    }

    public void writeToParcel(Parcel parcel, int i) {
        ad.m17773a(this, parcel, i);
    }
}
