package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.C3233b;
import com.google.android.gms.common.internal.safeparcel.C2149a;

/* renamed from: com.google.android.gms.maps.model.w */
public final class C3634w extends C2149a {
    public static final Creator<C3634w> CREATOR;
    public final LatLng f10498a;
    public final LatLng f10499b;
    public final LatLng f10500c;
    public final LatLng f10501d;
    public final LatLngBounds f10502e;

    static {
        CREATOR = new ap();
    }

    public C3634w(LatLng latLng, LatLng latLng2, LatLng latLng3, LatLng latLng4, LatLngBounds latLngBounds) {
        this.f10498a = latLng;
        this.f10499b = latLng2;
        this.f10500c = latLng3;
        this.f10501d = latLng4;
        this.f10502e = latLngBounds;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C3634w)) {
            return false;
        }
        C3634w c3634w = (C3634w) obj;
        return this.f10498a.equals(c3634w.f10498a) && this.f10499b.equals(c3634w.f10499b) && this.f10500c.equals(c3634w.f10500c) && this.f10501d.equals(c3634w.f10501d) && this.f10502e.equals(c3634w.f10502e);
    }

    public int hashCode() {
        return C3233b.m16038a(this.f10498a, this.f10499b, this.f10500c, this.f10501d, this.f10502e);
    }

    public String toString() {
        return C3233b.m16039a((Object) this).m16037a("nearLeft", this.f10498a).m16037a("nearRight", this.f10499b).m16037a("farLeft", this.f10500c).m16037a("farRight", this.f10501d).m16037a("latLngBounds", this.f10502e).toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        ap.m17809a(this, parcel, i);
    }
}
