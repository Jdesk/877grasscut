package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C2149a;
import com.yalantis.ucrop.view.CropImageView;
import java.util.ArrayList;
import java.util.List;

/* renamed from: com.google.android.gms.maps.model.o */
public final class C3624o extends C2149a {
    public static final Creator<C3624o> CREATOR;
    private final List<LatLng> f10466a;
    private float f10467b;
    private int f10468c;
    private float f10469d;
    private boolean f10470e;
    private boolean f10471f;
    private boolean f10472g;
    private C3612d f10473h;
    private C3612d f10474i;
    private int f10475j;
    private List<C3620k> f10476k;

    static {
        CREATOR = new ai();
    }

    public C3624o() {
        this.f10467b = CropImageView.DEFAULT_MAX_SCALE_MULTIPLIER;
        this.f10468c = -16777216;
        this.f10469d = 0.0f;
        this.f10470e = true;
        this.f10471f = false;
        this.f10472g = false;
        this.f10473h = new C3613c();
        this.f10474i = new C3613c();
        this.f10475j = 0;
        this.f10476k = null;
        this.f10466a = new ArrayList();
    }

    C3624o(List list, float f, int i, float f2, boolean z, boolean z2, boolean z3, C3612d c3612d, C3612d c3612d2, int i2, List<C3620k> list2) {
        this.f10467b = CropImageView.DEFAULT_MAX_SCALE_MULTIPLIER;
        this.f10468c = -16777216;
        this.f10469d = 0.0f;
        this.f10470e = true;
        this.f10471f = false;
        this.f10472g = false;
        this.f10473h = new C3613c();
        this.f10474i = new C3613c();
        this.f10475j = 0;
        this.f10476k = null;
        this.f10466a = list;
        this.f10467b = f;
        this.f10468c = i;
        this.f10469d = f2;
        this.f10470e = z;
        this.f10471f = z2;
        this.f10472g = z3;
        if (c3612d != null) {
            this.f10473h = c3612d;
        }
        if (c3612d2 != null) {
            this.f10474i = c3612d2;
        }
        this.f10475j = i2;
        this.f10476k = list2;
    }

    public List<LatLng> m17885a() {
        return this.f10466a;
    }

    public float m17886b() {
        return this.f10467b;
    }

    public int m17887c() {
        return this.f10468c;
    }

    public C3612d m17888d() {
        return this.f10473h;
    }

    public C3612d m17889e() {
        return this.f10474i;
    }

    public int m17890f() {
        return this.f10475j;
    }

    public List<C3620k> m17891g() {
        return this.f10476k;
    }

    public float m17892h() {
        return this.f10469d;
    }

    public boolean m17893i() {
        return this.f10470e;
    }

    public boolean m17894j() {
        return this.f10471f;
    }

    public boolean m17895k() {
        return this.f10472g;
    }

    public void writeToParcel(Parcel parcel, int i) {
        ai.m17788a(this, parcel, i);
    }
}
