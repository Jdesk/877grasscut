package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import net.cachapa.expandablelayout.C5541a.C5538a;

public class ad implements Creator<C3617h> {
    static void m17773a(C3617h c3617h, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16177a(parcel, 2, c3617h.m17846a(), false);
        C3264c.m16164a(parcel, a);
    }

    public C3617h m17774a(Parcel parcel) {
        int b = C3263b.m16139b(parcel);
        String str = null;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    str = C3263b.m16154n(parcel, a);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new C3617h(str);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public C3617h[] m17775a(int i) {
        return new C3617h[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m17774a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m17775a(i);
    }
}
