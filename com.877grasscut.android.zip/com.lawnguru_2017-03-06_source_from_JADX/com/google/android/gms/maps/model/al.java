package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

public class al implements Creator<C3627r> {
    static void m17797a(C3627r c3627r, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16183a(parcel, 2, c3627r.f10479a, i, false);
        C3264c.m16172a(parcel, 3, c3627r.f10480b, i, false);
        C3264c.m16177a(parcel, 4, c3627r.f10481c, false);
        C3264c.m16164a(parcel, a);
    }

    public C3627r m17798a(Parcel parcel) {
        String str = null;
        int b = C3263b.m16139b(parcel);
        LatLng latLng = null;
        C3626q[] c3626qArr = null;
        while (parcel.dataPosition() < b) {
            LatLng latLng2;
            C3626q[] c3626qArr2;
            String str2;
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    String str3 = str;
                    latLng2 = latLng;
                    c3626qArr2 = (C3626q[]) C3263b.m16141b(parcel, a, C3626q.CREATOR);
                    str2 = str3;
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    c3626qArr2 = c3626qArr;
                    LatLng latLng3 = (LatLng) C3263b.m16135a(parcel, a, LatLng.CREATOR);
                    str2 = str;
                    latLng2 = latLng3;
                    break;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    str2 = C3263b.m16154n(parcel, a);
                    latLng2 = latLng;
                    c3626qArr2 = c3626qArr;
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    str2 = str;
                    latLng2 = latLng;
                    c3626qArr2 = c3626qArr;
                    break;
            }
            c3626qArr = c3626qArr2;
            latLng = latLng2;
            str = str2;
        }
        if (parcel.dataPosition() == b) {
            return new C3627r(c3626qArr, latLng, str);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public C3627r[] m17799a(int i) {
        return new C3627r[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m17798a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m17799a(i);
    }
}
