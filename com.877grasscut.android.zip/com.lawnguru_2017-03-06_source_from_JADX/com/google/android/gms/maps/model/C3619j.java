package com.google.android.gms.maps.model;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C2149a;
import com.google.android.gms.p097a.C2046a.C2048a;

/* renamed from: com.google.android.gms.maps.model.j */
public final class C3619j extends C2149a {
    public static final Creator<C3619j> CREATOR;
    private LatLng f10434a;
    private String f10435b;
    private String f10436c;
    private C3610a f10437d;
    private float f10438e;
    private float f10439f;
    private boolean f10440g;
    private boolean f10441h;
    private boolean f10442i;
    private float f10443j;
    private float f10444k;
    private float f10445l;
    private float f10446m;
    private float f10447n;

    static {
        CREATOR = new ae();
    }

    public C3619j() {
        this.f10438e = 0.5f;
        this.f10439f = 1.0f;
        this.f10441h = true;
        this.f10442i = false;
        this.f10443j = 0.0f;
        this.f10444k = 0.5f;
        this.f10445l = 0.0f;
        this.f10446m = 1.0f;
    }

    C3619j(LatLng latLng, String str, String str2, IBinder iBinder, float f, float f2, boolean z, boolean z2, boolean z3, float f3, float f4, float f5, float f6, float f7) {
        this.f10438e = 0.5f;
        this.f10439f = 1.0f;
        this.f10441h = true;
        this.f10442i = false;
        this.f10443j = 0.0f;
        this.f10444k = 0.5f;
        this.f10445l = 0.0f;
        this.f10446m = 1.0f;
        this.f10434a = latLng;
        this.f10435b = str;
        this.f10436c = str2;
        if (iBinder == null) {
            this.f10437d = null;
        } else {
            this.f10437d = new C3610a(C2048a.m7925a(iBinder));
        }
        this.f10438e = f;
        this.f10439f = f2;
        this.f10440g = z;
        this.f10441h = z2;
        this.f10442i = z3;
        this.f10443j = f3;
        this.f10444k = f4;
        this.f10445l = f5;
        this.f10446m = f6;
        this.f10447n = f7;
    }

    IBinder m17849a() {
        return this.f10437d == null ? null : this.f10437d.m17763a().asBinder();
    }

    public C3619j m17850a(float f) {
        this.f10443j = f;
        return this;
    }

    public C3619j m17851a(float f, float f2) {
        this.f10438e = f;
        this.f10439f = f2;
        return this;
    }

    public C3619j m17852a(LatLng latLng) {
        if (latLng == null) {
            throw new IllegalArgumentException("latlng cannot be null - a position is required.");
        }
        this.f10434a = latLng;
        return this;
    }

    public C3619j m17853a(C3610a c3610a) {
        this.f10437d = c3610a;
        return this;
    }

    public C3619j m17854a(String str) {
        this.f10435b = str;
        return this;
    }

    public LatLng m17855b() {
        return this.f10434a;
    }

    public String m17856c() {
        return this.f10435b;
    }

    public String m17857d() {
        return this.f10436c;
    }

    public float m17858e() {
        return this.f10438e;
    }

    public float m17859f() {
        return this.f10439f;
    }

    public boolean m17860g() {
        return this.f10440g;
    }

    public boolean m17861h() {
        return this.f10441h;
    }

    public boolean m17862i() {
        return this.f10442i;
    }

    public float m17863j() {
        return this.f10443j;
    }

    public float m17864k() {
        return this.f10444k;
    }

    public float m17865l() {
        return this.f10445l;
    }

    public float m17866m() {
        return this.f10446m;
    }

    public float m17867n() {
        return this.f10447n;
    }

    public void writeToParcel(Parcel parcel, int i) {
        ae.m17776a(this, parcel, i);
    }
}
