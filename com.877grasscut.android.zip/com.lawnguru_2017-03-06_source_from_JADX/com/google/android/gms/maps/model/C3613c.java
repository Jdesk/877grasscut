package com.google.android.gms.maps.model;

/* renamed from: com.google.android.gms.maps.model.c */
public final class C3613c extends C3612d {
    public C3613c() {
        super(0);
    }

    public String toString() {
        return "[ButtCap]";
    }
}
