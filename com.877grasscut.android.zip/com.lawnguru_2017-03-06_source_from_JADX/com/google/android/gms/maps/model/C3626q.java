package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.C3233b;
import com.google.android.gms.common.internal.safeparcel.C2149a;

/* renamed from: com.google.android.gms.maps.model.q */
public class C3626q extends C2149a {
    public static final Creator<C3626q> CREATOR;
    public final String f10477a;
    public final float f10478b;

    static {
        CREATOR = new ak();
    }

    public C3626q(String str, float f) {
        this.f10477a = str;
        if (((double) f) <= 0.0d) {
            f = (f % 360.0f) + 360.0f;
        }
        this.f10478b = f % 360.0f;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C3626q)) {
            return false;
        }
        C3626q c3626q = (C3626q) obj;
        return this.f10477a.equals(c3626q.f10477a) && Float.floatToIntBits(this.f10478b) == Float.floatToIntBits(c3626q.f10478b);
    }

    public int hashCode() {
        return C3233b.m16038a(this.f10477a, Float.valueOf(this.f10478b));
    }

    public String toString() {
        return C3233b.m16039a((Object) this).m16037a("panoId", this.f10477a).m16037a("bearing", Float.valueOf(this.f10478b)).toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        ak.m17794a(this, parcel, i);
    }
}
