package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.C3233b;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.common.internal.safeparcel.C2149a;

/* renamed from: com.google.android.gms.maps.model.k */
public class C3620k extends C2149a {
    public static final Creator<C3620k> CREATOR;
    private static final String f10448a;
    private final int f10449b;
    private final Float f10450c;

    static {
        f10448a = C3620k.class.getSimpleName();
        CREATOR = new af();
    }

    public C3620k(int i, Float f) {
        boolean z = true;
        if (i != 1 && (f == null || f.floatValue() < 0.0f)) {
            z = false;
        }
        String valueOf = String.valueOf(f);
        C3234c.m16052b(z, new StringBuilder(String.valueOf(valueOf).length() + 45).append("Invalid PatternItem: type=").append(i).append(" length=").append(valueOf).toString());
        this.f10449b = i;
        this.f10450c = f;
    }

    public int m17868a() {
        return this.f10449b;
    }

    public Float m17869b() {
        return this.f10450c;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C3620k)) {
            return false;
        }
        C3620k c3620k = (C3620k) obj;
        return this.f10449b == c3620k.f10449b && C3233b.m16040a(this.f10450c, c3620k.f10450c);
    }

    public int hashCode() {
        return C3233b.m16038a(Integer.valueOf(this.f10449b), this.f10450c);
    }

    public String toString() {
        int i = this.f10449b;
        String valueOf = String.valueOf(this.f10450c);
        return new StringBuilder(String.valueOf(valueOf).length() + 39).append("[PatternItem: type=").append(i).append(" length=").append(valueOf).append("]").toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        af.m17779a(this, parcel, i);
    }
}
