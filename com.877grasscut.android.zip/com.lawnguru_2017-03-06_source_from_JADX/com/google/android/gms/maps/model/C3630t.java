package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C2149a;

/* renamed from: com.google.android.gms.maps.model.t */
public final class C3630t extends C2149a {
    public static final Creator<C3630t> CREATOR;
    public final int f10486a;
    public final int f10487b;
    public final byte[] f10488c;

    static {
        CREATOR = new an();
    }

    public C3630t(int i, int i2, byte[] bArr) {
        this.f10486a = i;
        this.f10487b = i2;
        this.f10488c = bArr;
    }

    public void writeToParcel(Parcel parcel, int i) {
        an.m17803a(this, parcel, i);
    }
}
