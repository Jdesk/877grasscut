package com.google.android.gms.maps.model;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.C3233b;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.common.internal.safeparcel.C2149a;
import com.google.android.gms.p097a.C2046a.C2048a;

/* renamed from: com.google.android.gms.maps.model.d */
public class C3612d extends C2149a {
    public static final Creator<C3612d> CREATOR;
    private static final String f10405a;
    private final int f10406b;
    private final C3610a f10407c;
    private final Float f10408d;

    static {
        f10405a = C3612d.class.getSimpleName();
        CREATOR = new C3636y();
    }

    protected C3612d(int i) {
        this(i, null, null);
    }

    C3612d(int i, IBinder iBinder, Float f) {
        this(i, C3612d.m17815a(iBinder), f);
    }

    private C3612d(int i, C3610a c3610a, Float f) {
        boolean z = false;
        boolean z2 = f != null && f.floatValue() > 0.0f;
        if (i != 3 || (c3610a != null && z2)) {
            z = true;
        }
        String valueOf = String.valueOf(c3610a);
        String valueOf2 = String.valueOf(f);
        C3234c.m16052b(z, new StringBuilder((String.valueOf(valueOf).length() + 63) + String.valueOf(valueOf2).length()).append("Invalid Cap: type=").append(i).append(" bitmapDescriptor=").append(valueOf).append(" bitmapRefWidth=").append(valueOf2).toString());
        this.f10406b = i;
        this.f10407c = c3610a;
        this.f10408d = f;
    }

    private static C3610a m17815a(IBinder iBinder) {
        return iBinder == null ? null : new C3610a(C2048a.m7925a(iBinder));
    }

    public int m17816a() {
        return this.f10406b;
    }

    public Float m17817b() {
        return this.f10408d;
    }

    IBinder m17818c() {
        return this.f10407c == null ? null : this.f10407c.m17763a().asBinder();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C3612d)) {
            return false;
        }
        C3612d c3612d = (C3612d) obj;
        return this.f10406b == c3612d.f10406b && C3233b.m16040a(this.f10407c, c3612d.f10407c) && C3233b.m16040a(this.f10408d, c3612d.f10408d);
    }

    public int hashCode() {
        return C3233b.m16038a(Integer.valueOf(this.f10406b), this.f10407c, this.f10408d);
    }

    public String toString() {
        return "[Cap: type=" + this.f10406b + "]";
    }

    public void writeToParcel(Parcel parcel, int i) {
        C3636y.m17908a(this, parcel, i);
    }
}
