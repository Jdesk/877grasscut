package com.google.android.gms.maps.model;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.util.AttributeSet;
import com.google.android.gms.C2063a.C2045c;
import com.google.android.gms.common.internal.C3233b;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.C2149a;

public final class LatLngBounds extends C2149a implements ReflectedParcelable {
    public static final Creator<LatLngBounds> CREATOR;
    public final LatLng f10388a;
    public final LatLng f10389b;

    /* renamed from: com.google.android.gms.maps.model.LatLngBounds.a */
    public static final class C3582a {
        private double f10384a;
        private double f10385b;
        private double f10386c;
        private double f10387d;

        public C3582a() {
            this.f10384a = Double.POSITIVE_INFINITY;
            this.f10385b = Double.NEGATIVE_INFINITY;
            this.f10386c = Double.NaN;
            this.f10387d = Double.NaN;
        }

        private boolean m17422a(double d) {
            boolean z = false;
            if (this.f10386c <= this.f10387d) {
                return this.f10386c <= d && d <= this.f10387d;
            } else {
                if (this.f10386c <= d || d <= this.f10387d) {
                    z = true;
                }
                return z;
            }
        }

        public C3582a m17423a(LatLng latLng) {
            this.f10384a = Math.min(this.f10384a, latLng.f10382a);
            this.f10385b = Math.max(this.f10385b, latLng.f10382a);
            double d = latLng.f10383b;
            if (Double.isNaN(this.f10386c)) {
                this.f10386c = d;
                this.f10387d = d;
            } else if (!m17422a(d)) {
                if (LatLngBounds.m17428c(this.f10386c, d) < LatLngBounds.m17429d(this.f10387d, d)) {
                    this.f10386c = d;
                } else {
                    this.f10387d = d;
                }
            }
            return this;
        }

        public LatLngBounds m17424a() {
            C3234c.m16048a(!Double.isNaN(this.f10386c), (Object) "no included points");
            return new LatLngBounds(new LatLng(this.f10384a, this.f10386c), new LatLng(this.f10385b, this.f10387d));
        }
    }

    static {
        CREATOR = new ab();
    }

    public LatLngBounds(LatLng latLng, LatLng latLng2) {
        C3234c.m16043a((Object) latLng, (Object) "null southwest");
        C3234c.m16043a((Object) latLng2, (Object) "null northeast");
        C3234c.m16053b(latLng2.f10382a >= latLng.f10382a, "southern latitude exceeds northern latitude (%s > %s)", Double.valueOf(latLng.f10382a), Double.valueOf(latLng2.f10382a));
        this.f10388a = latLng;
        this.f10389b = latLng2;
    }

    public static LatLngBounds m17426a(Context context, AttributeSet attributeSet) {
        if (context == null || attributeSet == null) {
            return null;
        }
        TypedArray obtainAttributes = context.getResources().obtainAttributes(attributeSet, C2045c.MapAttrs);
        Float valueOf = obtainAttributes.hasValue(C2045c.MapAttrs_latLngBoundsSouthWestLatitude) ? Float.valueOf(obtainAttributes.getFloat(C2045c.MapAttrs_latLngBoundsSouthWestLatitude, 0.0f)) : null;
        Float valueOf2 = obtainAttributes.hasValue(C2045c.MapAttrs_latLngBoundsSouthWestLongitude) ? Float.valueOf(obtainAttributes.getFloat(C2045c.MapAttrs_latLngBoundsSouthWestLongitude, 0.0f)) : null;
        Float valueOf3 = obtainAttributes.hasValue(C2045c.MapAttrs_latLngBoundsNorthEastLatitude) ? Float.valueOf(obtainAttributes.getFloat(C2045c.MapAttrs_latLngBoundsNorthEastLatitude, 0.0f)) : null;
        Float valueOf4 = obtainAttributes.hasValue(C2045c.MapAttrs_latLngBoundsNorthEastLongitude) ? Float.valueOf(obtainAttributes.getFloat(C2045c.MapAttrs_latLngBoundsNorthEastLongitude, 0.0f)) : null;
        return (valueOf == null || valueOf2 == null || valueOf3 == null || valueOf4 == null) ? null : new LatLngBounds(new LatLng((double) valueOf.floatValue(), (double) valueOf2.floatValue()), new LatLng((double) valueOf3.floatValue(), (double) valueOf4.floatValue()));
    }

    private static double m17428c(double d, double d2) {
        return ((d - d2) + 360.0d) % 360.0d;
    }

    private static double m17429d(double d, double d2) {
        return ((d2 - d) + 360.0d) % 360.0d;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof LatLngBounds)) {
            return false;
        }
        LatLngBounds latLngBounds = (LatLngBounds) obj;
        return this.f10388a.equals(latLngBounds.f10388a) && this.f10389b.equals(latLngBounds.f10389b);
    }

    public int hashCode() {
        return C3233b.m16038a(this.f10388a, this.f10389b);
    }

    public String toString() {
        return C3233b.m16039a((Object) this).m16037a("southwest", this.f10388a).m16037a("northeast", this.f10389b).toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        ab.m17767a(this, parcel, i);
    }
}
