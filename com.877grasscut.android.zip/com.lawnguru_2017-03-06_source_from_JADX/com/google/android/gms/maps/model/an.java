package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

public class an implements Creator<C3630t> {
    static void m17803a(C3630t c3630t, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16168a(parcel, 2, c3630t.f10486a);
        C3264c.m16168a(parcel, 3, c3630t.f10487b);
        C3264c.m16181a(parcel, 4, c3630t.f10488c, false);
        C3264c.m16164a(parcel, a);
    }

    public C3630t m17804a(Parcel parcel) {
        int i = 0;
        int b = C3263b.m16139b(parcel);
        byte[] bArr = null;
        int i2 = 0;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    i2 = C3263b.m16146f(parcel, a);
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    i = C3263b.m16146f(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    bArr = C3263b.m16157q(parcel, a);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new C3630t(i2, i, bArr);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public C3630t[] m17805a(int i) {
        return new C3630t[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m17804a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m17805a(i);
    }
}
