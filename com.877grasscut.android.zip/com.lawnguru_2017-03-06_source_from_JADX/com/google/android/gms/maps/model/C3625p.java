package com.google.android.gms.maps.model;

import android.os.RemoteException;

/* renamed from: com.google.android.gms.maps.model.p */
public final class C3625p extends RuntimeException {
    public C3625p(RemoteException remoteException) {
        super(remoteException);
    }
}
