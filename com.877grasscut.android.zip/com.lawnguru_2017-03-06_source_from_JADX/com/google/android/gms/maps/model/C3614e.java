package com.google.android.gms.maps.model;

import android.os.RemoteException;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.maps.model.p104a.C3589c;

/* renamed from: com.google.android.gms.maps.model.e */
public final class C3614e {
    private final C3589c f10409a;

    public C3614e(C3589c c3589c) {
        this.f10409a = (C3589c) C3234c.m16042a((Object) c3589c);
    }

    public void m17819a() {
        try {
            this.f10409a.m17502a();
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof C3614e)) {
            return false;
        }
        try {
            return this.f10409a.m17510a(((C3614e) obj).f10409a);
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }

    public int hashCode() {
        try {
            return this.f10409a.m17522j();
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }
}
