package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C2149a;

/* renamed from: com.google.android.gms.maps.model.l */
public final class C3621l extends C2149a {
    public static final Creator<C3621l> CREATOR;
    public final LatLng f10451a;
    public final String f10452b;
    public final String f10453c;

    static {
        CREATOR = new ag();
    }

    public C3621l(LatLng latLng, String str, String str2) {
        this.f10451a = latLng;
        this.f10452b = str;
        this.f10453c = str2;
    }

    public void writeToParcel(Parcel parcel, int i) {
        ag.m17782a(this, parcel, i);
    }
}
