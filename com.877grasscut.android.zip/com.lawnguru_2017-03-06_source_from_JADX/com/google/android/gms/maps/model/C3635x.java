package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.maps.model.x */
public class C3635x implements Creator<CameraPosition> {
    static void m17905a(CameraPosition cameraPosition, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16172a(parcel, 2, cameraPosition.f10378a, i, false);
        C3264c.m16167a(parcel, 3, cameraPosition.f10379b);
        C3264c.m16167a(parcel, 4, cameraPosition.f10380c);
        C3264c.m16167a(parcel, 5, cameraPosition.f10381d);
        C3264c.m16164a(parcel, a);
    }

    public CameraPosition m17906a(Parcel parcel) {
        float f = 0.0f;
        int b = C3263b.m16139b(parcel);
        LatLng latLng = null;
        float f2 = 0.0f;
        float f3 = 0.0f;
        while (parcel.dataPosition() < b) {
            LatLng latLng2;
            float f4;
            int a = C3263b.m16133a(parcel);
            float f5;
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    f5 = f;
                    f = f2;
                    f2 = f3;
                    latLng2 = (LatLng) C3263b.m16135a(parcel, a, LatLng.CREATOR);
                    f4 = f5;
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    latLng2 = latLng;
                    f5 = f2;
                    f2 = C3263b.m16150j(parcel, a);
                    f4 = f;
                    f = f5;
                    break;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    f2 = f3;
                    latLng2 = latLng;
                    f5 = f;
                    f = C3263b.m16150j(parcel, a);
                    f4 = f5;
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTick /*5*/:
                    f4 = C3263b.m16150j(parcel, a);
                    f = f2;
                    f2 = f3;
                    latLng2 = latLng;
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    f4 = f;
                    f = f2;
                    f2 = f3;
                    latLng2 = latLng;
                    break;
            }
            latLng = latLng2;
            f3 = f2;
            f2 = f;
            f = f4;
        }
        if (parcel.dataPosition() == b) {
            return new CameraPosition(latLng, f3, f2, f);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public CameraPosition[] m17907a(int i) {
        return new CameraPosition[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m17906a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m17907a(i);
    }
}
