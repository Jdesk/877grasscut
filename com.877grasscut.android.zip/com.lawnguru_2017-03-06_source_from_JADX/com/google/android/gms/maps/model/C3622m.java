package com.google.android.gms.maps.model;

import android.os.RemoteException;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.maps.model.p104a.C3601g;

/* renamed from: com.google.android.gms.maps.model.m */
public final class C3622m {
    private final C3601g f10454a;

    public C3622m(C3601g c3601g) {
        this.f10454a = (C3601g) C3234c.m16042a((Object) c3601g);
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof C3622m)) {
            return false;
        }
        try {
            return this.f10454a.m17682a(((C3622m) obj).f10454a);
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }

    public int hashCode() {
        try {
            return this.f10454a.m17699k();
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }
}
