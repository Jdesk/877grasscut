package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import io.techery.properratingbar.C5501a.C5500d;
import java.util.List;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.maps.model.z */
public class C3637z implements Creator<C3615f> {
    static void m17911a(C3615f c3615f, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16172a(parcel, 2, c3615f.m17820a(), i, false);
        C3264c.m16166a(parcel, 3, c3615f.m17825b());
        C3264c.m16167a(parcel, 4, c3615f.m17827c());
        C3264c.m16168a(parcel, 5, c3615f.m17828d());
        C3264c.m16168a(parcel, 6, c3615f.m17830f());
        C3264c.m16167a(parcel, 7, c3615f.m17831g());
        C3264c.m16180a(parcel, 8, c3615f.m17832h());
        C3264c.m16180a(parcel, 9, c3615f.m17833i());
        C3264c.m16191c(parcel, 10, c3615f.m17829e(), false);
        C3264c.m16164a(parcel, a);
    }

    public C3615f m17912a(Parcel parcel) {
        List list = null;
        float f = 0.0f;
        boolean z = false;
        int b = C3263b.m16139b(parcel);
        double d = 0.0d;
        boolean z2 = false;
        int i = 0;
        int i2 = 0;
        float f2 = 0.0f;
        LatLng latLng = null;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    latLng = (LatLng) C3263b.m16135a(parcel, a, LatLng.CREATOR);
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    d = C3263b.m16152l(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    f2 = C3263b.m16150j(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTick /*5*/:
                    i2 = C3263b.m16146f(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickNormalColor /*6*/:
                    i = C3263b.m16146f(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickSelectedColor /*7*/:
                    f = C3263b.m16150j(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickNormalDrawable /*8*/:
                    z2 = C3263b.m16143c(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickSelectedDrawable /*9*/:
                    z = C3263b.m16143c(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickSpacing /*10*/:
                    list = C3263b.m16142c(parcel, a, C3620k.CREATOR);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new C3615f(latLng, d, f2, i2, i, f, z2, z, list);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public C3615f[] m17913a(int i) {
        return new C3615f[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m17912a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m17913a(i);
    }
}
