package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import net.cachapa.expandablelayout.C5541a.C5538a;

public class ac implements Creator<LatLng> {
    static void m17770a(LatLng latLng, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16166a(parcel, 2, latLng.f10382a);
        C3264c.m16166a(parcel, 3, latLng.f10383b);
        C3264c.m16164a(parcel, a);
    }

    public LatLng m17771a(Parcel parcel) {
        double d = 0.0d;
        int b = C3263b.m16139b(parcel);
        double d2 = 0.0d;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    d2 = C3263b.m16152l(parcel, a);
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    d = C3263b.m16152l(parcel, a);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new LatLng(d2, d);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public LatLng[] m17772a(int i) {
        return new LatLng[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m17771a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m17772a(i);
    }
}
