package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C2149a;
import com.yalantis.ucrop.view.CropImageView;
import java.util.ArrayList;
import java.util.List;

/* renamed from: com.google.android.gms.maps.model.n */
public final class C3623n extends C2149a {
    public static final Creator<C3623n> CREATOR;
    private final List<LatLng> f10455a;
    private final List<List<LatLng>> f10456b;
    private float f10457c;
    private int f10458d;
    private int f10459e;
    private float f10460f;
    private boolean f10461g;
    private boolean f10462h;
    private boolean f10463i;
    private int f10464j;
    private List<C3620k> f10465k;

    static {
        CREATOR = new ah();
    }

    public C3623n() {
        this.f10457c = CropImageView.DEFAULT_MAX_SCALE_MULTIPLIER;
        this.f10458d = -16777216;
        this.f10459e = 0;
        this.f10460f = 0.0f;
        this.f10461g = true;
        this.f10462h = false;
        this.f10463i = false;
        this.f10464j = 0;
        this.f10465k = null;
        this.f10455a = new ArrayList();
        this.f10456b = new ArrayList();
    }

    C3623n(List<LatLng> list, List list2, float f, int i, int i2, float f2, boolean z, boolean z2, boolean z3, int i3, List<C3620k> list3) {
        this.f10457c = CropImageView.DEFAULT_MAX_SCALE_MULTIPLIER;
        this.f10458d = -16777216;
        this.f10459e = 0;
        this.f10460f = 0.0f;
        this.f10461g = true;
        this.f10462h = false;
        this.f10463i = false;
        this.f10464j = 0;
        this.f10465k = null;
        this.f10455a = list;
        this.f10456b = list2;
        this.f10457c = f;
        this.f10458d = i;
        this.f10459e = i2;
        this.f10460f = f2;
        this.f10461g = z;
        this.f10462h = z2;
        this.f10463i = z3;
        this.f10464j = i3;
        this.f10465k = list3;
    }

    public C3623n m17870a(float f) {
        this.f10457c = f;
        return this;
    }

    public C3623n m17871a(int i) {
        this.f10458d = i;
        return this;
    }

    public C3623n m17872a(Iterable<LatLng> iterable) {
        for (LatLng add : iterable) {
            this.f10455a.add(add);
        }
        return this;
    }

    List m17873a() {
        return this.f10456b;
    }

    public C3623n m17874b(int i) {
        this.f10459e = i;
        return this;
    }

    public List<LatLng> m17875b() {
        return this.f10455a;
    }

    public float m17876c() {
        return this.f10457c;
    }

    public int m17877d() {
        return this.f10458d;
    }

    public int m17878e() {
        return this.f10464j;
    }

    public List<C3620k> m17879f() {
        return this.f10465k;
    }

    public int m17880g() {
        return this.f10459e;
    }

    public float m17881h() {
        return this.f10460f;
    }

    public boolean m17882i() {
        return this.f10461g;
    }

    public boolean m17883j() {
        return this.f10462h;
    }

    public boolean m17884k() {
        return this.f10463i;
    }

    public void writeToParcel(Parcel parcel, int i) {
        ah.m17785a(this, parcel, i);
    }
}
