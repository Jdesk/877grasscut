package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

public class ap implements Creator<C3634w> {
    static void m17809a(C3634w c3634w, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16172a(parcel, 2, c3634w.f10498a, i, false);
        C3264c.m16172a(parcel, 3, c3634w.f10499b, i, false);
        C3264c.m16172a(parcel, 4, c3634w.f10500c, i, false);
        C3264c.m16172a(parcel, 5, c3634w.f10501d, i, false);
        C3264c.m16172a(parcel, 6, c3634w.f10502e, i, false);
        C3264c.m16164a(parcel, a);
    }

    public C3634w m17810a(Parcel parcel) {
        LatLngBounds latLngBounds = null;
        int b = C3263b.m16139b(parcel);
        LatLng latLng = null;
        LatLng latLng2 = null;
        LatLng latLng3 = null;
        LatLng latLng4 = null;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    latLng4 = (LatLng) C3263b.m16135a(parcel, a, LatLng.CREATOR);
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    latLng3 = (LatLng) C3263b.m16135a(parcel, a, LatLng.CREATOR);
                    break;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    latLng2 = (LatLng) C3263b.m16135a(parcel, a, LatLng.CREATOR);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTick /*5*/:
                    latLng = (LatLng) C3263b.m16135a(parcel, a, LatLng.CREATOR);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickNormalColor /*6*/:
                    latLngBounds = (LatLngBounds) C3263b.m16135a(parcel, a, LatLngBounds.CREATOR);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new C3634w(latLng4, latLng3, latLng2, latLng, latLngBounds);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public C3634w[] m17811a(int i) {
        return new C3634w[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m17810a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m17811a(i);
    }
}
