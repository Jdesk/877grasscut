package com.google.android.gms.maps.model;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C2149a;
import com.google.android.gms.maps.model.p104a.C3607i;
import com.google.android.gms.maps.model.p104a.C3607i.C3609a;

/* renamed from: com.google.android.gms.maps.model.u */
public final class C3633u extends C2149a {
    public static final Creator<C3633u> CREATOR;
    private C3607i f10492a;
    private C3631v f10493b;
    private boolean f10494c;
    private float f10495d;
    private boolean f10496e;
    private float f10497f;

    /* renamed from: com.google.android.gms.maps.model.u.1 */
    class C36321 implements C3631v {
        final /* synthetic */ C3633u f10490a;
        private final C3607i f10491c;

        C36321(C3633u c3633u) {
            this.f10490a = c3633u;
            this.f10491c = this.f10490a.f10492a;
        }
    }

    static {
        CREATOR = new ao();
    }

    public C3633u() {
        this.f10494c = true;
        this.f10496e = true;
        this.f10497f = 0.0f;
    }

    C3633u(IBinder iBinder, boolean z, float f, boolean z2, float f2) {
        this.f10494c = true;
        this.f10496e = true;
        this.f10497f = 0.0f;
        this.f10492a = C3609a.m17762a(iBinder);
        this.f10493b = this.f10492a == null ? null : new C36321(this);
        this.f10494c = z;
        this.f10495d = f;
        this.f10496e = z2;
        this.f10497f = f2;
    }

    IBinder m17900a() {
        return this.f10492a.asBinder();
    }

    public float m17901b() {
        return this.f10495d;
    }

    public boolean m17902c() {
        return this.f10494c;
    }

    public boolean m17903d() {
        return this.f10496e;
    }

    public float m17904e() {
        return this.f10497f;
    }

    public void writeToParcel(Parcel parcel, int i) {
        ao.m17806a(this, parcel, i);
    }
}
