package com.google.android.gms.maps.model;

/* renamed from: com.google.android.gms.maps.model.v */
public interface C3631v {
    public static final C3630t f10489b;

    static {
        f10489b = new C3630t(-1, -1, null);
    }
}
