package com.google.android.gms.maps.model;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import com.zopim.android.sdk.api.C5264R;
import io.card.payment.CreditCard;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

public class ae implements Creator<C3619j> {
    static void m17776a(C3619j c3619j, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16172a(parcel, 2, c3619j.m17855b(), i, false);
        C3264c.m16177a(parcel, 3, c3619j.m17856c(), false);
        C3264c.m16177a(parcel, 4, c3619j.m17857d(), false);
        C3264c.m16171a(parcel, 5, c3619j.m17849a(), false);
        C3264c.m16167a(parcel, 6, c3619j.m17858e());
        C3264c.m16167a(parcel, 7, c3619j.m17859f());
        C3264c.m16180a(parcel, 8, c3619j.m17860g());
        C3264c.m16180a(parcel, 9, c3619j.m17861h());
        C3264c.m16180a(parcel, 10, c3619j.m17862i());
        C3264c.m16167a(parcel, 11, c3619j.m17863j());
        C3264c.m16167a(parcel, 12, c3619j.m17864k());
        C3264c.m16167a(parcel, 13, c3619j.m17865l());
        C3264c.m16167a(parcel, 14, c3619j.m17866m());
        C3264c.m16167a(parcel, 15, c3619j.m17867n());
        C3264c.m16164a(parcel, a);
    }

    public C3619j m17777a(Parcel parcel) {
        int b = C3263b.m16139b(parcel);
        LatLng latLng = null;
        String str = null;
        String str2 = null;
        IBinder iBinder = null;
        float f = 0.0f;
        float f2 = 0.0f;
        boolean z = false;
        boolean z2 = false;
        boolean z3 = false;
        float f3 = 0.0f;
        float f4 = 0.5f;
        float f5 = 0.0f;
        float f6 = 1.0f;
        float f7 = 0.0f;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    latLng = (LatLng) C3263b.m16135a(parcel, a, LatLng.CREATOR);
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    str = C3263b.m16154n(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    str2 = C3263b.m16154n(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTick /*5*/:
                    iBinder = C3263b.m16155o(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickNormalColor /*6*/:
                    f = C3263b.m16150j(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickSelectedColor /*7*/:
                    f2 = C3263b.m16150j(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickNormalDrawable /*8*/:
                    z = C3263b.m16143c(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickSelectedDrawable /*9*/:
                    z2 = C3263b.m16143c(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickSpacing /*10*/:
                    z3 = C3263b.m16143c(parcel, a);
                    break;
                case C5264R.styleable.Toolbar_popupTheme /*11*/:
                    f3 = C3263b.m16150j(parcel, a);
                    break;
                case C5264R.styleable.Toolbar_titleTextAppearance /*12*/:
                    f4 = C3263b.m16150j(parcel, a);
                    break;
                case C5264R.styleable.Toolbar_subtitleTextAppearance /*13*/:
                    f5 = C3263b.m16150j(parcel, a);
                    break;
                case C5264R.styleable.SearchView_suggestionRowLayout /*14*/:
                    f6 = C3263b.m16150j(parcel, a);
                    break;
                case CreditCard.EXPIRY_MAX_FUTURE_YEARS /*15*/:
                    f7 = C3263b.m16150j(parcel, a);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new C3619j(latLng, str, str2, iBinder, f, f2, z, z2, z3, f3, f4, f5, f6, f7);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public C3619j[] m17778a(int i) {
        return new C3619j[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m17777a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m17778a(i);
    }
}
