package com.google.android.gms.maps;

import android.os.RemoteException;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.maps.model.C3625p;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.p103a.C3457a;

/* renamed from: com.google.android.gms.maps.b */
public final class C3566b {
    private static C3457a f10365a;

    private static C3457a m17372a() {
        return (C3457a) C3234c.m16043a(f10365a, (Object) "CameraUpdateFactory is not initialized");
    }

    public static C3565a m17373a(CameraPosition cameraPosition) {
        try {
            return new C3565a(C3566b.m17372a().m16874a(cameraPosition));
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }

    public static C3565a m17374a(LatLng latLng) {
        try {
            return new C3565a(C3566b.m17372a().m16875a(latLng));
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }

    public static C3565a m17375a(LatLng latLng, float f) {
        try {
            return new C3565a(C3566b.m17372a().m16876a(latLng, f));
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }

    public static C3565a m17376a(LatLngBounds latLngBounds, int i) {
        try {
            return new C3565a(C3566b.m17372a().m16877a(latLngBounds, i));
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }

    public static void m17377a(C3457a c3457a) {
        f10365a = (C3457a) C3234c.m16042a((Object) c3457a);
    }
}
