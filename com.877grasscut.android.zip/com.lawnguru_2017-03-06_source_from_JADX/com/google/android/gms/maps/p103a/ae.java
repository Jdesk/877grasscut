package com.google.android.gms.maps.p103a;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.maps.model.p104a.C3592d;
import com.google.android.gms.maps.model.p104a.C3592d.C3594a;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.maps.a.ae */
public interface ae extends IInterface {

    /* renamed from: com.google.android.gms.maps.a.ae.a */
    public static abstract class C3469a extends Binder implements ae {

        /* renamed from: com.google.android.gms.maps.a.ae.a.a */
        private static class C3468a implements ae {
            private IBinder f10325a;

            C3468a(IBinder iBinder) {
                this.f10325a = iBinder;
            }

            public void m16906a(C3592d c3592d) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.maps.internal.IOnGroundOverlayClickListener");
                    obtain.writeStrongBinder(c3592d != null ? c3592d.asBinder() : null);
                    this.f10325a.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public IBinder asBinder() {
                return this.f10325a;
            }
        }

        public static ae m16907a(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.maps.internal.IOnGroundOverlayClickListener");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof ae)) ? new C3468a(iBinder) : (ae) queryLocalInterface;
        }

        public IBinder asBinder() {
            return this;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
            switch (i) {
                case C5538a.ExpandableLayout_el_duration /*1*/:
                    parcel.enforceInterface("com.google.android.gms.maps.internal.IOnGroundOverlayClickListener");
                    m16905a(C3594a.m17601a(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 1598968902:
                    parcel2.writeString("com.google.android.gms.maps.internal.IOnGroundOverlayClickListener");
                    return true;
                default:
                    return super.onTransact(i, parcel, parcel2, i2);
            }
        }
    }

    void m16905a(C3592d c3592d);
}
