package com.google.android.gms.maps.p103a;

import android.content.Context;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.C3206d;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.maps.model.C3625p;
import com.google.android.gms.maps.p103a.C3553w.C3555a;
import com.google.android.gms.p097a.C2060d;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.maps.a.u */
public class C3549u {
    private static Context f10357a;
    private static C3553w f10358b;

    public static C3553w m17332a(Context context) {
        C3234c.m16042a((Object) context);
        if (f10358b != null) {
            return f10358b;
        }
        C3549u.m17335b(context);
        f10358b = C3549u.m17336c(context);
        try {
            f10358b.m17347a(C2060d.m7973a(C3549u.m17337d(context).getResources()), GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE);
            return f10358b;
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }

    private static <T> T m17333a(Class<?> cls) {
        String str;
        String valueOf;
        try {
            return cls.newInstance();
        } catch (InstantiationException e) {
            str = "Unable to instantiate the dynamic class ";
            valueOf = String.valueOf(cls.getName());
            throw new IllegalStateException(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
        } catch (IllegalAccessException e2) {
            str = "Unable to call the default constructor of ";
            valueOf = String.valueOf(cls.getName());
            throw new IllegalStateException(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
        }
    }

    private static <T> T m17334a(ClassLoader classLoader, String str) {
        try {
            return C3549u.m17333a(((ClassLoader) C3234c.m16042a((Object) classLoader)).loadClass(str));
        } catch (ClassNotFoundException e) {
            String str2 = "Unable to find dynamic class ";
            String valueOf = String.valueOf(str);
            throw new IllegalStateException(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
        }
    }

    private static void m17335b(Context context) {
        int isGooglePlayServicesAvailable = GooglePlayServicesUtil.isGooglePlayServicesAvailable(context);
        switch (isGooglePlayServicesAvailable) {
            case C5538a.ExpandableLayout_android_orientation /*0*/:
            default:
                throw new C3206d(isGooglePlayServicesAvailable);
        }
    }

    private static C3553w m17336c(Context context) {
        Log.i(C3549u.class.getSimpleName(), "Making Creator dynamically");
        return C3555a.m17359a((IBinder) C3549u.m17334a(C3549u.m17337d(context).getClassLoader(), "com.google.android.gms.maps.internal.CreatorImpl"));
    }

    private static Context m17337d(Context context) {
        if (f10357a == null) {
            f10357a = GooglePlayServicesUtil.getRemoteContext(context);
        }
        return f10357a;
    }
}
