package com.google.android.gms.maps.p103a;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.maps.model.p104a.C3583a;
import com.google.android.gms.maps.model.p104a.C3583a.C3585a;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.maps.a.m */
public interface C3527m extends IInterface {

    /* renamed from: com.google.android.gms.maps.a.m.a */
    public static abstract class C3529a extends Binder implements C3527m {

        /* renamed from: com.google.android.gms.maps.a.m.a.a */
        private static class C3528a implements C3527m {
            private IBinder f10350a;

            C3528a(IBinder iBinder) {
                this.f10350a = iBinder;
            }

            public void m17307a(C3583a c3583a) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.maps.internal.IOnPolylineClickListener");
                    obtain.writeStrongBinder(c3583a != null ? c3583a.asBinder() : null);
                    this.f10350a.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public IBinder asBinder() {
                return this.f10350a;
            }
        }

        public static C3527m m17308a(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.maps.internal.IOnPolylineClickListener");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof C3527m)) ? new C3528a(iBinder) : (C3527m) queryLocalInterface;
        }

        public IBinder asBinder() {
            return this;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
            switch (i) {
                case C5538a.ExpandableLayout_el_duration /*1*/:
                    parcel.enforceInterface("com.google.android.gms.maps.internal.IOnPolylineClickListener");
                    m17306a(C3585a.m17486a(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 1598968902:
                    parcel2.writeString("com.google.android.gms.maps.internal.IOnPolylineClickListener");
                    return true;
                default:
                    return super.onTransact(i, parcel, parcel2, i2);
            }
        }
    }

    void m17306a(C3583a c3583a);
}
