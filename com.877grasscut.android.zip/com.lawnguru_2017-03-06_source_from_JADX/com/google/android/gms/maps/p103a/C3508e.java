package com.google.android.gms.maps.p103a;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.maps.p103a.C3499b.C3501a;
import com.google.android.gms.maps.p103a.an.C3449a;
import com.google.android.gms.p097a.C2046a;
import com.google.android.gms.p097a.C2046a.C2048a;
import com.zopim.android.sdk.api.C5264R;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.maps.a.e */
public interface C3508e extends IInterface {

    /* renamed from: com.google.android.gms.maps.a.e.a */
    public static abstract class C3510a extends Binder implements C3508e {

        /* renamed from: com.google.android.gms.maps.a.e.a.a */
        private static class C3509a implements C3508e {
            private IBinder f10344a;

            C3509a(IBinder iBinder) {
                this.f10344a = iBinder;
            }

            public C3499b m17159a() {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.maps.internal.IMapViewDelegate");
                    this.f10344a.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                    C3499b a = C3501a.m17107a(obtain2.readStrongBinder());
                    return a;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m17160a(Bundle bundle) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.maps.internal.IMapViewDelegate");
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.f10344a.transact(2, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m17161a(an anVar) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.maps.internal.IMapViewDelegate");
                    obtain.writeStrongBinder(anVar != null ? anVar.asBinder() : null);
                    this.f10344a.transact(9, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public IBinder asBinder() {
                return this.f10344a;
            }

            public void m17162b() {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.maps.internal.IMapViewDelegate");
                    this.f10344a.transact(3, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m17163b(Bundle bundle) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.maps.internal.IMapViewDelegate");
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.f10344a.transact(7, obtain, obtain2, 0);
                    obtain2.readException();
                    if (obtain2.readInt() != 0) {
                        bundle.readFromParcel(obtain2);
                    }
                    obtain2.recycle();
                    obtain.recycle();
                } catch (Throwable th) {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m17164c() {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.maps.internal.IMapViewDelegate");
                    this.f10344a.transact(4, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m17165c(Bundle bundle) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.maps.internal.IMapViewDelegate");
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.f10344a.transact(10, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m17166d() {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.maps.internal.IMapViewDelegate");
                    this.f10344a.transact(5, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m17167e() {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.maps.internal.IMapViewDelegate");
                    this.f10344a.transact(6, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public C2046a m17168f() {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.maps.internal.IMapViewDelegate");
                    this.f10344a.transact(8, obtain, obtain2, 0);
                    obtain2.readException();
                    C2046a a = C2048a.m7925a(obtain2.readStrongBinder());
                    return a;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m17169g() {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.maps.internal.IMapViewDelegate");
                    this.f10344a.transact(11, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m17170h() {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.maps.internal.IMapViewDelegate");
                    this.f10344a.transact(12, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m17171i() {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.maps.internal.IMapViewDelegate");
                    this.f10344a.transact(13, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }

        public static C3508e m17172a(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.maps.internal.IMapViewDelegate");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof C3508e)) ? new C3509a(iBinder) : (C3508e) queryLocalInterface;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
            Bundle bundle = null;
            IBinder asBinder;
            switch (i) {
                case C5538a.ExpandableLayout_el_duration /*1*/:
                    parcel.enforceInterface("com.google.android.gms.maps.internal.IMapViewDelegate");
                    C3499b a = m17146a();
                    parcel2.writeNoException();
                    if (a != null) {
                        asBinder = a.asBinder();
                    }
                    parcel2.writeStrongBinder(asBinder);
                    return true;
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    parcel.enforceInterface("com.google.android.gms.maps.internal.IMapViewDelegate");
                    if (parcel.readInt() != 0) {
                        bundle = (Bundle) Bundle.CREATOR.createFromParcel(parcel);
                    }
                    m17147a(bundle);
                    parcel2.writeNoException();
                    return true;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    parcel.enforceInterface("com.google.android.gms.maps.internal.IMapViewDelegate");
                    m17149b();
                    parcel2.writeNoException();
                    return true;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    parcel.enforceInterface("com.google.android.gms.maps.internal.IMapViewDelegate");
                    m17151c();
                    parcel2.writeNoException();
                    return true;
                case C5500d.ProperRatingBar_prb_symbolicTick /*5*/:
                    parcel.enforceInterface("com.google.android.gms.maps.internal.IMapViewDelegate");
                    m17153d();
                    parcel2.writeNoException();
                    return true;
                case C5500d.ProperRatingBar_prb_symbolicTickNormalColor /*6*/:
                    parcel.enforceInterface("com.google.android.gms.maps.internal.IMapViewDelegate");
                    m17154e();
                    parcel2.writeNoException();
                    return true;
                case C5500d.ProperRatingBar_prb_symbolicTickSelectedColor /*7*/:
                    parcel.enforceInterface("com.google.android.gms.maps.internal.IMapViewDelegate");
                    if (parcel.readInt() != 0) {
                        bundle = (Bundle) Bundle.CREATOR.createFromParcel(parcel);
                    }
                    m17150b(bundle);
                    parcel2.writeNoException();
                    if (bundle != null) {
                        parcel2.writeInt(1);
                        bundle.writeToParcel(parcel2, 1);
                    } else {
                        parcel2.writeInt(0);
                    }
                    return true;
                case C5500d.ProperRatingBar_prb_tickNormalDrawable /*8*/:
                    parcel.enforceInterface("com.google.android.gms.maps.internal.IMapViewDelegate");
                    C2046a f = m17155f();
                    parcel2.writeNoException();
                    if (f != null) {
                        asBinder = f.asBinder();
                    }
                    parcel2.writeStrongBinder(asBinder);
                    return true;
                case C5500d.ProperRatingBar_prb_tickSelectedDrawable /*9*/:
                    parcel.enforceInterface("com.google.android.gms.maps.internal.IMapViewDelegate");
                    m17148a(C3449a.m16822a(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case C5500d.ProperRatingBar_prb_tickSpacing /*10*/:
                    parcel.enforceInterface("com.google.android.gms.maps.internal.IMapViewDelegate");
                    if (parcel.readInt() != 0) {
                        bundle = (Bundle) Bundle.CREATOR.createFromParcel(parcel);
                    }
                    m17152c(bundle);
                    parcel2.writeNoException();
                    return true;
                case C5264R.styleable.Toolbar_popupTheme /*11*/:
                    parcel.enforceInterface("com.google.android.gms.maps.internal.IMapViewDelegate");
                    m17156g();
                    parcel2.writeNoException();
                    return true;
                case C5264R.styleable.Toolbar_titleTextAppearance /*12*/:
                    parcel.enforceInterface("com.google.android.gms.maps.internal.IMapViewDelegate");
                    m17157h();
                    parcel2.writeNoException();
                    return true;
                case C5264R.styleable.Toolbar_subtitleTextAppearance /*13*/:
                    parcel.enforceInterface("com.google.android.gms.maps.internal.IMapViewDelegate");
                    m17158i();
                    parcel2.writeNoException();
                    return true;
                case 1598968902:
                    parcel2.writeString("com.google.android.gms.maps.internal.IMapViewDelegate");
                    return true;
                default:
                    return super.onTransact(i, parcel, parcel2, i2);
            }
        }
    }

    C3499b m17146a();

    void m17147a(Bundle bundle);

    void m17148a(an anVar);

    void m17149b();

    void m17150b(Bundle bundle);

    void m17151c();

    void m17152c(Bundle bundle);

    void m17153d();

    void m17154e();

    C2046a m17155f();

    void m17156g();

    void m17157h();

    void m17158i();
}
