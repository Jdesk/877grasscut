package com.google.android.gms.maps.p103a;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.maps.p103a.aj.C3479a;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.maps.a.c */
public interface C3502c extends IInterface {

    /* renamed from: com.google.android.gms.maps.a.c.a */
    public static abstract class C3504a extends Binder implements C3502c {

        /* renamed from: com.google.android.gms.maps.a.c.a.a */
        private static class C3503a implements C3502c {
            private IBinder f10342a;

            C3503a(IBinder iBinder) {
                this.f10342a = iBinder;
            }

            public void m17110a() {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.maps.internal.ILocationSourceDelegate");
                    this.f10342a.transact(2, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m17111a(aj ajVar) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.maps.internal.ILocationSourceDelegate");
                    obtain.writeStrongBinder(ajVar != null ? ajVar.asBinder() : null);
                    this.f10342a.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public IBinder asBinder() {
                return this.f10342a;
            }
        }

        public static C3502c m17112a(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.maps.internal.ILocationSourceDelegate");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof C3502c)) ? new C3503a(iBinder) : (C3502c) queryLocalInterface;
        }

        public IBinder asBinder() {
            return this;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
            switch (i) {
                case C5538a.ExpandableLayout_el_duration /*1*/:
                    parcel.enforceInterface("com.google.android.gms.maps.internal.ILocationSourceDelegate");
                    m17109a(C3479a.m16926a(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    parcel.enforceInterface("com.google.android.gms.maps.internal.ILocationSourceDelegate");
                    m17108a();
                    parcel2.writeNoException();
                    return true;
                case 1598968902:
                    parcel2.writeString("com.google.android.gms.maps.internal.ILocationSourceDelegate");
                    return true;
                default:
                    return super.onTransact(i, parcel, parcel2, i2);
            }
        }
    }

    void m17108a();

    void m17109a(aj ajVar);
}
