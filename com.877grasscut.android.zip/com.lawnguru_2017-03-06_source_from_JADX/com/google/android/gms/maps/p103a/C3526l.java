package com.google.android.gms.maps.p103a;

import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.maps.a.l */
public final class C3526l {
    public static byte m17304a(Boolean bool) {
        return bool != null ? bool.booleanValue() ? (byte) 1 : (byte) 0 : (byte) -1;
    }

    public static Boolean m17305a(byte b) {
        switch (b) {
            case C5538a.ExpandableLayout_android_orientation /*0*/:
                return Boolean.FALSE;
            case C5538a.ExpandableLayout_el_duration /*1*/:
                return Boolean.TRUE;
            default:
                return null;
        }
    }
}
