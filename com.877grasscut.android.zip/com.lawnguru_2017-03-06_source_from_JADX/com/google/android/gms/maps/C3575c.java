package com.google.android.gms.maps;

import android.graphics.Bitmap;
import android.os.RemoteException;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.maps.model.C3614e;
import com.google.android.gms.maps.model.C3615f;
import com.google.android.gms.maps.model.C3618i;
import com.google.android.gms.maps.model.C3619j;
import com.google.android.gms.maps.model.C3622m;
import com.google.android.gms.maps.model.C3623n;
import com.google.android.gms.maps.model.C3625p;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.p104a.C3598f;
import com.google.android.gms.maps.p103a.C3499b;
import com.google.android.gms.maps.p103a.C3545s.C3547a;
import com.google.android.gms.maps.p103a.ak.C3481a;
import com.google.android.gms.maps.p103a.al.C3483a;
import com.google.android.gms.maps.p103a.ao.C3488a;
import com.google.android.gms.p097a.C2046a;
import com.google.android.gms.p097a.C2060d;

/* renamed from: com.google.android.gms.maps.c */
public final class C3575c {
    private final C3499b f10370a;
    private C3578f f10371b;

    /* renamed from: com.google.android.gms.maps.c.1 */
    class C35671 extends C3483a {
        final /* synthetic */ C3572b f10366a;

        C35671(C3575c c3575c, C3572b c3572b) {
            this.f10366a = c3572b;
        }

        public void m17378a() {
            this.f10366a.m17384a();
        }
    }

    /* renamed from: com.google.android.gms.maps.c.2 */
    class C35682 extends C3547a {
        final /* synthetic */ C3574d f10367a;

        C35682(C3575c c3575c, C3574d c3574d) {
            this.f10367a = c3574d;
        }

        public void m17379a(Bitmap bitmap) {
            this.f10367a.m17386a(bitmap);
        }

        public void m17380a(C2046a c2046a) {
            this.f10367a.m17386a((Bitmap) C2060d.m7974a(c2046a));
        }
    }

    /* renamed from: com.google.android.gms.maps.c.3 */
    class C35693 extends C3488a {
        final /* synthetic */ C3573c f10368a;

        C35693(C3575c c3575c, C3573c c3573c) {
            this.f10368a = c3573c;
        }

        public boolean m17381a(C3598f c3598f) {
            return this.f10368a.m17385a(new C3618i(c3598f));
        }
    }

    /* renamed from: com.google.android.gms.maps.c.4 */
    class C35704 extends C3481a {
        final /* synthetic */ C3571a f10369a;

        C35704(C3575c c3575c, C3571a c3571a) {
            this.f10369a = c3571a;
        }

        public void m17382a(LatLng latLng) {
            this.f10369a.m17383a(latLng);
        }
    }

    /* renamed from: com.google.android.gms.maps.c.a */
    public interface C3571a {
        void m17383a(LatLng latLng);
    }

    /* renamed from: com.google.android.gms.maps.c.b */
    public interface C3572b {
        void m17384a();
    }

    /* renamed from: com.google.android.gms.maps.c.c */
    public interface C3573c {
        boolean m17385a(C3618i c3618i);
    }

    /* renamed from: com.google.android.gms.maps.c.d */
    public interface C3574d {
        void m17386a(Bitmap bitmap);
    }

    protected C3575c(C3499b c3499b) {
        this.f10370a = (C3499b) C3234c.m16042a((Object) c3499b);
    }

    public final CameraPosition m17387a() {
        try {
            return this.f10370a.m16959a();
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }

    public final C3614e m17388a(C3615f c3615f) {
        try {
            return new C3614e(this.f10370a.m16961a(c3615f));
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }

    public final C3618i m17389a(C3619j c3619j) {
        try {
            C3598f a = this.f10370a.m16963a(c3619j);
            return a != null ? new C3618i(a) : null;
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }

    public final C3622m m17390a(C3623n c3623n) {
        try {
            return new C3622m(this.f10370a.m16964a(c3623n));
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }

    public final void m17391a(int i) {
        try {
            this.f10370a.m16967a(i);
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }

    public final void m17392a(int i, int i2, int i3, int i4) {
        try {
            this.f10370a.m16968a(i, i2, i3, i4);
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }

    public final void m17393a(C3565a c3565a) {
        try {
            this.f10370a.m16970a(c3565a.m17371a());
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }

    public final void m17394a(C3571a c3571a) {
        if (c3571a == null) {
            try {
                this.f10370a.m16982a(null);
                return;
            } catch (RemoteException e) {
                throw new C3625p(e);
            }
        }
        this.f10370a.m16982a(new C35704(this, c3571a));
    }

    public void m17395a(C3572b c3572b) {
        if (c3572b == null) {
            try {
                this.f10370a.m16983a(null);
                return;
            } catch (RemoteException e) {
                throw new C3625p(e);
            }
        }
        this.f10370a.m16983a(new C35671(this, c3572b));
    }

    public final void m17396a(C3573c c3573c) {
        if (c3573c == null) {
            try {
                this.f10370a.m16986a(null);
                return;
            } catch (RemoteException e) {
                throw new C3625p(e);
            }
        }
        this.f10370a.m16986a(new C35693(this, c3573c));
    }

    public final void m17397a(C3574d c3574d) {
        m17398a(c3574d, null);
    }

    public final void m17398a(C3574d c3574d, Bitmap bitmap) {
        try {
            this.f10370a.m16995a(new C35682(this, c3574d), (C2060d) (bitmap != null ? C2060d.m7973a((Object) bitmap) : null));
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }

    public final void m17399a(boolean z) {
        try {
            this.f10370a.m17010c(z);
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }

    public final void m17400b() {
        try {
            this.f10370a.m17013e();
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }

    public final void m17401b(C3565a c3565a) {
        try {
            this.f10370a.m17006b(c3565a.m17371a());
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }

    public final C3578f m17402c() {
        try {
            if (this.f10371b == null) {
                this.f10371b = new C3578f(this.f10370a.m17020k());
            }
            return this.f10371b;
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }
}
