package com.google.android.gms.maps;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLngBounds;
import com.zopim.android.sdk.api.C5264R;
import io.card.payment.CreditCard;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.maps.g */
public class C3579g implements Creator<GoogleMapOptions> {
    static void m17409a(GoogleMapOptions googleMapOptions, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16165a(parcel, 2, googleMapOptions.m16789a());
        C3264c.m16165a(parcel, 3, googleMapOptions.m16795b());
        C3264c.m16168a(parcel, 4, googleMapOptions.m16816l());
        C3264c.m16172a(parcel, 5, googleMapOptions.m16817m(), i, false);
        C3264c.m16165a(parcel, 6, googleMapOptions.m16798c());
        C3264c.m16165a(parcel, 7, googleMapOptions.m16800d());
        C3264c.m16165a(parcel, 8, googleMapOptions.m16802e());
        C3264c.m16165a(parcel, 9, googleMapOptions.m16804f());
        C3264c.m16165a(parcel, 10, googleMapOptions.m16806g());
        C3264c.m16165a(parcel, 11, googleMapOptions.m16808h());
        C3264c.m16165a(parcel, 12, googleMapOptions.m16810i());
        C3264c.m16165a(parcel, 14, googleMapOptions.m16812j());
        C3264c.m16165a(parcel, 15, googleMapOptions.m16814k());
        C3264c.m16174a(parcel, 16, googleMapOptions.m16818n(), false);
        C3264c.m16174a(parcel, 17, googleMapOptions.m16819o(), false);
        C3264c.m16172a(parcel, 18, googleMapOptions.m16820p(), i, false);
        C3264c.m16164a(parcel, a);
    }

    public GoogleMapOptions m17410a(Parcel parcel) {
        int b = C3263b.m16139b(parcel);
        byte b2 = (byte) -1;
        byte b3 = (byte) -1;
        int i = 0;
        CameraPosition cameraPosition = null;
        byte b4 = (byte) -1;
        byte b5 = (byte) -1;
        byte b6 = (byte) -1;
        byte b7 = (byte) -1;
        byte b8 = (byte) -1;
        byte b9 = (byte) -1;
        byte b10 = (byte) -1;
        byte b11 = (byte) -1;
        byte b12 = (byte) -1;
        Float f = null;
        Float f2 = null;
        LatLngBounds latLngBounds = null;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    b2 = C3263b.m16144d(parcel, a);
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    b3 = C3263b.m16144d(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    i = C3263b.m16146f(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTick /*5*/:
                    cameraPosition = (CameraPosition) C3263b.m16135a(parcel, a, CameraPosition.CREATOR);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickNormalColor /*6*/:
                    b4 = C3263b.m16144d(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickSelectedColor /*7*/:
                    b5 = C3263b.m16144d(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickNormalDrawable /*8*/:
                    b6 = C3263b.m16144d(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickSelectedDrawable /*9*/:
                    b7 = C3263b.m16144d(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickSpacing /*10*/:
                    b8 = C3263b.m16144d(parcel, a);
                    break;
                case C5264R.styleable.Toolbar_popupTheme /*11*/:
                    b9 = C3263b.m16144d(parcel, a);
                    break;
                case C5264R.styleable.Toolbar_titleTextAppearance /*12*/:
                    b10 = C3263b.m16144d(parcel, a);
                    break;
                case C5264R.styleable.SearchView_suggestionRowLayout /*14*/:
                    b11 = C3263b.m16144d(parcel, a);
                    break;
                case CreditCard.EXPIRY_MAX_FUTURE_YEARS /*15*/:
                    b12 = C3263b.m16144d(parcel, a);
                    break;
                case C5264R.styleable.Toolbar_titleMarginEnd /*16*/:
                    f = C3263b.m16151k(parcel, a);
                    break;
                case C5264R.styleable.Toolbar_titleMarginTop /*17*/:
                    f2 = C3263b.m16151k(parcel, a);
                    break;
                case C5264R.styleable.Toolbar_titleMarginBottom /*18*/:
                    latLngBounds = (LatLngBounds) C3263b.m16135a(parcel, a, LatLngBounds.CREATOR);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new GoogleMapOptions(b2, b3, i, cameraPosition, b4, b5, b6, b7, b8, b9, b10, b11, b12, f, f2, latLngBounds);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public GoogleMapOptions[] m17411a(int i) {
        return new GoogleMapOptions[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m17410a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m17411a(i);
    }
}
