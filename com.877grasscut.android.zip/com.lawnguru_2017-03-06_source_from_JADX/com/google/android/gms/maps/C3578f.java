package com.google.android.gms.maps;

import android.os.RemoteException;
import com.google.android.gms.maps.model.C3625p;
import com.google.android.gms.maps.p103a.C3523j;

/* renamed from: com.google.android.gms.maps.f */
public final class C3578f {
    private final C3523j f10373a;

    C3578f(C3523j c3523j) {
        this.f10373a = c3523j;
    }

    public void m17406a(boolean z) {
        try {
            this.f10373a.m17269c(z);
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }

    public void m17407b(boolean z) {
        try {
            this.f10373a.m17279h(z);
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }

    public void m17408c(boolean z) {
        try {
            this.f10373a.m17283j(z);
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }
}
