package com.google.android.gms.maps;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.C2149a;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.StreetViewPanoramaCamera;
import com.google.android.gms.maps.p103a.C3526l;

public final class StreetViewPanoramaOptions extends C2149a implements ReflectedParcelable {
    public static final Creator<StreetViewPanoramaOptions> CREATOR;
    private StreetViewPanoramaCamera f10303a;
    private String f10304b;
    private LatLng f10305c;
    private Integer f10306d;
    private Boolean f10307e;
    private Boolean f10308f;
    private Boolean f10309g;
    private Boolean f10310h;
    private Boolean f10311i;

    static {
        CREATOR = new C3580h();
    }

    public StreetViewPanoramaOptions() {
        this.f10307e = Boolean.valueOf(true);
        this.f10308f = Boolean.valueOf(true);
        this.f10309g = Boolean.valueOf(true);
        this.f10310h = Boolean.valueOf(true);
    }

    StreetViewPanoramaOptions(StreetViewPanoramaCamera streetViewPanoramaCamera, String str, LatLng latLng, Integer num, byte b, byte b2, byte b3, byte b4, byte b5) {
        this.f10307e = Boolean.valueOf(true);
        this.f10308f = Boolean.valueOf(true);
        this.f10309g = Boolean.valueOf(true);
        this.f10310h = Boolean.valueOf(true);
        this.f10303a = streetViewPanoramaCamera;
        this.f10305c = latLng;
        this.f10306d = num;
        this.f10304b = str;
        this.f10307e = C3526l.m17305a(b);
        this.f10308f = C3526l.m17305a(b2);
        this.f10309g = C3526l.m17305a(b3);
        this.f10310h = C3526l.m17305a(b4);
        this.f10311i = C3526l.m17305a(b5);
    }

    byte m16844a() {
        return C3526l.m17304a(this.f10307e);
    }

    byte m16845b() {
        return C3526l.m17304a(this.f10308f);
    }

    byte m16846c() {
        return C3526l.m17304a(this.f10309g);
    }

    byte m16847d() {
        return C3526l.m17304a(this.f10310h);
    }

    byte m16848e() {
        return C3526l.m17304a(this.f10311i);
    }

    public StreetViewPanoramaCamera m16849f() {
        return this.f10303a;
    }

    public LatLng m16850g() {
        return this.f10305c;
    }

    public Integer m16851h() {
        return this.f10306d;
    }

    public String m16852i() {
        return this.f10304b;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C3580h.m17412a(this, parcel, i);
    }
}
