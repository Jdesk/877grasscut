package com.google.android.gms.maps;

import android.content.Context;
import android.os.RemoteException;
import com.google.android.gms.common.C3206d;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.maps.model.C3611b;
import com.google.android.gms.maps.model.C3625p;
import com.google.android.gms.maps.p103a.C3549u;
import com.google.android.gms.maps.p103a.C3553w;

/* renamed from: com.google.android.gms.maps.d */
public final class C3576d {
    private static boolean f10372a;

    static {
        f10372a = false;
    }

    public static synchronized int m17403a(Context context) {
        int i = 0;
        synchronized (C3576d.class) {
            C3234c.m16043a((Object) context, (Object) "Context is null");
            if (!f10372a) {
                try {
                    C3576d.m17404a(C3549u.m17332a(context));
                    f10372a = true;
                } catch (C3206d e) {
                    i = e.f9792a;
                }
            }
        }
        return i;
    }

    public static void m17404a(C3553w c3553w) {
        try {
            C3566b.m17377a(c3553w.m17343a());
            C3611b.m17814a(c3553w.m17349b());
        } catch (RemoteException e) {
            throw new C3625p(e);
        }
    }
}
