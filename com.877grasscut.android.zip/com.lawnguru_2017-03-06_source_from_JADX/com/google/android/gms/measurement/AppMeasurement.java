package com.google.android.gms.measurement;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Keep;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.common.util.C3294d;
import com.google.android.gms.p095b.ab;
import com.google.android.gms.p095b.es;
import com.google.android.gms.p095b.fh;
import com.google.firebase.p105a.C3650a.C3638a;
import com.google.firebase.p105a.C3650a.C3643b;
import com.google.firebase.p105a.C3650a.C3645c;
import java.util.List;
import java.util.Map;

@Deprecated
public class AppMeasurement {
    private final es f10506a;

    /* renamed from: com.google.android.gms.measurement.AppMeasurement.f */
    public static class C2572f {
        public String f6624b;
        public String f6625c;
        public long f6626d;

        public C2572f(C2572f c2572f) {
            this.f6624b = c2572f.f6624b;
            this.f6625c = c2572f.f6625c;
            this.f6626d = c2572f.f6626d;
        }
    }

    public static class ConditionalUserProperty {
        @Keep
        public boolean mActive;
        @Keep
        public String mAppId;
        @Keep
        public long mCreationTimestamp;
        @Keep
        public String mExpiredEventName;
        @Keep
        public Bundle mExpiredEventParams;
        @Keep
        public String mName;
        @Keep
        public String mOrigin;
        @Keep
        public long mTimeToLive;
        @Keep
        public String mTimedOutEventName;
        @Keep
        public Bundle mTimedOutEventParams;
        @Keep
        public String mTriggerEventName;
        @Keep
        public long mTriggerTimeout;
        @Keep
        public String mTriggeredEventName;
        @Keep
        public Bundle mTriggeredEventParams;
        @Keep
        public long mTriggeredTimestamp;
        @Keep
        public Object mValue;

        public ConditionalUserProperty(ConditionalUserProperty conditionalUserProperty) {
            C3234c.m16042a((Object) conditionalUserProperty);
            this.mAppId = conditionalUserProperty.mAppId;
            this.mOrigin = conditionalUserProperty.mOrigin;
            this.mCreationTimestamp = conditionalUserProperty.mCreationTimestamp;
            this.mName = conditionalUserProperty.mName;
            if (conditionalUserProperty.mValue != null) {
                this.mValue = fh.m11189a(conditionalUserProperty.mValue);
                if (this.mValue == null) {
                    this.mValue = conditionalUserProperty.mValue;
                }
            }
            this.mValue = conditionalUserProperty.mValue;
            this.mActive = conditionalUserProperty.mActive;
            this.mTriggerEventName = conditionalUserProperty.mTriggerEventName;
            this.mTriggerTimeout = conditionalUserProperty.mTriggerTimeout;
            this.mTimedOutEventName = conditionalUserProperty.mTimedOutEventName;
            if (conditionalUserProperty.mTimedOutEventParams != null) {
                this.mTimedOutEventParams = new Bundle(conditionalUserProperty.mTimedOutEventParams);
            }
            this.mTriggeredEventName = conditionalUserProperty.mTriggeredEventName;
            if (conditionalUserProperty.mTriggeredEventParams != null) {
                this.mTriggeredEventParams = new Bundle(conditionalUserProperty.mTriggeredEventParams);
            }
            this.mTriggeredTimestamp = conditionalUserProperty.mTriggeredTimestamp;
            this.mTimeToLive = conditionalUserProperty.mTimeToLive;
            this.mExpiredEventName = conditionalUserProperty.mExpiredEventName;
            if (conditionalUserProperty.mExpiredEventParams != null) {
                this.mExpiredEventParams = new Bundle(conditionalUserProperty.mExpiredEventParams);
            }
        }
    }

    /* renamed from: com.google.android.gms.measurement.AppMeasurement.a */
    public static final class C3639a extends C3638a {
        public static final Map<String, String> f10503a;

        static {
            f10503a = C3294d.m16306a(new String[]{"app_clear_data", "app_exception", "app_remove", "app_upgrade", "app_install", "app_update", "firebase_campaign", "error", "first_open", "in_app_purchase", "notification_dismiss", "notification_foreground", "notification_open", "notification_receive", "os_update", "session_start", "user_engagement", "firebase_ad_exposure", "firebase_adunit_exposure"}, new String[]{"_cd", "_ae", "_ui", "_in", "_ug", "_au", "_cmp", "_err", "_f", "_iap", "_nd", "_nf", "_no", "_nr", "_ou", "_s", "_e", "_xa", "_xu"});
        }
    }

    /* renamed from: com.google.android.gms.measurement.AppMeasurement.b */
    public interface C3640b {
        void m17914a(String str, String str2, Bundle bundle, long j);
    }

    /* renamed from: com.google.android.gms.measurement.AppMeasurement.c */
    public interface C3641c {
        void m17915a(String str, String str2, Bundle bundle, long j);
    }

    /* renamed from: com.google.android.gms.measurement.AppMeasurement.d */
    public interface C3642d {
        boolean m17916a(C2572f c2572f, C2572f c2572f2);
    }

    /* renamed from: com.google.android.gms.measurement.AppMeasurement.e */
    public static final class C3644e extends C3643b {
        public static final Map<String, String> f10504a;

        static {
            f10504a = C3294d.m16306a(new String[]{"firebase_conversion", "engagement_time_msec", "exposure_time", "ad_event_id", "ad_unit_id", "firebase_error", "firebase_error_value", "firebase_error_length", "debug", "realtime", "firebase_event_origin", "firebase_screen", "firebase_screen_class", "firebase_screen_id", "message_device_time", "message_id", "message_name", "message_time", "previous_app_version", "previous_os_version", "topic", "update_with_analytics", "previous_first_open_count", "system_app", "system_app_update", "previous_install_count"}, new String[]{"_c", "_et", "_xt", "_aeid", "_ai", "_err", "_ev", "_el", "_dbg", "_r", "_o", "_sn", "_sc", "_si", "_ndt", "_nmid", "_nmn", "_nmt", "_pv", "_po", "_nt", "_uwa", "_pfo", "_sys", "_sysu", "_pin"});
        }
    }

    /* renamed from: com.google.android.gms.measurement.AppMeasurement.g */
    public static final class C3646g extends C3645c {
        public static final Map<String, String> f10505a;

        static {
            f10505a = C3294d.m16306a(new String[]{"firebase_last_notification", "first_open_time", "last_deep_link_referrer", "user_id"}, new String[]{"_ln", "_fot", "_ldl", "_id"});
        }
    }

    public AppMeasurement(es esVar) {
        C3234c.m16042a((Object) esVar);
        this.f10506a = esVar;
    }

    private void m17917b(String str, String str2, Object obj) {
        this.f10506a.m10885l().m10978a(str, str2, obj);
    }

    @Keep
    @Deprecated
    public static AppMeasurement getInstance(Context context) {
        return es.m10824a(context).m10886m();
    }

    public void m17918a(String str, String str2, Object obj) {
        m17917b(str, str2, obj);
    }

    @Keep
    public void beginAdUnitExposure(String str) {
        this.f10506a.m10831A().m10213a(str);
    }

    @Keep
    protected void clearConditionalUserProperty(String str, String str2, Bundle bundle) {
        this.f10506a.m10885l().m10983b(str, str2, bundle);
    }

    @Keep
    protected void clearConditionalUserPropertyAs(String str, String str2, String str3, Bundle bundle) {
        this.f10506a.m10885l().m10979a(str, str2, str3, bundle);
    }

    @Keep
    public void endAdUnitExposure(String str) {
        this.f10506a.m10831A().m10215b(str);
    }

    @Keep
    public long generateEventId() {
        return this.f10506a.m10887n().m11281x();
    }

    @Keep
    public String getAppInstanceId() {
        return this.f10506a.m10885l().m10967a(null);
    }

    @Keep
    protected List<ConditionalUserProperty> getConditionalUserProperties(String str, String str2) {
        return this.f10506a.m10885l().m10968a(str, str2);
    }

    @Keep
    protected List<ConditionalUserProperty> getConditionalUserPropertiesAs(String str, String str2, String str3) {
        return this.f10506a.m10885l().m10969a(str, str2, str3);
    }

    @Keep
    public String getCurrentScreenName() {
        C2572f y = this.f10506a.m10893t().m11045y();
        return y != null ? y.f6624b : null;
    }

    @Keep
    public String getGmpAppId() {
        try {
            return ab.m9566a();
        } catch (IllegalStateException e) {
            this.f10506a.m10879f().m10665x().m10625a("getGoogleAppId failed with exception", e);
            return null;
        }
    }

    @Keep
    protected int getMaxUserProperties(String str) {
        return this.f10506a.m10885l().m10980b(str);
    }

    @Keep
    protected Map<String, Object> getUserProperties(String str, String str2, boolean z) {
        return this.f10506a.m10885l().m10971a(str, str2, z);
    }

    @Keep
    protected Map<String, Object> getUserPropertiesAs(String str, String str2, String str3, boolean z) {
        return this.f10506a.m10885l().m10970a(str, str2, str3, z);
    }

    @Keep
    public void logEventInternal(String str, String str2, Bundle bundle) {
        if (bundle == null) {
            bundle = new Bundle();
        }
        this.f10506a.m10885l().m10977a(str, str2, bundle);
    }

    @Keep
    public void registerOnScreenChangeCallback(C3642d c3642d) {
        this.f10506a.m10893t().m11015a(c3642d);
    }

    @Keep
    protected void setConditionalUserProperty(ConditionalUserProperty conditionalUserProperty) {
        this.f10506a.m10885l().m10973a(conditionalUserProperty);
    }

    @Keep
    protected void setConditionalUserPropertyAs(ConditionalUserProperty conditionalUserProperty) {
        this.f10506a.m10885l().m10982b(conditionalUserProperty);
    }

    @Keep
    public void unregisterOnScreenChangeCallback(C3642d c3642d) {
        this.f10506a.m10893t().m11020b(c3642d);
    }
}
