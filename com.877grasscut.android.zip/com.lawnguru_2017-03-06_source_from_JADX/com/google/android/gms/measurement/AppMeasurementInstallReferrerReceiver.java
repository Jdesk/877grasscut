package com.google.android.gms.measurement;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.google.android.gms.p095b.ep;
import com.google.android.gms.p095b.ep.C2542a;

public final class AppMeasurementInstallReferrerReceiver extends BroadcastReceiver implements C2542a {
    private ep f10507a;

    private ep m17919a() {
        if (this.f10507a == null) {
            this.f10507a = new ep(this);
        }
        return this.f10507a;
    }

    public void m17920a(Context context, Intent intent) {
    }

    public void onReceive(Context context, Intent intent) {
        m17919a().m10737a(context, intent);
    }
}
