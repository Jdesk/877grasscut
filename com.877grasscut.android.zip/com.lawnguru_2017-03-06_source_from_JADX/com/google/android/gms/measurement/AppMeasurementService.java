package com.google.android.gms.measurement;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.support.v4.content.C0420q;
import com.google.android.gms.p095b.fa;
import com.google.android.gms.p095b.fa.C2591a;

public final class AppMeasurementService extends Service implements C2591a {
    private fa f10509a;

    private fa m17923b() {
        if (this.f10509a == null) {
            this.f10509a = new fa(this);
        }
        return this.f10509a;
    }

    public Context m17924a() {
        return this;
    }

    public boolean m17925a(int i) {
        return stopSelfResult(i);
    }

    public IBinder onBind(Intent intent) {
        return m17923b().m11111a(intent);
    }

    public void onCreate() {
        super.onCreate();
        m17923b().m11112a();
    }

    public void onDestroy() {
        m17923b().m11113b();
        super.onDestroy();
    }

    public void onRebind(Intent intent) {
        m17923b().m11115c(intent);
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        m17923b().m11110a(intent, i, i2);
        C0420q.m1768a(intent);
        return 2;
    }

    public boolean onUnbind(Intent intent) {
        return m17923b().m11114b(intent);
    }
}
