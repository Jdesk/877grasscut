package com.google.android.gms.measurement;

import android.content.Context;
import android.content.Intent;
import android.support.v4.content.C0420q;
import com.google.android.gms.p095b.ep;
import com.google.android.gms.p095b.ep.C2542a;

public final class AppMeasurementReceiver extends C0420q implements C2542a {
    private ep f10508a;

    private ep m17921a() {
        if (this.f10508a == null) {
            this.f10508a = new ep(this);
        }
        return this.f10508a;
    }

    public void m17922a(Context context, Intent intent) {
        C0420q.a_(context, intent);
    }

    public void onReceive(Context context, Intent intent) {
        m17921a().m10737a(context, intent);
    }
}
