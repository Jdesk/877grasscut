package com.google.android.gms.ads.purchase;

/* renamed from: com.google.android.gms.ads.purchase.b */
public interface C2269b {
    void m8872a(C2268a c2268a);
}
