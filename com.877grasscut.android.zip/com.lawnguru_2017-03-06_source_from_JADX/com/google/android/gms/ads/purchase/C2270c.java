package com.google.android.gms.ads.purchase;

/* renamed from: com.google.android.gms.ads.purchase.c */
public interface C2270c {
}
