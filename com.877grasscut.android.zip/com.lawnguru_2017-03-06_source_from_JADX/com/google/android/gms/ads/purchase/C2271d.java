package com.google.android.gms.ads.purchase;

/* renamed from: com.google.android.gms.ads.purchase.d */
public interface C2271d {
    void m8873a(C2270c c2270c);

    boolean m8874a(String str);
}
