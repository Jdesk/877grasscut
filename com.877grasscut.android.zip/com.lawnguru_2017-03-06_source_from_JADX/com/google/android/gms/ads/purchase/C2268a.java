package com.google.android.gms.ads.purchase;

/* renamed from: com.google.android.gms.ads.purchase.a */
public interface C2268a {
}
