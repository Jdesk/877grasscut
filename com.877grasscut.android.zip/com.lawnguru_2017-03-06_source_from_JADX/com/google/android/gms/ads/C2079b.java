package com.google.android.gms.ads;

import android.content.Context;
import com.google.android.gms.ads.p096b.C2075c;
import com.google.android.gms.ads.p096b.C2077e.C2022a;
import com.google.android.gms.ads.p096b.C2078f.C2023a;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.p095b.jw;
import com.google.android.gms.p095b.kd;
import com.google.android.gms.p095b.kj;
import com.google.android.gms.p095b.ko;
import com.google.android.gms.p095b.kp;
import com.google.android.gms.p095b.ld;
import com.google.android.gms.p095b.my;
import com.google.android.gms.p095b.np;
import com.google.android.gms.p095b.nq;
import com.google.android.gms.p095b.pu;
import com.google.android.gms.p095b.wg;

/* renamed from: com.google.android.gms.ads.b */
public class C2079b {
    private final kd f4856a;
    private final Context f4857b;
    private final ko f4858c;

    /* renamed from: com.google.android.gms.ads.b.a */
    public static class C2069a {
        private final Context f4842a;
        private final kp f4843b;

        C2069a(Context context, kp kpVar) {
            this.f4842a = context;
            this.f4843b = kpVar;
        }

        public C2069a(Context context, String str) {
            this((Context) C3234c.m16043a((Object) context, (Object) "context cannot be null"), kj.m12295b().m12286a(context, str, new pu()));
        }

        public C2069a m7980a(C2019a c2019a) {
            try {
                this.f4843b.m8310a(new jw(c2019a));
            } catch (Throwable e) {
                wg.m14618c("Failed to set AdListener.", e);
            }
            return this;
        }

        public C2069a m7981a(C2075c c2075c) {
            try {
                this.f4843b.m8312a(new my(c2075c));
            } catch (Throwable e) {
                wg.m14618c("Failed to specify native ad options", e);
            }
            return this;
        }

        public C2069a m7982a(C2022a c2022a) {
            try {
                this.f4843b.m8313a(new np(c2022a));
            } catch (Throwable e) {
                wg.m14618c("Failed to add app install ad listener", e);
            }
            return this;
        }

        public C2069a m7983a(C2023a c2023a) {
            try {
                this.f4843b.m8314a(new nq(c2023a));
            } catch (Throwable e) {
                wg.m14618c("Failed to add content ad listener", e);
            }
            return this;
        }

        public C2079b m7984a() {
            try {
                return new C2079b(this.f4842a, this.f4843b.m8309a());
            } catch (Throwable e) {
                wg.m14616b("Failed to build AdLoader.", e);
                return null;
            }
        }
    }

    C2079b(Context context, ko koVar) {
        this(context, koVar, kd.m12230a());
    }

    C2079b(Context context, ko koVar, kd kdVar) {
        this.f4857b = context;
        this.f4858c = koVar;
        this.f4856a = kdVar;
    }

    private void m8023a(ld ldVar) {
        try {
            this.f4858c.m8290a(this.f4856a.m12231a(this.f4857b, ldVar));
        } catch (Throwable e) {
            wg.m14616b("Failed to load ad.", e);
        }
    }

    public void m8024a(C2085c c2085c) {
        m8023a(c2085c.m8046a());
    }
}
