package com.google.android.gms.ads;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import com.google.android.gms.p095b.kj;
import com.google.android.gms.p095b.qv;
import com.google.android.gms.p095b.wg;
import com.google.android.gms.p097a.C2060d;

public class AdActivity extends Activity {
    private qv f4840a;

    private void m7977a() {
        if (this.f4840a != null) {
            try {
                this.f4840a.m8463l();
            } catch (Throwable e) {
                wg.m14618c("Could not forward setContentViewSet to ad overlay:", e);
            }
        }
    }

    protected void onActivityResult(int i, int i2, Intent intent) {
        try {
            this.f4840a.m8451a(i, i2, intent);
        } catch (Throwable e) {
            wg.m14618c("Could not forward onActivityResult to ad overlay:", e);
        }
        super.onActivityResult(i, i2, intent);
    }

    public void onBackPressed() {
        boolean z = true;
        try {
            if (this.f4840a != null) {
                z = this.f4840a.m8456e();
            }
        } catch (Throwable e) {
            wg.m14618c("Could not forward onBackPressed to ad overlay:", e);
        }
        if (z) {
            super.onBackPressed();
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        try {
            this.f4840a.m8453a(C2060d.m7973a((Object) configuration));
        } catch (Throwable e) {
            wg.m14618c("Failed to wrap configuration.", e);
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f4840a = kj.m12295b().m12292b((Activity) this);
        if (this.f4840a == null) {
            wg.m14620e("Could not create ad overlay.");
            finish();
            return;
        }
        try {
            this.f4840a.m8452a(bundle);
        } catch (Throwable e) {
            wg.m14618c("Could not forward onCreate to ad overlay:", e);
            finish();
        }
    }

    protected void onDestroy() {
        try {
            if (this.f4840a != null) {
                this.f4840a.m8462k();
            }
        } catch (Throwable e) {
            wg.m14618c("Could not forward onDestroy to ad overlay:", e);
        }
        super.onDestroy();
    }

    protected void onPause() {
        try {
            if (this.f4840a != null) {
                this.f4840a.m8460i();
            }
        } catch (Throwable e) {
            wg.m14618c("Could not forward onPause to ad overlay:", e);
            finish();
        }
        super.onPause();
    }

    protected void onRestart() {
        super.onRestart();
        try {
            if (this.f4840a != null) {
                this.f4840a.m8457f();
            }
        } catch (Throwable e) {
            wg.m14618c("Could not forward onRestart to ad overlay:", e);
            finish();
        }
    }

    protected void onResume() {
        super.onResume();
        try {
            if (this.f4840a != null) {
                this.f4840a.m8459h();
            }
        } catch (Throwable e) {
            wg.m14618c("Could not forward onResume to ad overlay:", e);
            finish();
        }
    }

    protected void onSaveInstanceState(Bundle bundle) {
        try {
            if (this.f4840a != null) {
                this.f4840a.m8454b(bundle);
            }
        } catch (Throwable e) {
            wg.m14618c("Could not forward onSaveInstanceState to ad overlay:", e);
            finish();
        }
        super.onSaveInstanceState(bundle);
    }

    protected void onStart() {
        super.onStart();
        try {
            if (this.f4840a != null) {
                this.f4840a.m8458g();
            }
        } catch (Throwable e) {
            wg.m14618c("Could not forward onStart to ad overlay:", e);
            finish();
        }
    }

    protected void onStop() {
        try {
            if (this.f4840a != null) {
                this.f4840a.m8461j();
            }
        } catch (Throwable e) {
            wg.m14618c("Could not forward onStop to ad overlay:", e);
            finish();
        }
        super.onStop();
    }

    public void setContentView(int i) {
        super.setContentView(i);
        m7977a();
    }

    public void setContentView(View view) {
        super.setContentView(view);
        m7977a();
    }

    public void setContentView(View view, LayoutParams layoutParams) {
        super.setContentView(view, layoutParams);
        m7977a();
    }
}
