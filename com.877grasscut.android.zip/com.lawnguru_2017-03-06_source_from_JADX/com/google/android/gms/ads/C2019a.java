package com.google.android.gms.ads;

/* renamed from: com.google.android.gms.ads.a */
public abstract class C2019a {
    public void m7870a() {
    }

    public void m7871a(int i) {
    }

    public void m7872b() {
    }

    public void m7873c() {
    }

    public void m7874d() {
    }
}
