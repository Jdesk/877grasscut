package com.google.android.gms.ads;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.ads.purchase.C2269b;
import com.google.android.gms.p095b.ju;
import com.google.android.gms.p095b.le;
import com.google.android.gms.p095b.wg;

/* renamed from: com.google.android.gms.ads.f */
class C2089f extends ViewGroup {
    protected final le f4889a;

    public C2089f(Context context, int i) {
        super(context);
        this.f4889a = new le(this, i);
    }

    public void m8066a() {
        this.f4889a.m12477j();
    }

    public void m8067a(C2085c c2085c) {
        this.f4889a.m12463a(c2085c.m8046a());
    }

    public void m8068b() {
        this.f4889a.m12476i();
    }

    public void m8069c() {
        this.f4889a.m12455a();
    }

    public C2019a getAdListener() {
        return this.f4889a.m12468b();
    }

    public C2088d getAdSize() {
        return this.f4889a.m12470c();
    }

    public String getAdUnitId() {
        return this.f4889a.m12472e();
    }

    public C2269b getInAppPurchaseListener() {
        return this.f4889a.m12474g();
    }

    public String getMediationAdapterClassName() {
        return this.f4889a.m12478k();
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        View childAt = getChildAt(0);
        if (childAt != null && childAt.getVisibility() != 8) {
            int measuredWidth = childAt.getMeasuredWidth();
            int measuredHeight = childAt.getMeasuredHeight();
            int i5 = ((i3 - i) - measuredWidth) / 2;
            int i6 = ((i4 - i2) - measuredHeight) / 2;
            childAt.layout(i5, i6, measuredWidth + i5, measuredHeight + i6);
        }
    }

    protected void onMeasure(int i, int i2) {
        int b;
        int i3 = 0;
        View childAt = getChildAt(0);
        if (childAt == null || childAt.getVisibility() == 8) {
            C2088d adSize;
            C2088d c2088d = null;
            try {
                adSize = getAdSize();
            } catch (Throwable e) {
                wg.m14616b("Unable to retrieve ad size.", e);
                adSize = c2088d;
            }
            if (adSize != null) {
                Context context = getContext();
                b = adSize.m8064b(context);
                i3 = adSize.m8062a(context);
            } else {
                b = 0;
            }
        } else {
            measureChild(childAt, i, i2);
            b = childAt.getMeasuredWidth();
            i3 = childAt.getMeasuredHeight();
        }
        setMeasuredDimension(View.resolveSize(Math.max(b, getSuggestedMinimumWidth()), i), View.resolveSize(Math.max(i3, getSuggestedMinimumHeight()), i2));
    }

    public void setAdListener(C2019a c2019a) {
        this.f4889a.m12458a(c2019a);
        if (c2019a != null && (c2019a instanceof ju)) {
            this.f4889a.m12462a((ju) c2019a);
        } else if (c2019a == null) {
            this.f4889a.m12462a(null);
        }
    }

    public void setAdSize(C2088d c2088d) {
        this.f4889a.m12466a(c2088d);
    }

    public void setAdUnitId(String str) {
        this.f4889a.m12464a(str);
    }

    public void setInAppPurchaseListener(C2269b c2269b) {
        this.f4889a.m12461a(c2269b);
    }
}
