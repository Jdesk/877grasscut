package com.google.android.gms.ads.mediation;

import android.content.Context;
import android.os.Bundle;

/* renamed from: com.google.android.gms.ads.mediation.g */
public interface C2009g extends C2006b {
    void requestNativeAd(Context context, C2265h c2265h, Bundle bundle, C2266l c2266l, Bundle bundle2);
}
