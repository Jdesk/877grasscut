package com.google.android.gms.ads.mediation.customevent;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import com.google.android.gms.ads.C2088d;
import com.google.android.gms.ads.mediation.C2008c;
import com.google.android.gms.ads.mediation.C2009g;
import com.google.android.gms.ads.mediation.C2010e;
import com.google.android.gms.ads.mediation.C2250a;
import com.google.android.gms.ads.mediation.C2263d;
import com.google.android.gms.ads.mediation.C2264f;
import com.google.android.gms.ads.mediation.C2265h;
import com.google.android.gms.ads.mediation.C2266l;
import com.google.android.gms.common.annotation.KeepName;
import com.google.android.gms.p095b.wg;

@KeepName
public final class CustomEventAdapter implements C2008c, C2010e, C2009g {
    C2259b f5382a;
    C2261e f5383b;
    C2262g f5384c;
    private View f5385d;

    /* renamed from: com.google.android.gms.ads.mediation.customevent.CustomEventAdapter.a */
    static final class C2253a implements C2252c {
        private final CustomEventAdapter f5375a;
        private final C2263d f5376b;

        public C2253a(CustomEventAdapter customEventAdapter, C2263d c2263d) {
            this.f5375a = customEventAdapter;
            this.f5376b = c2263d;
        }
    }

    /* renamed from: com.google.android.gms.ads.mediation.customevent.CustomEventAdapter.b */
    class C2255b implements C2254f {
        final /* synthetic */ CustomEventAdapter f5377a;
        private final CustomEventAdapter f5378b;
        private final C2264f f5379c;

        public C2255b(CustomEventAdapter customEventAdapter, CustomEventAdapter customEventAdapter2, C2264f c2264f) {
            this.f5377a = customEventAdapter;
            this.f5378b = customEventAdapter2;
            this.f5379c = c2264f;
        }
    }

    /* renamed from: com.google.android.gms.ads.mediation.customevent.CustomEventAdapter.c */
    static class C2257c implements C2256h {
        private final CustomEventAdapter f5380a;
        private final C2265h f5381b;

        public C2257c(CustomEventAdapter customEventAdapter, C2265h c2265h) {
            this.f5380a = customEventAdapter;
            this.f5381b = c2265h;
        }
    }

    private static <T> T m8840a(String str) {
        try {
            return Class.forName(str).newInstance();
        } catch (Throwable th) {
            String valueOf = String.valueOf(th.getMessage());
            wg.m14620e(new StringBuilder((String.valueOf(str).length() + 46) + String.valueOf(valueOf).length()).append("Could not instantiate custom event adapter: ").append(str).append(". ").append(valueOf).toString());
            return null;
        }
    }

    C2255b m8841a(C2264f c2264f) {
        return new C2255b(this, this, c2264f);
    }

    public View getBannerView() {
        return this.f5385d;
    }

    public void onDestroy() {
        if (this.f5382a != null) {
            this.f5382a.m8842a();
        }
        if (this.f5383b != null) {
            this.f5383b.m8842a();
        }
        if (this.f5384c != null) {
            this.f5384c.m8842a();
        }
    }

    public void onPause() {
        if (this.f5382a != null) {
            this.f5382a.m8843b();
        }
        if (this.f5383b != null) {
            this.f5383b.m8843b();
        }
        if (this.f5384c != null) {
            this.f5384c.m8843b();
        }
    }

    public void onResume() {
        if (this.f5382a != null) {
            this.f5382a.m8844c();
        }
        if (this.f5383b != null) {
            this.f5383b.m8844c();
        }
        if (this.f5384c != null) {
            this.f5384c.m8844c();
        }
    }

    public void requestBannerAd(Context context, C2263d c2263d, Bundle bundle, C2088d c2088d, C2250a c2250a, Bundle bundle2) {
        this.f5382a = (C2259b) m8840a(bundle.getString("class_name"));
        if (this.f5382a == null) {
            c2263d.m8851a(this, 0);
            return;
        }
        this.f5382a.m8845a(context, new C2253a(this, c2263d), bundle.getString("parameter"), c2088d, c2250a, bundle2 == null ? null : bundle2.getBundle(bundle.getString("class_name")));
    }

    public void requestInterstitialAd(Context context, C2264f c2264f, Bundle bundle, C2250a c2250a, Bundle bundle2) {
        this.f5383b = (C2261e) m8840a(bundle.getString("class_name"));
        if (this.f5383b == null) {
            c2264f.m8857a(this, 0);
            return;
        }
        this.f5383b.m8847a(context, m8841a(c2264f), bundle.getString("parameter"), c2250a, bundle2 == null ? null : bundle2.getBundle(bundle.getString("class_name")));
    }

    public void requestNativeAd(Context context, C2265h c2265h, Bundle bundle, C2266l c2266l, Bundle bundle2) {
        this.f5384c = (C2262g) m8840a(bundle.getString("class_name"));
        if (this.f5384c == null) {
            c2265h.m8863a((C2009g) this, 0);
            return;
        }
        this.f5384c.m8849a(context, new C2257c(this, c2265h), bundle.getString("parameter"), c2266l, bundle2 == null ? null : bundle2.getBundle(bundle.getString("class_name")));
    }

    public void showInterstitial() {
        this.f5383b.m8848d();
    }
}
