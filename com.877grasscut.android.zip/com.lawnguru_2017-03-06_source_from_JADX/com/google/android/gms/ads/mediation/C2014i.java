package com.google.android.gms.ads.mediation;

import android.os.Bundle;
import android.view.View;
import com.google.android.gms.p095b.sc;

@sc
/* renamed from: com.google.android.gms.ads.mediation.i */
public abstract class C2014i {
    protected boolean f4772a;
    protected boolean f4773b;
    protected Bundle f4774c;
    protected View f4775d;

    public C2014i() {
        this.f4774c = new Bundle();
    }

    public void m7826a(View view) {
    }

    public final void m7827a(boolean z) {
        this.f4772a = z;
    }

    public final boolean m7828a() {
        return this.f4772a;
    }

    public void m7829b(View view) {
    }

    public final void m7830b(boolean z) {
        this.f4773b = z;
    }

    public final boolean m7831b() {
        return this.f4773b;
    }

    public final Bundle m7832c() {
        return this.f4774c;
    }

    public void m7833c(View view) {
    }

    public View m7834d() {
        return this.f4775d;
    }

    public void m7835e() {
    }
}
