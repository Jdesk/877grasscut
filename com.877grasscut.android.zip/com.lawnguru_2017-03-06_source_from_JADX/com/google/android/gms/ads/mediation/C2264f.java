package com.google.android.gms.ads.mediation;

/* renamed from: com.google.android.gms.ads.mediation.f */
public interface C2264f {
    void m8856a(C2010e c2010e);

    void m8857a(C2010e c2010e, int i);

    void m8858b(C2010e c2010e);

    void m8859c(C2010e c2010e);

    void m8860d(C2010e c2010e);

    void m8861e(C2010e c2010e);
}
