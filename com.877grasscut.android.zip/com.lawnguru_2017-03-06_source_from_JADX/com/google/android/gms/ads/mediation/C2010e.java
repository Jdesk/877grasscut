package com.google.android.gms.ads.mediation;

import android.content.Context;
import android.os.Bundle;

/* renamed from: com.google.android.gms.ads.mediation.e */
public interface C2010e extends C2006b {
    void requestInterstitialAd(Context context, C2264f c2264f, Bundle bundle, C2250a c2250a, Bundle bundle2);

    void showInterstitial();
}
