package com.google.android.gms.ads.mediation.customevent;

import android.content.Context;
import android.os.Bundle;
import com.google.android.gms.ads.mediation.C2250a;

/* renamed from: com.google.android.gms.ads.mediation.customevent.e */
public interface C2261e extends C2258a {
    void m8847a(Context context, C2254f c2254f, String str, C2250a c2250a, Bundle bundle);

    void m8848d();
}
