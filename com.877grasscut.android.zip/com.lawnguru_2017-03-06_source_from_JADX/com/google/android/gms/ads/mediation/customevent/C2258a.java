package com.google.android.gms.ads.mediation.customevent;

/* renamed from: com.google.android.gms.ads.mediation.customevent.a */
public interface C2258a {
    void m8842a();

    void m8843b();

    void m8844c();
}
