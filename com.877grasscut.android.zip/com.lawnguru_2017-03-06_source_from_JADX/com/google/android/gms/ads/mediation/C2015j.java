package com.google.android.gms.ads.mediation;

import com.google.android.gms.ads.C2094i;
import com.google.android.gms.ads.p096b.C2072b.C2071a;
import java.util.List;

/* renamed from: com.google.android.gms.ads.mediation.j */
public abstract class C2015j extends C2014i {
    private String f4776e;
    private List<C2071a> f4777f;
    private String f4778g;
    private C2071a f4779h;
    private String f4780i;
    private double f4781j;
    private String f4782k;
    private String f4783l;
    private C2094i f4784m;

    public final void m7836a(double d) {
        this.f4781j = d;
    }

    public final void m7837a(C2071a c2071a) {
        this.f4779h = c2071a;
    }

    public final void m7838a(C2094i c2094i) {
        this.f4784m = c2094i;
    }

    public final void m7839a(String str) {
        this.f4776e = str;
    }

    public final void m7840a(List<C2071a> list) {
        this.f4777f = list;
    }

    public final void m7841b(String str) {
        this.f4778g = str;
    }

    public final void m7842c(String str) {
        this.f4780i = str;
    }

    public final void m7843d(String str) {
        this.f4782k = str;
    }

    public final void m7844e(String str) {
        this.f4783l = str;
    }

    public final String m7845f() {
        return this.f4776e;
    }

    public final List<C2071a> m7846g() {
        return this.f4777f;
    }

    public final String m7847h() {
        return this.f4778g;
    }

    public final C2071a m7848i() {
        return this.f4779h;
    }

    public final String m7849j() {
        return this.f4780i;
    }

    public final double m7850k() {
        return this.f4781j;
    }

    public final String m7851l() {
        return this.f4782k;
    }

    public final String m7852m() {
        return this.f4783l;
    }

    public final C2094i m7853n() {
        return this.f4784m;
    }
}
