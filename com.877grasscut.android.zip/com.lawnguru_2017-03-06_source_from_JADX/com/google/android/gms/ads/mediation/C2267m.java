package com.google.android.gms.ads.mediation;

import android.content.Context;

/* renamed from: com.google.android.gms.ads.mediation.m */
public interface C2267m {
    void m8871a(Context context);
}
