package com.google.android.gms.ads.mediation.customevent;

/* renamed from: com.google.android.gms.ads.mediation.customevent.c */
public interface C2252c {
}
