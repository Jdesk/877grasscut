package com.google.android.gms.ads.mediation.customevent;

/* renamed from: com.google.android.gms.ads.mediation.customevent.f */
public interface C2254f {
}
