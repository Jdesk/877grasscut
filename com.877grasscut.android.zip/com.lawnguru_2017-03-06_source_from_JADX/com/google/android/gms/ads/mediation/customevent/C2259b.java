package com.google.android.gms.ads.mediation.customevent;

import android.content.Context;
import android.os.Bundle;
import com.google.android.gms.ads.C2088d;
import com.google.android.gms.ads.mediation.C2250a;

/* renamed from: com.google.android.gms.ads.mediation.customevent.b */
public interface C2259b extends C2258a {
    void m8845a(Context context, C2252c c2252c, String str, C2088d c2088d, C2250a c2250a, Bundle bundle);
}
