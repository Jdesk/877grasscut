package com.google.android.gms.ads.mediation.customevent;

import android.content.Context;
import android.os.Bundle;
import com.google.android.gms.ads.mediation.C2266l;

/* renamed from: com.google.android.gms.ads.mediation.customevent.g */
public interface C2262g extends C2258a {
    void m8849a(Context context, C2256h c2256h, String str, C2266l c2266l, Bundle bundle);
}
