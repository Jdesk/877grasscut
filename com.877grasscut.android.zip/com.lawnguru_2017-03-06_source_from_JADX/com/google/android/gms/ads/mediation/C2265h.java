package com.google.android.gms.ads.mediation;

/* renamed from: com.google.android.gms.ads.mediation.h */
public interface C2265h {
    void m8862a(C2009g c2009g);

    void m8863a(C2009g c2009g, int i);

    void m8864a(C2009g c2009g, C2014i c2014i);

    void m8865b(C2009g c2009g);

    void m8866c(C2009g c2009g);

    void m8867d(C2009g c2009g);
}
