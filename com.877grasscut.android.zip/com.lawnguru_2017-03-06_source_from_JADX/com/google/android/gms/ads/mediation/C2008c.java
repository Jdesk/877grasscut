package com.google.android.gms.ads.mediation;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import com.google.android.gms.ads.C2088d;

/* renamed from: com.google.android.gms.ads.mediation.c */
public interface C2008c extends C2006b {
    View getBannerView();

    void requestBannerAd(Context context, C2263d c2263d, Bundle bundle, C2088d c2088d, C2250a c2250a, Bundle bundle2);
}
