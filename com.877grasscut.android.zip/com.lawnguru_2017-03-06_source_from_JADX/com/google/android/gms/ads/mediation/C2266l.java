package com.google.android.gms.ads.mediation;

import com.google.android.gms.ads.p096b.C2075c;

/* renamed from: com.google.android.gms.ads.mediation.l */
public interface C2266l extends C2250a {
    C2075c m8868h();

    boolean m8869i();

    boolean m8870j();
}
