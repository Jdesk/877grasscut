package com.google.android.gms.ads.mediation.customevent;

/* renamed from: com.google.android.gms.ads.mediation.customevent.h */
public interface C2256h {
}
