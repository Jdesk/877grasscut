package com.google.android.gms.ads.mediation;

/* renamed from: com.google.android.gms.ads.mediation.d */
public interface C2263d {
    void m8850a(C2008c c2008c);

    void m8851a(C2008c c2008c, int i);

    void m8852b(C2008c c2008c);

    void m8853c(C2008c c2008c);

    void m8854d(C2008c c2008c);

    void m8855e(C2008c c2008c);
}
