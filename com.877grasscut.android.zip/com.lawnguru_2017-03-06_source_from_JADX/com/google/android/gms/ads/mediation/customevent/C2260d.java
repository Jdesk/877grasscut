package com.google.android.gms.ads.mediation.customevent;

import com.google.ads.mediation.C2042i;
import java.util.HashMap;

@Deprecated
/* renamed from: com.google.android.gms.ads.mediation.customevent.d */
public final class C2260d implements C2042i {
    private final HashMap<String, Object> f5386a;

    public C2260d() {
        this.f5386a = new HashMap();
    }

    public Object m8846a(String str) {
        return this.f5386a.get(str);
    }
}
