package com.google.android.gms.ads.mediation;

import com.google.android.gms.ads.C2094i;
import com.google.android.gms.ads.p096b.C2072b.C2071a;
import java.util.List;

/* renamed from: com.google.android.gms.ads.mediation.k */
public abstract class C2017k extends C2014i {
    private String f4786e;
    private List<C2071a> f4787f;
    private String f4788g;
    private C2071a f4789h;
    private String f4790i;
    private String f4791j;
    private C2094i f4792k;

    public final void m7855a(C2071a c2071a) {
        this.f4789h = c2071a;
    }

    public final void m7856a(C2094i c2094i) {
        this.f4792k = c2094i;
    }

    public final void m7857a(String str) {
        this.f4786e = str;
    }

    public final void m7858a(List<C2071a> list) {
        this.f4787f = list;
    }

    public final void m7859b(String str) {
        this.f4788g = str;
    }

    public final void m7860c(String str) {
        this.f4790i = str;
    }

    public final void m7861d(String str) {
        this.f4791j = str;
    }

    public final String m7862f() {
        return this.f4786e;
    }

    public final List<C2071a> m7863g() {
        return this.f4787f;
    }

    public final String m7864h() {
        return this.f4788g;
    }

    public final C2071a m7865i() {
        return this.f4789h;
    }

    public final String m7866j() {
        return this.f4790i;
    }

    public final String m7867k() {
        return this.f4791j;
    }

    public final C2094i m7868l() {
        return this.f4792k;
    }
}
