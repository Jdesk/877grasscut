package com.google.android.gms.ads.mediation;

import android.location.Location;
import java.util.Date;
import java.util.Set;

/* renamed from: com.google.android.gms.ads.mediation.a */
public interface C2250a {
    Date m8831a();

    int m8832b();

    Set<String> m8833c();

    Location m8834d();

    int m8835e();

    boolean m8836f();

    boolean m8837g();
}
