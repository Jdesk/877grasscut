package com.google.android.gms.ads.p093c.p094a;

import com.google.android.gms.ads.p093c.C2084a;

/* renamed from: com.google.android.gms.ads.c.a.c */
public interface C2083c {
    void m8036a(C2007b c2007b);

    void m8037a(C2007b c2007b, int i);

    void m8038a(C2007b c2007b, C2084a c2084a);

    void m8039b(C2007b c2007b);

    void m8040c(C2007b c2007b);

    void m8041d(C2007b c2007b);

    void m8042e(C2007b c2007b);

    void m8043f(C2007b c2007b);
}
