package com.google.android.gms.ads.p093c.p094a;

import android.content.Context;
import android.os.Bundle;
import java.util.List;

/* renamed from: com.google.android.gms.ads.c.a.a */
public interface C2082a extends C2007b {
    void m8035a(Context context, C2083c c2083c, List<Bundle> list);
}
