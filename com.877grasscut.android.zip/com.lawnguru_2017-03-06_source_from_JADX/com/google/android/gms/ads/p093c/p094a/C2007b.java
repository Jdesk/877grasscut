package com.google.android.gms.ads.p093c.p094a;

import android.content.Context;
import android.os.Bundle;
import com.google.android.gms.ads.mediation.C2006b;
import com.google.android.gms.ads.mediation.C2250a;

/* renamed from: com.google.android.gms.ads.c.a.b */
public interface C2007b extends C2006b {
    void initialize(Context context, C2250a c2250a, String str, C2083c c2083c, Bundle bundle, Bundle bundle2);

    boolean isInitialized();

    void loadAd(C2250a c2250a, Bundle bundle, Bundle bundle2);

    void showVideo();
}
