package com.google.android.gms.ads.p093c;

/* renamed from: com.google.android.gms.ads.c.b */
public interface C2012b {
    void m7812a();

    void m7813a(int i);

    void m7814a(C2084a c2084a);

    void m7815b();

    void m7816c();

    void m7817d();

    void m7818e();
}
