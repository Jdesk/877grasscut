package com.google.android.gms.ads.p093c;

/* renamed from: com.google.android.gms.ads.c.a */
public interface C2084a {
    String m8044a();

    int m8045b();
}
