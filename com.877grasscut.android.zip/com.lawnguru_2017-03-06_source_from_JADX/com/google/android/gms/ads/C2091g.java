package com.google.android.gms.ads;

import com.google.android.gms.p095b.kk;
import com.google.android.gms.p095b.sc;

@sc
/* renamed from: com.google.android.gms.ads.g */
public final class C2091g {
    private kk f4890a;

    public kk m8074a() {
        return this.f4890a;
    }
}
