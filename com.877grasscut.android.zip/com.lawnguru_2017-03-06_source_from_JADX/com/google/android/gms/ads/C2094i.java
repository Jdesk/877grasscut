package com.google.android.gms.ads;

import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.p095b.kz;
import com.google.android.gms.p095b.lm;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.wg;

@sc
/* renamed from: com.google.android.gms.ads.i */
public final class C2094i {
    private final Object f4892a;
    private kz f4893b;
    private C2093a f4894c;

    /* renamed from: com.google.android.gms.ads.i.a */
    public static abstract class C2093a {
        public void m8081a() {
        }
    }

    public C2094i() {
        this.f4892a = new Object();
    }

    public kz m8082a() {
        kz kzVar;
        synchronized (this.f4892a) {
            kzVar = this.f4893b;
        }
        return kzVar;
    }

    public void m8083a(C2093a c2093a) {
        C3234c.m16043a((Object) c2093a, (Object) "VideoLifecycleCallbacks may not be null.");
        synchronized (this.f4892a) {
            this.f4894c = c2093a;
            if (this.f4893b == null) {
                return;
            }
            try {
                this.f4893b.m12374a(new lm(c2093a));
            } catch (Throwable e) {
                wg.m14616b("Unable to call setVideoLifecycleCallbacks on video controller.", e);
            }
        }
    }

    public void m8084a(kz kzVar) {
        synchronized (this.f4892a) {
            this.f4893b = kzVar;
            if (this.f4894c != null) {
                m8083a(this.f4894c);
            }
        }
    }
}
