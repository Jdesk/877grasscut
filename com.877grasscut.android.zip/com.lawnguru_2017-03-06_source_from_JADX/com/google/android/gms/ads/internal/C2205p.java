package com.google.android.gms.ads.internal;

import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.text.TextUtils;
import android.util.Base64;
import android.view.View;
import android.view.View.OnClickListener;
import com.google.android.gms.ads.internal.C2132g.C2131a;
import com.google.android.gms.p095b.mq;
import com.google.android.gms.p095b.mr;
import com.google.android.gms.p095b.nb;
import com.google.android.gms.p095b.nb.C2765a;
import com.google.android.gms.p095b.nx;
import com.google.android.gms.p095b.pq;
import com.google.android.gms.p095b.qa;
import com.google.android.gms.p095b.qb;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.vb;
import com.google.android.gms.p095b.wg;
import com.google.android.gms.p095b.wx;
import com.google.android.gms.p095b.wy.C2169a;
import com.google.android.gms.p097a.C2046a;
import com.google.android.gms.p097a.C2060d;
import io.card.payment.BuildConfig;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import org.json.JSONArray;
import org.json.JSONObject;

@sc
/* renamed from: com.google.android.gms.ads.internal.p */
public class C2205p {

    /* renamed from: com.google.android.gms.ads.internal.p.1 */
    class C22001 implements C2169a {
        final /* synthetic */ mq f5188a;
        final /* synthetic */ String f5189b;
        final /* synthetic */ wx f5190c;

        C22001(mq mqVar, String str, wx wxVar) {
            this.f5188a = mqVar;
            this.f5189b = str;
            this.f5190c = wxVar;
        }

        public void m8562a(wx wxVar, boolean z) {
            try {
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("headline", this.f5188a.m12735a());
                jSONObject.put("body", this.f5188a.m12738c());
                jSONObject.put("call_to_action", this.f5188a.m12740e());
                jSONObject.put("price", this.f5188a.m12743h());
                jSONObject.put("star_rating", String.valueOf(this.f5188a.m12741f()));
                jSONObject.put("store", this.f5188a.m12742g());
                jSONObject.put("icon", C2205p.m8574a(this.f5188a.m12739d()));
                JSONArray jSONArray = new JSONArray();
                List<Object> b = this.f5188a.m12737b();
                if (b != null) {
                    for (Object a : b) {
                        jSONArray.put(C2205p.m8574a(C2205p.m8582b(a)));
                    }
                }
                jSONObject.put("images", jSONArray);
                jSONObject.put("extras", C2205p.m8585b(this.f5188a.m12749n(), this.f5189b));
                JSONObject jSONObject2 = new JSONObject();
                jSONObject2.put("assets", jSONObject);
                jSONObject2.put("template_id", "2");
                this.f5190c.m14968a("google.afma.nativeExpressAds.loadAssets", jSONObject2);
            } catch (Throwable e) {
                wg.m14618c("Exception occurred when loading assets", e);
            }
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.p.2 */
    class C22012 implements C2169a {
        final /* synthetic */ mr f5191a;
        final /* synthetic */ String f5192b;
        final /* synthetic */ wx f5193c;

        C22012(mr mrVar, String str, wx wxVar) {
            this.f5191a = mrVar;
            this.f5192b = str;
            this.f5193c = wxVar;
        }

        public void m8563a(wx wxVar, boolean z) {
            try {
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("headline", this.f5191a.m12763a());
                jSONObject.put("body", this.f5191a.m12766c());
                jSONObject.put("call_to_action", this.f5191a.m12768e());
                jSONObject.put("advertiser", this.f5191a.m12769f());
                jSONObject.put("logo", C2205p.m8574a(this.f5191a.m12767d()));
                JSONArray jSONArray = new JSONArray();
                List<Object> b = this.f5191a.m12765b();
                if (b != null) {
                    for (Object a : b) {
                        jSONArray.put(C2205p.m8574a(C2205p.m8582b(a)));
                    }
                }
                jSONObject.put("images", jSONArray);
                jSONObject.put("extras", C2205p.m8585b(this.f5191a.m12772i(), this.f5192b));
                JSONObject jSONObject2 = new JSONObject();
                jSONObject2.put("assets", jSONObject);
                jSONObject2.put("template_id", "1");
                this.f5193c.m14968a("google.afma.nativeExpressAds.loadAssets", jSONObject2);
            } catch (Throwable e) {
                wg.m14618c("Exception occurred when loading assets", e);
            }
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.p.3 */
    class C22023 implements nx {
        final /* synthetic */ CountDownLatch f5194a;

        C22023(CountDownLatch countDownLatch) {
            this.f5194a = countDownLatch;
        }

        public void m8564a(wx wxVar, Map<String, String> map) {
            this.f5194a.countDown();
            wxVar.m14970b().setVisibility(0);
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.p.4 */
    class C22034 implements nx {
        final /* synthetic */ CountDownLatch f5195a;

        C22034(CountDownLatch countDownLatch) {
            this.f5195a = countDownLatch;
        }

        public void m8565a(wx wxVar, Map<String, String> map) {
            wg.m14620e("Adapter returned an ad, but assets substitution failed");
            this.f5195a.countDown();
            wxVar.destroy();
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.p.5 */
    class C22045 implements nx {
        final /* synthetic */ qa f5196a;
        final /* synthetic */ C2131a f5197b;
        final /* synthetic */ qb f5198c;

        C22045(qa qaVar, C2131a c2131a, qb qbVar) {
            this.f5196a = qaVar;
            this.f5197b = c2131a;
            this.f5198c = qbVar;
        }

        public void m8566a(wx wxVar, Map<String, String> map) {
            Object b = wxVar.m14970b();
            if (b != null) {
                try {
                    if (this.f5196a != null) {
                        if (this.f5196a.m13533k()) {
                            C2205p.m8586b(wxVar);
                            return;
                        }
                        this.f5196a.m13521a(C2060d.m7973a(b));
                        this.f5197b.m8251a();
                    } else if (this.f5198c == null) {
                    } else {
                        if (this.f5198c.m13566i()) {
                            C2205p.m8586b(wxVar);
                            return;
                        }
                        this.f5198c.m13556a(C2060d.m7973a(b));
                        this.f5197b.m8251a();
                    }
                } catch (Throwable e) {
                    wg.m14618c("Unable to call handleClick on mapper", e);
                }
            }
        }
    }

    public static View m8567a(vb vbVar) {
        if (vbVar == null) {
            wg.m14617c("AdState is null");
            return null;
        } else if (C2205p.m8587b(vbVar) && vbVar.f8981b != null) {
            return vbVar.f8981b.m14970b();
        } else {
            try {
                C2046a a = vbVar.f8995p != null ? vbVar.f8995p.m13441a() : null;
                if (a != null) {
                    return (View) C2060d.m7974a(a);
                }
                wg.m14620e("View in mediation adapter is null.");
                return null;
            } catch (Throwable e) {
                wg.m14618c("Could not get View from mediation adapter.", e);
                return null;
            }
        }
    }

    private static mq m8568a(qa qaVar) {
        return new mq(qaVar.m13520a(), qaVar.m13522b(), qaVar.m13524c(), qaVar.m13526d(), qaVar.m13527e(), qaVar.m13528f(), qaVar.m13529g(), qaVar.m13530h(), null, qaVar.m13534l(), null, null);
    }

    private static mr m8569a(qb qbVar) {
        return new mr(qbVar.m13555a(), qbVar.m13557b(), qbVar.m13559c(), qbVar.m13561d(), qbVar.m13562e(), qbVar.m13563f(), null, qbVar.m13567j(), null, null);
    }

    static nx m8571a(qa qaVar, qb qbVar, C2131a c2131a) {
        return new C22045(qaVar, c2131a, qbVar);
    }

    static nx m8572a(CountDownLatch countDownLatch) {
        return new C22023(countDownLatch);
    }

    private static String m8573a(Bitmap bitmap) {
        OutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        if (bitmap == null) {
            wg.m14620e("Bitmap is null. Returning empty string");
            return BuildConfig.FLAVOR;
        }
        bitmap.compress(CompressFormat.PNG, 100, byteArrayOutputStream);
        String encodeToString = Base64.encodeToString(byteArrayOutputStream.toByteArray(), 0);
        String valueOf = String.valueOf("data:image/png;base64,");
        encodeToString = String.valueOf(encodeToString);
        return encodeToString.length() != 0 ? valueOf.concat(encodeToString) : new String(valueOf);
    }

    static String m8574a(nb nbVar) {
        if (nbVar == null) {
            wg.m14620e("Image is null. Returning empty string");
            return BuildConfig.FLAVOR;
        }
        try {
            Uri b = nbVar.m12710b();
            if (b != null) {
                return b.toString();
            }
        } catch (RemoteException e) {
            wg.m14620e("Unable to get image uri. Trying data uri next");
        }
        return C2205p.m8584b(nbVar);
    }

    public static void m8576a(vb vbVar, C2131a c2131a) {
        qb qbVar = null;
        if (vbVar != null && C2205p.m8587b(vbVar)) {
            wx wxVar = vbVar.f8981b;
            Object b = wxVar != null ? wxVar.m14970b() : null;
            if (b == null) {
                wg.m14620e("AdWebView is null");
                return;
            }
            try {
                List list = vbVar.f8994o != null ? vbVar.f8994o.f8063o : null;
                if (list == null || list.isEmpty()) {
                    wg.m14620e("No template ids present in mediation response");
                    return;
                }
                qa h = vbVar.f8995p != null ? vbVar.f8995p.m13458h() : null;
                if (vbVar.f8995p != null) {
                    qbVar = vbVar.f8995p.m13459i();
                }
                if (list.contains("2") && h != null) {
                    h.m13523b(C2060d.m7973a(b));
                    if (!h.m13532j()) {
                        h.m13531i();
                    }
                    wxVar.m14986l().m15024a("/nativeExpressViewClicked", C2205p.m8571a(h, null, c2131a));
                } else if (!list.contains("1") || qbVar == null) {
                    wg.m14620e("No matching template id and mapper");
                } else {
                    qbVar.m13558b(C2060d.m7973a(b));
                    if (!qbVar.m13565h()) {
                        qbVar.m13564g();
                    }
                    wxVar.m14986l().m15024a("/nativeExpressViewClicked", C2205p.m8571a(null, qbVar, c2131a));
                }
            } catch (Throwable e) {
                wg.m14618c("Error occurred while recording impression and registering for clicks", e);
            }
        }
    }

    private static void m8578a(wx wxVar, mq mqVar, String str) {
        wxVar.m14986l().m15020a(new C22001(mqVar, str, wxVar));
    }

    private static void m8579a(wx wxVar, mr mrVar, String str) {
        wxVar.m14986l().m15020a(new C22012(mrVar, str, wxVar));
    }

    private static void m8580a(wx wxVar, CountDownLatch countDownLatch) {
        wxVar.m14986l().m15024a("/nativeExpressAssetsLoaded", C2205p.m8572a(countDownLatch));
        wxVar.m14986l().m15024a("/nativeExpressAssetsLoadingFailed", C2205p.m8583b(countDownLatch));
    }

    public static boolean m8581a(wx wxVar, pq pqVar, CountDownLatch countDownLatch) {
        boolean z = false;
        try {
            z = C2205p.m8588b(wxVar, pqVar, countDownLatch);
        } catch (Throwable e) {
            wg.m14618c("Unable to invoke load assets", e);
        } catch (RuntimeException e2) {
            countDownLatch.countDown();
            throw e2;
        }
        if (!z) {
            countDownLatch.countDown();
        }
        return z;
    }

    private static nb m8582b(Object obj) {
        return obj instanceof IBinder ? C2765a.m12712a((IBinder) obj) : null;
    }

    static nx m8583b(CountDownLatch countDownLatch) {
        return new C22034(countDownLatch);
    }

    private static String m8584b(nb nbVar) {
        try {
            C2046a a = nbVar.m12709a();
            if (a == null) {
                wg.m14620e("Drawable is null. Returning empty string");
                return BuildConfig.FLAVOR;
            }
            Drawable drawable = (Drawable) C2060d.m7974a(a);
            if (drawable instanceof BitmapDrawable) {
                return C2205p.m8573a(((BitmapDrawable) drawable).getBitmap());
            }
            wg.m14620e("Drawable is not an instance of BitmapDrawable. Returning empty string");
            return BuildConfig.FLAVOR;
        } catch (RemoteException e) {
            wg.m14620e("Unable to get drawable. Returning empty string");
            return BuildConfig.FLAVOR;
        }
    }

    private static JSONObject m8585b(Bundle bundle, String str) {
        JSONObject jSONObject = new JSONObject();
        if (bundle == null || TextUtils.isEmpty(str)) {
            return jSONObject;
        }
        JSONObject jSONObject2 = new JSONObject(str);
        Iterator keys = jSONObject2.keys();
        while (keys.hasNext()) {
            String str2 = (String) keys.next();
            if (bundle.containsKey(str2)) {
                if ("image".equals(jSONObject2.getString(str2))) {
                    Object obj = bundle.get(str2);
                    if (obj instanceof Bitmap) {
                        jSONObject.put(str2, C2205p.m8573a((Bitmap) obj));
                    } else {
                        wg.m14620e("Invalid type. An image type extra should return a bitmap");
                    }
                } else if (bundle.get(str2) instanceof Bitmap) {
                    wg.m14620e("Invalid asset type. Bitmap should be returned only for image type");
                } else {
                    jSONObject.put(str2, String.valueOf(bundle.get(str2)));
                }
            }
        }
        return jSONObject;
    }

    private static void m8586b(wx wxVar) {
        OnClickListener D = wxVar.m14954D();
        if (D != null) {
            D.onClick(wxVar.m14970b());
        }
    }

    public static boolean m8587b(vb vbVar) {
        return (vbVar == null || !vbVar.f8993n || vbVar.f8994o == null || vbVar.f8994o.f8060l == null) ? false : true;
    }

    private static boolean m8588b(wx wxVar, pq pqVar, CountDownLatch countDownLatch) {
        View b = wxVar.m14970b();
        if (b == null) {
            wg.m14620e("AdWebView is null");
            return false;
        }
        b.setVisibility(4);
        List list = pqVar.f8106b.f8063o;
        if (list == null || list.isEmpty()) {
            wg.m14620e("No template ids present in mediation response");
            return false;
        }
        C2205p.m8580a(wxVar, countDownLatch);
        qa h = pqVar.f8107c.m13458h();
        qb i = pqVar.f8107c.m13459i();
        if (list.contains("2") && h != null) {
            C2205p.m8578a(wxVar, C2205p.m8568a(h), pqVar.f8106b.f8062n);
        } else if (!list.contains("1") || i == null) {
            wg.m14620e("No matching template id and mapper");
            return false;
        } else {
            C2205p.m8579a(wxVar, C2205p.m8569a(i), pqVar.f8106b.f8062n);
        }
        String str = pqVar.f8106b.f8060l;
        String str2 = pqVar.f8106b.f8061m;
        if (str2 != null) {
            wxVar.loadDataWithBaseURL(str2, str, "text/html", HttpRequest.CHARSET, null);
        } else {
            wxVar.loadData(str, "text/html", HttpRequest.CHARSET);
        }
        return true;
    }
}
