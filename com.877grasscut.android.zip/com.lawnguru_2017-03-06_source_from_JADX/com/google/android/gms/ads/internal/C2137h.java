package com.google.android.gms.ads.internal;

import android.content.Context;
import android.text.TextUtils;
import com.google.android.gms.p095b.ly;
import com.google.android.gms.p095b.nx;
import com.google.android.gms.p095b.pd;
import com.google.android.gms.p095b.pe;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.vd;
import com.google.android.gms.p095b.vo;
import com.google.android.gms.p095b.wg;
import com.google.android.gms.p095b.wi;
import com.google.android.gms.p095b.wq.C2134c;
import com.google.android.gms.p095b.wq.C3107b;
import com.google.android.gms.p095b.wx;
import java.util.Map;
import org.json.JSONObject;

@sc
/* renamed from: com.google.android.gms.ads.internal.h */
public class C2137h {
    private final Object f4957a;
    private Context f4958b;

    /* renamed from: com.google.android.gms.ads.internal.h.1 */
    class C21331 implements nx {
        final /* synthetic */ Runnable f4948a;
        final /* synthetic */ C2137h f4949b;

        C21331(C2137h c2137h, Runnable runnable) {
            this.f4949b = c2137h;
            this.f4948a = runnable;
        }

        public void m8265a(wx wxVar, Map<String, String> map) {
            wxVar.m13268b("/appSettingsFetched", (nx) this);
            synchronized (this.f4949b.f4957a) {
                if (map != null) {
                    if ("true".equalsIgnoreCase((String) map.get("isSuccessful"))) {
                        C2243w.m8790i().m14575d(this.f4949b.f4958b, (String) map.get("appSettingsJson"));
                        try {
                            if (this.f4948a != null) {
                                this.f4948a.run();
                            }
                        } catch (Throwable th) {
                            C2243w.m8790i().m14562a(th, "ConfigLoader.maybeFetchNewAppSettings");
                            wg.m14618c("ConfigLoader post task failed.", th);
                        }
                    }
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.h.2 */
    class C21362 implements Runnable {
        final /* synthetic */ pd f4951a;
        final /* synthetic */ nx f4952b;
        final /* synthetic */ String f4953c;
        final /* synthetic */ String f4954d;
        final /* synthetic */ boolean f4955e;
        final /* synthetic */ Context f4956f;

        /* renamed from: com.google.android.gms.ads.internal.h.2.1 */
        class C21351 implements C2134c<pe> {
            final /* synthetic */ C21362 f4950a;

            C21351(C21362 c21362) {
                this.f4950a = c21362;
            }

            public void m8267a(pe peVar) {
                peVar.m13265a("/appSettingsFetched", this.f4950a.f4952b);
                try {
                    JSONObject jSONObject = new JSONObject();
                    if (!TextUtils.isEmpty(this.f4950a.f4953c)) {
                        jSONObject.put("app_id", this.f4950a.f4953c);
                    } else if (!TextUtils.isEmpty(this.f4950a.f4954d)) {
                        jSONObject.put("ad_unit_id", this.f4950a.f4954d);
                    }
                    jSONObject.put("is_init", this.f4950a.f4955e);
                    jSONObject.put("pn", this.f4950a.f4956f.getPackageName());
                    peVar.m13267a("AFMA_fetchAppSettings", jSONObject);
                } catch (Throwable e) {
                    peVar.m13268b("/appSettingsFetched", this.f4950a.f4952b);
                    wg.m14616b("Error requesting application settings", e);
                }
            }

            public /* synthetic */ void m8268a(Object obj) {
                m8267a((pe) obj);
            }
        }

        C21362(C2137h c2137h, pd pdVar, nx nxVar, String str, String str2, boolean z, Context context) {
            this.f4951a = pdVar;
            this.f4952b = nxVar;
            this.f4953c = str;
            this.f4954d = str2;
            this.f4955e = z;
            this.f4956f = context;
        }

        public void run() {
            this.f4951a.m13347a().m13319a(new C21351(this), new C3107b());
        }
    }

    public C2137h() {
        this.f4957a = new Object();
    }

    private static boolean m8270a(vd vdVar) {
        if (vdVar == null) {
            return true;
        }
        boolean z = (((C2243w.m8792k().m16301a() - vdVar.m14543a()) > ((Long) ly.cF.m12563c()).longValue() ? 1 : ((C2243w.m8792k().m16301a() - vdVar.m14543a()) == ((Long) ly.cF.m12563c()).longValue() ? 0 : -1)) > 0) || !vdVar.m14544b();
        return z;
    }

    public void m8272a(Context context, wi wiVar, String str, vd vdVar) {
        m8274a(context, wiVar, false, vdVar, vdVar != null ? null : vdVar.m14546d(), str, null);
    }

    public void m8273a(Context context, wi wiVar, String str, Runnable runnable) {
        m8274a(context, wiVar, true, null, str, null, runnable);
    }

    void m8274a(Context context, wi wiVar, boolean z, vd vdVar, String str, String str2, Runnable runnable) {
        if (!C2137h.m8270a(vdVar)) {
            return;
        }
        if (context == null) {
            wg.m14620e("Context not provided to fetch application settings");
        } else if (TextUtils.isEmpty(str) && TextUtils.isEmpty(str2)) {
            wg.m14620e("App settings could not be fetched. Required parameters missing");
        } else {
            this.f4958b = context;
            vo.f9130a.post(new C21362(this, C2243w.m8786e().m14695a(context, wiVar), new C21331(this, runnable), str, str2, z, context));
        }
    }
}
