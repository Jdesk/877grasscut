package com.google.android.gms.ads.internal.purchase;

import android.content.Intent;

/* renamed from: com.google.android.gms.ads.internal.purchase.j */
public interface C2113j {
    void m8183a(String str, boolean z, int i, Intent intent, C2214f c2214f);
}
