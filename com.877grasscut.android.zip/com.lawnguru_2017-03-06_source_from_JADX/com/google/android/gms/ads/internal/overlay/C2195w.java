package com.google.android.gms.ads.internal.overlay;

import android.app.Activity;
import android.widget.RelativeLayout;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.wx;

@sc
/* renamed from: com.google.android.gms.ads.internal.overlay.w */
public class C2195w implements C2188p {
    public C2187o m8552a(Activity activity, wx wxVar, RelativeLayout relativeLayout) {
        return new C2194v();
    }
}
