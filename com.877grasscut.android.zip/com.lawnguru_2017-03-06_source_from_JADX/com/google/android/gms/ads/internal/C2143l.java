package com.google.android.gms.ads.internal;

import android.content.Context;
import android.support.v4.util.SimpleArrayMap;
import android.text.TextUtils;
import com.google.android.gms.p095b.kn;
import com.google.android.gms.p095b.ko;
import com.google.android.gms.p095b.kp.C2142a;
import com.google.android.gms.p095b.kv;
import com.google.android.gms.p095b.my;
import com.google.android.gms.p095b.nk;
import com.google.android.gms.p095b.nl;
import com.google.android.gms.p095b.nm;
import com.google.android.gms.p095b.nn;
import com.google.android.gms.p095b.pw;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.wi;

@sc
/* renamed from: com.google.android.gms.ads.internal.l */
public class C2143l extends C2142a {
    private kn f4980a;
    private nk f4981b;
    private nl f4982c;
    private SimpleArrayMap<String, nm> f4983d;
    private SimpleArrayMap<String, nn> f4984e;
    private my f4985f;
    private kv f4986g;
    private final Context f4987h;
    private final pw f4988i;
    private final String f4989j;
    private final wi f4990k;
    private final C2124e f4991l;

    public C2143l(Context context, String str, pw pwVar, wi wiVar, C2124e c2124e) {
        this.f4987h = context;
        this.f4989j = str;
        this.f4988i = pwVar;
        this.f4990k = wiVar;
        this.f4984e = new SimpleArrayMap();
        this.f4983d = new SimpleArrayMap();
        this.f4991l = c2124e;
    }

    public ko m8317a() {
        return new C2141k(this.f4987h, this.f4989j, this.f4988i, this.f4990k, this.f4980a, this.f4981b, this.f4982c, this.f4984e, this.f4983d, this.f4985f, this.f4986g, this.f4991l);
    }

    public void m8318a(kn knVar) {
        this.f4980a = knVar;
    }

    public void m8319a(kv kvVar) {
        this.f4986g = kvVar;
    }

    public void m8320a(my myVar) {
        this.f4985f = myVar;
    }

    public void m8321a(nk nkVar) {
        this.f4981b = nkVar;
    }

    public void m8322a(nl nlVar) {
        this.f4982c = nlVar;
    }

    public void m8323a(String str, nn nnVar, nm nmVar) {
        if (TextUtils.isEmpty(str)) {
            throw new IllegalArgumentException("Custom template ID for native custom template ad is empty. Please provide a valid template id.");
        }
        this.f4984e.put(str, nnVar);
        this.f4983d.put(str, nmVar);
    }
}
