package com.google.android.gms.ads.internal;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.p095b.ke;
import com.google.android.gms.p095b.ly;
import com.google.android.gms.p095b.mg;
import com.google.android.gms.p095b.mh;
import com.google.android.gms.p095b.mj;
import com.google.android.gms.p095b.mk;
import com.google.android.gms.p095b.nx;
import com.google.android.gms.p095b.pe;
import com.google.android.gms.p095b.pw;
import com.google.android.gms.p095b.qt;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.us;
import com.google.android.gms.p095b.vb;
import com.google.android.gms.p095b.vb.C3048a;
import com.google.android.gms.p095b.vo;
import com.google.android.gms.p095b.wg;
import com.google.android.gms.p095b.wi;
import com.google.android.gms.p095b.wx;
import java.util.Map;

@sc
/* renamed from: com.google.android.gms.ads.internal.c */
public abstract class C2122c extends C2115b implements C2121i, qt {

    /* renamed from: com.google.android.gms.ads.internal.c.1 */
    class C21161 implements nx {
        final /* synthetic */ C2122c f4925a;

        C21161(C2122c c2122c) {
            this.f4925a = c2122c;
        }

        public void m8225a(wx wxVar, Map<String, String> map) {
            if (this.f4925a.f.f5355j != null) {
                this.f4925a.h.m11922a(this.f4925a.f.f5354i, this.f4925a.f.f5355j, wxVar.m14970b(), (pe) wxVar);
            } else {
                wg.m14620e("Request to enable ActiveView before adState is available.");
            }
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.c.2 */
    class C21172 implements Runnable {
        final /* synthetic */ C3048a f4926a;
        final /* synthetic */ C2122c f4927b;

        C21172(C2122c c2122c, C3048a c3048a) {
            this.f4927b = c2122c;
            this.f4926a = c3048a;
        }

        public void run() {
            this.f4927b.m8215b(new vb(this.f4926a, null, null, null, null, null, null, null));
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.c.3 */
    class C21203 implements Runnable {
        final /* synthetic */ C3048a f4930a;
        final /* synthetic */ us f4931b;
        final /* synthetic */ mg f4932c;
        final /* synthetic */ C2122c f4933d;

        /* renamed from: com.google.android.gms.ads.internal.c.3.1 */
        class C21181 implements OnTouchListener {
            final /* synthetic */ C2125f f4928a;

            C21181(C21203 c21203, C2125f c2125f) {
                this.f4928a = c2125f;
            }

            public boolean onTouch(View view, MotionEvent motionEvent) {
                this.f4928a.m8244a();
                return false;
            }
        }

        /* renamed from: com.google.android.gms.ads.internal.c.3.2 */
        class C21192 implements OnClickListener {
            final /* synthetic */ C2125f f4929a;

            C21192(C21203 c21203, C2125f c2125f) {
                this.f4929a = c2125f;
            }

            public void onClick(View view) {
                this.f4929a.m8244a();
            }
        }

        C21203(C2122c c2122c, C3048a c3048a, us usVar, mg mgVar) {
            this.f4933d = c2122c;
            this.f4930a = c3048a;
            this.f4931b = usVar;
            this.f4932c = mgVar;
        }

        public void run() {
            if (this.f4930a.f8964b.f8617s && this.f4933d.f.f5371z != null) {
                String str = null;
                if (this.f4930a.f8964b.f8600b != null) {
                    str = C2243w.m8786e().m14701a(this.f4930a.f8964b.f8600b);
                }
                mj mhVar = new mh(this.f4933d, str, this.f4930a.f8964b.f8601c);
                this.f4933d.f.f5336F = 1;
                try {
                    this.f4933d.d = false;
                    this.f4933d.f.f5371z.m12687a(mhVar);
                    return;
                } catch (Throwable e) {
                    wg.m14618c("Could not call the onCustomRenderedAdLoadedListener.", e);
                    this.f4933d.d = true;
                }
            }
            C2125f c2125f = new C2125f(this.f4933d.f.f5348c, this.f4930a);
            wx a = this.f4933d.m8234a(this.f4930a, c2125f, this.f4931b);
            a.setOnTouchListener(new C21181(this, c2125f));
            a.setOnClickListener(new C21192(this, c2125f));
            this.f4933d.f.f5336F = 0;
            this.f4933d.f.f5353h = C2243w.m8785d().m13884a(this.f4933d.f.f5348c, this.f4933d, this.f4930a, this.f4933d.f.f5349d, a, this.f4933d.j, this.f4933d, this.f4932c);
        }
    }

    public C2122c(Context context, ke keVar, String str, pw pwVar, wi wiVar, C2124e c2124e) {
        super(context, keVar, str, pwVar, wiVar, c2124e);
    }

    public void m8231K() {
        m8219e();
    }

    public void m8232L() {
        m8199F();
        m8164m();
    }

    public void m8233M() {
        m8170s();
    }

    protected wx m8234a(C3048a c3048a, C2125f c2125f, us usVar) {
        wx wxVar = null;
        View nextView = this.f.f5351f.getNextView();
        if (nextView instanceof wx) {
            wxVar = (wx) nextView;
            if (((Boolean) ly.aC.m12563c()).booleanValue()) {
                wg.m14615b("Reusing webview...");
                wxVar.m14960a(this.f.f5348c, this.f.f5354i, this.a);
            } else {
                wxVar.destroy();
                wxVar = null;
            }
        }
        if (wxVar == null) {
            if (nextView != null) {
                this.f.f5351f.removeView(nextView);
            }
            wxVar = C2243w.m8787f().m15047a(this.f.f5348c, this.f.f5354i, false, false, this.f.f5349d, this.f.f5350e, this.a, this, this.i);
            if (this.f.f5354i.f7389g == null) {
                m8126a(wxVar.m14970b());
            }
        }
        pe peVar = wxVar;
        peVar.m14986l().m15018a(this, this, this, this, false, this, null, c2125f, this, usVar);
        m8237a(peVar);
        peVar.m14973b(c3048a.f8963a.f8576v);
        return peVar;
    }

    public void m8235a(int i, int i2, int i3, int i4) {
        m8172u();
    }

    public void m8236a(mk mkVar) {
        C3234c.m16050b("setOnCustomRenderedAdLoadedListener must be called on the main UI thread.");
        this.f.f5371z = mkVar;
    }

    protected void m8237a(pe peVar) {
        peVar.m13265a("/trackActiveViewUnit", new C21161(this));
    }

    protected void m8238a(C3048a c3048a, mg mgVar) {
        if (c3048a.f8967e != -2) {
            vo.f9130a.post(new C21172(this, c3048a));
            return;
        }
        if (c3048a.f8966d != null) {
            this.f.f5354i = c3048a.f8966d;
        }
        if (!c3048a.f8964b.f8606h || c3048a.f8964b.f8583B) {
            vo.f9130a.post(new C21203(this, c3048a, null, mgVar));
            return;
        }
        this.f.f5336F = 0;
        this.f.f5353h = C2243w.m8785d().m13884a(this.f.f5348c, this, c3048a, this.f.f5349d, null, this.j, this, mgVar);
    }

    protected boolean m8239a(vb vbVar, vb vbVar2) {
        if (this.f.m8820e() && this.f.f5351f != null) {
            this.f.f5351f.m8808a().m14828c(vbVar2.f8973C);
        }
        return super.m8213a(vbVar, vbVar2);
    }

    public void m8240b(View view) {
        this.f.f5335E = view;
        m8215b(new vb(this.f.f5356k, null, null, null, null, null, null, null));
    }
}
