package com.google.android.gms.ads.internal.purchase;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import com.google.android.gms.ads.internal.C2243w;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.stats.C3286a;
import com.google.android.gms.p095b.re.C2215a;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.wg;

@sc
/* renamed from: com.google.android.gms.ads.internal.purchase.g */
public final class C2216g extends C2215a implements ServiceConnection {
    C2207b f5233a;
    private boolean f5234b;
    private Context f5235c;
    private int f5236d;
    private Intent f5237e;
    private C2214f f5238f;
    private String f5239g;

    public C2216g(Context context, String str, boolean z, int i, Intent intent, C2214f c2214f) {
        this.f5234b = false;
        this.f5239g = str;
        this.f5236d = i;
        this.f5237e = intent;
        this.f5234b = z;
        this.f5235c = context;
        this.f5238f = c2214f;
    }

    public boolean m8636a() {
        return this.f5234b;
    }

    public String m8637b() {
        return this.f5239g;
    }

    public Intent m8638c() {
        return this.f5237e;
    }

    public int m8639d() {
        return this.f5236d;
    }

    public void m8640e() {
        int a = C2243w.m8800s().m8650a(this.f5237e);
        if (this.f5236d == -1 && a == 0) {
            this.f5233a = new C2207b(this.f5235c);
            Intent intent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
            intent.setPackage(GooglePlayServicesUtil.GOOGLE_PLAY_STORE_PACKAGE);
            C3286a.m16282a().m16286a(this.f5235c, intent, (ServiceConnection) this, 1);
        }
    }

    public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        wg.m14619d("In-app billing service connected.");
        this.f5233a.m8602a(iBinder);
        String b = C2243w.m8800s().m8656b(C2243w.m8800s().m8655b(this.f5237e));
        if (b != null) {
            if (this.f5233a.m8599a(this.f5235c.getPackageName(), b) == 0) {
                C2218h.m8641a(this.f5235c).m8646a(this.f5238f);
            }
            C3286a.m16282a().m16284a(this.f5235c, (ServiceConnection) this);
            this.f5233a.m8601a();
        }
    }

    public void onServiceDisconnected(ComponentName componentName) {
        wg.m14619d("In-app billing service disconnected.");
        this.f5233a.m8601a();
    }
}
