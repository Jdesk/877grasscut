package com.google.android.gms.ads.internal;

import com.google.android.gms.p095b.sc;

@sc
/* renamed from: com.google.android.gms.ads.internal.r */
public class C2228r {
    public C2227q m8683a() {
        return C2227q.m8671a();
    }
}
