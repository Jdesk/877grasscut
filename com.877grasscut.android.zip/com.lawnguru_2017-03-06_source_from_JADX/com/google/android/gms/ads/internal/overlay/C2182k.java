package com.google.android.gms.ads.internal.overlay;

/* renamed from: com.google.android.gms.ads.internal.overlay.k */
public interface C2182k {
    void m8502a();

    void m8503a(int i, int i2);

    void m8504a(String str, String str2);

    void m8505b();

    void m8506c();

    void m8507d();

    void m8508e();

    void m8509f();

    void m8510g();
}
