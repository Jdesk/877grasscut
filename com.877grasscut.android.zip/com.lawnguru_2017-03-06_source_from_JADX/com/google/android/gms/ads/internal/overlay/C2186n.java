package com.google.android.gms.ads.internal.overlay;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.support.v4.app.ad;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.android.gms.ads.internal.C2243w;
import com.google.android.gms.common.internal.C3243l;
import com.google.android.gms.p095b.ly;
import com.google.android.gms.p095b.mg;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.vk;
import com.google.android.gms.p095b.vo;
import com.google.android.gms.p095b.wg;
import com.google.android.gms.p095b.wx;
import java.util.HashMap;
import java.util.Map;

@sc
/* renamed from: com.google.android.gms.ads.internal.overlay.n */
public class C2186n extends FrameLayout implements C2182k {
    private final wx f5153a;
    private final FrameLayout f5154b;
    private final mg f5155c;
    private final C2154b f5156d;
    private final long f5157e;
    private C2167l f5158f;
    private boolean f5159g;
    private boolean f5160h;
    private boolean f5161i;
    private boolean f5162j;
    private long f5163k;
    private long f5164l;
    private String f5165m;
    private Bitmap f5166n;
    private ImageView f5167o;
    private boolean f5168p;

    /* renamed from: com.google.android.gms.ads.internal.overlay.n.1 */
    class C21841 implements Runnable {
        final /* synthetic */ C2186n f5151a;

        C21841(C2186n c2186n) {
            this.f5151a = c2186n;
        }

        public void run() {
            this.f5151a.m8516a("surfaceCreated", new String[0]);
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.overlay.n.2 */
    class C21852 implements Runnable {
        final /* synthetic */ C2186n f5152a;

        C21852(C2186n c2186n) {
            this.f5152a = c2186n;
        }

        public void run() {
            this.f5152a.m8516a("surfaceDestroyed", new String[0]);
        }
    }

    public C2186n(Context context, wx wxVar, int i, boolean z, mg mgVar) {
        super(context);
        this.f5153a = wxVar;
        this.f5155c = mgVar;
        this.f5154b = new FrameLayout(context);
        addView(this.f5154b, new LayoutParams(-1, -1));
        C3243l.m16076a(wxVar.m14982h());
        this.f5158f = wxVar.m14982h().f4935b.m8511a(context, wxVar, i, z, mgVar);
        if (this.f5158f != null) {
            this.f5154b.addView(this.f5158f, new LayoutParams(-1, -1, 17));
            if (((Boolean) ly.f7565A.m12563c()).booleanValue()) {
                m8544m();
            }
        }
        this.f5167o = new ImageView(context);
        this.f5157e = ((Long) ly.f7569E.m12563c()).longValue();
        this.f5162j = ((Boolean) ly.f7567C.m12563c()).booleanValue();
        if (this.f5155c != null) {
            this.f5155c.m12664a("spinner_used", this.f5162j ? "1" : "0");
        }
        this.f5156d = new C2154b(this);
        if (this.f5158f != null) {
            this.f5158f.m8423a((C2182k) this);
        }
        if (this.f5158f == null) {
            m8532a("AdVideoUnderlay Error", "Allocating player failed.");
        }
    }

    public static void m8515a(wx wxVar) {
        Map hashMap = new HashMap();
        hashMap.put(ad.CATEGORY_EVENT, "no_video_view");
        wxVar.m14967a("onVideoEvent", hashMap);
    }

    private void m8516a(String str, String... strArr) {
        Map hashMap = new HashMap();
        hashMap.put(ad.CATEGORY_EVENT, str);
        int length = strArr.length;
        int i = 0;
        Object obj = null;
        while (i < length) {
            Object obj2 = strArr[i];
            if (obj != null) {
                hashMap.put(obj, obj2);
                obj2 = null;
            }
            i++;
            obj = obj2;
        }
        this.f5153a.m14967a("onVideoEvent", hashMap);
    }

    private void m8517b(int i, int i2) {
        if (this.f5162j) {
            int max = Math.max(i / ((Integer) ly.f7568D.m12563c()).intValue(), 1);
            int max2 = Math.max(i2 / ((Integer) ly.f7568D.m12563c()).intValue(), 1);
            if (this.f5166n == null || this.f5166n.getWidth() != max || this.f5166n.getHeight() != max2) {
                this.f5166n = Bitmap.createBitmap(max, max2, Config.ARGB_8888);
                this.f5168p = false;
            }
        }
    }

    @TargetApi(14)
    private void m8518p() {
        if (this.f5166n != null) {
            long b = C2243w.m8792k().m16302b();
            if (this.f5158f.getBitmap(this.f5166n) != null) {
                this.f5168p = true;
            }
            b = C2243w.m8792k().m16302b() - b;
            if (vk.m14623b()) {
                vk.m14621a("Spinner frame grab took " + b + "ms");
            }
            if (b > this.f5157e) {
                wg.m14620e("Spinner frame grab crossed jank threshold! Suspending spinner.");
                this.f5162j = false;
                this.f5166n = null;
                if (this.f5155c != null) {
                    this.f5155c.m12664a("spinner_jank", Long.toString(b));
                }
            }
        }
    }

    private void m8519q() {
        if (this.f5168p && this.f5166n != null && !m8521s()) {
            this.f5167o.setImageBitmap(this.f5166n);
            this.f5167o.invalidate();
            this.f5154b.addView(this.f5167o, new LayoutParams(-1, -1));
            this.f5154b.bringChildToFront(this.f5167o);
        }
    }

    private void m8520r() {
        if (m8521s()) {
            this.f5154b.removeView(this.f5167o);
        }
    }

    private boolean m8521s() {
        return this.f5167o.getParent() != null;
    }

    private void m8522t() {
        if (this.f5153a.m14980f() != null && !this.f5160h) {
            this.f5161i = (this.f5153a.m14980f().getWindow().getAttributes().flags & ad.FLAG_HIGH_PRIORITY) != 0;
            if (!this.f5161i) {
                this.f5153a.m14980f().getWindow().addFlags(ad.FLAG_HIGH_PRIORITY);
                this.f5160h = true;
            }
        }
    }

    private void m8523u() {
        if (this.f5153a.m14980f() != null && this.f5160h && !this.f5161i) {
            this.f5153a.m14980f().getWindow().clearFlags(ad.FLAG_HIGH_PRIORITY);
            this.f5160h = false;
        }
    }

    public void m8524a() {
        this.f5156d.m8406b();
        vo.f9130a.post(new C21841(this));
    }

    public void m8525a(float f) {
        if (this.f5158f != null) {
            this.f5158f.m8420a(f);
        }
    }

    public void m8526a(float f, float f2) {
        if (this.f5158f != null) {
            this.f5158f.m8421a(f, f2);
        }
    }

    public void m8527a(int i) {
        if (this.f5158f != null) {
            this.f5158f.m8422a(i);
        }
    }

    public void m8528a(int i, int i2) {
        m8517b(i, i2);
    }

    public void m8529a(int i, int i2, int i3, int i4) {
        if (i3 != 0 && i4 != 0) {
            ViewGroup.LayoutParams layoutParams = new LayoutParams(i3, i4);
            layoutParams.setMargins(i, i2, 0, 0);
            this.f5154b.setLayoutParams(layoutParams);
            requestLayout();
        }
    }

    @TargetApi(14)
    public void m8530a(MotionEvent motionEvent) {
        if (this.f5158f != null) {
            this.f5158f.dispatchTouchEvent(motionEvent);
        }
    }

    public void m8531a(String str) {
        this.f5165m = str;
    }

    public void m8532a(String str, String str2) {
        m8516a("error", "what", str, "extra", str2);
    }

    public void m8533b() {
        if (this.f5158f != null && this.f5164l == 0) {
            float duration = ((float) this.f5158f.getDuration()) / 1000.0f;
            int videoWidth = this.f5158f.getVideoWidth();
            int videoHeight = this.f5158f.getVideoHeight();
            m8516a("canplaythrough", "duration", String.valueOf(duration), "videoWidth", String.valueOf(videoWidth), "videoHeight", String.valueOf(videoHeight));
        }
    }

    public void m8534c() {
        m8522t();
        this.f5159g = true;
    }

    public void m8535d() {
        m8516a("pause", new String[0]);
        m8523u();
        this.f5159g = false;
    }

    public void m8536e() {
        m8516a("ended", new String[0]);
        m8523u();
    }

    public void m8537f() {
        m8519q();
        this.f5156d.m8405a();
        this.f5164l = this.f5163k;
        vo.f9130a.post(new C21852(this));
    }

    public void m8538g() {
        if (this.f5159g) {
            m8520r();
        }
        m8518p();
    }

    public void m8539h() {
        if (this.f5158f != null) {
            if (TextUtils.isEmpty(this.f5165m)) {
                m8516a("no_src", new String[0]);
            } else {
                this.f5158f.setVideoPath(this.f5165m);
            }
        }
    }

    public void m8540i() {
        if (this.f5158f != null) {
            this.f5158f.m8427e();
        }
    }

    public void m8541j() {
        if (this.f5158f != null) {
            this.f5158f.m8426d();
        }
    }

    public void m8542k() {
        if (this.f5158f != null) {
            this.f5158f.m8428f();
        }
    }

    public void m8543l() {
        if (this.f5158f != null) {
            this.f5158f.m8429g();
        }
    }

    @TargetApi(14)
    public void m8544m() {
        if (this.f5158f != null) {
            View textView = new TextView(this.f5158f.getContext());
            String str = "AdMob - ";
            String valueOf = String.valueOf(this.f5158f.m8424b());
            textView.setText(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
            textView.setTextColor(-65536);
            textView.setBackgroundColor(-256);
            this.f5154b.addView(textView, new LayoutParams(-2, -2, 17));
            this.f5154b.bringChildToFront(textView);
        }
    }

    public void m8545n() {
        this.f5156d.m8405a();
        if (this.f5158f != null) {
            this.f5158f.m8425c();
        }
        m8523u();
    }

    void m8546o() {
        if (this.f5158f != null) {
            long currentPosition = (long) this.f5158f.getCurrentPosition();
            if (this.f5163k != currentPosition && currentPosition > 0) {
                float f = ((float) currentPosition) / 1000.0f;
                m8516a("timeupdate", "time", String.valueOf(f));
                this.f5163k = currentPosition;
            }
        }
    }
}
