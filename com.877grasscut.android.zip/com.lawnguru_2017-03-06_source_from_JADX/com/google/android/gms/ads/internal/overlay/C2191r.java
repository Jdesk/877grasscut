package com.google.android.gms.ads.internal.overlay;

import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageButton;
import com.google.android.gms.p095b.kj;
import com.google.android.gms.p095b.sc;

@sc
/* renamed from: com.google.android.gms.ads.internal.overlay.r */
public class C2191r extends FrameLayout implements OnClickListener {
    private final ImageButton f5174a;
    private final C2178x f5175b;

    /* renamed from: com.google.android.gms.ads.internal.overlay.r.a */
    static class C2190a {
        public int f5169a;
        public int f5170b;
        public int f5171c;
        public int f5172d;
        public int f5173e;

        C2190a() {
            this.f5169a = 0;
            this.f5170b = 0;
            this.f5171c = 0;
            this.f5172d = 0;
            this.f5173e = 32;
        }
    }

    public C2191r(Context context, C2190a c2190a, C2178x c2178x) {
        super(context);
        this.f5175b = c2178x;
        setOnClickListener(this);
        this.f5174a = new ImageButton(context);
        this.f5174a.setImageResource(17301527);
        this.f5174a.setBackgroundColor(0);
        this.f5174a.setOnClickListener(this);
        this.f5174a.setPadding(kj.m12293a().m14895a(context, c2190a.f5169a), kj.m12293a().m14895a(context, 0), kj.m12293a().m14895a(context, c2190a.f5170b), kj.m12293a().m14895a(context, c2190a.f5172d));
        this.f5174a.setContentDescription("Interstitial close button");
        kj.m12293a().m14895a(context, c2190a.f5173e);
        addView(this.f5174a, new LayoutParams(kj.m12293a().m14895a(context, (c2190a.f5173e + c2190a.f5169a) + c2190a.f5170b), kj.m12293a().m14895a(context, (c2190a.f5173e + 0) + c2190a.f5172d), 17));
    }

    public void m8549a(boolean z, boolean z2) {
        if (!z2) {
            this.f5174a.setVisibility(0);
        } else if (z) {
            this.f5174a.setVisibility(4);
        } else {
            this.f5174a.setVisibility(8);
        }
    }

    public void onClick(View view) {
        if (this.f5175b != null) {
            this.f5175b.m8465c();
        }
    }
}
