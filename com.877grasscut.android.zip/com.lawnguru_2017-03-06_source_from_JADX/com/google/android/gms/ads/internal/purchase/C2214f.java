package com.google.android.gms.ads.internal.purchase;

import com.google.android.gms.p095b.sc;

@sc
/* renamed from: com.google.android.gms.ads.internal.purchase.f */
public final class C2214f {
    public long f5230a;
    public final String f5231b;
    public final String f5232c;

    public C2214f(long j, String str, String str2) {
        this.f5230a = j;
        this.f5232c = str;
        this.f5231b = str2;
    }

    public C2214f(String str, String str2) {
        this(-1, str, str2);
    }
}
