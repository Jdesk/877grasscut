package com.google.android.gms.ads.internal.overlay;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import com.google.android.gms.ads.internal.C2243w;
import com.google.android.gms.common.util.C3303m;
import com.google.android.gms.p095b.sc;

@sc
/* renamed from: com.google.android.gms.ads.internal.overlay.h */
public class C2180h {
    public void m8497a(Context context, AdOverlayInfoParcel adOverlayInfoParcel) {
        m8498a(context, adOverlayInfoParcel, true);
    }

    public void m8498a(Context context, AdOverlayInfoParcel adOverlayInfoParcel, boolean z) {
        if (adOverlayInfoParcel.f5022k == 4 && adOverlayInfoParcel.f5014c == null) {
            if (adOverlayInfoParcel.f5013b != null) {
                adOverlayInfoParcel.f5013b.m7875e();
            }
            C2243w.m8783b().m8371a(context, adOverlayInfoParcel.f5012a, adOverlayInfoParcel.f5020i);
            return;
        }
        Intent intent = new Intent();
        intent.setClassName(context, "com.google.android.gms.ads.AdActivity");
        intent.putExtra("com.google.android.gms.ads.internal.overlay.useClientJar", adOverlayInfoParcel.f5024m.f9230d);
        intent.putExtra("shouldCallOnOverlayOpened", z);
        AdOverlayInfoParcel.m8363a(intent, adOverlayInfoParcel);
        if (!C3303m.m16345i()) {
            intent.addFlags(524288);
        }
        if (!(context instanceof Activity)) {
            intent.addFlags(268435456);
        }
        C2243w.m8786e().m14709a(context, intent);
    }
}
