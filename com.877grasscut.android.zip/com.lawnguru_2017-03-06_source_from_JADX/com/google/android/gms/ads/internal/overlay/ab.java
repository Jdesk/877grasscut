package com.google.android.gms.ads.internal.overlay;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.ad;
import android.text.TextUtils;
import android.view.TextureView;
import com.google.android.gms.ads.internal.C2243w;
import com.google.android.gms.p095b.ly;
import com.google.android.gms.p095b.mc;
import com.google.android.gms.p095b.me;
import com.google.android.gms.p095b.mg;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.vu;
import com.google.android.gms.p095b.vu.C3090a;
import com.google.android.gms.p095b.vu.C3091b;
import com.google.android.gms.p095b.wg;
import com.google.android.gms.p095b.wi;
import java.util.concurrent.TimeUnit;

@sc
public class ab {
    private final Context f5056a;
    private final String f5057b;
    private final wi f5058c;
    private final me f5059d;
    private final mg f5060e;
    private final vu f5061f;
    private final long[] f5062g;
    private final String[] f5063h;
    private boolean f5064i;
    private boolean f5065j;
    private boolean f5066k;
    private boolean f5067l;
    private boolean f5068m;
    private C2167l f5069n;
    private boolean f5070o;
    private boolean f5071p;
    private long f5072q;

    public ab(Context context, wi wiVar, String str, mg mgVar, me meVar) {
        this.f5061f = new C3091b().m14846a("min_1", Double.MIN_VALUE, 1.0d).m14846a("1_5", 1.0d, 5.0d).m14846a("5_10", 5.0d, 10.0d).m14846a("10_20", 10.0d, 20.0d).m14846a("20_30", 20.0d, 30.0d).m14846a("30_max", 30.0d, Double.MAX_VALUE).m14847a();
        this.f5064i = false;
        this.f5065j = false;
        this.f5066k = false;
        this.f5067l = false;
        this.f5072q = -1;
        this.f5056a = context;
        this.f5058c = wiVar;
        this.f5057b = str;
        this.f5060e = mgVar;
        this.f5059d = meVar;
        String str2 = (String) ly.f7616y.m12563c();
        if (str2 == null) {
            this.f5063h = new String[0];
            this.f5062g = new long[0];
            return;
        }
        String[] split = TextUtils.split(str2, ",");
        this.f5063h = new String[split.length];
        this.f5062g = new long[split.length];
        for (int i = 0; i < split.length; i++) {
            try {
                this.f5062g[i] = Long.parseLong(split[i]);
            } catch (Throwable e) {
                wg.m14618c("Unable to parse frame hash target time number.", e);
                this.f5062g[i] = -1;
            }
        }
    }

    private void m8395c(C2167l c2167l) {
        long longValue = ((Long) ly.f7617z.m12563c()).longValue();
        long currentPosition = (long) c2167l.getCurrentPosition();
        int i = 0;
        while (i < this.f5063h.length) {
            if (this.f5063h[i] == null && longValue > Math.abs(currentPosition - this.f5062g[i])) {
                this.f5063h[i] = m8397a((TextureView) c2167l);
                return;
            }
            i++;
        }
    }

    private void m8396e() {
        if (this.f5066k && !this.f5067l) {
            mc.m12647a(this.f5060e, this.f5059d, "vff2");
            this.f5067l = true;
        }
        long c = C2243w.m8792k().m16303c();
        if (this.f5068m && this.f5071p && this.f5072q != -1) {
            this.f5061f.m14850a(((double) TimeUnit.SECONDS.toNanos(1)) / ((double) (c - this.f5072q)));
        }
        this.f5071p = this.f5068m;
        this.f5072q = c;
    }

    @TargetApi(14)
    String m8397a(TextureView textureView) {
        Bitmap bitmap = textureView.getBitmap(8, 8);
        long j = 0;
        long j2 = 63;
        int i = 0;
        while (i < 8) {
            long j3 = j;
            j = j2;
            for (int i2 = 0; i2 < 8; i2++) {
                int pixel = bitmap.getPixel(i2, i);
                j3 |= (Color.green(pixel) + (Color.blue(pixel) + Color.red(pixel)) > ad.FLAG_HIGH_PRIORITY ? 1 : 0) << ((int) j);
                j--;
            }
            i++;
            j2 = j;
            j = j3;
        }
        return String.format("%016X", new Object[]{Long.valueOf(j)});
    }

    public void m8398a() {
        if (this.f5064i && !this.f5065j) {
            mc.m12647a(this.f5060e, this.f5059d, "vfr2");
            this.f5065j = true;
        }
    }

    public void m8399a(C2167l c2167l) {
        mc.m12647a(this.f5060e, this.f5059d, "vpc2");
        this.f5064i = true;
        if (this.f5060e != null) {
            this.f5060e.m12664a("vpn", c2167l.m8424b());
        }
        this.f5069n = c2167l;
    }

    public void m8400b() {
        if (((Boolean) ly.f7615x.m12563c()).booleanValue() && !this.f5070o) {
            String valueOf;
            String valueOf2;
            Bundle bundle = new Bundle();
            bundle.putString("type", "native-player-metrics");
            bundle.putString("request", this.f5057b);
            bundle.putString("player", this.f5069n.m8424b());
            for (C3090a c3090a : this.f5061f.m14849a()) {
                valueOf = String.valueOf("fps_c_");
                valueOf2 = String.valueOf(c3090a.f9165a);
                bundle.putString(valueOf2.length() != 0 ? valueOf.concat(valueOf2) : new String(valueOf), Integer.toString(c3090a.f9169e));
                valueOf = String.valueOf("fps_p_");
                valueOf2 = String.valueOf(c3090a.f9165a);
                bundle.putString(valueOf2.length() != 0 ? valueOf.concat(valueOf2) : new String(valueOf), Double.toString(c3090a.f9168d));
            }
            for (int i = 0; i < this.f5062g.length; i++) {
                valueOf2 = this.f5063h[i];
                if (valueOf2 != null) {
                    String valueOf3 = String.valueOf("fh_");
                    valueOf = String.valueOf(Long.valueOf(this.f5062g[i]));
                    bundle.putString(new StringBuilder(String.valueOf(valueOf3).length() + String.valueOf(valueOf).length()).append(valueOf3).append(valueOf).toString(), valueOf2);
                }
            }
            C2243w.m8786e().m14712a(this.f5056a, this.f5058c.f9227a, "gmob-apps", bundle, true);
            this.f5070o = true;
        }
    }

    public void m8401b(C2167l c2167l) {
        m8396e();
        m8395c(c2167l);
    }

    public void m8402c() {
        this.f5068m = true;
        if (this.f5065j && !this.f5066k) {
            mc.m12647a(this.f5060e, this.f5059d, "vfp2");
            this.f5066k = true;
        }
    }

    public void m8403d() {
        this.f5068m = false;
    }
}
