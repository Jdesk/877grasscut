package com.google.android.gms.ads.internal.overlay;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import com.google.android.gms.common.util.C3303m;
import com.google.android.gms.p095b.mg;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.wx;

@sc
/* renamed from: com.google.android.gms.ads.internal.overlay.m */
public abstract class C2183m {
    public abstract C2167l m8511a(Context context, wx wxVar, int i, boolean z, mg mgVar);

    protected boolean m8512a(Context context) {
        ApplicationInfo applicationInfo = context.getApplicationInfo();
        C3303m.m16338b();
        return applicationInfo == null || applicationInfo.targetSdkVersion >= 11;
    }

    protected boolean m8513a(wx wxVar) {
        return wxVar.m14985k().f7386d;
    }
}
