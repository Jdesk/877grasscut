package com.google.android.gms.ads.internal.overlay;

/* renamed from: com.google.android.gms.ads.internal.overlay.x */
public interface C2178x {
    void m8465c();
}
