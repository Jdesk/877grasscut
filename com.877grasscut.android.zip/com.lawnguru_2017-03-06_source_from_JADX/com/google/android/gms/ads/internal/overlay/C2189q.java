package com.google.android.gms.ads.internal.overlay;

import android.content.Context;
import com.google.android.gms.p095b.mg;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.wx;

@sc
/* renamed from: com.google.android.gms.ads.internal.overlay.q */
public class C2189q extends C2183m {
    public C2167l m8548a(Context context, wx wxVar, int i, boolean z, mg mgVar) {
        if (!m8512a(context)) {
            return null;
        }
        return new C2168f(context, z, m8513a(wxVar), new ab(context, wxVar.m14989o(), wxVar.m14996v(), mgVar, wxVar.m14998x()));
    }
}
