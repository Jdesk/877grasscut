package com.google.android.gms.ads.internal;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import com.google.android.gms.p095b.cg;
import com.google.android.gms.p095b.fl;
import com.google.android.gms.p095b.kj;
import com.google.android.gms.p095b.ly;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.vn;
import com.google.android.gms.p095b.wg;
import io.card.payment.BuildConfig;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicReference;

@sc
/* renamed from: com.google.android.gms.ads.internal.j */
class C2138j implements cg, Runnable {
    CountDownLatch f4959a;
    private final List<Object[]> f4960b;
    private final AtomicReference<cg> f4961c;
    private C2245x f4962d;

    public C2138j(C2245x c2245x) {
        this.f4960b = new Vector();
        this.f4961c = new AtomicReference();
        this.f4959a = new CountDownLatch(1);
        this.f4962d = c2245x;
        if (kj.m12293a().m14910b()) {
            vn.m14668a((Runnable) this);
        } else {
            run();
        }
    }

    private Context m8279b(Context context) {
        if (!((Boolean) ly.f7604m.m12563c()).booleanValue()) {
            return context;
        }
        Context applicationContext = context.getApplicationContext();
        return applicationContext != null ? applicationContext : context;
    }

    private void m8280b() {
        if (!this.f4960b.isEmpty()) {
            for (Object[] objArr : this.f4960b) {
                if (objArr.length == 1) {
                    ((cg) this.f4961c.get()).m8278a((MotionEvent) objArr[0]);
                } else if (objArr.length == 3) {
                    ((cg) this.f4961c.get()).m8277a(((Integer) objArr[0]).intValue(), ((Integer) objArr[1]).intValue(), ((Integer) objArr[2]).intValue());
                }
            }
            this.f4960b.clear();
        }
    }

    protected cg m8281a(String str, Context context, boolean z) {
        return fl.m11373a(str, context, z);
    }

    public String m8282a(Context context) {
        return m8284a(context, null);
    }

    public String m8283a(Context context, String str, View view) {
        if (m8288a()) {
            cg cgVar = (cg) this.f4961c.get();
            if (cgVar != null) {
                m8280b();
                return cgVar.m8276a(m8279b(context), str, view);
            }
        }
        return BuildConfig.FLAVOR;
    }

    public String m8284a(Context context, byte[] bArr) {
        if (m8288a()) {
            cg cgVar = (cg) this.f4961c.get();
            if (cgVar != null) {
                m8280b();
                return cgVar.m8275a(m8279b(context));
            }
        }
        return BuildConfig.FLAVOR;
    }

    public void m8285a(int i, int i2, int i3) {
        cg cgVar = (cg) this.f4961c.get();
        if (cgVar != null) {
            m8280b();
            cgVar.m8277a(i, i2, i3);
            return;
        }
        this.f4960b.add(new Object[]{Integer.valueOf(i), Integer.valueOf(i2), Integer.valueOf(i3)});
    }

    public void m8286a(MotionEvent motionEvent) {
        cg cgVar = (cg) this.f4961c.get();
        if (cgVar != null) {
            m8280b();
            cgVar.m8278a(motionEvent);
            return;
        }
        this.f4960b.add(new Object[]{motionEvent});
    }

    protected void m8287a(cg cgVar) {
        this.f4961c.set(cgVar);
    }

    protected boolean m8288a() {
        try {
            this.f4959a.await();
            return true;
        } catch (Throwable e) {
            wg.m14618c("Interrupted during GADSignals creation.", e);
            return false;
        }
    }

    public void run() {
        try {
            Object obj = (this.f4962d.f5350e.f9230d || !((Boolean) ly.f7573I.m12563c()).booleanValue()) ? 1 : null;
            boolean z = (((Boolean) ly.aO.m12563c()).booleanValue() || obj == null) ? false : true;
            m8287a(m8281a(this.f4962d.f5350e.f9227a, m8279b(this.f4962d.f5348c), z));
        } finally {
            this.f4959a.countDown();
            this.f4962d = null;
        }
    }
}
