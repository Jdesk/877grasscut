package com.google.android.gms.ads.internal.purchase;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.ads.internal.purchase.a */
public class C2206a implements Creator<GInAppPurchaseManagerInfoParcel> {
    static void m8595a(GInAppPurchaseManagerInfoParcel gInAppPurchaseManagerInfoParcel, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16171a(parcel, 3, gInAppPurchaseManagerInfoParcel.m8592b(), false);
        C3264c.m16171a(parcel, 4, gInAppPurchaseManagerInfoParcel.m8593c(), false);
        C3264c.m16171a(parcel, 5, gInAppPurchaseManagerInfoParcel.m8594d(), false);
        C3264c.m16171a(parcel, 6, gInAppPurchaseManagerInfoParcel.m8591a(), false);
        C3264c.m16164a(parcel, a);
    }

    public GInAppPurchaseManagerInfoParcel m8596a(Parcel parcel) {
        IBinder iBinder = null;
        int b = C3263b.m16139b(parcel);
        IBinder iBinder2 = null;
        IBinder iBinder3 = null;
        IBinder iBinder4 = null;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    iBinder4 = C3263b.m16155o(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    iBinder3 = C3263b.m16155o(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTick /*5*/:
                    iBinder2 = C3263b.m16155o(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickNormalColor /*6*/:
                    iBinder = C3263b.m16155o(parcel, a);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new GInAppPurchaseManagerInfoParcel(iBinder4, iBinder3, iBinder2, iBinder);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public GInAppPurchaseManagerInfoParcel[] m8597a(int i) {
        return new GInAppPurchaseManagerInfoParcel[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m8596a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m8597a(i);
    }
}
