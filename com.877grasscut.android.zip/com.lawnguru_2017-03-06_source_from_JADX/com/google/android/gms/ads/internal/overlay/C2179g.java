package com.google.android.gms.ads.internal.overlay;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView.ItemAnimator;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import android.view.Window;
import android.webkit.WebChromeClient.CustomViewCallback;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import com.google.android.gms.ads.internal.C2124e;
import com.google.android.gms.ads.internal.C2243w;
import com.google.android.gms.ads.internal.overlay.C2191r.C2190a;
import com.google.android.gms.common.util.C3303m;
import com.google.android.gms.p095b.ly;
import com.google.android.gms.p095b.qv.C2177a;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.vj;
import com.google.android.gms.p095b.vo;
import com.google.android.gms.p095b.vr;
import com.google.android.gms.p095b.wg;
import com.google.android.gms.p095b.wx;
import com.google.android.gms.p095b.wy;
import com.google.android.gms.p095b.wy.C2169a;
import com.google.android.gms.p097a.C2046a;
import com.google.android.gms.p097a.C2060d;
import io.techery.properratingbar.C5501a.C5500d;
import java.util.Collections;
import java.util.Map;
import net.cachapa.expandablelayout.C5541a.C5538a;

@sc
/* renamed from: com.google.android.gms.ads.internal.overlay.g */
public class C2179g extends C2177a implements C2178x {
    static final int f5129a;
    AdOverlayInfoParcel f5130b;
    wx f5131c;
    C2174c f5132d;
    C2191r f5133e;
    boolean f5134f;
    FrameLayout f5135g;
    CustomViewCallback f5136h;
    boolean f5137i;
    boolean f5138j;
    C2173b f5139k;
    boolean f5140l;
    int f5141m;
    C2187o f5142n;
    private final Activity f5143o;
    private final Object f5144p;
    private Runnable f5145q;
    private boolean f5146r;
    private boolean f5147s;
    private boolean f5148t;
    private boolean f5149u;
    private boolean f5150v;

    /* renamed from: com.google.android.gms.ads.internal.overlay.g.1 */
    class C21701 implements C2169a {
        C21701(C2179g c2179g) {
        }

        public void m8447a(wx wxVar, boolean z) {
            wxVar.m14977d();
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.overlay.g.2 */
    class C21712 implements Runnable {
        final /* synthetic */ C2179g f5119a;

        C21712(C2179g c2179g) {
            this.f5119a = c2179g;
        }

        public void run() {
            this.f5119a.m8492o();
        }
    }

    @sc
    /* renamed from: com.google.android.gms.ads.internal.overlay.g.a */
    private static final class C2172a extends Exception {
        public C2172a(String str) {
            super(str);
        }
    }

    @sc
    /* renamed from: com.google.android.gms.ads.internal.overlay.g.b */
    static class C2173b extends RelativeLayout {
        vr f5120a;
        boolean f5121b;

        public C2173b(Context context, String str, String str2) {
            super(context);
            this.f5120a = new vr(context, str);
            this.f5120a.m14827b(str2);
        }

        void m8448a() {
            this.f5121b = true;
        }

        public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
            if (!this.f5121b) {
                this.f5120a.m14825a(motionEvent);
            }
            return false;
        }
    }

    @sc
    /* renamed from: com.google.android.gms.ads.internal.overlay.g.c */
    public static class C2174c {
        public final int f5122a;
        public final LayoutParams f5123b;
        public final ViewGroup f5124c;
        public final Context f5125d;

        public C2174c(wx wxVar) {
            this.f5123b = wxVar.getLayoutParams();
            ViewParent parent = wxVar.getParent();
            this.f5125d = wxVar.m14981g();
            if (parent == null || !(parent instanceof ViewGroup)) {
                throw new C2172a("Could not get the parent of the WebView for an overlay.");
            }
            this.f5124c = (ViewGroup) parent;
            this.f5122a = this.f5124c.indexOfChild(wxVar.m14970b());
            this.f5124c.removeView(wxVar.m14970b());
            wxVar.m14969a(true);
        }
    }

    @sc
    /* renamed from: com.google.android.gms.ads.internal.overlay.g.d */
    private class C2176d extends vj {
        final /* synthetic */ C2179g f5128a;

        /* renamed from: com.google.android.gms.ads.internal.overlay.g.d.1 */
        class C21751 implements Runnable {
            final /* synthetic */ Drawable f5126a;
            final /* synthetic */ C2176d f5127b;

            C21751(C2176d c2176d, Drawable drawable) {
                this.f5127b = c2176d;
                this.f5126a = drawable;
            }

            public void run() {
                this.f5127b.f5128a.f5143o.getWindow().setBackgroundDrawable(this.f5126a);
            }
        }

        private C2176d(C2179g c2179g) {
            this.f5128a = c2179g;
        }

        public void m8449a() {
            Bitmap a = C2243w.m8807z().m14872a(Integer.valueOf(this.f5128a.f5130b.f5027p.f5011f));
            if (a != null) {
                vo.f9130a.post(new C21751(this, C2243w.m8788g().m14761a(this.f5128a.f5143o, a, this.f5128a.f5130b.f5027p.f5009d, this.f5128a.f5130b.f5027p.f5010e)));
            }
        }

        public void m8450b() {
        }
    }

    static {
        f5129a = Color.argb(0, 0, 0, 0);
    }

    public C2179g(Activity activity) {
        this.f5134f = false;
        this.f5137i = false;
        this.f5138j = false;
        this.f5140l = false;
        this.f5141m = 0;
        this.f5144p = new Object();
        this.f5148t = false;
        this.f5149u = false;
        this.f5150v = true;
        this.f5143o = activity;
        this.f5142n = new C2194v();
    }

    public void m8467a() {
        this.f5141m = 2;
        this.f5143o.finish();
    }

    public void m8468a(int i) {
        this.f5143o.setRequestedOrientation(i);
    }

    public void m8469a(int i, int i2, Intent intent) {
    }

    public void m8470a(Bundle bundle) {
        boolean z = false;
        this.f5143o.requestWindowFeature(1);
        if (bundle != null) {
            z = bundle.getBoolean("com.google.android.gms.ads.internal.overlay.hasResumed", false);
        }
        this.f5137i = z;
        try {
            this.f5130b = AdOverlayInfoParcel.m8362a(this.f5143o.getIntent());
            if (this.f5130b == null) {
                throw new C2172a("Could not get info for ad overlay.");
            }
            if (this.f5130b.f5024m.f9229c > 7500000) {
                this.f5141m = 3;
            }
            if (this.f5143o.getIntent() != null) {
                this.f5150v = this.f5143o.getIntent().getBooleanExtra("shouldCallOnOverlayOpened", true);
            }
            if (this.f5130b.f5027p != null) {
                this.f5138j = this.f5130b.f5027p.f5006a;
            } else {
                this.f5138j = false;
            }
            if (((Boolean) ly.bU.m12563c()).booleanValue() && this.f5138j && this.f5130b.f5027p.f5011f != -1) {
                new C2176d().m8331d();
            }
            if (bundle == null) {
                if (this.f5130b.f5014c != null && this.f5150v) {
                    this.f5130b.f5014c.m8182d();
                }
                if (!(this.f5130b.f5022k == 1 || this.f5130b.f5013b == null)) {
                    this.f5130b.f5013b.m7875e();
                }
            }
            this.f5139k = new C2173b(this.f5143o, this.f5130b.f5026o, this.f5130b.f5024m.f9227a);
            this.f5139k.setId(1000);
            switch (this.f5130b.f5022k) {
                case C5538a.ExpandableLayout_el_duration /*1*/:
                    m8479b(false);
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    this.f5132d = new C2174c(this.f5130b.f5015d);
                    m8479b(false);
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    m8479b(true);
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    if (this.f5137i) {
                        this.f5141m = 3;
                        this.f5143o.finish();
                    } else if (!C2243w.m8783b().m8371a(this.f5143o, this.f5130b.f5012a, this.f5130b.f5020i)) {
                        this.f5141m = 3;
                        this.f5143o.finish();
                    }
                default:
                    throw new C2172a("Could not determine ad overlay type.");
            }
        } catch (C2172a e) {
            wg.m14620e(e.getMessage());
            this.f5141m = 3;
            this.f5143o.finish();
        }
    }

    public void m8471a(View view, CustomViewCallback customViewCallback) {
        this.f5135g = new FrameLayout(this.f5143o);
        this.f5135g.setBackgroundColor(-16777216);
        this.f5135g.addView(view, -1, -1);
        this.f5143o.setContentView(this.f5135g);
        m8489l();
        this.f5136h = customViewCallback;
        this.f5134f = true;
    }

    public void m8472a(C2046a c2046a) {
        if (((Boolean) ly.dn.m12563c()).booleanValue() && C3303m.m16348l()) {
            if (C2243w.m8786e().m14721a(this.f5143o, (Configuration) C2060d.m7974a(c2046a))) {
                this.f5143o.getWindow().addFlags(1024);
                this.f5143o.getWindow().clearFlags(ItemAnimator.FLAG_MOVED);
                return;
            }
            this.f5143o.getWindow().addFlags(ItemAnimator.FLAG_MOVED);
            this.f5143o.getWindow().clearFlags(1024);
        }
    }

    public void m8473a(wx wxVar, Map<String, String> map) {
    }

    public void m8474a(boolean z) {
        int intValue = ((Integer) ly.dp.m12563c()).intValue();
        C2190a c2190a = new C2190a();
        c2190a.f5173e = 50;
        c2190a.f5169a = z ? intValue : 0;
        c2190a.f5170b = z ? 0 : intValue;
        c2190a.f5171c = 0;
        c2190a.f5172d = intValue;
        this.f5133e = new C2191r(this.f5143o, c2190a, this);
        LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(10);
        layoutParams.addRule(z ? 11 : 9);
        this.f5133e.m8549a(z, this.f5130b.f5018g);
        this.f5139k.addView(this.f5133e, layoutParams);
    }

    public void m8475a(boolean z, boolean z2) {
        if (this.f5133e != null) {
            this.f5133e.m8549a(z, z2);
        }
    }

    public void m8476b() {
        if (this.f5130b != null && this.f5134f) {
            m8468a(this.f5130b.f5021j);
        }
        if (this.f5135g != null) {
            this.f5143o.setContentView(this.f5139k);
            m8489l();
            this.f5135g.removeAllViews();
            this.f5135g = null;
        }
        if (this.f5136h != null) {
            this.f5136h.onCustomViewHidden();
            this.f5136h = null;
        }
        this.f5134f = false;
    }

    protected void m8477b(int i) {
        this.f5131c.m14958a(i);
    }

    public void m8478b(Bundle bundle) {
        bundle.putBoolean("com.google.android.gms.ads.internal.overlay.hasResumed", this.f5137i);
    }

    protected void m8479b(boolean z) {
        if (!this.f5147s) {
            this.f5143o.requestWindowFeature(1);
        }
        Window window = this.f5143o.getWindow();
        if (window == null) {
            throw new C2172a("Invalid activity, no window available.");
        }
        boolean a = (C3303m.m16348l() && ((Boolean) ly.dn.m12563c()).booleanValue()) ? C2243w.m8786e().m14721a(this.f5143o, this.f5143o.getResources().getConfiguration()) : true;
        Object obj = (this.f5130b.f5027p == null || !this.f5130b.f5027p.f5007b) ? null : 1;
        if (!(this.f5138j && obj == null) && a) {
            window.setFlags(1024, 1024);
        }
        wy l = this.f5130b.f5015d.m14986l();
        boolean b = l != null ? l.m15030b() : false;
        this.f5140l = false;
        if (b) {
            if (this.f5130b.f5021j == C2243w.m8788g().m14760a()) {
                this.f5140l = this.f5143o.getResources().getConfiguration().orientation == 1;
            } else if (this.f5130b.f5021j == C2243w.m8788g().m14774b()) {
                this.f5140l = this.f5143o.getResources().getConfiguration().orientation == 2;
            }
        }
        wg.m14615b("Delay onShow to next orientation change: " + this.f5140l);
        m8468a(this.f5130b.f5021j);
        if (C2243w.m8788g().m14772a(window)) {
            wg.m14615b("Hardware acceleration on the AdActivity window enabled.");
        }
        if (this.f5138j) {
            this.f5139k.setBackgroundColor(f5129a);
        } else {
            this.f5139k.setBackgroundColor(-16777216);
        }
        this.f5143o.setContentView(this.f5139k);
        m8489l();
        if (z) {
            this.f5131c = C2243w.m8787f().m15047a(this.f5143o, this.f5130b.f5015d.m14985k(), true, b, null, this.f5130b.f5024m, null, null, this.f5130b.f5015d.m14982h());
            this.f5131c.m14986l().m15018a(null, null, this.f5130b.f5016e, this.f5130b.f5020i, true, this.f5130b.f5025n, null, this.f5130b.f5015d.m14986l().m15011a(), null, null);
            this.f5131c.m14986l().m15020a(new C21701(this));
            if (this.f5130b.f5023l != null) {
                this.f5131c.loadUrl(this.f5130b.f5023l);
            } else if (this.f5130b.f5019h != null) {
                this.f5131c.loadDataWithBaseURL(this.f5130b.f5017f, this.f5130b.f5019h, "text/html", HttpRequest.CHARSET, null);
            } else {
                throw new C2172a("No URL or HTML to display in ad overlay.");
            }
            if (this.f5130b.f5015d != null) {
                this.f5130b.f5015d.m14972b(this);
            }
        } else {
            this.f5131c = this.f5130b.f5015d;
            this.f5131c.m14959a(this.f5143o);
        }
        this.f5131c.m14961a(this);
        ViewParent parent = this.f5131c.getParent();
        if (parent != null && (parent instanceof ViewGroup)) {
            ((ViewGroup) parent).removeView(this.f5131c.m14970b());
        }
        if (this.f5138j) {
            this.f5131c.m14956F();
        }
        this.f5139k.addView(this.f5131c.m14970b(), -1, -1);
        if (!(z || this.f5140l)) {
            m8494q();
        }
        m8474a(b);
        if (this.f5131c.m14987m()) {
            m8475a(b, true);
        }
        C2124e h = this.f5131c.m14982h();
        C2188p c2188p = h != null ? h.f4936c : null;
        if (c2188p != null) {
            this.f5142n = c2188p.m8547a(this.f5143o, this.f5131c, this.f5139k);
        } else {
            wg.m14620e("Appstreaming controller is null.");
        }
    }

    public void m8480c() {
        this.f5141m = 1;
        this.f5143o.finish();
    }

    public void m8481d() {
        this.f5141m = 0;
    }

    public boolean m8482e() {
        boolean z = true;
        this.f5141m = 0;
        if (this.f5131c != null) {
            if (!this.f5131c.m14994t()) {
                z = false;
            }
            if (!z) {
                this.f5131c.m14967a("onbackblocked", Collections.emptyMap());
            }
        }
        return z;
    }

    public void m8483f() {
    }

    public void m8484g() {
        if (!((Boolean) ly.f7595do.m12563c()).booleanValue()) {
            return;
        }
        if (this.f5131c == null || this.f5131c.m14992r()) {
            wg.m14620e("The webview does not exist. Ignoring action.");
        } else {
            C2243w.m8788g().m14777b(this.f5131c);
        }
    }

    public void m8485h() {
        if (this.f5130b != null && this.f5130b.f5022k == 4) {
            if (this.f5137i) {
                this.f5141m = 3;
                this.f5143o.finish();
            } else {
                this.f5137i = true;
            }
        }
        if (this.f5130b.f5014c != null) {
            this.f5130b.f5014c.m8181c();
        }
        if (!((Boolean) ly.f7595do.m12563c()).booleanValue()) {
            if (this.f5131c == null || this.f5131c.m14992r()) {
                wg.m14620e("The webview does not exist. Ignoring action.");
            } else {
                C2243w.m8788g().m14777b(this.f5131c);
            }
        }
    }

    public void m8486i() {
        m8476b();
        if (this.f5130b.f5014c != null) {
            this.f5130b.f5014c.m8180b();
        }
        if (!(((Boolean) ly.f7595do.m12563c()).booleanValue() || this.f5131c == null || (this.f5143o.isFinishing() && this.f5132d != null))) {
            C2243w.m8788g().m14773a(this.f5131c);
        }
        m8491n();
    }

    public void m8487j() {
        if (((Boolean) ly.f7595do.m12563c()).booleanValue() && this.f5131c != null && (!this.f5143o.isFinishing() || this.f5132d == null)) {
            C2243w.m8788g().m14773a(this.f5131c);
        }
        m8491n();
    }

    public void m8488k() {
        if (this.f5131c != null) {
            this.f5139k.removeView(this.f5131c.m14970b());
        }
        m8491n();
    }

    public void m8489l() {
        this.f5147s = true;
    }

    public void m8490m() {
        this.f5139k.removeView(this.f5133e);
        m8474a(true);
    }

    protected void m8491n() {
        if (this.f5143o.isFinishing() && !this.f5148t) {
            this.f5148t = true;
            if (this.f5131c != null) {
                m8477b(this.f5141m);
                synchronized (this.f5144p) {
                    if (this.f5146r || !this.f5131c.m14951A()) {
                    } else {
                        this.f5145q = new C21712(this);
                        vo.f9130a.postDelayed(this.f5145q, ((Long) ly.aS.m12563c()).longValue());
                        return;
                    }
                }
            }
            m8492o();
        }
    }

    void m8492o() {
        if (!this.f5149u) {
            this.f5149u = true;
            if (this.f5131c != null) {
                this.f5139k.removeView(this.f5131c.m14970b());
                if (this.f5132d != null) {
                    this.f5131c.m14959a(this.f5132d.f5125d);
                    this.f5131c.m14969a(false);
                    this.f5132d.f5124c.addView(this.f5131c.m14970b(), this.f5132d.f5122a, this.f5132d.f5123b);
                    this.f5132d = null;
                } else if (this.f5143o.getApplicationContext() != null) {
                    this.f5131c.m14959a(this.f5143o.getApplicationContext());
                }
                this.f5131c = null;
            }
            if (this.f5130b != null && this.f5130b.f5014c != null) {
                this.f5130b.f5014c.m8179a();
            }
        }
    }

    public void m8493p() {
        if (this.f5140l) {
            this.f5140l = false;
            m8494q();
        }
    }

    protected void m8494q() {
        this.f5131c.m14977d();
    }

    public void m8495r() {
        this.f5139k.m8448a();
    }

    public void m8496s() {
        synchronized (this.f5144p) {
            this.f5146r = true;
            if (this.f5145q != null) {
                vo.f9130a.removeCallbacks(this.f5145q);
                vo.f9130a.post(this.f5145q);
            }
        }
    }
}
