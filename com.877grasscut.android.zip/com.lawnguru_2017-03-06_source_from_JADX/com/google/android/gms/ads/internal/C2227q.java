package com.google.android.gms.ads.internal;

import android.content.Context;
import android.text.TextUtils;
import com.google.android.gms.p095b.kw.C2226a;
import com.google.android.gms.p095b.ly;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.uc;
import com.google.android.gms.p095b.vr;
import com.google.android.gms.p095b.wg;
import com.google.android.gms.p095b.wi;
import com.google.android.gms.p097a.C2046a;
import com.google.android.gms.p097a.C2060d;

@sc
/* renamed from: com.google.android.gms.ads.internal.q */
public class C2227q extends C2226a {
    private static final Object f5250b;
    private static C2227q f5251c;
    private final Context f5252a;
    private final Object f5253d;
    private boolean f5254e;
    private boolean f5255f;
    private float f5256g;
    private wi f5257h;

    /* renamed from: com.google.android.gms.ads.internal.q.1 */
    class C22251 implements Runnable {
        final /* synthetic */ Runnable f5248a;
        final /* synthetic */ C2227q f5249b;

        /* renamed from: com.google.android.gms.ads.internal.q.1.1 */
        class C22241 implements Runnable {
            final /* synthetic */ C22251 f5247a;

            C22241(C22251 c22251) {
                this.f5247a = c22251;
            }

            public void run() {
                uc.m14378a(this.f5247a.f5249b.f5252a, this.f5247a.f5248a);
            }
        }

        C22251(C2227q c2227q, Runnable runnable) {
            this.f5249b = c2227q;
            this.f5248a = runnable;
        }

        public void run() {
            C2243w.m8786e().m14717a(new C22241(this));
        }
    }

    static {
        f5250b = new Object();
    }

    C2227q(Context context, wi wiVar) {
        this.f5253d = new Object();
        this.f5256g = -1.0f;
        this.f5252a = context;
        this.f5257h = wiVar;
        this.f5254e = false;
    }

    public static C2227q m8671a() {
        C2227q c2227q;
        synchronized (f5250b) {
            c2227q = f5251c;
        }
        return c2227q;
    }

    public static C2227q m8672a(Context context, wi wiVar) {
        C2227q c2227q;
        synchronized (f5250b) {
            if (f5251c == null) {
                f5251c = new C2227q(context.getApplicationContext(), wiVar);
            }
            c2227q = f5251c;
        }
        return c2227q;
    }

    vr m8673a(Context context) {
        return new vr(context);
    }

    public void m8674a(float f) {
        synchronized (this.f5253d) {
            this.f5256g = f;
        }
    }

    public void m8675a(C2046a c2046a, String str) {
        if (c2046a == null) {
            wg.m14617c("Wrapped context is null. Failed to open debug menu.");
            return;
        }
        Context context = (Context) C2060d.m7974a(c2046a);
        if (context == null) {
            wg.m14617c("Context is null. Failed to open debug menu.");
            return;
        }
        vr a = m8673a(context);
        a.m14826a(str);
        a.m14827b(this.f5257h.f9227a);
        a.m14823a();
    }

    public void m8676a(String str) {
        ly.m12586a(this.f5252a);
        if (!TextUtils.isEmpty(str) && ((Boolean) ly.cD.m12563c()).booleanValue()) {
            C2243w.m8776A().m8273a(this.f5252a, this.f5257h, str, null);
        }
    }

    public void m8677a(String str, C2046a c2046a) {
        if (!TextUtils.isEmpty(str)) {
            Runnable c22251;
            int i;
            ly.m12586a(this.f5252a);
            int booleanValue = ((Boolean) ly.cD.m12563c()).booleanValue() | ((Boolean) ly.aH.m12563c()).booleanValue();
            if (((Boolean) ly.aH.m12563c()).booleanValue()) {
                c22251 = new C22251(this, (Runnable) C2060d.m7974a(c2046a));
                i = 1;
            } else {
                c22251 = null;
                i = booleanValue;
            }
            if (i != 0) {
                C2243w.m8776A().m8273a(this.f5252a, this.f5257h, str, c22251);
            }
        }
    }

    public void m8678a(boolean z) {
        synchronized (this.f5253d) {
            this.f5255f = z;
        }
    }

    public void m8679b() {
        synchronized (f5250b) {
            if (this.f5254e) {
                wg.m14620e("Mobile ads is initialized already.");
                return;
            }
            this.f5254e = true;
            ly.m12586a(this.f5252a);
            C2243w.m8790i().m14556a(this.f5252a, this.f5257h);
            C2243w.m8791j().m12133a(this.f5252a);
        }
    }

    public float m8680c() {
        float f;
        synchronized (this.f5253d) {
            f = this.f5256g;
        }
        return f;
    }

    public boolean m8681d() {
        boolean z;
        synchronized (this.f5253d) {
            z = this.f5256g >= 0.0f;
        }
        return z;
    }

    public boolean m8682e() {
        boolean z;
        synchronized (this.f5253d) {
            z = this.f5255f;
        }
        return z;
    }
}
