package com.google.android.gms.ads.internal.overlay;

import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.ads.internal.C2150n;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.C2149a;
import com.google.android.gms.p095b.ju;
import com.google.android.gms.p095b.ns;
import com.google.android.gms.p095b.nz;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.wi;
import com.google.android.gms.p095b.wx;
import com.google.android.gms.p097a.C2046a.C2048a;
import com.google.android.gms.p097a.C2060d;

@sc
public final class AdOverlayInfoParcel extends C2149a implements ReflectedParcelable {
    public static final Creator<AdOverlayInfoParcel> CREATOR;
    public final C2158e f5012a;
    public final ju f5013b;
    public final C2112j f5014c;
    public final wx f5015d;
    public final ns f5016e;
    public final String f5017f;
    public final boolean f5018g;
    public final String f5019h;
    public final C2101s f5020i;
    public final int f5021j;
    public final int f5022k;
    public final String f5023l;
    public final wi f5024m;
    public final nz f5025n;
    public final String f5026o;
    public final C2150n f5027p;

    static {
        CREATOR = new C2181i();
    }

    AdOverlayInfoParcel(C2158e c2158e, IBinder iBinder, IBinder iBinder2, IBinder iBinder3, IBinder iBinder4, String str, boolean z, String str2, IBinder iBinder5, int i, int i2, String str3, wi wiVar, IBinder iBinder6, String str4, C2150n c2150n) {
        this.f5012a = c2158e;
        this.f5013b = (ju) C2060d.m7974a(C2048a.m7925a(iBinder));
        this.f5014c = (C2112j) C2060d.m7974a(C2048a.m7925a(iBinder2));
        this.f5015d = (wx) C2060d.m7974a(C2048a.m7925a(iBinder3));
        this.f5016e = (ns) C2060d.m7974a(C2048a.m7925a(iBinder4));
        this.f5017f = str;
        this.f5018g = z;
        this.f5019h = str2;
        this.f5020i = (C2101s) C2060d.m7974a(C2048a.m7925a(iBinder5));
        this.f5021j = i;
        this.f5022k = i2;
        this.f5023l = str3;
        this.f5024m = wiVar;
        this.f5025n = (nz) C2060d.m7974a(C2048a.m7925a(iBinder6));
        this.f5026o = str4;
        this.f5027p = c2150n;
    }

    public AdOverlayInfoParcel(C2158e c2158e, ju juVar, C2112j c2112j, C2101s c2101s, wi wiVar) {
        this.f5012a = c2158e;
        this.f5013b = juVar;
        this.f5014c = c2112j;
        this.f5015d = null;
        this.f5016e = null;
        this.f5017f = null;
        this.f5018g = false;
        this.f5019h = null;
        this.f5020i = c2101s;
        this.f5021j = -1;
        this.f5022k = 4;
        this.f5023l = null;
        this.f5024m = wiVar;
        this.f5025n = null;
        this.f5026o = null;
        this.f5027p = null;
    }

    public AdOverlayInfoParcel(ju juVar, C2112j c2112j, C2101s c2101s, wx wxVar, int i, wi wiVar, String str, C2150n c2150n) {
        this.f5012a = null;
        this.f5013b = juVar;
        this.f5014c = c2112j;
        this.f5015d = wxVar;
        this.f5016e = null;
        this.f5017f = null;
        this.f5018g = false;
        this.f5019h = null;
        this.f5020i = c2101s;
        this.f5021j = i;
        this.f5022k = 1;
        this.f5023l = null;
        this.f5024m = wiVar;
        this.f5025n = null;
        this.f5026o = str;
        this.f5027p = c2150n;
    }

    public AdOverlayInfoParcel(ju juVar, C2112j c2112j, C2101s c2101s, wx wxVar, boolean z, int i, wi wiVar) {
        this.f5012a = null;
        this.f5013b = juVar;
        this.f5014c = c2112j;
        this.f5015d = wxVar;
        this.f5016e = null;
        this.f5017f = null;
        this.f5018g = z;
        this.f5019h = null;
        this.f5020i = c2101s;
        this.f5021j = i;
        this.f5022k = 2;
        this.f5023l = null;
        this.f5024m = wiVar;
        this.f5025n = null;
        this.f5026o = null;
        this.f5027p = null;
    }

    public AdOverlayInfoParcel(ju juVar, C2112j c2112j, ns nsVar, C2101s c2101s, wx wxVar, boolean z, int i, String str, wi wiVar, nz nzVar) {
        this.f5012a = null;
        this.f5013b = juVar;
        this.f5014c = c2112j;
        this.f5015d = wxVar;
        this.f5016e = nsVar;
        this.f5017f = null;
        this.f5018g = z;
        this.f5019h = null;
        this.f5020i = c2101s;
        this.f5021j = i;
        this.f5022k = 3;
        this.f5023l = str;
        this.f5024m = wiVar;
        this.f5025n = nzVar;
        this.f5026o = null;
        this.f5027p = null;
    }

    public AdOverlayInfoParcel(ju juVar, C2112j c2112j, ns nsVar, C2101s c2101s, wx wxVar, boolean z, int i, String str, String str2, wi wiVar, nz nzVar) {
        this.f5012a = null;
        this.f5013b = juVar;
        this.f5014c = c2112j;
        this.f5015d = wxVar;
        this.f5016e = nsVar;
        this.f5017f = str2;
        this.f5018g = z;
        this.f5019h = str;
        this.f5020i = c2101s;
        this.f5021j = i;
        this.f5022k = 3;
        this.f5023l = null;
        this.f5024m = wiVar;
        this.f5025n = nzVar;
        this.f5026o = null;
        this.f5027p = null;
    }

    public static AdOverlayInfoParcel m8362a(Intent intent) {
        try {
            Bundle bundleExtra = intent.getBundleExtra("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo");
            bundleExtra.setClassLoader(AdOverlayInfoParcel.class.getClassLoader());
            return (AdOverlayInfoParcel) bundleExtra.getParcelable("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo");
        } catch (Exception e) {
            return null;
        }
    }

    public static void m8363a(Intent intent, AdOverlayInfoParcel adOverlayInfoParcel) {
        Bundle bundle = new Bundle(1);
        bundle.putParcelable("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo", adOverlayInfoParcel);
        intent.putExtra("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo", bundle);
    }

    IBinder m8364a() {
        return C2060d.m7973a(this.f5013b).asBinder();
    }

    IBinder m8365b() {
        return C2060d.m7973a(this.f5014c).asBinder();
    }

    IBinder m8366c() {
        return C2060d.m7973a(this.f5015d).asBinder();
    }

    IBinder m8367d() {
        return C2060d.m7973a(this.f5016e).asBinder();
    }

    IBinder m8368e() {
        return C2060d.m7973a(this.f5025n).asBinder();
    }

    IBinder m8369f() {
        return C2060d.m7973a(this.f5020i).asBinder();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C2181i.m8499a(this, parcel, i);
    }
}
