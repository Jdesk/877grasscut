package com.google.android.gms.ads.internal;

import android.app.Activity;
import android.content.Context;
import android.graphics.Rect;
import android.os.RemoteException;
import android.support.v4.util.SimpleArrayMap;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.ViewTreeObserver.OnScrollChangedListener;
import android.widget.ViewSwitcher;
import com.google.android.gms.ads.internal.purchase.C2222k;
import com.google.android.gms.p095b.fm;
import com.google.android.gms.p095b.ke;
import com.google.android.gms.p095b.kj;
import com.google.android.gms.p095b.km;
import com.google.android.gms.p095b.kn;
import com.google.android.gms.p095b.kt;
import com.google.android.gms.p095b.kv;
import com.google.android.gms.p095b.lb;
import com.google.android.gms.p095b.ln;
import com.google.android.gms.p095b.ly;
import com.google.android.gms.p095b.mk;
import com.google.android.gms.p095b.my;
import com.google.android.gms.p095b.nk;
import com.google.android.gms.p095b.nl;
import com.google.android.gms.p095b.nm;
import com.google.android.gms.p095b.nn;
import com.google.android.gms.p095b.rb;
import com.google.android.gms.p095b.rf;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.tv;
import com.google.android.gms.p095b.vb;
import com.google.android.gms.p095b.vb.C3048a;
import com.google.android.gms.p095b.vc;
import com.google.android.gms.p095b.vh;
import com.google.android.gms.p095b.vj;
import com.google.android.gms.p095b.vk;
import com.google.android.gms.p095b.vq;
import com.google.android.gms.p095b.vr;
import com.google.android.gms.p095b.vz;
import com.google.android.gms.p095b.we;
import com.google.android.gms.p095b.wg;
import com.google.android.gms.p095b.wi;
import com.google.android.gms.p095b.wx;
import com.google.android.gms.p095b.wy;
import io.card.payment.BuildConfig;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.UUID;

@sc
/* renamed from: com.google.android.gms.ads.internal.x */
public final class C2245x implements OnGlobalLayoutListener, OnScrollChangedListener {
    tv f5331A;
    List<String> f5332B;
    C2222k f5333C;
    public vh f5334D;
    View f5335E;
    public int f5336F;
    boolean f5337G;
    boolean f5338H;
    private HashSet<vc> f5339I;
    private int f5340J;
    private int f5341K;
    private vz f5342L;
    private boolean f5343M;
    private boolean f5344N;
    private boolean f5345O;
    final String f5346a;
    public String f5347b;
    public final Context f5348c;
    final fm f5349d;
    public final wi f5350e;
    C2244a f5351f;
    public vj f5352g;
    public vq f5353h;
    public ke f5354i;
    public vb f5355j;
    public C3048a f5356k;
    public vc f5357l;
    km f5358m;
    kn f5359n;
    kt f5360o;
    kv f5361p;
    rb f5362q;
    rf f5363r;
    nk f5364s;
    nl f5365t;
    SimpleArrayMap<String, nm> f5366u;
    SimpleArrayMap<String, nn> f5367v;
    my f5368w;
    ln f5369x;
    lb f5370y;
    mk f5371z;

    /* renamed from: com.google.android.gms.ads.internal.x.a */
    public static class C2244a extends ViewSwitcher {
        private final vr f5328a;
        private final we f5329b;
        private boolean f5330c;

        public C2244a(Context context, String str, String str2, OnGlobalLayoutListener onGlobalLayoutListener, OnScrollChangedListener onScrollChangedListener) {
            super(context);
            this.f5328a = new vr(context);
            this.f5328a.m14826a(str);
            this.f5328a.m14827b(str2);
            this.f5330c = true;
            if (context instanceof Activity) {
                this.f5329b = new we((Activity) context, this, onGlobalLayoutListener, onScrollChangedListener);
            } else {
                this.f5329b = new we(null, this, onGlobalLayoutListener, onScrollChangedListener);
            }
            this.f5329b.m14888a();
        }

        public vr m8808a() {
            return this.f5328a;
        }

        public void m8809b() {
            vk.m14621a("Disable position monitoring on adFrame.");
            if (this.f5329b != null) {
                this.f5329b.m14890b();
            }
        }

        public void m8810c() {
            vk.m14621a("Enable debug gesture detector on adFrame.");
            this.f5330c = true;
        }

        public void m8811d() {
            vk.m14621a("Disable debug gesture detector on adFrame.");
            this.f5330c = false;
        }

        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            if (this.f5329b != null) {
                this.f5329b.m14891c();
            }
        }

        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            if (this.f5329b != null) {
                this.f5329b.m14892d();
            }
        }

        public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
            if (this.f5330c) {
                this.f5328a.m14825a(motionEvent);
            }
            return false;
        }

        public void removeAllViews() {
            List<wx> arrayList = new ArrayList();
            for (int i = 0; i < getChildCount(); i++) {
                View childAt = getChildAt(i);
                if (childAt != null && (childAt instanceof wx)) {
                    arrayList.add((wx) childAt);
                }
            }
            super.removeAllViews();
            for (wx destroy : arrayList) {
                destroy.destroy();
            }
        }
    }

    public C2245x(Context context, ke keVar, String str, wi wiVar) {
        this(context, keVar, str, wiVar, null);
    }

    C2245x(Context context, ke keVar, String str, wi wiVar, fm fmVar) {
        this.f5334D = null;
        this.f5335E = null;
        this.f5336F = 0;
        this.f5337G = false;
        this.f5338H = false;
        this.f5339I = null;
        this.f5340J = -1;
        this.f5341K = -1;
        this.f5343M = true;
        this.f5344N = true;
        this.f5345O = false;
        ly.m12586a(context);
        if (C2243w.m8790i().m14579f() != null) {
            List b = ly.m12587b();
            if (wiVar.f9228b != 0) {
                b.add(Integer.toString(wiVar.f9228b));
            }
            C2243w.m8790i().m14579f().m12641a(b);
        }
        this.f5346a = UUID.randomUUID().toString();
        if (keVar.f7386d || keVar.f7390h) {
            this.f5351f = null;
        } else {
            this.f5351f = new C2244a(context, str, wiVar.f9227a, this, this);
            this.f5351f.setMinimumWidth(keVar.f7388f);
            this.f5351f.setMinimumHeight(keVar.f7385c);
            this.f5351f.setVisibility(4);
        }
        this.f5354i = keVar;
        this.f5347b = str;
        this.f5348c = context;
        this.f5350e = wiVar;
        if (fmVar == null) {
            fmVar = new fm(new C2138j(this));
        }
        this.f5349d = fmVar;
        this.f5342L = new vz(200);
        this.f5367v = new SimpleArrayMap();
    }

    private void m8812b(boolean z) {
        boolean z2 = true;
        if (this.f5351f != null && this.f5355j != null && this.f5355j.f8981b != null && this.f5355j.f8981b.m14986l() != null) {
            if (!z || this.f5342L.m14876a()) {
                if (this.f5355j.f8981b.m14986l().m15030b()) {
                    int[] iArr = new int[2];
                    this.f5351f.getLocationOnScreen(iArr);
                    int b = kj.m12293a().m14907b(this.f5348c, iArr[0]);
                    int b2 = kj.m12293a().m14907b(this.f5348c, iArr[1]);
                    if (!(b == this.f5340J && b2 == this.f5341K)) {
                        this.f5340J = b;
                        this.f5341K = b2;
                        wy l = this.f5355j.f8981b.m14986l();
                        b = this.f5340J;
                        int i = this.f5341K;
                        if (z) {
                            z2 = false;
                        }
                        l.m15013a(b, i, z2);
                    }
                }
                m8813k();
            }
        }
    }

    private void m8813k() {
        if (this.f5351f != null) {
            View findViewById = this.f5351f.getRootView().findViewById(16908290);
            if (findViewById != null) {
                Rect rect = new Rect();
                Rect rect2 = new Rect();
                this.f5351f.getGlobalVisibleRect(rect);
                findViewById.getGlobalVisibleRect(rect2);
                if (rect.top != rect2.top) {
                    this.f5343M = false;
                }
                if (rect.bottom != rect2.bottom) {
                    this.f5344N = false;
                }
            }
        }
    }

    public HashSet<vc> m8814a() {
        return this.f5339I;
    }

    public void m8815a(HashSet<vc> hashSet) {
        this.f5339I = hashSet;
    }

    public void m8816a(boolean z) {
        if (this.f5336F == 0) {
            m8818c();
        }
        if (this.f5352g != null) {
            this.f5352g.m8330c();
        }
        if (this.f5353h != null) {
            this.f5353h.m8325c();
        }
        if (z) {
            this.f5355j = null;
        }
    }

    public void m8817b() {
        if (this.f5355j != null && this.f5355j.f8981b != null) {
            this.f5355j.f8981b.destroy();
        }
    }

    public void m8818c() {
        if (this.f5355j != null && this.f5355j.f8981b != null) {
            this.f5355j.f8981b.stopLoading();
        }
    }

    public void m8819d() {
        if (this.f5355j != null && this.f5355j.f8995p != null) {
            try {
                this.f5355j.f8995p.m13453c();
            } catch (RemoteException e) {
                wg.m14620e("Could not destroy mediation adapter.");
            }
        }
    }

    public boolean m8820e() {
        return this.f5336F == 0;
    }

    public boolean m8821f() {
        return this.f5336F == 1;
    }

    public void m8822g() {
        if (this.f5351f != null) {
            this.f5351f.m8809b();
        }
    }

    public String m8823h() {
        return (this.f5343M && this.f5344N) ? BuildConfig.FLAVOR : this.f5343M ? this.f5345O ? "top-scrollable" : "top-locked" : this.f5344N ? this.f5345O ? "bottom-scrollable" : "bottom-locked" : BuildConfig.FLAVOR;
    }

    public void m8824i() {
        if (this.f5357l != null) {
            if (this.f5355j != null) {
                this.f5357l.m14533a(this.f5355j.f8971A);
                this.f5357l.m14537b(this.f5355j.f8972B);
                this.f5357l.m14538b(this.f5355j.f8993n);
            }
            this.f5357l.m14535a(this.f5354i.f7386d);
        }
    }

    public void m8825j() {
        m8822g();
        this.f5359n = null;
        this.f5360o = null;
        this.f5363r = null;
        this.f5362q = null;
        this.f5371z = null;
        this.f5361p = null;
        m8816a(false);
        if (this.f5351f != null) {
            this.f5351f.removeAllViews();
        }
        m8817b();
        m8819d();
        this.f5355j = null;
    }

    public void onGlobalLayout() {
        m8812b(false);
    }

    public void onScrollChanged() {
        m8812b(true);
        this.f5345O = true;
    }
}
