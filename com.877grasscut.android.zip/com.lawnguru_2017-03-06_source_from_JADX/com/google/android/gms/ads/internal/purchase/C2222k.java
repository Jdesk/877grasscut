package com.google.android.gms.ads.internal.purchase;

import android.content.Intent;
import com.google.android.gms.ads.internal.C2243w;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.wg;

@sc
/* renamed from: com.google.android.gms.ads.internal.purchase.k */
public class C2222k {
    private final String f5246a;

    public C2222k(String str) {
        this.f5246a = str;
    }

    public String m8658a() {
        return C2243w.m8786e().m14743d();
    }

    public boolean m8659a(String str, int i, Intent intent) {
        if (str == null || intent == null) {
            return false;
        }
        String b = C2243w.m8800s().m8655b(intent);
        String c = C2243w.m8800s().m8657c(intent);
        if (b == null || c == null) {
            return false;
        }
        if (!str.equals(C2243w.m8800s().m8652a(b))) {
            wg.m14620e("Developer payload not match.");
            return false;
        } else if (this.f5246a == null || C2223l.m8661a(this.f5246a, b, c)) {
            return true;
        } else {
            wg.m14620e("Fail to verify signature.");
            return false;
        }
    }
}
