package com.google.android.gms.ads.internal.purchase;

import android.text.TextUtils;
import android.util.Base64;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.wg;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.spec.X509EncodedKeySpec;

@sc
/* renamed from: com.google.android.gms.ads.internal.purchase.l */
public class C2223l {
    public static PublicKey m8660a(String str) {
        try {
            return KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(Base64.decode(str, 0)));
        } catch (Throwable e) {
            throw new RuntimeException(e);
        } catch (Throwable e2) {
            wg.m14617c("Invalid key specification.");
            throw new IllegalArgumentException(e2);
        }
    }

    public static boolean m8661a(String str, String str2, String str3) {
        if (!TextUtils.isEmpty(str2) && !TextUtils.isEmpty(str) && !TextUtils.isEmpty(str3)) {
            return C2223l.m8662a(C2223l.m8660a(str), str2, str3);
        }
        wg.m14617c("Purchase verification failed: missing data.");
        return false;
    }

    public static boolean m8662a(PublicKey publicKey, String str, String str2) {
        try {
            Signature instance = Signature.getInstance("SHA1withRSA");
            instance.initVerify(publicKey);
            instance.update(str.getBytes());
            if (instance.verify(Base64.decode(str2, 0))) {
                return true;
            }
            wg.m14617c("Signature verification failed.");
            return false;
        } catch (NoSuchAlgorithmException e) {
            wg.m14617c("NoSuchAlgorithmException.");
            return false;
        } catch (InvalidKeyException e2) {
            wg.m14617c("Invalid key specification.");
            return false;
        } catch (SignatureException e3) {
            wg.m14617c("Signature exception.");
            return false;
        }
    }
}
