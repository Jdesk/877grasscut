package com.google.android.gms.ads.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.ads.internal.o */
public class C2151o implements Creator<C2150n> {
    static void m8359a(C2150n c2150n, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16180a(parcel, 2, c2150n.f5006a);
        C3264c.m16180a(parcel, 3, c2150n.f5007b);
        C3264c.m16177a(parcel, 4, c2150n.f5008c, false);
        C3264c.m16180a(parcel, 5, c2150n.f5009d);
        C3264c.m16167a(parcel, 6, c2150n.f5010e);
        C3264c.m16168a(parcel, 7, c2150n.f5011f);
        C3264c.m16164a(parcel, a);
    }

    public C2150n m8360a(Parcel parcel) {
        int i = 0;
        int b = C3263b.m16139b(parcel);
        String str = null;
        float f = 0.0f;
        boolean z = false;
        boolean z2 = false;
        boolean z3 = false;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    z3 = C3263b.m16143c(parcel, a);
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    z2 = C3263b.m16143c(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    str = C3263b.m16154n(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTick /*5*/:
                    z = C3263b.m16143c(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickNormalColor /*6*/:
                    f = C3263b.m16150j(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickSelectedColor /*7*/:
                    i = C3263b.m16146f(parcel, a);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new C2150n(z3, z2, str, z, f, i);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public C2150n[] m8361a(int i) {
        return new C2150n[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m8360a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m8361a(i);
    }
}
