package com.google.android.gms.ads.internal.overlay;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.ads.internal.C2150n;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import com.google.android.gms.p095b.wi;
import com.zopim.android.sdk.api.C5264R;
import io.card.payment.CreditCard;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.ads.internal.overlay.i */
public class C2181i implements Creator<AdOverlayInfoParcel> {
    static void m8499a(AdOverlayInfoParcel adOverlayInfoParcel, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16172a(parcel, 2, adOverlayInfoParcel.f5012a, i, false);
        C3264c.m16171a(parcel, 3, adOverlayInfoParcel.m8364a(), false);
        C3264c.m16171a(parcel, 4, adOverlayInfoParcel.m8365b(), false);
        C3264c.m16171a(parcel, 5, adOverlayInfoParcel.m8366c(), false);
        C3264c.m16171a(parcel, 6, adOverlayInfoParcel.m8367d(), false);
        C3264c.m16177a(parcel, 7, adOverlayInfoParcel.f5017f, false);
        C3264c.m16180a(parcel, 8, adOverlayInfoParcel.f5018g);
        C3264c.m16177a(parcel, 9, adOverlayInfoParcel.f5019h, false);
        C3264c.m16171a(parcel, 10, adOverlayInfoParcel.m8369f(), false);
        C3264c.m16168a(parcel, 11, adOverlayInfoParcel.f5021j);
        C3264c.m16168a(parcel, 12, adOverlayInfoParcel.f5022k);
        C3264c.m16177a(parcel, 13, adOverlayInfoParcel.f5023l, false);
        C3264c.m16172a(parcel, 14, adOverlayInfoParcel.f5024m, i, false);
        C3264c.m16171a(parcel, 15, adOverlayInfoParcel.m8368e(), false);
        C3264c.m16177a(parcel, 16, adOverlayInfoParcel.f5026o, false);
        C3264c.m16172a(parcel, 17, adOverlayInfoParcel.f5027p, i, false);
        C3264c.m16164a(parcel, a);
    }

    public AdOverlayInfoParcel m8500a(Parcel parcel) {
        int b = C3263b.m16139b(parcel);
        C2158e c2158e = null;
        IBinder iBinder = null;
        IBinder iBinder2 = null;
        IBinder iBinder3 = null;
        IBinder iBinder4 = null;
        String str = null;
        boolean z = false;
        String str2 = null;
        IBinder iBinder5 = null;
        int i = 0;
        int i2 = 0;
        String str3 = null;
        wi wiVar = null;
        IBinder iBinder6 = null;
        String str4 = null;
        C2150n c2150n = null;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    c2158e = (C2158e) C3263b.m16135a(parcel, a, C2158e.CREATOR);
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    iBinder = C3263b.m16155o(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    iBinder2 = C3263b.m16155o(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTick /*5*/:
                    iBinder3 = C3263b.m16155o(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickNormalColor /*6*/:
                    iBinder4 = C3263b.m16155o(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickSelectedColor /*7*/:
                    str = C3263b.m16154n(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickNormalDrawable /*8*/:
                    z = C3263b.m16143c(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickSelectedDrawable /*9*/:
                    str2 = C3263b.m16154n(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickSpacing /*10*/:
                    iBinder5 = C3263b.m16155o(parcel, a);
                    break;
                case C5264R.styleable.Toolbar_popupTheme /*11*/:
                    i = C3263b.m16146f(parcel, a);
                    break;
                case C5264R.styleable.Toolbar_titleTextAppearance /*12*/:
                    i2 = C3263b.m16146f(parcel, a);
                    break;
                case C5264R.styleable.Toolbar_subtitleTextAppearance /*13*/:
                    str3 = C3263b.m16154n(parcel, a);
                    break;
                case C5264R.styleable.SearchView_suggestionRowLayout /*14*/:
                    wiVar = (wi) C3263b.m16135a(parcel, a, wi.CREATOR);
                    break;
                case CreditCard.EXPIRY_MAX_FUTURE_YEARS /*15*/:
                    iBinder6 = C3263b.m16155o(parcel, a);
                    break;
                case C5264R.styleable.Toolbar_titleMarginEnd /*16*/:
                    str4 = C3263b.m16154n(parcel, a);
                    break;
                case C5264R.styleable.Toolbar_titleMarginTop /*17*/:
                    c2150n = (C2150n) C3263b.m16135a(parcel, a, C2150n.CREATOR);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new AdOverlayInfoParcel(c2158e, iBinder, iBinder2, iBinder3, iBinder4, str, z, str2, iBinder5, i, i2, str3, wiVar, iBinder6, str4, c2150n);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public AdOverlayInfoParcel[] m8501a(int i) {
        return new AdOverlayInfoParcel[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m8500a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m8501a(i);
    }
}
