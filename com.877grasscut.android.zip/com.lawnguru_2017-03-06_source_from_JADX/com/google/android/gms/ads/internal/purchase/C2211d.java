package com.google.android.gms.ads.internal.purchase;

import android.content.Context;
import android.os.Build.VERSION;
import android.os.SystemClock;
import android.support.v4.app.ad;
import com.google.android.gms.ads.internal.C2243w;
import com.google.android.gms.p095b.bn;
import com.google.android.gms.p095b.ra.C2210a;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.wg;
import io.card.payment.BuildConfig;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

@sc
/* renamed from: com.google.android.gms.ads.internal.purchase.d */
public class C2211d extends C2210a {
    private String f5217a;
    private Context f5218b;
    private String f5219c;
    private ArrayList<String> f5220d;

    public C2211d(String str, ArrayList<String> arrayList, Context context, String str2) {
        this.f5219c = str;
        this.f5220d = arrayList;
        this.f5217a = str2;
        this.f5218b = context;
    }

    protected int m8616a(int i) {
        return i == 0 ? 1 : i == 1 ? 2 : i == 4 ? 3 : 0;
    }

    public String m8617a() {
        return this.f5219c;
    }

    Map<String, String> m8618b() {
        String packageName = this.f5218b.getPackageName();
        Object obj = BuildConfig.FLAVOR;
        try {
            obj = bn.m9791b(this.f5218b).m9789b(packageName, 0).versionName;
        } catch (Throwable e) {
            wg.m14618c("Error to retrieve app version", e);
        }
        long elapsedRealtime = SystemClock.elapsedRealtime() - C2243w.m8790i().m14577e().m14601a();
        Map<String, String> hashMap = new HashMap();
        hashMap.put("sessionid", C2243w.m8790i().m14551a());
        hashMap.put("appid", packageName);
        hashMap.put("osversion", String.valueOf(VERSION.SDK_INT));
        hashMap.put("sdkversion", this.f5217a);
        hashMap.put("appversion", obj);
        hashMap.put("timestamp", String.valueOf(elapsedRealtime));
        return hashMap;
    }

    public void m8619b(int i) {
        if (i == 1) {
            m8620c();
        }
        Map b = m8618b();
        b.put(ad.CATEGORY_STATUS, String.valueOf(i));
        b.put("sku", this.f5219c);
        List linkedList = new LinkedList();
        Iterator it = this.f5220d.iterator();
        while (it.hasNext()) {
            linkedList.add(C2243w.m8786e().m14702a((String) it.next(), b));
        }
        C2243w.m8786e().m14713a(this.f5218b, this.f5217a, linkedList);
    }

    void m8620c() {
        try {
            this.f5218b.getClassLoader().loadClass("com.google.ads.conversiontracking.IAPConversionReporter").getDeclaredMethod("reportWithProductId", new Class[]{Context.class, String.class, String.class, Boolean.TYPE}).invoke(null, new Object[]{this.f5218b, this.f5219c, BuildConfig.FLAVOR, Boolean.valueOf(true)});
        } catch (ClassNotFoundException e) {
            wg.m14620e("Google Conversion Tracking SDK 1.2.0 or above is required to report a conversion.");
        } catch (NoSuchMethodException e2) {
            wg.m14620e("Google Conversion Tracking SDK 1.2.0 or above is required to report a conversion.");
        } catch (Throwable e3) {
            wg.m14618c("Fail to report a conversion.", e3);
        }
    }

    public void m8621c(int i) {
        if (i == 0) {
            m8620c();
        }
        Map b = m8618b();
        b.put("google_play_status", String.valueOf(i));
        b.put("sku", this.f5219c);
        b.put(ad.CATEGORY_STATUS, String.valueOf(m8616a(i)));
        List linkedList = new LinkedList();
        Iterator it = this.f5220d.iterator();
        while (it.hasNext()) {
            linkedList.add(C2243w.m8786e().m14702a((String) it.next(), b));
        }
        C2243w.m8786e().m14713a(this.f5218b, this.f5217a, linkedList);
    }
}
