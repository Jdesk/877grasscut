package com.google.android.gms.ads.internal.overlay;

import android.annotation.TargetApi;
import android.content.Context;
import android.media.AudioManager;
import android.media.AudioManager.OnAudioFocusChangeListener;
import com.google.android.gms.p095b.sc;

@TargetApi(14)
@sc
/* renamed from: com.google.android.gms.ads.internal.overlay.c */
public class C2156c implements OnAudioFocusChangeListener {
    private final AudioManager f5075a;
    private final C2155a f5076b;
    private boolean f5077c;
    private boolean f5078d;
    private boolean f5079e;
    private float f5080f;

    /* renamed from: com.google.android.gms.ads.internal.overlay.c.a */
    interface C2155a {
        void m8407a();
    }

    public C2156c(Context context, C2155a c2155a) {
        this.f5080f = 1.0f;
        this.f5075a = (AudioManager) context.getSystemService("audio");
        this.f5076b = c2155a;
    }

    private void m8408d() {
        Object obj = (!this.f5078d || this.f5079e || this.f5080f <= 0.0f) ? null : 1;
        if (obj != null && !this.f5077c) {
            m8409e();
            this.f5076b.m8407a();
        } else if (obj == null && this.f5077c) {
            m8410f();
            this.f5076b.m8407a();
        }
    }

    private void m8409e() {
        boolean z = true;
        if (this.f5075a != null && !this.f5077c) {
            if (this.f5075a.requestAudioFocus(this, 3, 2) != 1) {
                z = false;
            }
            this.f5077c = z;
        }
    }

    private void m8410f() {
        if (this.f5075a != null && this.f5077c) {
            this.f5077c = this.f5075a.abandonAudioFocus(this) == 0;
        }
    }

    public float m8411a() {
        return this.f5077c ? this.f5079e ? 0.0f : this.f5080f : 0.0f;
    }

    public void m8412a(float f) {
        this.f5080f = f;
        m8408d();
    }

    public void m8413a(boolean z) {
        this.f5079e = z;
        m8408d();
    }

    public void m8414b() {
        this.f5078d = true;
        m8408d();
    }

    public void m8415c() {
        this.f5078d = false;
        m8408d();
    }

    public void onAudioFocusChange(int i) {
        this.f5077c = i > 0;
        this.f5076b.m8407a();
    }
}
