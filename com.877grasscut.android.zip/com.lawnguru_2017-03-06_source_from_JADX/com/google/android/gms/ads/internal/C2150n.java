package com.google.android.gms.ads.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C2149a;
import com.google.android.gms.p095b.sc;

@sc
/* renamed from: com.google.android.gms.ads.internal.n */
public final class C2150n extends C2149a {
    public static final Creator<C2150n> CREATOR;
    public final boolean f5006a;
    public final boolean f5007b;
    public final String f5008c;
    public final boolean f5009d;
    public final float f5010e;
    public final int f5011f;

    static {
        CREATOR = new C2151o();
    }

    C2150n(boolean z, boolean z2, String str, boolean z3, float f, int i) {
        this.f5006a = z;
        this.f5007b = z2;
        this.f5008c = str;
        this.f5009d = z3;
        this.f5010e = f;
        this.f5011f = i;
    }

    public C2150n(boolean z, boolean z2, boolean z3, float f, int i) {
        this(z, z2, null, z3, f, i);
    }

    public void writeToParcel(Parcel parcel, int i) {
        C2151o.m8359a(this, parcel, i);
    }
}
