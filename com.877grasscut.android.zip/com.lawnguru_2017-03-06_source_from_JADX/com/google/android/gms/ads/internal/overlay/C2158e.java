package com.google.android.gms.ads.internal.overlay;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C2149a;
import com.google.android.gms.p095b.sc;

@sc
/* renamed from: com.google.android.gms.ads.internal.overlay.e */
public final class C2158e extends C2149a {
    public static final Creator<C2158e> CREATOR;
    public final String f5081a;
    public final String f5082b;
    public final String f5083c;
    public final String f5084d;
    public final String f5085e;
    public final String f5086f;
    public final String f5087g;
    public final Intent f5088h;

    static {
        CREATOR = new C2157d();
    }

    public C2158e(Intent intent) {
        this(null, null, null, null, null, null, null, intent);
    }

    public C2158e(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        this(str, str2, str3, str4, str5, str6, str7, null);
    }

    public C2158e(String str, String str2, String str3, String str4, String str5, String str6, String str7, Intent intent) {
        this.f5081a = str;
        this.f5082b = str2;
        this.f5083c = str3;
        this.f5084d = str4;
        this.f5085e = str5;
        this.f5086f = str6;
        this.f5087g = str7;
        this.f5088h = intent;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C2157d.m8416a(this, parcel, i);
    }
}
