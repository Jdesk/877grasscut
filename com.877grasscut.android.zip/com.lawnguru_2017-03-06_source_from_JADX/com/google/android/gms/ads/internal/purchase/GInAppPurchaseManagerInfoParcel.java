package com.google.android.gms.ads.internal.purchase;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.C2149a;
import com.google.android.gms.p095b.ra;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p097a.C2046a.C2048a;
import com.google.android.gms.p097a.C2060d;

@sc
public final class GInAppPurchaseManagerInfoParcel extends C2149a implements ReflectedParcelable {
    public static final Creator<GInAppPurchaseManagerInfoParcel> CREATOR;
    public final C2222k f5199a;
    public final ra f5200b;
    public final Context f5201c;
    public final C2113j f5202d;

    static {
        CREATOR = new C2206a();
    }

    public GInAppPurchaseManagerInfoParcel(Context context, C2222k c2222k, ra raVar, C2113j c2113j) {
        this.f5201c = context;
        this.f5199a = c2222k;
        this.f5200b = raVar;
        this.f5202d = c2113j;
    }

    GInAppPurchaseManagerInfoParcel(IBinder iBinder, IBinder iBinder2, IBinder iBinder3, IBinder iBinder4) {
        this.f5199a = (C2222k) C2060d.m7974a(C2048a.m7925a(iBinder));
        this.f5200b = (ra) C2060d.m7974a(C2048a.m7925a(iBinder2));
        this.f5201c = (Context) C2060d.m7974a(C2048a.m7925a(iBinder3));
        this.f5202d = (C2113j) C2060d.m7974a(C2048a.m7925a(iBinder4));
    }

    public static GInAppPurchaseManagerInfoParcel m8589a(Intent intent) {
        try {
            Bundle bundleExtra = intent.getBundleExtra("com.google.android.gms.ads.internal.purchase.InAppPurchaseManagerInfo");
            bundleExtra.setClassLoader(GInAppPurchaseManagerInfoParcel.class.getClassLoader());
            return (GInAppPurchaseManagerInfoParcel) bundleExtra.getParcelable("com.google.android.gms.ads.internal.purchase.InAppPurchaseManagerInfo");
        } catch (Exception e) {
            return null;
        }
    }

    public static void m8590a(Intent intent, GInAppPurchaseManagerInfoParcel gInAppPurchaseManagerInfoParcel) {
        Bundle bundle = new Bundle(1);
        bundle.putParcelable("com.google.android.gms.ads.internal.purchase.InAppPurchaseManagerInfo", gInAppPurchaseManagerInfoParcel);
        intent.putExtra("com.google.android.gms.ads.internal.purchase.InAppPurchaseManagerInfo", bundle);
    }

    IBinder m8591a() {
        return C2060d.m7973a(this.f5202d).asBinder();
    }

    IBinder m8592b() {
        return C2060d.m7973a(this.f5199a).asBinder();
    }

    IBinder m8593c() {
        return C2060d.m7973a(this.f5200b).asBinder();
    }

    IBinder m8594d() {
        return C2060d.m7973a(this.f5201c).asBinder();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C2206a.m8595a(this, parcel, i);
    }
}
