package com.google.android.gms.ads.internal;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.RemoteException;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.p095b.ig;
import com.google.android.gms.p095b.ih;
import com.google.android.gms.p095b.ka;
import com.google.android.gms.p095b.ke;
import com.google.android.gms.p095b.kj;
import com.google.android.gms.p095b.km;
import com.google.android.gms.p095b.kn;
import com.google.android.gms.p095b.kr.C2100a;
import com.google.android.gms.p095b.kt;
import com.google.android.gms.p095b.kv;
import com.google.android.gms.p095b.kz;
import com.google.android.gms.p095b.lb;
import com.google.android.gms.p095b.ln;
import com.google.android.gms.p095b.ly;
import com.google.android.gms.p095b.mk;
import com.google.android.gms.p095b.rb;
import com.google.android.gms.p095b.rf;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.tv;
import com.google.android.gms.p095b.vn;
import com.google.android.gms.p095b.wg;
import com.google.android.gms.p095b.wi;
import com.google.android.gms.p097a.C2046a;
import com.google.android.gms.p097a.C2060d;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@sc
/* renamed from: com.google.android.gms.ads.internal.v */
public class C2242v extends C2100a {
    private final wi f5285a;
    private final ke f5286b;
    private final Future<ig> f5287c;
    private final Context f5288d;
    private final C2241b f5289e;
    private WebView f5290f;
    private kn f5291g;
    private ig f5292h;
    private AsyncTask<Void, Void, String> f5293i;

    /* renamed from: com.google.android.gms.ads.internal.v.1 */
    class C22371 extends WebViewClient {
        final /* synthetic */ C2242v f5277a;

        C22371(C2242v c2242v) {
            this.f5277a = c2242v;
        }

        public void onReceivedError(WebView webView, WebResourceRequest webResourceRequest, WebResourceError webResourceError) {
            if (this.f5277a.f5291g != null) {
                try {
                    this.f5277a.f5291g.m12160a(0);
                } catch (Throwable e) {
                    wg.m14618c("Could not call AdListener.onAdFailedToLoad().", e);
                }
            }
        }

        public boolean shouldOverrideUrlLoading(WebView webView, String str) {
            if (str.startsWith(this.f5277a.m8765b())) {
                return false;
            }
            if (str.startsWith((String) ly.cI.m12563c())) {
                if (this.f5277a.f5291g != null) {
                    try {
                        this.f5277a.f5291g.m12160a(3);
                    } catch (Throwable e) {
                        wg.m14618c("Could not call AdListener.onAdFailedToLoad().", e);
                    }
                }
                this.f5277a.m8749a(0);
                return true;
            } else if (str.startsWith((String) ly.cJ.m12563c())) {
                if (this.f5277a.f5291g != null) {
                    try {
                        this.f5277a.f5291g.m12160a(0);
                    } catch (Throwable e2) {
                        wg.m14618c("Could not call AdListener.onAdFailedToLoad().", e2);
                    }
                }
                this.f5277a.m8749a(0);
                return true;
            } else if (str.startsWith((String) ly.cK.m12563c())) {
                if (this.f5277a.f5291g != null) {
                    try {
                        this.f5277a.f5291g.m12162c();
                    } catch (Throwable e22) {
                        wg.m14618c("Could not call AdListener.onAdLoaded().", e22);
                    }
                }
                this.f5277a.m8749a(this.f5277a.m8764b(str));
                return true;
            } else if (str.startsWith("gmsg://")) {
                return true;
            } else {
                if (this.f5277a.f5291g != null) {
                    try {
                        this.f5277a.f5291g.m12161b();
                    } catch (Throwable e222) {
                        wg.m14618c("Could not call AdListener.onAdLeftApplication().", e222);
                    }
                }
                this.f5277a.m8743d(this.f5277a.m8739c(str));
                return true;
            }
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.v.2 */
    class C22382 implements OnTouchListener {
        final /* synthetic */ C2242v f5278a;

        C22382(C2242v c2242v) {
            this.f5278a = c2242v;
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            if (this.f5278a.f5292h != null) {
                try {
                    this.f5278a.f5292h.m11854a(motionEvent);
                } catch (Throwable e) {
                    wg.m14618c("Unable to process ad data", e);
                }
            }
            return false;
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.v.3 */
    class C22393 implements Callable<ig> {
        final /* synthetic */ C2242v f5279a;

        C22393(C2242v c2242v) {
            this.f5279a = c2242v;
        }

        public ig m8725a() {
            return new ig(this.f5279a.f5285a.f9227a, this.f5279a.f5288d, false);
        }

        public /* synthetic */ Object call() {
            return m8725a();
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.v.a */
    private class C2240a extends AsyncTask<Void, Void, String> {
        final /* synthetic */ C2242v f5280a;

        private C2240a(C2242v c2242v) {
            this.f5280a = c2242v;
        }

        protected String m8726a(Void... voidArr) {
            Throwable e;
            try {
                this.f5280a.f5292h = (ig) this.f5280a.f5287c.get(((Long) ly.cN.m12563c()).longValue(), TimeUnit.MILLISECONDS);
            } catch (InterruptedException e2) {
                e = e2;
                wg.m14618c("Failed to load ad data", e);
            } catch (ExecutionException e3) {
                e = e3;
                wg.m14618c("Failed to load ad data", e);
            } catch (TimeoutException e4) {
                wg.m14620e("Timed out waiting for ad data");
            }
            return this.f5280a.m8748a();
        }

        protected void m8727a(String str) {
            if (this.f5280a.f5290f != null && str != null) {
                this.f5280a.f5290f.loadUrl(str);
            }
        }

        protected /* synthetic */ Object doInBackground(Object[] objArr) {
            return m8726a((Void[]) objArr);
        }

        protected /* synthetic */ void onPostExecute(Object obj) {
            m8727a((String) obj);
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.v.b */
    private static class C2241b {
        private final String f5281a;
        private final Map<String, String> f5282b;
        private String f5283c;
        private String f5284d;

        public C2241b(String str) {
            this.f5281a = str;
            this.f5282b = new TreeMap();
        }

        public String m8728a() {
            return this.f5284d;
        }

        public void m8729a(ka kaVar, wi wiVar) {
            this.f5283c = kaVar.f7356j.f7547n;
            Bundle bundle = kaVar.f7359m != null ? kaVar.f7359m.getBundle(AdMobAdapter.class.getName()) : null;
            if (bundle != null) {
                String str = (String) ly.cM.m12563c();
                for (String str2 : bundle.keySet()) {
                    if (str.equals(str2)) {
                        this.f5284d = bundle.getString(str2);
                    } else if (str2.startsWith("csa_")) {
                        this.f5282b.put(str2.substring("csa_".length()), bundle.getString(str2));
                    }
                }
                this.f5282b.put("SDKVersion", wiVar.f9227a);
            }
        }

        public String m8730b() {
            return this.f5283c;
        }

        public String m8731c() {
            return this.f5281a;
        }

        public Map<String, String> m8732d() {
            return this.f5282b;
        }
    }

    public C2242v(Context context, ke keVar, String str, wi wiVar) {
        this.f5288d = context;
        this.f5285a = wiVar;
        this.f5286b = keVar;
        this.f5290f = new WebView(this.f5288d);
        this.f5287c = m8742d();
        this.f5289e = new C2241b(str);
        m8740c();
    }

    private String m8739c(String str) {
        if (this.f5292h == null) {
            return str;
        }
        Uri parse = Uri.parse(str);
        try {
            parse = this.f5292h.m11855b(parse, this.f5288d);
        } catch (Throwable e) {
            wg.m14618c("Unable to process ad data", e);
        } catch (Throwable e2) {
            wg.m14618c("Unable to parse ad click url", e2);
        }
        return parse.toString();
    }

    private void m8740c() {
        m8749a(0);
        this.f5290f.setVerticalScrollBarEnabled(false);
        this.f5290f.getSettings().setJavaScriptEnabled(true);
        this.f5290f.setWebViewClient(new C22371(this));
        this.f5290f.setOnTouchListener(new C22382(this));
    }

    private Future<ig> m8742d() {
        return vn.m14669a(new C22393(this));
    }

    private void m8743d(String str) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse(str));
        this.f5288d.startActivity(intent);
    }

    public String m8746G() {
        return null;
    }

    public void m8747H() {
        throw new IllegalStateException("Unused method");
    }

    String m8748a() {
        String valueOf;
        Uri a;
        Throwable e;
        String valueOf2;
        Builder builder = new Builder();
        builder.scheme("https://").appendEncodedPath((String) ly.cL.m12563c());
        builder.appendQueryParameter("query", this.f5289e.m8730b());
        builder.appendQueryParameter("pubId", this.f5289e.m8731c());
        Map d = this.f5289e.m8732d();
        for (String valueOf3 : d.keySet()) {
            builder.appendQueryParameter(valueOf3, (String) d.get(valueOf3));
        }
        Uri build = builder.build();
        if (this.f5292h != null) {
            try {
                a = this.f5292h.m11853a(build, this.f5288d);
            } catch (ih e2) {
                e = e2;
                wg.m14618c("Unable to process ad data", e);
                a = build;
                valueOf2 = String.valueOf(m8765b());
                valueOf3 = String.valueOf(a.getEncodedQuery());
                return new StringBuilder((String.valueOf(valueOf2).length() + 1) + String.valueOf(valueOf3).length()).append(valueOf2).append("#").append(valueOf3).toString();
            } catch (RemoteException e3) {
                e = e3;
                wg.m14618c("Unable to process ad data", e);
                a = build;
                valueOf2 = String.valueOf(m8765b());
                valueOf3 = String.valueOf(a.getEncodedQuery());
                return new StringBuilder((String.valueOf(valueOf2).length() + 1) + String.valueOf(valueOf3).length()).append(valueOf2).append("#").append(valueOf3).toString();
            }
            valueOf2 = String.valueOf(m8765b());
            valueOf3 = String.valueOf(a.getEncodedQuery());
            return new StringBuilder((String.valueOf(valueOf2).length() + 1) + String.valueOf(valueOf3).length()).append(valueOf2).append("#").append(valueOf3).toString();
        }
        a = build;
        valueOf2 = String.valueOf(m8765b());
        valueOf3 = String.valueOf(a.getEncodedQuery());
        return new StringBuilder((String.valueOf(valueOf2).length() + 1) + String.valueOf(valueOf3).length()).append(valueOf2).append("#").append(valueOf3).toString();
    }

    void m8749a(int i) {
        if (this.f5290f != null) {
            this.f5290f.setLayoutParams(new LayoutParams(-1, i));
        }
    }

    public void m8750a(ke keVar) {
        throw new IllegalStateException("AdSize must be set before initialization");
    }

    public void m8751a(km kmVar) {
        throw new IllegalStateException("Unused method");
    }

    public void m8752a(kn knVar) {
        this.f5291g = knVar;
    }

    public void m8753a(kt ktVar) {
        throw new IllegalStateException("Unused method");
    }

    public void m8754a(kv kvVar) {
        throw new IllegalStateException("Unused method");
    }

    public void m8755a(lb lbVar) {
        throw new IllegalStateException("Unused method");
    }

    public void m8756a(ln lnVar) {
        throw new IllegalStateException("Unused method");
    }

    public void m8757a(mk mkVar) {
        throw new IllegalStateException("Unused method");
    }

    public void m8758a(rb rbVar) {
        throw new IllegalStateException("Unused method");
    }

    public void m8759a(rf rfVar, String str) {
        throw new IllegalStateException("Unused method");
    }

    public void m8760a(tv tvVar) {
        throw new IllegalStateException("Unused method");
    }

    public void m8761a(String str) {
        throw new IllegalStateException("Unused method");
    }

    public void m8762a(boolean z) {
    }

    public boolean m8763a(ka kaVar) {
        C3234c.m16043a(this.f5290f, (Object) "This Search Ad has already been torn down");
        this.f5289e.m8729a(kaVar, this.f5285a);
        this.f5293i = new C2240a().execute(new Void[0]);
        return true;
    }

    int m8764b(String str) {
        int i = 0;
        Object queryParameter = Uri.parse(str).getQueryParameter("height");
        if (!TextUtils.isEmpty(queryParameter)) {
            try {
                i = kj.m12293a().m14895a(this.f5288d, Integer.parseInt(queryParameter));
            } catch (NumberFormatException e) {
            }
        }
        return i;
    }

    String m8765b() {
        String str;
        CharSequence a = this.f5289e.m8728a();
        if (TextUtils.isEmpty(a)) {
            str = "www.google.com";
        } else {
            CharSequence charSequence = a;
        }
        String valueOf = String.valueOf("https://");
        String str2 = (String) ly.cL.m12563c();
        return new StringBuilder((String.valueOf(valueOf).length() + String.valueOf(str).length()) + String.valueOf(str2).length()).append(valueOf).append(str).append(str2).toString();
    }

    public void m8766i() {
        C3234c.m16050b("destroy must be called on the main UI thread.");
        this.f5293i.cancel(true);
        this.f5287c.cancel(true);
        this.f5290f.destroy();
        this.f5290f = null;
    }

    public C2046a m8767j() {
        C3234c.m16050b("getAdFrame must be called on the main UI thread.");
        return C2060d.m7973a(this.f5290f);
    }

    public ke m8768k() {
        return this.f5286b;
    }

    public boolean m8769l() {
        return false;
    }

    public void m8770m() {
        throw new IllegalStateException("Unused method");
    }

    public void m8771n() {
        C3234c.m16050b("pause must be called on the main UI thread.");
    }

    public void m8772o() {
        C3234c.m16050b("resume must be called on the main UI thread.");
    }

    public void m8773p() {
    }

    public boolean m8774q() {
        return false;
    }

    public kz m8775r() {
        return null;
    }
}
