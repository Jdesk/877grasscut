package com.google.android.gms.ads.internal.overlay;

import android.media.MediaPlayer;

/* renamed from: com.google.android.gms.ads.internal.overlay.t */
public class C2192t {
    public MediaPlayer m8550a() {
        return new MediaPlayer();
    }
}
