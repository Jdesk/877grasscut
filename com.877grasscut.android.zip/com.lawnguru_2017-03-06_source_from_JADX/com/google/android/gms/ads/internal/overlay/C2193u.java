package com.google.android.gms.ads.internal.overlay;

import android.annotation.TargetApi;
import android.graphics.SurfaceTexture;
import android.view.Surface;

/* renamed from: com.google.android.gms.ads.internal.overlay.u */
public class C2193u {
    @TargetApi(14)
    public Surface m8551a(SurfaceTexture surfaceTexture) {
        return new Surface(surfaceTexture);
    }
}
