package com.google.android.gms.ads.internal.overlay;

import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.vo;

@sc
/* renamed from: com.google.android.gms.ads.internal.overlay.b */
class C2154b implements Runnable {
    private C2186n f5073a;
    private boolean f5074b;

    C2154b(C2186n c2186n) {
        this.f5074b = false;
        this.f5073a = c2186n;
    }

    private void m8404c() {
        vo.f9130a.removeCallbacks(this);
        vo.f9130a.postDelayed(this, 250);
    }

    public void m8405a() {
        this.f5074b = true;
    }

    public void m8406b() {
        this.f5074b = false;
        m8404c();
    }

    public void run() {
        if (!this.f5074b) {
            this.f5073a.m8546o();
            m8404c();
        }
    }
}
