package com.google.android.gms.ads.internal.overlay;

import android.annotation.TargetApi;
import android.content.Context;
import android.view.TextureView;
import com.google.android.gms.ads.internal.overlay.C2156c.C2155a;
import com.google.android.gms.p095b.sc;

@TargetApi(14)
@sc
/* renamed from: com.google.android.gms.ads.internal.overlay.l */
public abstract class C2167l extends TextureView implements C2155a {
    protected final C2197y f5101a;
    protected final C2156c f5102b;

    public C2167l(Context context) {
        super(context);
        this.f5101a = new C2197y();
        this.f5102b = new C2156c(context, this);
    }

    public abstract void m8419a();

    public void m8420a(float f) {
        this.f5102b.m8412a(f);
        m8419a();
    }

    public abstract void m8421a(float f, float f2);

    public abstract void m8422a(int i);

    public abstract void m8423a(C2182k c2182k);

    public abstract String m8424b();

    public abstract void m8425c();

    public abstract void m8426d();

    public abstract void m8427e();

    public void m8428f() {
        this.f5102b.m8413a(true);
        m8419a();
    }

    public void m8429g() {
        this.f5102b.m8413a(false);
        m8419a();
    }

    public abstract int getCurrentPosition();

    public abstract int getDuration();

    public abstract int getVideoHeight();

    public abstract int getVideoWidth();

    public abstract void setVideoPath(String str);
}
