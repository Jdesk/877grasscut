package com.google.android.gms.ads.internal;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.os.RemoteException;
import android.util.DisplayMetrics;
import android.webkit.CookieManager;
import com.google.android.gms.ads.internal.overlay.C2112j;
import com.google.android.gms.ads.internal.purchase.C2113j;
import com.google.android.gms.ads.internal.purchase.C2209c;
import com.google.android.gms.ads.internal.purchase.C2211d;
import com.google.android.gms.ads.internal.purchase.C2214f;
import com.google.android.gms.ads.internal.purchase.C2216g;
import com.google.android.gms.ads.internal.purchase.C2222k;
import com.google.android.gms.ads.internal.purchase.GInAppPurchaseManagerInfoParcel;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.p095b.bn;
import com.google.android.gms.p095b.ka;
import com.google.android.gms.p095b.ke;
import com.google.android.gms.p095b.kj;
import com.google.android.gms.p095b.ly;
import com.google.android.gms.p095b.mg;
import com.google.android.gms.p095b.nz;
import com.google.android.gms.p095b.ox;
import com.google.android.gms.p095b.pn;
import com.google.android.gms.p095b.pw;
import com.google.android.gms.p095b.ra;
import com.google.android.gms.p095b.rb;
import com.google.android.gms.p095b.rf;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.si.C2991a;
import com.google.android.gms.p095b.sp;
import com.google.android.gms.p095b.vb;
import com.google.android.gms.p095b.vc;
import com.google.android.gms.p095b.vd;
import com.google.android.gms.p095b.vn;
import com.google.android.gms.p095b.vo;
import com.google.android.gms.p095b.wg;
import com.google.android.gms.p095b.wi;
import com.google.android.gms.p095b.wk;
import com.google.android.gms.p095b.wn;
import com.google.android.gms.p095b.wx;
import io.card.payment.BuildConfig;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;

@sc
/* renamed from: com.google.android.gms.ads.internal.b */
public abstract class C2115b extends C2104a implements C2112j, C2113j, C2114u, nz, pn {
    protected final pw f4923j;
    protected transient boolean f4924k;

    /* renamed from: com.google.android.gms.ads.internal.b.1 */
    class C21051 implements Callable<Boolean> {
        final /* synthetic */ C2115b f4912a;

        C21051(C2115b c2115b) {
            this.f4912a = c2115b;
        }

        public Boolean m8176a() {
            return Boolean.valueOf(false);
        }

        public /* synthetic */ Object call() {
            return m8176a();
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.b.2 */
    class C21062 implements Callable<String> {
        final /* synthetic */ C2115b f4913a;

        C21062(C2115b c2115b) {
            this.f4913a = c2115b;
        }

        public String m8177a() {
            String str = BuildConfig.FLAVOR;
            if (((Boolean) ly.cV.m12563c()).booleanValue()) {
                CookieManager c = C2243w.m8788g().m14779c(this.f4913a.f.f5348c);
                if (c != null) {
                    return c.getCookie("googleads.g.doubleclick.net");
                }
            }
            return str;
        }

        public /* synthetic */ Object call() {
            return m8177a();
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.b.3 */
    class C21073 implements Callable<String> {
        final /* synthetic */ C2115b f4914a;

        C21073(C2115b c2115b) {
            this.f4914a = c2115b;
        }

        public String m8178a() {
            return this.f4914a.f.f5349d.m11380a().m8275a(this.f4914a.f.f5348c);
        }

        public /* synthetic */ Object call() {
            return m8178a();
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.b.4 */
    class C21084 implements Runnable {
        final /* synthetic */ wn f4915a;
        final /* synthetic */ wk f4916b;
        final /* synthetic */ boolean f4917c;
        final /* synthetic */ boolean f4918d;

        C21084(C2115b c2115b, wn wnVar, wk wkVar, boolean z, boolean z2) {
            this.f4915a = wnVar;
            this.f4916b = wkVar;
            this.f4917c = z;
            this.f4918d = z2;
        }

        public void run() {
            boolean z = false;
            try {
                z = this.f4915a.isDone() ? ((Boolean) this.f4915a.get()).booleanValue() : false;
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } catch (Throwable e2) {
                wg.m14616b("Error receiving app streaming support", e2);
            }
            this.f4916b.m13283b(new sp(this.f4917c, this.f4918d, z));
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.b.5 */
    class C21095 implements Runnable {
        final /* synthetic */ Intent f4919a;
        final /* synthetic */ C2115b f4920b;

        C21095(C2115b c2115b, Intent intent) {
            this.f4920b = c2115b;
            this.f4919a = intent;
        }

        public void run() {
            int a = C2243w.m8800s().m8650a(this.f4919a);
            C2243w.m8800s();
            if (!(a != 0 || this.f4920b.f.f5355j == null || this.f4920b.f.f5355j.f8981b == null || this.f4920b.f.f5355j.f8981b.m14983i() == null)) {
                this.f4920b.f.f5355j.f8981b.m14983i().m8467a();
            }
            this.f4920b.f.f5337G = false;
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.b.6 */
    class C21106 implements Runnable {
        final /* synthetic */ C2115b f4921a;

        C21106(C2115b c2115b) {
            this.f4921a = c2115b;
        }

        public void run() {
            this.f4921a.e.m8721b();
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.b.7 */
    class C21117 implements Runnable {
        final /* synthetic */ C2115b f4922a;

        C21117(C2115b c2115b) {
            this.f4922a = c2115b;
        }

        public void run() {
            this.f4922a.e.m8723c();
        }
    }

    public C2115b(Context context, ke keVar, String str, pw pwVar, wi wiVar, C2124e c2124e) {
        this(new C2245x(context, keVar, str, wiVar), pwVar, null, c2124e);
    }

    protected C2115b(C2245x c2245x, pw pwVar, C2236t c2236t, C2124e c2124e) {
        super(c2245x, c2236t, c2124e);
        this.f4923j = pwVar;
        this.f4924k = false;
    }

    private C2991a m8193a(ka kaVar, Bundle bundle, vd vdVar) {
        PackageInfo b;
        ApplicationInfo applicationInfo = this.f.f5348c.getApplicationInfo();
        try {
            b = bn.m9791b(this.f.f5348c).m9789b(applicationInfo.packageName, 0);
        } catch (NameNotFoundException e) {
            b = null;
        }
        DisplayMetrics displayMetrics = this.f.f5348c.getResources().getDisplayMetrics();
        Bundle bundle2 = null;
        if (!(this.f.f5351f == null || this.f.f5351f.getParent() == null)) {
            int[] iArr = new int[2];
            this.f.f5351f.getLocationOnScreen(iArr);
            int i = iArr[0];
            int i2 = iArr[1];
            int width = this.f.f5351f.getWidth();
            int height = this.f.f5351f.getHeight();
            int i3 = 0;
            if (this.f.f5351f.isShown() && i + width > 0 && i2 + height > 0 && i <= displayMetrics.widthPixels && i2 <= displayMetrics.heightPixels) {
                i3 = 1;
            }
            bundle2 = new Bundle(5);
            bundle2.putInt("x", i);
            bundle2.putInt("y", i2);
            bundle2.putInt("width", width);
            bundle2.putInt("height", height);
            bundle2.putInt("visible", i3);
        }
        String d = C2243w.m8790i().m14574d();
        this.f.f5357l = new vc(d, this.f.f5347b);
        this.f.f5357l.m14534a(kaVar);
        String a = C2243w.m8786e().m14696a(this.f.f5348c, this.f.f5351f, this.f.f5354i);
        long j = 0;
        if (this.f.f5361p != null) {
            try {
                j = this.f.f5361p.m12297a();
            } catch (RemoteException e2) {
                wg.m14620e("Cannot get correlation id, default to 0.");
            }
        }
        String uuid = UUID.randomUUID().toString();
        Bundle a2 = C2243w.m8790i().m14549a(this.f.f5348c, this, d);
        List arrayList = new ArrayList();
        for (i = 0; i < this.f.f5367v.size(); i++) {
            arrayList.add((String) this.f.f5367v.m2061b(i));
        }
        boolean z = this.f.f5362q != null;
        boolean z2 = this.f.f5363r != null && C2243w.m8790i().m14595v();
        wn a3 = vn.m14669a(new C21051(this));
        Future a4 = vn.m14669a(new C21062(this));
        Future a5 = vn.m14669a(new C21073(this));
        String str = null;
        if (vdVar != null) {
            str = vdVar.m14545c();
        }
        wk wkVar = new wk();
        a3.m13278a(new C21084(this, a3, wkVar, z, z2));
        return new C2991a(bundle2, kaVar, this.f.f5354i, this.f.f5347b, applicationInfo, b, d, C2243w.m8790i().m14551a(), this.f.f5350e, a2, this.f.f5332B, arrayList, bundle, C2243w.m8790i().m14581h(), displayMetrics.widthPixels, displayMetrics.heightPixels, displayMetrics.density, a, j, uuid, ly.m12585a(), this.f.f5346a, this.f.f5368w, wkVar, this.f.m8823h(), C2243w.m8786e().m14749g(), C2243w.m8786e().m14752h(), C2243w.m8786e().m14756k(this.f.f5348c), C2243w.m8786e().m14728b(this.f.f5351f), this.f.f5348c instanceof Activity, C2243w.m8790i().m14586m(), a4, str, C2243w.m8790i().m14590q(), C2243w.m8777B().m13083a(), C2243w.m8786e().m14754i(), C2243w.m8794m().m14831a(), this.f.f5370y, C2243w.m8794m().m14839b(), ox.m13194a().m13203i(), C2243w.m8790i().m14573c(this.f.f5348c, this.f.f5347b), a5);
    }

    public void m8194A() {
        m8204a();
    }

    public void m8195B() {
        m8157f();
    }

    public void m8196C() {
        m8218d();
    }

    public void m8197D() {
        if (this.f.f5355j != null) {
            String str = this.f.f5355j.f8996q;
            wg.m14620e(new StringBuilder(String.valueOf(str).length() + 74).append("Mediation adapter ").append(str).append(" refreshed, but mediation adapters should never refresh.").toString());
        }
        m8207a(this.f.f5355j, true);
        m8173v();
    }

    public void m8198E() {
        m8199F();
    }

    public void m8199F() {
        m8207a(this.f.f5355j, false);
    }

    public String m8200G() {
        return this.f.f5355j == null ? null : this.f.f5355j.f8996q;
    }

    public void m8201H() {
        throw new IllegalStateException("showInterstitial is not supported for current ad type");
    }

    public void m8202I() {
        C2243w.m8786e().m14717a(new C21106(this));
    }

    public void m8203J() {
        C2243w.m8786e().m14717a(new C21117(this));
    }

    public void m8204a() {
        this.h.m11926b(this.f.f5355j);
        this.f4924k = false;
        m8170s();
        this.f.f5357l.m14539c();
    }

    public void m8205a(rb rbVar) {
        C3234c.m16050b("setInAppPurchaseListener must be called on the main UI thread.");
        this.f.f5362q = rbVar;
    }

    public void m8206a(rf rfVar, String str) {
        C3234c.m16050b("setPlayStorePurchaseParams must be called on the main UI thread.");
        this.f.f5333C = new C2222k(str);
        this.f.f5363r = rfVar;
        if (!C2243w.m8790i().m14580g() && rfVar != null) {
            new C2209c(this.f.f5348c, this.f.f5363r, this.f.f5333C).m8331d();
        }
    }

    protected void m8207a(vb vbVar, boolean z) {
        if (vbVar == null) {
            wg.m14620e("Ad state was null when trying to ping impression URLs.");
            return;
        }
        super.m8154c(vbVar);
        if (!(vbVar.f8997r == null || vbVar.f8997r.f8068d == null)) {
            String d = C2243w.m8779D().m14492d(this.f.f5348c);
            C2243w.m8805x().m13415a(this.f.f5348c, this.f.f5350e.f9227a, vbVar, this.f.f5347b, z, m8124a(d, vbVar.f8997r.f8068d));
            if (vbVar.f8997r.f8068d.size() > 0) {
                C2243w.m8779D().m14493d(this.f.f5348c, d);
            }
        }
        if (vbVar.f8994o != null && vbVar.f8994o.f8055g != null) {
            C2243w.m8805x().m13415a(this.f.f5348c, this.f.f5350e.f9227a, vbVar, this.f.f5347b, z, vbVar.f8994o.f8055g);
        }
    }

    public void m8208a(String str, ArrayList<String> arrayList) {
        ra c2211d = new C2211d(str, arrayList, this.f.f5348c, this.f.f5350e.f9227a);
        if (this.f.f5362q == null) {
            wg.m14620e("InAppPurchaseListener is not set. Try to launch default purchase flow.");
            if (!kj.m12293a().m14911c(this.f.f5348c)) {
                wg.m14620e("Google Play Service unavailable, cannot launch default purchase flow.");
                return;
            } else if (this.f.f5363r == null) {
                wg.m14620e("PlayStorePurchaseListener is not set.");
                return;
            } else if (this.f.f5333C == null) {
                wg.m14620e("PlayStorePurchaseVerifier is not initialized.");
                return;
            } else if (this.f.f5337G) {
                wg.m14620e("An in-app purchase request is already in progress, abort");
                return;
            } else {
                this.f.f5337G = true;
                try {
                    if (this.f.f5363r.m13860a(str)) {
                        C2243w.m8800s().m8654a(this.f.f5348c, this.f.f5350e.f9230d, new GInAppPurchaseManagerInfoParcel(this.f.f5348c, this.f.f5333C, c2211d, (C2113j) this));
                        return;
                    } else {
                        this.f.f5337G = false;
                        return;
                    }
                } catch (RemoteException e) {
                    wg.m14620e("Could not start In-App purchase.");
                    this.f.f5337G = false;
                    return;
                }
            }
        }
        try {
            this.f.f5362q.m13123a(c2211d);
        } catch (RemoteException e2) {
            wg.m14620e("Could not start In-App purchase.");
        }
    }

    public void m8209a(String str, boolean z, int i, Intent intent, C2214f c2214f) {
        try {
            if (this.f.f5363r != null) {
                this.f.f5363r.m13859a(new C2216g(this.f.f5348c, str, z, i, intent, c2214f));
            }
        } catch (RemoteException e) {
            wg.m14620e("Fail to invoke PlayStorePurchaseListener.");
        }
        vo.f9130a.postDelayed(new C21095(this, intent), 500);
    }

    public boolean m8210a(ka kaVar, mg mgVar) {
        if (!m8222y()) {
            return false;
        }
        vd r;
        Bundle m = C2243w.m8786e().m14758m(this.f.f5348c);
        this.e.m8718a();
        this.f.f5336F = 0;
        if (((Boolean) ly.cD.m12563c()).booleanValue()) {
            r = C2243w.m8790i().m14591r();
            C2243w.m8776A().m8272a(this.f.f5348c, this.f.f5350e, this.f.f5347b, r);
        } else {
            r = null;
        }
        C2991a a = m8193a(kaVar, m, r);
        mgVar.m12664a("seq_num", a.f8513g);
        mgVar.m12664a("request_id", a.f8527u);
        mgVar.m12664a("session_id", a.f8514h);
        if (a.f8512f != null) {
            mgVar.m12664a("app_version", String.valueOf(a.f8512f.versionCode));
        }
        this.f.f5352g = C2243w.m8781a().m14020a(this.f.f5348c, a, this);
        return true;
    }

    protected boolean m8211a(ka kaVar, vb vbVar, boolean z) {
        if (!z && this.f.m8820e()) {
            if (vbVar.f8987h > 0) {
                this.e.m8720a(kaVar, vbVar.f8987h);
            } else if (vbVar.f8997r != null && vbVar.f8997r.f8073i > 0) {
                this.e.m8720a(kaVar, vbVar.f8997r.f8073i);
            } else if (!vbVar.f8993n && vbVar.f8983d == 2) {
                this.e.m8722b(kaVar);
            }
        }
        return this.e.m8724d();
    }

    boolean m8212a(vb vbVar) {
        ka kaVar;
        boolean z = false;
        if (this.g != null) {
            kaVar = this.g;
            this.g = null;
        } else {
            kaVar = vbVar.f8980a;
            if (kaVar.f7349c != null) {
                z = kaVar.f7349c.getBoolean("_noRefresh", false);
            }
        }
        return m8211a(kaVar, vbVar, z);
    }

    protected boolean m8213a(vb vbVar, vb vbVar2) {
        int i;
        int i2 = 0;
        if (!(vbVar == null || vbVar.f8998s == null)) {
            vbVar.f8998s.m13374a(null);
        }
        if (vbVar2.f8998s != null) {
            vbVar2.f8998s.m13374a((pn) this);
        }
        if (vbVar2.f8997r != null) {
            i = vbVar2.f8997r.f8080p;
            i2 = vbVar2.f8997r.f8081q;
        } else {
            i = 0;
        }
        this.f.f5334D.m14609a(i, i2);
        return true;
    }

    public void m8214b() {
        this.h.m11928d(this.f.f5355j);
    }

    public void m8215b(vb vbVar) {
        super.m8151b(vbVar);
        if (vbVar.f8994o != null) {
            wg.m14615b("Disable the debug gesture detector on the mediation ad frame.");
            if (this.f.f5351f != null) {
                this.f.f5351f.m8811d();
            }
            wg.m14615b("Pinging network fill URLs.");
            C2243w.m8805x().m13415a(this.f.f5348c, this.f.f5350e.f9227a, vbVar, this.f.f5347b, false, vbVar.f8994o.f8056h);
            if (!(vbVar.f8997r == null || vbVar.f8997r.f8070f == null || vbVar.f8997r.f8070f.size() <= 0)) {
                wg.m14615b("Pinging urls remotely");
                C2243w.m8786e().m14716a(this.f.f5348c, vbVar.f8997r.f8070f);
            }
        } else {
            wg.m14615b("Enable the debug gesture detector on the admob ad frame.");
            if (this.f.f5351f != null) {
                this.f.f5351f.m8810c();
            }
        }
        if (vbVar.f8983d == 3 && vbVar.f8997r != null && vbVar.f8997r.f8069e != null) {
            wg.m14615b("Pinging no fill URLs.");
            C2243w.m8805x().m13415a(this.f.f5348c, this.f.f5350e.f9227a, vbVar, this.f.f5347b, false, vbVar.f8997r.f8069e);
        }
    }

    protected boolean m8216b(ka kaVar) {
        return super.m8152b(kaVar) && !this.f4924k;
    }

    public void m8217c() {
        this.h.m11929e(this.f.f5355j);
    }

    public void m8218d() {
        this.f4924k = true;
        m8172u();
    }

    public void m8219e() {
        if (this.f.f5355j == null) {
            wg.m14620e("Ad state was null when trying to ping click URLs.");
            return;
        }
        if (!(this.f.f5355j.f8997r == null || this.f.f5355j.f8997r.f8067c == null)) {
            String d = C2243w.m8779D().m14492d(this.f.f5348c);
            C2243w.m8805x().m13415a(this.f.f5348c, this.f.f5350e.f9227a, this.f.f5355j, this.f.f5347b, false, m8124a(d, this.f.f5355j.f8997r.f8067c));
            if (this.f.f5355j.f8997r.f8067c.size() > 0) {
                C2243w.m8779D().m14490c(this.f.f5348c, d);
            }
        }
        if (!(this.f.f5355j.f8994o == null || this.f.f5355j.f8994o.f8054f == null)) {
            C2243w.m8805x().m13415a(this.f.f5348c, this.f.f5350e.f9227a, this.f.f5355j, this.f.f5347b, false, this.f.f5355j.f8994o.f8054f);
        }
        super.m8156e();
    }

    public void m8220n() {
        C3234c.m16050b("pause must be called on the main UI thread.");
        if (!(this.f.f5355j == null || this.f.f5355j.f8981b == null || !this.f.m8820e())) {
            C2243w.m8788g().m14773a(this.f.f5355j.f8981b);
        }
        if (!(this.f.f5355j == null || this.f.f5355j.f8995p == null)) {
            try {
                this.f.f5355j.f8995p.m13454d();
            } catch (RemoteException e) {
                wg.m14620e("Could not pause mediation adapter.");
            }
        }
        this.h.m11928d(this.f.f5355j);
        this.e.m8721b();
    }

    public void m8221o() {
        C3234c.m16050b("resume must be called on the main UI thread.");
        wx wxVar = null;
        if (!(this.f.f5355j == null || this.f.f5355j.f8981b == null)) {
            wxVar = this.f.f5355j.f8981b;
        }
        if (wxVar != null && this.f.m8820e()) {
            C2243w.m8788g().m14777b(this.f.f5355j.f8981b);
        }
        if (!(this.f.f5355j == null || this.f.f5355j.f8995p == null)) {
            try {
                this.f.f5355j.f8995p.m13455e();
            } catch (RemoteException e) {
                wg.m14620e("Could not resume mediation adapter.");
            }
        }
        if (wxVar == null || !wxVar.m14995u()) {
            this.e.m8723c();
        }
        this.h.m11929e(this.f.f5355j);
    }

    protected boolean m8222y() {
        return C2243w.m8786e().m14723a(this.f.f5348c, this.f.f5348c.getPackageName(), "android.permission.INTERNET") && C2243w.m8786e().m14722a(this.f.f5348c);
    }

    public void m8223z() {
        m8219e();
    }
}
