package com.google.android.gms.ads.internal.purchase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.SystemClock;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.wg;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;

@sc
/* renamed from: com.google.android.gms.ads.internal.purchase.h */
public class C2218h {
    private static final String f5240a;
    private static final Object f5241c;
    private static C2218h f5242d;
    private final C2217a f5243b;

    /* renamed from: com.google.android.gms.ads.internal.purchase.h.a */
    public class C2217a extends SQLiteOpenHelper {
        public C2217a(C2218h c2218h, Context context, String str) {
            super(context, str, null, 4);
        }

        public void onCreate(SQLiteDatabase sQLiteDatabase) {
            sQLiteDatabase.execSQL(C2218h.f5240a);
        }

        public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
            wg.m14619d("Database updated from version " + i + " to version " + i2);
            sQLiteDatabase.execSQL("DROP TABLE IF EXISTS InAppPurchase");
            onCreate(sQLiteDatabase);
        }
    }

    static {
        f5240a = String.format(Locale.US, "CREATE TABLE IF NOT EXISTS %s ( %s INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, %s TEXT NOT NULL, %s TEXT NOT NULL, %s INTEGER)", new Object[]{"InAppPurchase", "purchase_id", "product_id", "developer_payload", "record_time"});
        f5241c = new Object();
    }

    C2218h(Context context) {
        this.f5243b = new C2217a(this, context, "google_inapp_purchase.db");
    }

    public static C2218h m8641a(Context context) {
        C2218h c2218h;
        synchronized (f5241c) {
            if (f5242d == null) {
                f5242d = new C2218h(context);
            }
            c2218h = f5242d;
        }
        return c2218h;
    }

    public SQLiteDatabase m8643a() {
        try {
            return this.f5243b.getWritableDatabase();
        } catch (SQLiteException e) {
            wg.m14620e("Error opening writable conversion tracking database");
            return null;
        }
    }

    public C2214f m8644a(Cursor cursor) {
        return cursor == null ? null : new C2214f(cursor.getLong(0), cursor.getString(1), cursor.getString(2));
    }

    public List<C2214f> m8645a(long j) {
        Cursor query;
        SQLiteException e;
        String str;
        String valueOf;
        Throwable th;
        synchronized (f5241c) {
            List<C2214f> linkedList = new LinkedList();
            if (j <= 0) {
                return linkedList;
            }
            SQLiteDatabase a = m8643a();
            if (a == null) {
                return linkedList;
            }
            try {
                query = a.query("InAppPurchase", null, null, null, null, null, "record_time ASC", String.valueOf(j));
                try {
                    if (query.moveToFirst()) {
                        do {
                            linkedList.add(m8644a(query));
                        } while (query.moveToNext());
                    }
                    if (query != null) {
                        query.close();
                    }
                } catch (SQLiteException e2) {
                    e = e2;
                    try {
                        str = "Error extracing purchase info: ";
                        valueOf = String.valueOf(e.getMessage());
                        wg.m14620e(valueOf.length() == 0 ? new String(str) : str.concat(valueOf));
                        if (query != null) {
                            query.close();
                        }
                        return linkedList;
                    } catch (Throwable th2) {
                        th = th2;
                        if (query != null) {
                            query.close();
                        }
                        throw th;
                    }
                }
            } catch (SQLiteException e3) {
                e = e3;
                query = null;
                str = "Error extracing purchase info: ";
                valueOf = String.valueOf(e.getMessage());
                if (valueOf.length() == 0) {
                }
                wg.m14620e(valueOf.length() == 0 ? new String(str) : str.concat(valueOf));
                if (query != null) {
                    query.close();
                }
                return linkedList;
            } catch (Throwable th3) {
                th = th3;
                query = null;
                if (query != null) {
                    query.close();
                }
                throw th;
            }
            return linkedList;
        }
    }

    public void m8646a(C2214f c2214f) {
        if (c2214f != null) {
            synchronized (f5241c) {
                SQLiteDatabase a = m8643a();
                if (a == null) {
                    return;
                }
                a.delete("InAppPurchase", String.format(Locale.US, "%s = %d", new Object[]{"purchase_id", Long.valueOf(c2214f.f5230a)}), null);
            }
        }
    }

    public int m8647b() {
        Cursor cursor = null;
        int i = 0;
        synchronized (f5241c) {
            SQLiteDatabase a = m8643a();
            if (a == null) {
            } else {
                try {
                    cursor = a.rawQuery("select count(*) from InAppPurchase", null);
                    if (cursor.moveToFirst()) {
                        i = cursor.getInt(0);
                        if (cursor != null) {
                            cursor.close();
                        }
                    } else {
                        if (cursor != null) {
                            cursor.close();
                        }
                    }
                } catch (SQLiteException e) {
                    String str = "Error getting record count";
                    String valueOf = String.valueOf(e.getMessage());
                    wg.m14620e(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
                    if (cursor != null) {
                        cursor.close();
                    }
                } catch (Throwable th) {
                    if (cursor != null) {
                        cursor.close();
                    }
                }
            }
        }
        return i;
    }

    public void m8648b(C2214f c2214f) {
        if (c2214f != null) {
            synchronized (f5241c) {
                SQLiteDatabase a = m8643a();
                if (a == null) {
                    return;
                }
                ContentValues contentValues = new ContentValues();
                contentValues.put("product_id", c2214f.f5232c);
                contentValues.put("developer_payload", c2214f.f5231b);
                contentValues.put("record_time", Long.valueOf(SystemClock.elapsedRealtime()));
                c2214f.f5230a = a.insert("InAppPurchase", null, contentValues);
                if (((long) m8647b()) > 20000) {
                    m8649c();
                }
            }
        }
    }

    public void m8649c() {
        SQLiteException e;
        String str;
        String valueOf;
        Throwable th;
        synchronized (f5241c) {
            SQLiteDatabase a = m8643a();
            if (a == null) {
                return;
            }
            Cursor query;
            try {
                query = a.query("InAppPurchase", null, null, null, null, null, "record_time ASC", "1");
                if (query != null) {
                    try {
                        if (query.moveToFirst()) {
                            m8646a(m8644a(query));
                        }
                    } catch (SQLiteException e2) {
                        e = e2;
                        try {
                            str = "Error remove oldest record";
                            valueOf = String.valueOf(e.getMessage());
                            wg.m14620e(valueOf.length() == 0 ? new String(str) : str.concat(valueOf));
                            if (query != null) {
                                query.close();
                            }
                        } catch (Throwable th2) {
                            th = th2;
                            if (query != null) {
                                query.close();
                            }
                            throw th;
                        }
                    }
                }
                if (query != null) {
                    query.close();
                }
            } catch (SQLiteException e3) {
                e = e3;
                query = null;
                str = "Error remove oldest record";
                valueOf = String.valueOf(e.getMessage());
                if (valueOf.length() == 0) {
                }
                wg.m14620e(valueOf.length() == 0 ? new String(str) : str.concat(valueOf));
                if (query != null) {
                    query.close();
                }
            } catch (Throwable th3) {
                th = th3;
                query = null;
                if (query != null) {
                    query.close();
                }
                throw th;
            }
        }
    }
}
