package com.google.android.gms.ads.internal.overlay;

/* renamed from: com.google.android.gms.ads.internal.overlay.j */
public interface C2112j {
    void m8179a();

    void m8180b();

    void m8181c();

    void m8182d();
}
