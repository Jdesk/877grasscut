package com.google.android.gms.ads.internal;

import android.view.View;

/* renamed from: com.google.android.gms.ads.internal.i */
public interface C2121i {
    void m8226K();

    void m8227L();

    void m8228b(View view);
}
