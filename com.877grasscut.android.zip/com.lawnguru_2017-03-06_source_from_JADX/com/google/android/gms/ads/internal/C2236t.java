package com.google.android.gms.ads.internal;

import android.os.Handler;
import com.google.android.gms.p095b.ka;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.vo;
import com.google.android.gms.p095b.wg;
import java.lang.ref.WeakReference;

@sc
/* renamed from: com.google.android.gms.ads.internal.t */
public class C2236t {
    private final C2235a f5271a;
    private final Runnable f5272b;
    private ka f5273c;
    private boolean f5274d;
    private boolean f5275e;
    private long f5276f;

    /* renamed from: com.google.android.gms.ads.internal.t.1 */
    class C22341 implements Runnable {
        final /* synthetic */ WeakReference f5268a;
        final /* synthetic */ C2236t f5269b;

        C22341(C2236t c2236t, WeakReference weakReference) {
            this.f5269b = c2236t;
            this.f5268a = weakReference;
        }

        public void run() {
            this.f5269b.f5274d = false;
            C2104a c2104a = (C2104a) this.f5268a.get();
            if (c2104a != null) {
                c2104a.m8153c(this.f5269b.f5273c);
            }
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.t.a */
    public static class C2235a {
        private final Handler f5270a;

        public C2235a(Handler handler) {
            this.f5270a = handler;
        }

        public void m8714a(Runnable runnable) {
            this.f5270a.removeCallbacks(runnable);
        }

        public boolean m8715a(Runnable runnable, long j) {
            return this.f5270a.postDelayed(runnable, j);
        }
    }

    public C2236t(C2104a c2104a) {
        this(c2104a, new C2235a(vo.f9130a));
    }

    C2236t(C2104a c2104a, C2235a c2235a) {
        this.f5274d = false;
        this.f5275e = false;
        this.f5276f = 0;
        this.f5271a = c2235a;
        this.f5272b = new C22341(this, new WeakReference(c2104a));
    }

    public void m8718a() {
        this.f5274d = false;
        this.f5271a.m8714a(this.f5272b);
    }

    public void m8719a(ka kaVar) {
        this.f5273c = kaVar;
    }

    public void m8720a(ka kaVar, long j) {
        if (this.f5274d) {
            wg.m14620e("An ad refresh is already scheduled.");
            return;
        }
        this.f5273c = kaVar;
        this.f5274d = true;
        this.f5276f = j;
        if (!this.f5275e) {
            wg.m14619d("Scheduling ad refresh " + j + " milliseconds from now.");
            this.f5271a.m8715a(this.f5272b, j);
        }
    }

    public void m8721b() {
        this.f5275e = true;
        if (this.f5274d) {
            this.f5271a.m8714a(this.f5272b);
        }
    }

    public void m8722b(ka kaVar) {
        m8720a(kaVar, 60000);
    }

    public void m8723c() {
        this.f5275e = false;
        if (this.f5274d) {
            this.f5274d = false;
            m8720a(this.f5273c, this.f5276f);
        }
    }

    public boolean m8724d() {
        return this.f5274d;
    }
}
