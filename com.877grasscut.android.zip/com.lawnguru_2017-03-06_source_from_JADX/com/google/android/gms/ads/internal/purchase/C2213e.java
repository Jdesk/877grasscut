package com.google.android.gms.ads.internal.purchase;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender.SendIntentException;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import com.google.android.gms.ads.internal.C2243w;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.stats.C3286a;
import com.google.android.gms.p095b.ra;
import com.google.android.gms.p095b.rc.C2212a;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.wg;

@sc
/* renamed from: com.google.android.gms.ads.internal.purchase.e */
public class C2213e extends C2212a implements ServiceConnection {
    C2218h f5221a;
    private final Activity f5222b;
    private Context f5223c;
    private ra f5224d;
    private C2207b f5225e;
    private C2214f f5226f;
    private C2113j f5227g;
    private C2222k f5228h;
    private String f5229i;

    public C2213e(Activity activity) {
        this.f5229i = null;
        this.f5222b = activity;
        this.f5221a = C2218h.m8641a(this.f5222b.getApplicationContext());
    }

    public void m8626a() {
        GInAppPurchaseManagerInfoParcel a = GInAppPurchaseManagerInfoParcel.m8589a(this.f5222b.getIntent());
        this.f5227g = a.f5202d;
        this.f5228h = a.f5199a;
        this.f5224d = a.f5200b;
        this.f5225e = new C2207b(this.f5222b.getApplicationContext());
        this.f5223c = a.f5201c;
        if (this.f5222b.getResources().getConfiguration().orientation == 2) {
            this.f5222b.setRequestedOrientation(C2243w.m8788g().m14760a());
        } else {
            this.f5222b.setRequestedOrientation(C2243w.m8788g().m14774b());
        }
        Intent intent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
        intent.setPackage(GooglePlayServicesUtil.GOOGLE_PLAY_STORE_PACKAGE);
        C3286a.m16282a().m16286a(this.f5222b, intent, (ServiceConnection) this, 1);
    }

    public void m8627a(int i, int i2, Intent intent) {
        if (i == 1001) {
            boolean z = false;
            try {
                int a = C2243w.m8800s().m8650a(intent);
                if (i2 == -1) {
                    C2243w.m8800s();
                    if (a == 0) {
                        if (this.f5228h.m8659a(this.f5229i, i2, intent)) {
                            z = true;
                        }
                        this.f5224d.m8614c(a);
                        this.f5222b.finish();
                        m8628a(this.f5224d.m8612a(), z, i2, intent);
                    }
                }
                this.f5221a.m8646a(this.f5226f);
                this.f5224d.m8614c(a);
                this.f5222b.finish();
                m8628a(this.f5224d.m8612a(), z, i2, intent);
            } catch (RemoteException e) {
                wg.m14620e("Fail to process purchase result.");
                this.f5222b.finish();
            } finally {
                this.f5229i = null;
            }
        }
    }

    protected void m8628a(String str, boolean z, int i, Intent intent) {
        if (this.f5227g != null) {
            this.f5227g.m8183a(str, z, i, intent, this.f5226f);
        }
    }

    public void m8629b() {
        C3286a.m16282a().m16284a(this.f5222b, (ServiceConnection) this);
        this.f5225e.m8601a();
    }

    public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        Throwable e;
        this.f5225e.m8602a(iBinder);
        try {
            this.f5229i = this.f5228h.m8658a();
            Bundle a = this.f5225e.m8600a(this.f5222b.getPackageName(), this.f5224d.m8612a(), this.f5229i);
            PendingIntent pendingIntent = (PendingIntent) a.getParcelable("BUY_INTENT");
            if (pendingIntent == null) {
                int a2 = C2243w.m8800s().m8651a(a);
                this.f5224d.m8614c(a2);
                m8628a(this.f5224d.m8612a(), false, a2, null);
                this.f5222b.finish();
                return;
            }
            this.f5226f = new C2214f(this.f5224d.m8612a(), this.f5229i);
            this.f5221a.m8648b(this.f5226f);
            this.f5222b.startIntentSenderForResult(pendingIntent.getIntentSender(), 1001, new Intent(), Integer.valueOf(0).intValue(), Integer.valueOf(0).intValue(), Integer.valueOf(0).intValue());
        } catch (RemoteException e2) {
            e = e2;
            wg.m14618c("Error when connecting in-app billing service", e);
            this.f5222b.finish();
        } catch (SendIntentException e3) {
            e = e3;
            wg.m14618c("Error when connecting in-app billing service", e);
            this.f5222b.finish();
        }
    }

    public void onServiceDisconnected(ComponentName componentName) {
        wg.m14619d("In-app billing service disconnected.");
        this.f5225e.m8601a();
    }
}
