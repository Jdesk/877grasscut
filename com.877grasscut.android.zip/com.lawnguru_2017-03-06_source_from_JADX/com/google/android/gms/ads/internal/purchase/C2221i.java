package com.google.android.gms.ads.internal.purchase;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import com.google.android.gms.ads.internal.C2243w;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.stats.C3286a;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.ve;
import com.google.android.gms.p095b.vo;
import com.google.android.gms.p095b.wg;
import org.json.JSONException;
import org.json.JSONObject;

@sc
/* renamed from: com.google.android.gms.ads.internal.purchase.i */
public class C2221i {

    /* renamed from: com.google.android.gms.ads.internal.purchase.i.1 */
    class C22201 implements Runnable {
        final /* synthetic */ Context f5245a;

        /* renamed from: com.google.android.gms.ads.internal.purchase.i.1.1 */
        class C22191 implements ServiceConnection {
            final /* synthetic */ C22201 f5244a;

            C22191(C22201 c22201) {
                this.f5244a = c22201;
            }

            public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
                boolean z = false;
                C2207b c2207b = new C2207b(this.f5244a.f5245a.getApplicationContext(), false);
                c2207b.m8602a(iBinder);
                int a = c2207b.m8598a(3, this.f5244a.f5245a.getPackageName(), "inapp");
                ve i = C2243w.m8790i();
                if (a == 0) {
                    z = true;
                }
                i.m14578e(z);
                C3286a.m16282a().m16284a(this.f5244a.f5245a, (ServiceConnection) this);
                c2207b.m8601a();
            }

            public void onServiceDisconnected(ComponentName componentName) {
            }
        }

        C22201(C2221i c2221i, Context context) {
            this.f5245a = context;
        }

        public void run() {
            ServiceConnection c22191 = new C22191(this);
            Intent intent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
            intent.setPackage(GooglePlayServicesUtil.GOOGLE_PLAY_STORE_PACKAGE);
            C3286a.m16282a().m16286a(this.f5245a, intent, c22191, 1);
        }
    }

    public int m8650a(Intent intent) {
        if (intent == null) {
            return 5;
        }
        Object obj = intent.getExtras().get("RESPONSE_CODE");
        if (obj == null) {
            wg.m14620e("Intent with no response code, assuming OK (known issue)");
            return 0;
        } else if (obj instanceof Integer) {
            return ((Integer) obj).intValue();
        } else {
            if (obj instanceof Long) {
                return (int) ((Long) obj).longValue();
            }
            String str = "Unexpected type for intent response code. ";
            String valueOf = String.valueOf(obj.getClass().getName());
            wg.m14620e(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
            return 5;
        }
    }

    public int m8651a(Bundle bundle) {
        Object obj = bundle.get("RESPONSE_CODE");
        if (obj == null) {
            wg.m14620e("Bundle with null response code, assuming OK (known issue)");
            return 0;
        } else if (obj instanceof Integer) {
            return ((Integer) obj).intValue();
        } else {
            if (obj instanceof Long) {
                return (int) ((Long) obj).longValue();
            }
            String str = "Unexpected type for intent response code. ";
            String valueOf = String.valueOf(obj.getClass().getName());
            wg.m14620e(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
            return 5;
        }
    }

    public String m8652a(String str) {
        String str2 = null;
        if (str != null) {
            try {
                str2 = new JSONObject(str).getString("developerPayload");
            } catch (JSONException e) {
                wg.m14620e("Fail to parse purchase data");
            }
        }
        return str2;
    }

    public void m8653a(Context context) {
        vo.m14685b(new C22201(this, context));
    }

    public void m8654a(Context context, boolean z, GInAppPurchaseManagerInfoParcel gInAppPurchaseManagerInfoParcel) {
        Intent intent = new Intent();
        intent.setClassName(context, "com.google.android.gms.ads.purchase.InAppPurchaseActivity");
        intent.putExtra("com.google.android.gms.ads.internal.purchase.useClientJar", z);
        GInAppPurchaseManagerInfoParcel.m8590a(intent, gInAppPurchaseManagerInfoParcel);
        C2243w.m8786e().m14709a(context, intent);
    }

    public String m8655b(Intent intent) {
        return intent == null ? null : intent.getStringExtra("INAPP_PURCHASE_DATA");
    }

    public String m8656b(String str) {
        String str2 = null;
        if (str != null) {
            try {
                str2 = new JSONObject(str).getString("purchaseToken");
            } catch (JSONException e) {
                wg.m14620e("Fail to parse purchase data");
            }
        }
        return str2;
    }

    public String m8657c(Intent intent) {
        return intent == null ? null : intent.getStringExtra("INAPP_DATA_SIGNATURE");
    }
}
