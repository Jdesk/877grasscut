package com.google.android.gms.ads.internal.overlay;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.C2243w;
import com.google.android.gms.p095b.ly;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.vk;
import com.google.android.gms.p095b.wg;

@sc
/* renamed from: com.google.android.gms.ads.internal.overlay.a */
public class C2152a {
    public boolean m8370a(Context context, Intent intent, C2101s c2101s) {
        try {
            String str = "Launching an intent: ";
            String valueOf = String.valueOf(intent.toURI());
            vk.m14621a(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
            C2243w.m8786e().m14709a(context, intent);
            if (c2101s != null) {
                c2101s.m8116f();
            }
            return true;
        } catch (ActivityNotFoundException e) {
            wg.m14620e(e.getMessage());
            return false;
        }
    }

    public boolean m8371a(Context context, C2158e c2158e, C2101s c2101s) {
        if (c2158e == null) {
            wg.m14620e("No intent data for launcher overlay.");
            return false;
        }
        ly.m12586a(context);
        if (c2158e.f5088h != null) {
            return m8370a(context, c2158e.f5088h, c2101s);
        }
        Intent intent = new Intent();
        if (TextUtils.isEmpty(c2158e.f5082b)) {
            wg.m14620e("Open GMSG did not contain a URL.");
            return false;
        }
        if (TextUtils.isEmpty(c2158e.f5083c)) {
            intent.setData(Uri.parse(c2158e.f5082b));
        } else {
            intent.setDataAndType(Uri.parse(c2158e.f5082b), c2158e.f5083c);
        }
        intent.setAction("android.intent.action.VIEW");
        if (!TextUtils.isEmpty(c2158e.f5084d)) {
            intent.setPackage(c2158e.f5084d);
        }
        if (!TextUtils.isEmpty(c2158e.f5085e)) {
            String[] split = c2158e.f5085e.split("/", 2);
            if (split.length < 2) {
                String str = "Could not parse component name from open GMSG: ";
                String valueOf = String.valueOf(c2158e.f5085e);
                wg.m14620e(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
                return false;
            }
            intent.setClassName(split[0], split[1]);
        }
        Object obj = c2158e.f5086f;
        if (!TextUtils.isEmpty(obj)) {
            int parseInt;
            try {
                parseInt = Integer.parseInt(obj);
            } catch (NumberFormatException e) {
                wg.m14620e("Could not parse intent flags.");
                parseInt = 0;
            }
            intent.addFlags(parseInt);
        }
        if (((Boolean) ly.de.m12563c()).booleanValue()) {
            intent.addFlags(268435456);
            intent.putExtra("android.support.customtabs.extra.user_opt_out", true);
        }
        return m8370a(context, intent, c2101s);
    }
}
