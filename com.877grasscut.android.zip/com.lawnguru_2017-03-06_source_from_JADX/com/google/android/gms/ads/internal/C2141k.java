package com.google.android.gms.ads.internal;

import android.content.Context;
import android.support.v4.util.SimpleArrayMap;
import com.google.android.gms.p095b.ka;
import com.google.android.gms.p095b.ke;
import com.google.android.gms.p095b.kn;
import com.google.android.gms.p095b.ko.C2140a;
import com.google.android.gms.p095b.kv;
import com.google.android.gms.p095b.my;
import com.google.android.gms.p095b.nk;
import com.google.android.gms.p095b.nl;
import com.google.android.gms.p095b.nm;
import com.google.android.gms.p095b.nn;
import com.google.android.gms.p095b.pw;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.vo;
import com.google.android.gms.p095b.wi;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

@sc
/* renamed from: com.google.android.gms.ads.internal.k */
public class C2141k extends C2140a {
    private final Context f4965a;
    private final kn f4966b;
    private final pw f4967c;
    private final nk f4968d;
    private final nl f4969e;
    private final SimpleArrayMap<String, nn> f4970f;
    private final SimpleArrayMap<String, nm> f4971g;
    private final my f4972h;
    private final List<String> f4973i;
    private final kv f4974j;
    private final String f4975k;
    private final wi f4976l;
    private WeakReference<C2233s> f4977m;
    private final C2124e f4978n;
    private final Object f4979o;

    /* renamed from: com.google.android.gms.ads.internal.k.1 */
    class C21391 implements Runnable {
        final /* synthetic */ ka f4963a;
        final /* synthetic */ C2141k f4964b;

        C21391(C2141k c2141k, ka kaVar) {
            this.f4964b = c2141k;
            this.f4963a = kaVar;
        }

        public void run() {
            synchronized (this.f4964b.f4979o) {
                C2233s c = this.f4964b.m8308c();
                this.f4964b.f4977m = new WeakReference(c);
                c.m8701a(this.f4964b.f4968d);
                c.m8702a(this.f4964b.f4969e);
                c.m8696a(this.f4964b.f4970f);
                c.m8129a(this.f4964b.f4966b);
                c.m8710b(this.f4964b.f4971g);
                c.m8706a(this.f4964b.m8298d());
                c.m8700a(this.f4964b.f4972h);
                c.m8131a(this.f4964b.f4974j);
                c.m8145a(this.f4963a);
            }
        }
    }

    C2141k(Context context, String str, pw pwVar, wi wiVar, kn knVar, nk nkVar, nl nlVar, SimpleArrayMap<String, nn> simpleArrayMap, SimpleArrayMap<String, nm> simpleArrayMap2, my myVar, kv kvVar, C2124e c2124e) {
        this.f4979o = new Object();
        this.f4965a = context;
        this.f4975k = str;
        this.f4967c = pwVar;
        this.f4976l = wiVar;
        this.f4966b = knVar;
        this.f4969e = nlVar;
        this.f4968d = nkVar;
        this.f4970f = simpleArrayMap;
        this.f4971g = simpleArrayMap2;
        this.f4972h = myVar;
        this.f4973i = m8298d();
        this.f4974j = kvVar;
        this.f4978n = c2124e;
    }

    private List<String> m8298d() {
        List<String> arrayList = new ArrayList();
        if (this.f4969e != null) {
            arrayList.add("1");
        }
        if (this.f4968d != null) {
            arrayList.add("2");
        }
        if (this.f4970f.size() > 0) {
            arrayList.add("3");
        }
        return arrayList;
    }

    public String m8304a() {
        synchronized (this.f4979o) {
            if (this.f4977m != null) {
                C2233s c2233s = (C2233s) this.f4977m.get();
                String G = c2233s != null ? c2233s.m8200G() : null;
                return G;
            }
            return null;
        }
    }

    public void m8305a(ka kaVar) {
        m8306a(new C21391(this, kaVar));
    }

    protected void m8306a(Runnable runnable) {
        vo.f9130a.post(runnable);
    }

    public boolean m8307b() {
        synchronized (this.f4979o) {
            if (this.f4977m != null) {
                C2233s c2233s = (C2233s) this.f4977m.get();
                boolean q = c2233s != null ? c2233s.m8168q() : false;
                return q;
            }
            return false;
        }
    }

    protected C2233s m8308c() {
        return new C2233s(this.f4965a, this.f4978n, ke.m12234a(this.f4965a), this.f4975k, this.f4967c, this.f4976l);
    }
}
