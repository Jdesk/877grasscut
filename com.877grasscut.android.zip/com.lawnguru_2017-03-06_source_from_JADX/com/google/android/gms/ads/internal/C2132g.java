package com.google.android.gms.ads.internal;

import android.content.Context;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.View;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.ViewTreeObserver.OnScrollChangedListener;
import com.google.android.gms.ads.C2088d;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.common.util.C3303m;
import com.google.android.gms.p095b.iu;
import com.google.android.gms.p095b.ka;
import com.google.android.gms.p095b.ke;
import com.google.android.gms.p095b.kj;
import com.google.android.gms.p095b.kz;
import com.google.android.gms.p095b.ly;
import com.google.android.gms.p095b.pw;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.us;
import com.google.android.gms.p095b.uu;
import com.google.android.gms.p095b.vb;
import com.google.android.gms.p095b.vb.C3048a;
import com.google.android.gms.p095b.vo;
import com.google.android.gms.p095b.wg;
import com.google.android.gms.p095b.wi;
import com.google.android.gms.p095b.wx;
import com.google.android.gms.p095b.wy;
import com.google.android.gms.p095b.wy.C2127e;
import com.google.android.gms.p095b.wy.C2129c;
import com.google.android.gms.p095b.xd;
import java.util.List;

@sc
/* renamed from: com.google.android.gms.ads.internal.g */
public class C2132g extends C2122c implements OnGlobalLayoutListener, OnScrollChangedListener {
    private boolean f4947l;

    /* renamed from: com.google.android.gms.ads.internal.g.1 */
    class C21261 implements Runnable {
        final /* synthetic */ C2132g f4941a;

        C21261(C2132g c2132g) {
            this.f4941a = c2132g;
        }

        public void run() {
            this.f4941a.m8262e(this.f4941a.f.f5355j);
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.g.2 */
    class C21282 implements C2127e {
        final /* synthetic */ vb f4942a;
        final /* synthetic */ Runnable f4943b;

        C21282(C2132g c2132g, vb vbVar, Runnable runnable) {
            this.f4942a = vbVar;
            this.f4943b = runnable;
        }

        public void m8248a() {
            if (!this.f4942a.f8992m) {
                C2243w.m8786e();
                vo.m14685b(this.f4943b);
            }
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.g.3 */
    class C21303 implements C2129c {
        final /* synthetic */ iu f4944a;
        final /* synthetic */ vb f4945b;

        C21303(C2132g c2132g, iu iuVar, vb vbVar) {
            this.f4944a = iuVar;
            this.f4945b = vbVar;
        }

        public void m8250a() {
            this.f4944a.m12022a(this.f4945b.f8981b);
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.g.a */
    public class C2131a {
        final /* synthetic */ C2132g f4946a;

        public C2131a(C2132g c2132g) {
            this.f4946a = c2132g;
        }

        public void m8251a() {
            this.f4946a.m8219e();
        }
    }

    public C2132g(Context context, ke keVar, String str, pw pwVar, wi wiVar, C2124e c2124e) {
        super(context, keVar, str, pwVar, wiVar, c2124e);
    }

    private ke m8252b(C3048a c3048a) {
        if (c3048a.f8964b.f8582A) {
            return this.f.f5354i;
        }
        C2088d c2088d;
        String str = c3048a.f8964b.f8611m;
        if (str != null) {
            String[] split = str.split("[xX]");
            split[0] = split[0].trim();
            split[1] = split[1].trim();
            c2088d = new C2088d(Integer.parseInt(split[0]), Integer.parseInt(split[1]));
        } else {
            c2088d = this.f.f5354i.m12238b();
        }
        return new ke(this.f.f5348c, c2088d);
    }

    private boolean m8253b(vb vbVar, vb vbVar2) {
        if (vbVar2.f8993n) {
            View a = C2205p.m8567a(vbVar2);
            if (a == null) {
                wg.m14620e("Could not get mediation view");
                return false;
            }
            View nextView = this.f.f5351f.getNextView();
            if (nextView != null) {
                if (nextView instanceof wx) {
                    ((wx) nextView).destroy();
                }
                this.f.f5351f.removeView(nextView);
            }
            if (!C2205p.m8587b(vbVar2)) {
                try {
                    m8126a(a);
                } catch (Throwable th) {
                    C2243w.m8790i().m14562a(th, "BannerAdManager.swapViews");
                    wg.m14618c("Could not add mediation view to view hierarchy.", th);
                    return false;
                }
            }
        } else if (!(vbVar2.f9001v == null || vbVar2.f8981b == null)) {
            vbVar2.f8981b.m14962a(vbVar2.f9001v);
            this.f.f5351f.removeAllViews();
            this.f.f5351f.setMinimumWidth(vbVar2.f9001v.f7388f);
            this.f.f5351f.setMinimumHeight(vbVar2.f9001v.f7385c);
            m8126a(vbVar2.f8981b.m14970b());
        }
        if (this.f.f5351f.getChildCount() > 1) {
            this.f.f5351f.showNext();
        }
        if (vbVar != null) {
            View nextView2 = this.f.f5351f.getNextView();
            if (nextView2 instanceof wx) {
                ((wx) nextView2).m14960a(this.f.f5348c, this.f.f5354i, this.a);
            } else if (nextView2 != null) {
                this.f.f5351f.removeView(nextView2);
            }
            this.f.m8819d();
        }
        this.f.f5351f.setVisibility(0);
        return true;
    }

    private void m8254f(vb vbVar) {
        C3303m.m16338b();
        if (this.f.m8820e()) {
            if (vbVar.f8981b != null) {
                if (vbVar.f8989j != null) {
                    this.h.m11920a(this.f.f5354i, vbVar);
                }
                iu iuVar = new iu(this.f.f5348c, vbVar.f8981b.m14970b());
                if (C2243w.m8779D().m14488b()) {
                    iuVar.m12022a(new uu(this.f.f5348c, this.f.f5347b));
                }
                if (vbVar.m14527a()) {
                    iuVar.m12022a(vbVar.f8981b);
                } else {
                    vbVar.f8981b.m14986l().m15022a(new C21303(this, iuVar, vbVar));
                }
            }
        } else if (this.f.f5335E != null && vbVar.f8989j != null) {
            this.h.m11921a(this.f.f5354i, vbVar, this.f.f5335E);
        }
    }

    public void m8255H() {
        throw new IllegalStateException("Interstitial is NOT supported by BannerAdManager.");
    }

    protected wx m8256a(C3048a c3048a, C2125f c2125f, us usVar) {
        if (this.f.f5354i.f7389g == null && this.f.f5354i.f7391i) {
            this.f.f5354i = m8252b(c3048a);
        }
        return super.m8234a(c3048a, c2125f, usVar);
    }

    protected void m8257a(vb vbVar, boolean z) {
        super.m8207a(vbVar, z);
        if (C2205p.m8587b(vbVar)) {
            C2205p.m8576a(vbVar, new C2131a(this));
        }
    }

    public void m8258a(boolean z) {
        C3234c.m16050b("setManualImpressionsEnabled must be called from the main thread.");
        this.f4947l = z;
    }

    public boolean m8259a(ka kaVar) {
        return super.m8145a(m8261d(kaVar));
    }

    public boolean m8260a(vb vbVar, vb vbVar2) {
        if (!super.m8239a(vbVar, vbVar2)) {
            return false;
        }
        if (!this.f.m8820e() || m8253b(vbVar, vbVar2)) {
            xd z;
            if (vbVar2.f8990k) {
                m8262e(vbVar2);
                C2243w.m8778C().m14935a(this.f.f5351f, (OnGlobalLayoutListener) this);
                C2243w.m8778C().m14936a(this.f.f5351f, (OnScrollChangedListener) this);
                if (!vbVar2.f8992m) {
                    Runnable c21261 = new C21261(this);
                    wy l = vbVar2.f8981b != null ? vbVar2.f8981b.m14986l() : null;
                    if (l != null) {
                        l.m15023a(new C21282(this, vbVar2, c21261));
                    }
                }
            } else if (!this.f.m8821f() || ((Boolean) ly.cb.m12563c()).booleanValue()) {
                m8257a(vbVar2, false);
            }
            if (vbVar2.f8981b != null) {
                z = vbVar2.f8981b.m15000z();
                wy l2 = vbVar2.f8981b.m14986l();
                if (l2 != null) {
                    l2.m15036h();
                }
            } else {
                z = null;
            }
            if (!(this.f.f5369x == null || z == null)) {
                z.m15275b(this.f.f5369x.f7549a);
            }
            m8254f(vbVar2);
            return true;
        }
        m8125a(0);
        return false;
    }

    ka m8261d(ka kaVar) {
        if (kaVar.f7354h == this.f4947l) {
            return kaVar;
        }
        int i = kaVar.f7347a;
        long j = kaVar.f7348b;
        Bundle bundle = kaVar.f7349c;
        int i2 = kaVar.f7350d;
        List list = kaVar.f7351e;
        boolean z = kaVar.f7352f;
        int i3 = kaVar.f7353g;
        boolean z2 = kaVar.f7354h || this.f4947l;
        return new ka(i, j, bundle, i2, list, z, i3, z2, kaVar.f7355i, kaVar.f7356j, kaVar.f7357k, kaVar.f7358l, kaVar.f7359m, kaVar.f7360n, kaVar.f7361o, kaVar.f7362p, kaVar.f7363q, kaVar.f7364r);
    }

    void m8262e(vb vbVar) {
        if (vbVar != null && !vbVar.f8992m && this.f.f5351f != null && C2243w.m8786e().m14724a(this.f.f5351f, this.f.f5348c) && this.f.f5351f.getGlobalVisibleRect(new Rect(), null)) {
            if (!(vbVar == null || vbVar.f8981b == null || vbVar.f8981b.m14986l() == null)) {
                vbVar.f8981b.m14986l().m15023a(null);
            }
            m8257a(vbVar, false);
            vbVar.f8992m = true;
        }
    }

    public void onGlobalLayout() {
        m8262e(this.f.f5355j);
    }

    public void onScrollChanged() {
        m8262e(this.f.f5355j);
    }

    public kz m8263r() {
        C3234c.m16050b("getVideoController must be called from the main thread.");
        return (this.f.f5355j == null || this.f.f5355j.f8981b == null) ? null : this.f.f5355j.f8981b.m15000z();
    }

    protected boolean m8264y() {
        boolean z = true;
        if (!C2243w.m8786e().m14723a(this.f.f5348c, this.f.f5348c.getPackageName(), "android.permission.INTERNET")) {
            kj.m12293a().m14904a(this.f.f5351f, this.f.f5354i, "Missing internet permission in AndroidManifest.xml.", "Missing internet permission in AndroidManifest.xml. You must have the following declaration: <uses-permission android:name=\"android.permission.INTERNET\" />");
            z = false;
        }
        if (!C2243w.m8786e().m14722a(this.f.f5348c)) {
            kj.m12293a().m14904a(this.f.f5351f, this.f.f5354i, "Missing AdActivity with android:configChanges in AndroidManifest.xml.", "Missing AdActivity with android:configChanges in AndroidManifest.xml. You must have the following declaration within the <application> element: <activity android:name=\"com.google.android.gms.ads.AdActivity\" android:configChanges=\"keyboard|keyboardHidden|orientation|screenLayout|uiMode|screenSize|smallestScreenSize\" />");
            z = false;
        }
        if (!(z || this.f.f5351f == null)) {
            this.f.f5351f.setVisibility(0);
        }
        return z;
    }
}
