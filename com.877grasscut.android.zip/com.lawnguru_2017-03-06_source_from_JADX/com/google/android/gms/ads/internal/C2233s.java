package com.google.android.gms.ads.internal;

import android.content.Context;
import android.support.v4.util.SimpleArrayMap;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.p095b.ka;
import com.google.android.gms.p095b.ke;
import com.google.android.gms.p095b.ly;
import com.google.android.gms.p095b.mg;
import com.google.android.gms.p095b.mk;
import com.google.android.gms.p095b.mq;
import com.google.android.gms.p095b.mr;
import com.google.android.gms.p095b.ms;
import com.google.android.gms.p095b.mt;
import com.google.android.gms.p095b.mu;
import com.google.android.gms.p095b.mw;
import com.google.android.gms.p095b.mw.C2767a;
import com.google.android.gms.p095b.my;
import com.google.android.gms.p095b.nk;
import com.google.android.gms.p095b.nl;
import com.google.android.gms.p095b.nm;
import com.google.android.gms.p095b.nn;
import com.google.android.gms.p095b.pw;
import com.google.android.gms.p095b.qa;
import com.google.android.gms.p095b.qb;
import com.google.android.gms.p095b.rb;
import com.google.android.gms.p095b.rt;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.vb;
import com.google.android.gms.p095b.vb.C3048a;
import com.google.android.gms.p095b.vo;
import com.google.android.gms.p095b.wg;
import com.google.android.gms.p095b.wi;
import com.google.android.gms.p095b.wx;
import java.util.List;

@sc
/* renamed from: com.google.android.gms.ads.internal.s */
public class C2233s extends C2115b {
    private wx f5267l;

    /* renamed from: com.google.android.gms.ads.internal.s.1 */
    class C22291 implements Runnable {
        final /* synthetic */ C3048a f5258a;
        final /* synthetic */ C2233s f5259b;

        C22291(C2233s c2233s, C3048a c3048a) {
            this.f5259b = c2233s;
            this.f5258a = c3048a;
        }

        public void run() {
            this.f5259b.m8215b(new vb(this.f5258a, null, null, null, null, null, null, null));
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.s.2 */
    class C22302 implements Runnable {
        final /* synthetic */ mq f5260a;
        final /* synthetic */ C2233s f5261b;

        C22302(C2233s c2233s, mq mqVar) {
            this.f5261b = c2233s;
            this.f5260a = mqVar;
        }

        public void run() {
            try {
                if (this.f5261b.f.f5364s != null) {
                    this.f5261b.f.f5364s.m12988a(this.f5260a);
                }
            } catch (Throwable e) {
                wg.m14618c("Could not call OnAppInstallAdLoadedListener.onAppInstallAdLoaded().", e);
            }
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.s.3 */
    class C22313 implements Runnable {
        final /* synthetic */ mr f5262a;
        final /* synthetic */ C2233s f5263b;

        C22313(C2233s c2233s, mr mrVar) {
            this.f5263b = c2233s;
            this.f5262a = mrVar;
        }

        public void run() {
            try {
                if (this.f5263b.f.f5365t != null) {
                    this.f5263b.f.f5365t.m12991a(this.f5262a);
                }
            } catch (Throwable e) {
                wg.m14618c("Could not call OnContentAdLoadedListener.onContentAdLoaded().", e);
            }
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.s.4 */
    class C22324 implements Runnable {
        final /* synthetic */ String f5264a;
        final /* synthetic */ vb f5265b;
        final /* synthetic */ C2233s f5266c;

        C22324(C2233s c2233s, String str, vb vbVar) {
            this.f5266c = c2233s;
            this.f5264a = str;
            this.f5265b = vbVar;
        }

        public void run() {
            try {
                ((nn) this.f5266c.f.f5367v.get(this.f5264a)).m12997a((ms) this.f5265b.f8975E);
            } catch (Throwable e) {
                wg.m14618c("Could not call onCustomTemplateAdLoadedListener.onCustomTemplateAdLoaded().", e);
            }
        }
    }

    public C2233s(Context context, C2124e c2124e, ke keVar, String str, pw pwVar, wi wiVar) {
        super(context, keVar, str, pwVar, wiVar, c2124e);
    }

    private static mq m8684a(qa qaVar) {
        return new mq(qaVar.m13520a(), qaVar.m13522b(), qaVar.m13524c(), qaVar.m13526d() != null ? qaVar.m13526d() : null, qaVar.m13527e(), qaVar.m13528f(), qaVar.m13529g(), qaVar.m13530h(), null, qaVar.m13534l(), qaVar.m13535m(), null);
    }

    private static mr m8685a(qb qbVar) {
        return new mr(qbVar.m13555a(), qbVar.m13557b(), qbVar.m13559c(), qbVar.m13561d() != null ? qbVar.m13561d() : null, qbVar.m13562e(), qbVar.m13563f(), null, qbVar.m13567j(), qbVar.m13569l(), null);
    }

    private void m8686a(mq mqVar) {
        vo.f9130a.post(new C22302(this, mqVar));
    }

    private void m8687a(mr mrVar) {
        vo.f9130a.post(new C22313(this, mrVar));
    }

    private void m8688a(vb vbVar, String str) {
        vo.f9130a.post(new C22324(this, str, vbVar));
    }

    public void m8689H() {
        throw new IllegalStateException("Interstitial is NOT supported by NativeAdManager.");
    }

    public void m8690K() {
        if (this.f.f5355j == null || this.f5267l == null) {
            wg.m14620e("Request to enable ActiveView before adState is available.");
        } else {
            C2243w.m8790i().m14592s().m11922a(this.f.f5354i, this.f.f5355j, this.f5267l.m14970b(), this.f5267l);
        }
    }

    public String m8691L() {
        return this.f.f5347b;
    }

    public SimpleArrayMap<String, nn> m8692M() {
        C3234c.m16050b("getOnCustomTemplateAdLoadedListeners must be called on the main UI thread.");
        return this.f.f5367v;
    }

    public void m8693N() {
        if (this.f5267l != null) {
            this.f5267l.destroy();
            this.f5267l = null;
        }
    }

    public void m8694O() {
        if (this.f5267l != null && this.f5267l.m15000z() != null && this.f.f5368w != null && this.f.f5368w.f7775f != null) {
            this.f5267l.m15000z().m15275b(this.f.f5368w.f7775f.f7549a);
        }
    }

    public boolean m8695P() {
        return this.f.f5355j != null && this.f.f5355j.f8993n && this.f.f5355j.f8997r != null && this.f.f5355j.f8997r.f8079o;
    }

    public void m8696a(SimpleArrayMap<String, nn> simpleArrayMap) {
        C3234c.m16050b("setOnCustomTemplateAdLoadedListeners must be called on the main UI thread.");
        this.f.f5367v = simpleArrayMap;
    }

    public void m8697a(mk mkVar) {
        throw new IllegalStateException("CustomRendering is NOT supported by NativeAdManager.");
    }

    public void m8698a(mt mtVar) {
        if (this.f5267l != null) {
            this.f5267l.m14963a(mtVar);
        }
    }

    public void m8699a(mw mwVar) {
        if (this.f.f5355j.f8989j != null) {
            C2243w.m8790i().m14592s().m11924a(this.f.f5354i, this.f.f5355j, mwVar);
        }
    }

    public void m8700a(my myVar) {
        C3234c.m16050b("setNativeAdOptions must be called on the main UI thread.");
        this.f.f5368w = myVar;
    }

    public void m8701a(nk nkVar) {
        C3234c.m16050b("setOnAppInstallAdLoadedListener must be called on the main UI thread.");
        this.f.f5364s = nkVar;
    }

    public void m8702a(nl nlVar) {
        C3234c.m16050b("setOnContentAdLoadedListener must be called on the main UI thread.");
        this.f.f5365t = nlVar;
    }

    public void m8703a(rb rbVar) {
        throw new IllegalStateException("In App Purchase is NOT supported by NativeAdManager.");
    }

    public void m8704a(C3048a c3048a, mg mgVar) {
        if (c3048a.f8966d != null) {
            this.f.f5354i = c3048a.f8966d;
        }
        if (c3048a.f8967e != -2) {
            vo.f9130a.post(new C22291(this, c3048a));
            return;
        }
        this.f.f5336F = 0;
        this.f.f5353h = C2243w.m8785d().m13884a(this.f.f5348c, this, c3048a, this.f.f5349d, null, this.j, this, mgVar);
        String str = "AdRenderer: ";
        String valueOf = String.valueOf(this.f.f5353h.getClass().getName());
        wg.m14615b(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
    }

    public void m8705a(wx wxVar) {
        this.f5267l = wxVar;
    }

    public void m8706a(List<String> list) {
        C3234c.m16050b("setNativeTemplates must be called on the main UI thread.");
        this.f.f5332B = list;
    }

    public boolean m8707a(ka kaVar, mg mgVar) {
        if (((Boolean) ly.cg.m12563c()).booleanValue() && ((Boolean) ly.ch.m12563c()).booleanValue()) {
            rt rtVar = new rt(this.f.f5348c, this, this.f.f5349d, this.f.f5350e);
            rtVar.m13920a();
            try {
                rtVar.m13922b();
            } catch (Throwable e) {
                wg.m14618c("Initializing javascript failed", e);
                return false;
            }
        }
        return super.m8210a(kaVar, mgVar);
    }

    protected boolean m8708a(ka kaVar, vb vbVar, boolean z) {
        return this.e.m8724d();
    }

    protected boolean m8709a(vb vbVar, vb vbVar2) {
        m8706a(null);
        if (this.f.m8820e()) {
            if (vbVar2.f8993n) {
                try {
                    qa h = vbVar2.f8995p != null ? vbVar2.f8995p.m13458h() : null;
                    qb i = vbVar2.f8995p != null ? vbVar2.f8995p.m13459i() : null;
                    if (h == null || this.f.f5364s == null) {
                        if (i != null) {
                            if (this.f.f5365t != null) {
                                mr a = C2233s.m8685a(i);
                                a.m12764a(new mu(this.f.f5348c, this, this.f.f5349d, i, (C2767a) a));
                                m8687a(a);
                            }
                        }
                        wg.m14620e("No matching mapper/listener for retrieved native ad template.");
                        m8125a(0);
                        return false;
                    }
                    mq a2 = C2233s.m8684a(h);
                    a2.m12736a(new mu(this.f.f5348c, this, this.f.f5349d, h, (C2767a) a2));
                    m8686a(a2);
                } catch (Throwable e) {
                    wg.m14618c("Failed to get native ad mapper", e);
                }
            } else {
                C2767a c2767a = vbVar2.f8975E;
                if ((c2767a instanceof mr) && this.f.f5365t != null) {
                    m8687a((mr) vbVar2.f8975E);
                } else if ((c2767a instanceof mq) && this.f.f5364s != null) {
                    m8686a((mq) vbVar2.f8975E);
                } else if (!(c2767a instanceof ms) || this.f.f5367v == null || this.f.f5367v.get(((ms) c2767a).m12804l()) == null) {
                    wg.m14620e("No matching listener for retrieved native ad template.");
                    m8125a(0);
                    return false;
                } else {
                    m8688a(vbVar2, ((ms) c2767a).m12804l());
                }
            }
            return super.m8213a(vbVar, vbVar2);
        }
        throw new IllegalStateException("Native ad DOES NOT have custom rendering mode.");
    }

    public void m8710b(SimpleArrayMap<String, nm> simpleArrayMap) {
        C3234c.m16050b("setOnCustomClickListener must be called on the main UI thread.");
        this.f.f5366u = simpleArrayMap;
    }

    public nm m8711c(String str) {
        C3234c.m16050b("getOnCustomClickListener must be called on the main UI thread.");
        return (nm) this.f.f5366u.get(str);
    }

    public void m8712n() {
        throw new IllegalStateException("Native Ad DOES NOT support pause().");
    }

    public void m8713o() {
        throw new IllegalStateException("Native Ad DOES NOT support resume().");
    }
}
