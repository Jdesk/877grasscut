package com.google.android.gms.ads.internal.overlay;

import android.app.Activity;
import android.widget.RelativeLayout;
import com.google.android.gms.p095b.wx;

/* renamed from: com.google.android.gms.ads.internal.overlay.p */
public interface C2188p {
    C2187o m8547a(Activity activity, wx wxVar, RelativeLayout relativeLayout);
}
