package com.google.android.gms.ads.internal.overlay;

/* renamed from: com.google.android.gms.ads.internal.overlay.s */
public interface C2101s {
    void m8116f();
}
