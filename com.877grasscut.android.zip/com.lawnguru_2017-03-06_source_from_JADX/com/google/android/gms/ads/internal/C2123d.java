package com.google.android.gms.ads.internal;

import android.os.Bundle;
import com.google.android.gms.p095b.ka;
import com.google.android.gms.p095b.ke;
import com.google.android.gms.p095b.sc;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

@sc
/* renamed from: com.google.android.gms.ads.internal.d */
public class C2123d {
    private static String m8241a(Bundle bundle) {
        if (bundle == null) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        Iterator it = new TreeSet(bundle.keySet()).iterator();
        while (it.hasNext()) {
            Object obj = bundle.get((String) it.next());
            String a = obj == null ? "null" : obj instanceof Bundle ? C2123d.m8241a((Bundle) obj) : obj.toString();
            stringBuilder.append(a);
        }
        return stringBuilder.toString();
    }

    public static Object[] m8242a(String str, ka kaVar, String str2, int i, ke keVar) {
        Set hashSet = new HashSet(Arrays.asList(str.split(",")));
        ArrayList arrayList = new ArrayList();
        arrayList.add(str);
        arrayList.add(str2);
        if (hashSet.contains("formatString")) {
            if (keVar != null) {
                arrayList.add(keVar.f7383a);
            } else {
                arrayList.add(null);
            }
        }
        if (hashSet.contains("networkType")) {
            arrayList.add(Integer.valueOf(i));
        }
        if (hashSet.contains("birthday")) {
            arrayList.add(Long.valueOf(kaVar.f7348b));
        }
        if (hashSet.contains("extras")) {
            arrayList.add(C2123d.m8241a(kaVar.f7349c));
        }
        if (hashSet.contains("gender")) {
            arrayList.add(Integer.valueOf(kaVar.f7350d));
        }
        if (hashSet.contains("keywords")) {
            if (kaVar.f7351e != null) {
                arrayList.add(kaVar.f7351e.toString());
            } else {
                arrayList.add(null);
            }
        }
        if (hashSet.contains("isTestDevice")) {
            arrayList.add(Boolean.valueOf(kaVar.f7352f));
        }
        if (hashSet.contains("tagForChildDirectedTreatment")) {
            arrayList.add(Integer.valueOf(kaVar.f7353g));
        }
        if (hashSet.contains("manualImpressionsEnabled")) {
            arrayList.add(Boolean.valueOf(kaVar.f7354h));
        }
        if (hashSet.contains("publisherProvidedId")) {
            arrayList.add(kaVar.f7355i);
        }
        if (hashSet.contains("location")) {
            if (kaVar.f7357k != null) {
                arrayList.add(kaVar.f7357k.toString());
            } else {
                arrayList.add(null);
            }
        }
        if (hashSet.contains("contentUrl")) {
            arrayList.add(kaVar.f7358l);
        }
        if (hashSet.contains("networkExtras")) {
            arrayList.add(C2123d.m8241a(kaVar.f7359m));
        }
        if (hashSet.contains("customTargeting")) {
            arrayList.add(C2123d.m8241a(kaVar.f7360n));
        }
        if (hashSet.contains("categoryExclusions")) {
            if (kaVar.f7361o != null) {
                arrayList.add(kaVar.f7361o.toString());
            } else {
                arrayList.add(null);
            }
        }
        if (hashSet.contains("requestAgent")) {
            arrayList.add(kaVar.f7362p);
        }
        if (hashSet.contains("requestPackage")) {
            arrayList.add(kaVar.f7363q);
        }
        if (hashSet.contains("isDesignedForFamilies")) {
            arrayList.add(Boolean.valueOf(kaVar.f7364r));
        }
        return arrayList.toArray();
    }
}
