package com.google.android.gms.ads.internal;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.Keep;
import android.widget.FrameLayout;
import com.google.android.gms.ads.internal.overlay.C2179g;
import com.google.android.gms.ads.internal.purchase.C2213e;
import com.google.android.gms.common.util.DynamiteApi;
import com.google.android.gms.p095b.ke;
import com.google.android.gms.p095b.kp;
import com.google.android.gms.p095b.kr;
import com.google.android.gms.p095b.ku.C2098a;
import com.google.android.gms.p095b.kw;
import com.google.android.gms.p095b.ly;
import com.google.android.gms.p095b.na;
import com.google.android.gms.p095b.nd;
import com.google.android.gms.p095b.oy;
import com.google.android.gms.p095b.pw;
import com.google.android.gms.p095b.qv;
import com.google.android.gms.p095b.rc;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.tq;
import com.google.android.gms.p095b.tt;
import com.google.android.gms.p095b.wi;
import com.google.android.gms.p097a.C2046a;
import com.google.android.gms.p097a.C2060d;

@Keep
@sc
@DynamiteApi
public class ClientApi extends C2098a {
    public kp createAdLoaderBuilder(C2046a c2046a, String str, pw pwVar, int i) {
        Context context = (Context) C2060d.m7974a(c2046a);
        return new C2143l(context, str, pwVar, new wi(10298000, i, true, C2243w.m8786e().m14757l(context)), C2124e.m8243a());
    }

    public qv createAdOverlay(C2046a c2046a) {
        return new C2179g((Activity) C2060d.m7974a(c2046a));
    }

    public kr createBannerAdManager(C2046a c2046a, ke keVar, String str, pw pwVar, int i) {
        Context context = (Context) C2060d.m7974a(c2046a);
        return new C2132g(context, keVar, str, pwVar, new wi(10298000, i, true, C2243w.m8786e().m14757l(context)), C2124e.m8243a());
    }

    public rc createInAppPurchaseManager(C2046a c2046a) {
        return new C2213e((Activity) C2060d.m7974a(c2046a));
    }

    public kr createInterstitialAdManager(C2046a c2046a, ke keVar, String str, pw pwVar, int i) {
        Context context = (Context) C2060d.m7974a(c2046a);
        ly.m12586a(context);
        wi wiVar = new wi(10298000, i, true, C2243w.m8786e().m14757l(context));
        boolean equals = "reward_mb".equals(keVar.f7383a);
        Object obj = ((equals || !((Boolean) ly.aW.m12563c()).booleanValue()) && !(equals && ((Boolean) ly.aX.m12563c()).booleanValue())) ? null : 1;
        if (obj != null) {
            return new oy(context, str, pwVar, wiVar, C2124e.m8243a());
        }
        return new C2148m(context, keVar, str, pwVar, wiVar, C2124e.m8243a());
    }

    public nd createNativeAdViewDelegate(C2046a c2046a, C2046a c2046a2) {
        return new na((FrameLayout) C2060d.m7974a(c2046a), (FrameLayout) C2060d.m7974a(c2046a2));
    }

    public tt createRewardedVideoAd(C2046a c2046a, pw pwVar, int i) {
        Context context = (Context) C2060d.m7974a(c2046a);
        return new tq(context, C2124e.m8243a(), pwVar, new wi(10298000, i, true, C2243w.m8786e().m14757l(context)));
    }

    public kr createSearchAdManager(C2046a c2046a, ke keVar, String str, int i) {
        Context context = (Context) C2060d.m7974a(c2046a);
        return new C2242v(context, keVar, str, new wi(10298000, i, true, C2243w.m8786e().m14757l(context)));
    }

    public kw getMobileAdsSettingsManager(C2046a c2046a) {
        return null;
    }

    public kw getMobileAdsSettingsManagerWithClientJarVersion(C2046a c2046a, int i) {
        Context context = (Context) C2060d.m7974a(c2046a);
        return C2227q.m8672a(context, new wi(10298000, i, true, C2243w.m8786e().m14757l(context)));
    }
}
