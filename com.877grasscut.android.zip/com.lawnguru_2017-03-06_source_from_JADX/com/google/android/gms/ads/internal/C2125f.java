package com.google.android.gms.ads.internal;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.sn;
import com.google.android.gms.p095b.vb.C3048a;
import com.google.android.gms.p095b.wg;
import io.card.payment.BuildConfig;

@sc
/* renamed from: com.google.android.gms.ads.internal.f */
public class C2125f {
    private final Context f4938a;
    private final sn f4939b;
    private boolean f4940c;

    public C2125f(Context context) {
        this(context, false);
    }

    public C2125f(Context context, C3048a c3048a) {
        this.f4938a = context;
        if (c3048a == null || c3048a.f8964b.f8588G == null) {
            this.f4939b = new sn();
        } else {
            this.f4939b = c3048a.f8964b.f8588G;
        }
    }

    public C2125f(Context context, boolean z) {
        this.f4938a = context;
        this.f4939b = new sn(z);
    }

    public void m8244a() {
        this.f4940c = true;
    }

    public void m8245a(String str) {
        if (str == null) {
            str = BuildConfig.FLAVOR;
        }
        wg.m14619d("Action was blocked because no touch was detected.");
        if (this.f4939b.f8625a && this.f4939b.f8626b != null) {
            for (String str2 : this.f4939b.f8626b) {
                if (!TextUtils.isEmpty(str2)) {
                    C2243w.m8786e().m14733b(this.f4938a, BuildConfig.FLAVOR, str2.replace("{NAVIGATION_URL}", Uri.encode(str)));
                }
            }
        }
    }

    public boolean m8246b() {
        return !this.f4939b.f8625a || this.f4940c;
    }
}
