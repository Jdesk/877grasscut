package com.google.android.gms.ads.internal.purchase;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.os.SystemClock;
import com.google.android.gms.ads.internal.C2243w;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.stats.C3286a;
import com.google.android.gms.p095b.rf;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.vj;
import com.google.android.gms.p095b.vk;
import com.google.android.gms.p095b.vo;
import com.google.android.gms.p095b.wg;
import java.util.List;

@sc
/* renamed from: com.google.android.gms.ads.internal.purchase.c */
public class C2209c extends vj implements ServiceConnection {
    private final Object f5209a;
    private boolean f5210b;
    private Context f5211c;
    private rf f5212d;
    private C2207b f5213e;
    private C2218h f5214f;
    private List<C2214f> f5215g;
    private C2222k f5216h;

    /* renamed from: com.google.android.gms.ads.internal.purchase.c.1 */
    class C22081 implements Runnable {
        final /* synthetic */ C2214f f5206a;
        final /* synthetic */ Intent f5207b;
        final /* synthetic */ C2209c f5208c;

        C22081(C2209c c2209c, C2214f c2214f, Intent intent) {
            this.f5208c = c2209c;
            this.f5206a = c2214f;
            this.f5207b = intent;
        }

        public void run() {
            try {
                if (this.f5208c.f5216h.m8659a(this.f5206a.f5231b, -1, this.f5207b)) {
                    this.f5208c.f5212d.m13859a(new C2216g(this.f5208c.f5211c, this.f5206a.f5232c, true, -1, this.f5207b, this.f5206a));
                } else {
                    this.f5208c.f5212d.m13859a(new C2216g(this.f5208c.f5211c, this.f5206a.f5232c, false, -1, this.f5207b, this.f5206a));
                }
            } catch (RemoteException e) {
                wg.m14620e("Fail to verify and dispatch pending transaction");
            }
        }
    }

    public C2209c(Context context, rf rfVar, C2222k c2222k) {
        this(context, rfVar, c2222k, new C2207b(context), C2218h.m8641a(context.getApplicationContext()));
    }

    C2209c(Context context, rf rfVar, C2222k c2222k, C2207b c2207b, C2218h c2218h) {
        this.f5209a = new Object();
        this.f5210b = false;
        this.f5215g = null;
        this.f5211c = context;
        this.f5212d = rfVar;
        this.f5216h = c2222k;
        this.f5213e = c2207b;
        this.f5214f = c2218h;
        this.f5215g = this.f5214f.m8645a(10);
    }

    private void m8605a(long j) {
        do {
            if (!m8607b(j)) {
                vk.m14621a("Timeout waiting for pending transaction to be processed.");
            }
        } while (!this.f5210b);
    }

    private boolean m8607b(long j) {
        long elapsedRealtime = 60000 - (SystemClock.elapsedRealtime() - j);
        if (elapsedRealtime <= 0) {
            return false;
        }
        try {
            this.f5209a.wait(elapsedRealtime);
        } catch (InterruptedException e) {
            wg.m14620e("waitWithTimeout_lock interrupted");
        }
        return true;
    }

    public void m8609a() {
        synchronized (this.f5209a) {
            Intent intent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
            intent.setPackage(GooglePlayServicesUtil.GOOGLE_PLAY_STORE_PACKAGE);
            C3286a.m16282a().m16286a(this.f5211c, intent, (ServiceConnection) this, 1);
            m8605a(SystemClock.elapsedRealtime());
            C3286a.m16282a().m16284a(this.f5211c, (ServiceConnection) this);
            this.f5213e.m8601a();
        }
    }

    protected void m8610a(C2214f c2214f, String str, String str2) {
        Intent intent = new Intent();
        C2243w.m8800s();
        intent.putExtra("RESPONSE_CODE", 0);
        C2243w.m8800s();
        intent.putExtra("INAPP_PURCHASE_DATA", str);
        C2243w.m8800s();
        intent.putExtra("INAPP_DATA_SIGNATURE", str2);
        vo.f9130a.post(new C22081(this, c2214f, intent));
    }

    public void m8611b() {
        synchronized (this.f5209a) {
            C3286a.m16282a().m16284a(this.f5211c, (ServiceConnection) this);
            this.f5213e.m8601a();
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected void d_() {
        /*
        r12 = this;
        r0 = r12.f5215g;
        r0 = r0.isEmpty();
        if (r0 == 0) goto L_0x0009;
    L_0x0008:
        return;
    L_0x0009:
        r6 = new java.util.HashMap;
        r6.<init>();
        r0 = r12.f5215g;
        r1 = r0.iterator();
    L_0x0014:
        r0 = r1.hasNext();
        if (r0 == 0) goto L_0x0026;
    L_0x001a:
        r0 = r1.next();
        r0 = (com.google.android.gms.ads.internal.purchase.C2214f) r0;
        r2 = r0.f5232c;
        r6.put(r2, r0);
        goto L_0x0014;
    L_0x0026:
        r0 = 0;
    L_0x0027:
        r1 = r12.f5213e;
        r2 = r12.f5211c;
        r2 = r2.getPackageName();
        r0 = r1.m8603b(r2, r0);
        if (r0 != 0) goto L_0x0055;
    L_0x0035:
        r0 = r6.keySet();
        r1 = r0.iterator();
    L_0x003d:
        r0 = r1.hasNext();
        if (r0 == 0) goto L_0x0008;
    L_0x0043:
        r0 = r1.next();
        r0 = (java.lang.String) r0;
        r2 = r12.f5214f;
        r0 = r6.get(r0);
        r0 = (com.google.android.gms.ads.internal.purchase.C2214f) r0;
        r2.m8646a(r0);
        goto L_0x003d;
    L_0x0055:
        r1 = com.google.android.gms.ads.internal.C2243w.m8800s();
        r1 = r1.m8651a(r0);
        if (r1 != 0) goto L_0x0035;
    L_0x005f:
        r1 = "INAPP_PURCHASE_ITEM_LIST";
        r7 = r0.getStringArrayList(r1);
        r1 = "INAPP_PURCHASE_DATA_LIST";
        r8 = r0.getStringArrayList(r1);
        r1 = "INAPP_DATA_SIGNATURE_LIST";
        r9 = r0.getStringArrayList(r1);
        r1 = "INAPP_CONTINUATION_TOKEN";
        r5 = r0.getString(r1);
        r0 = 0;
        r4 = r0;
    L_0x0079:
        r0 = r7.size();
        if (r4 >= r0) goto L_0x00bb;
    L_0x007f:
        r0 = r7.get(r4);
        r0 = r6.containsKey(r0);
        if (r0 == 0) goto L_0x00b7;
    L_0x0089:
        r0 = r7.get(r4);
        r0 = (java.lang.String) r0;
        r1 = r8.get(r4);
        r1 = (java.lang.String) r1;
        r2 = r9.get(r4);
        r2 = (java.lang.String) r2;
        r3 = r6.get(r0);
        r3 = (com.google.android.gms.ads.internal.purchase.C2214f) r3;
        r10 = com.google.android.gms.ads.internal.C2243w.m8800s();
        r10 = r10.m8652a(r1);
        r11 = r3.f5231b;
        r10 = r11.equals(r10);
        if (r10 == 0) goto L_0x00b7;
    L_0x00b1:
        r12.m8610a(r3, r1, r2);
        r6.remove(r0);
    L_0x00b7:
        r0 = r4 + 1;
        r4 = r0;
        goto L_0x0079;
    L_0x00bb:
        if (r5 == 0) goto L_0x0035;
    L_0x00bd:
        r0 = r6.isEmpty();
        if (r0 != 0) goto L_0x0035;
    L_0x00c3:
        r0 = r5;
        goto L_0x0027;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.ads.internal.purchase.c.d_():void");
    }

    public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        synchronized (this.f5209a) {
            this.f5213e.m8602a(iBinder);
            d_();
            this.f5210b = true;
            this.f5209a.notify();
        }
    }

    public void onServiceDisconnected(ComponentName componentName) {
        wg.m14619d("In-app billing service disconnected.");
        this.f5213e.m8601a();
    }
}
