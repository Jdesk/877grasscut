package com.google.android.gms.ads.internal;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.Window;
import com.google.ads.mediation.C2011a;
import com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.common.util.C3303m;
import com.google.android.gms.p095b.iu;
import com.google.android.gms.p095b.ka;
import com.google.android.gms.p095b.ke;
import com.google.android.gms.p095b.ly;
import com.google.android.gms.p095b.mg;
import com.google.android.gms.p095b.ob;
import com.google.android.gms.p095b.oh;
import com.google.android.gms.p095b.oh.C2147a;
import com.google.android.gms.p095b.pe;
import com.google.android.gms.p095b.pl;
import com.google.android.gms.p095b.pm;
import com.google.android.gms.p095b.pw;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.sl;
import com.google.android.gms.p095b.tc;
import com.google.android.gms.p095b.un;
import com.google.android.gms.p095b.us;
import com.google.android.gms.p095b.uu;
import com.google.android.gms.p095b.vb;
import com.google.android.gms.p095b.vb.C3048a;
import com.google.android.gms.p095b.vj;
import com.google.android.gms.p095b.vo;
import com.google.android.gms.p095b.wg;
import com.google.android.gms.p095b.wi;
import com.google.android.gms.p095b.wx;
import com.google.android.gms.p095b.wy;
import com.google.android.gms.p095b.wy.C2129c;
import io.card.payment.BuildConfig;
import java.util.Collections;
import org.json.JSONObject;

@sc
/* renamed from: com.google.android.gms.ads.internal.m */
public class C2148m extends C2122c implements ob, C2147a {
    protected transient boolean f5001l;
    private int f5002m;
    private boolean f5003n;
    private float f5004o;
    private final uu f5005p;

    /* renamed from: com.google.android.gms.ads.internal.m.1 */
    class C21441 implements C2129c {
        final /* synthetic */ vb f4992a;
        final /* synthetic */ C2148m f4993b;

        C21441(C2148m c2148m, vb vbVar) {
            this.f4993b = c2148m;
            this.f4992a = vbVar;
        }

        public void m8324a() {
            new iu(this.f4993b.f.f5348c, this.f4992a.f8981b.m14970b()).m12022a(this.f4992a.f8981b);
        }
    }

    @sc
    /* renamed from: com.google.android.gms.ads.internal.m.a */
    private class C2146a extends vj {
        final /* synthetic */ C2148m f4999a;
        private final int f5000b;

        /* renamed from: com.google.android.gms.ads.internal.m.a.1 */
        class C21451 implements Runnable {
            final /* synthetic */ AdOverlayInfoParcel f4994a;
            final /* synthetic */ C2146a f4995b;

            C21451(C2146a c2146a, AdOverlayInfoParcel adOverlayInfoParcel) {
                this.f4995b = c2146a;
                this.f4994a = adOverlayInfoParcel;
            }

            public void run() {
                C2243w.m8784c().m8497a(this.f4995b.f4999a.f.f5348c, this.f4994a);
            }
        }

        public C2146a(C2148m c2148m, int i) {
            this.f4999a = c2148m;
            this.f5000b = i;
        }

        public void m8333a() {
            C2150n c2150n = new C2150n(this.f4999a.f.f5338H, this.f4999a.m8344N(), this.f4999a.f5003n, this.f4999a.f5004o, this.f4999a.f.f5338H ? this.f5000b : -1);
            int q = this.f4999a.f.f5355j.f8981b.m14991q();
            vo.f9130a.post(new C21451(this, new AdOverlayInfoParcel(this.f4999a, this.f4999a, this.f4999a, this.f4999a.f.f5355j.f8981b, q == -1 ? this.f4999a.f.f5355j.f8986g : q, this.f4999a.f.f5350e, this.f4999a.f.f5355j.f8973C, c2150n)));
        }

        public void m8334b() {
        }
    }

    public C2148m(Context context, ke keVar, String str, pw pwVar, wi wiVar, C2124e c2124e) {
        super(context, keVar, str, pwVar, wiVar, c2124e);
        this.f5002m = -1;
        this.f5001l = false;
        this.f5005p = C2243w.m8779D().m14494d() ? new uu(context, str) : null;
    }

    private void m8339a(Bundle bundle) {
        C2243w.m8786e().m14734b(this.f.f5348c, this.f.f5350e.f9227a, "gmob-apps", bundle, false);
    }

    static C3048a m8342b(C3048a c3048a) {
        try {
            String jSONObject = tc.m14201a(c3048a.f8964b).toString();
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.put(C2011a.AD_UNIT_ID_PARAMETER, c3048a.f8963a.f8559e);
            pl plVar = new pl(jSONObject, null, Collections.singletonList("com.google.ads.mediation.admob.AdMobAdapter"), null, null, Collections.emptyList(), Collections.emptyList(), jSONObject2.toString(), null, Collections.emptyList(), Collections.emptyList(), null, null, null, null, null, Collections.emptyList());
            sl slVar = c3048a.f8964b;
            pm pmVar = new pm(Collections.singletonList(plVar), ((Long) ly.bG.m12563c()).longValue(), Collections.emptyList(), Collections.emptyList(), Collections.emptyList(), slVar.f8591J, slVar.f8592K, BuildConfig.FLAVOR, -1, 0, 1, null, 0, -1, -1, false);
            return new C3048a(c3048a.f8963a, new sl(c3048a.f8963a, slVar.f8600b, slVar.f8601c, Collections.emptyList(), Collections.emptyList(), slVar.f8605g, true, slVar.f8607i, Collections.emptyList(), slVar.f8609k, slVar.f8610l, slVar.f8611m, slVar.f8612n, slVar.f8613o, slVar.f8614p, slVar.f8615q, null, slVar.f8617s, slVar.f8618t, slVar.f8619u, slVar.f8620v, slVar.f8621w, slVar.f8624z, slVar.f8582A, slVar.f8583B, null, Collections.emptyList(), Collections.emptyList(), slVar.f8587F, slVar.f8588G, slVar.f8589H, slVar.f8590I, slVar.f8591J, slVar.f8592K, slVar.f8593L, null, slVar.f8595N, slVar.f8596O, slVar.f8597P), pmVar, c3048a.f8966d, c3048a.f8967e, c3048a.f8968f, c3048a.f8969g, null);
        } catch (Throwable e) {
            wg.m14616b("Unable to generate ad state for an interstitial ad with pooling.", e);
            return c3048a;
        }
    }

    public void m8343H() {
        C3234c.m16050b("showInterstitial must be called on the main UI thread.");
        if (this.f.f5355j == null) {
            wg.m14620e("The interstitial has not loaded.");
            return;
        }
        if (((Boolean) ly.br.m12563c()).booleanValue()) {
            Bundle bundle;
            String packageName = this.f.f5348c.getApplicationContext() != null ? this.f.f5348c.getApplicationContext().getPackageName() : this.f.f5348c.getPackageName();
            if (!this.f5001l) {
                wg.m14620e("It is not recommended to show an interstitial before onAdLoaded completes.");
                bundle = new Bundle();
                bundle.putString("appid", packageName);
                bundle.putString("action", "show_interstitial_before_load_finish");
                m8339a(bundle);
            }
            if (!C2243w.m8786e().m14750g(this.f.f5348c)) {
                wg.m14620e("It is not recommended to show an interstitial when app is not in foreground.");
                bundle = new Bundle();
                bundle.putString("appid", packageName);
                bundle.putString("action", "show_interstitial_app_not_in_foreground");
                m8339a(bundle);
            }
        }
        if (!this.f.m8821f()) {
            if (this.f.f5355j.f8993n && this.f.f5355j.f8995p != null) {
                try {
                    this.f.f5355j.f8995p.m13452b();
                } catch (Throwable e) {
                    wg.m14618c("Could not show interstitial.", e);
                    m8345O();
                }
            } else if (this.f.f5355j.f8981b == null) {
                wg.m14620e("The interstitial failed to load.");
            } else if (this.f.f5355j.f8981b.m14990p()) {
                wg.m14620e("The interstitial is already showing.");
            } else {
                this.f.f5355j.f8981b.m14969a(true);
                if (this.f.f5355j.f8989j != null) {
                    this.h.m11920a(this.f.f5354i, this.f.f5355j);
                }
                C3303m.m16338b();
                vb vbVar = this.f.f5355j;
                if (vbVar.m14527a()) {
                    new iu(this.f.f5348c, vbVar.f8981b.m14970b()).m12022a(vbVar.f8981b);
                } else {
                    vbVar.f8981b.m14986l().m15022a(new C21441(this, vbVar));
                }
                Bitmap h = this.f.f5338H ? C2243w.m8786e().m14751h(this.f.f5348c) : null;
                this.f5002m = C2243w.m8807z().m14871a(h);
                if (!((Boolean) ly.bU.m12563c()).booleanValue() || h == null) {
                    C2150n c2150n = new C2150n(this.f.f5338H, m8344N(), false, 0.0f, -1);
                    int q = this.f.f5355j.f8981b.m14991q();
                    if (q == -1) {
                        q = this.f.f5355j.f8986g;
                    }
                    C2243w.m8784c().m8497a(this.f.f5348c, new AdOverlayInfoParcel(this, this, this, this.f.f5355j.f8981b, q, this.f.f5350e, this.f.f5355j.f8973C, c2150n));
                    return;
                }
                new C2146a(this, this.f5002m).m8331d();
            }
        }
    }

    protected boolean m8344N() {
        if (!(this.f.f5348c instanceof Activity)) {
            return false;
        }
        Window window = ((Activity) this.f.f5348c).getWindow();
        if (window == null || window.getDecorView() == null) {
            return false;
        }
        Rect rect = new Rect();
        Rect rect2 = new Rect();
        window.getDecorView().getGlobalVisibleRect(rect, null);
        window.getDecorView().getWindowVisibleDisplayFrame(rect2);
        boolean z = (rect.bottom == 0 || rect2.bottom == 0 || rect.top != rect2.top) ? false : true;
        return z;
    }

    public void m8345O() {
        C2243w.m8807z().m14873b(Integer.valueOf(this.f5002m));
        if (this.f.m8820e()) {
            this.f.m8817b();
            this.f.f5355j = null;
            this.f.f5338H = false;
            this.f5001l = false;
        }
    }

    public void m8346P() {
        if (!(this.f.f5355j == null || this.f.f5355j.f9004y == null)) {
            C2243w.m8786e().m14713a(this.f.f5348c, this.f.f5350e.f9227a, this.f.f5355j.f9004y);
        }
        m8174w();
    }

    protected wx m8347a(C3048a c3048a, C2125f c2125f, us usVar) {
        wx a = C2243w.m8787f().m15047a(this.f.f5348c, this.f.f5354i, false, false, this.f.f5349d, this.f.f5350e, this.a, this, this.i);
        a.m14986l().m15018a(this, null, this, this, ((Boolean) ly.ap.m12563c()).booleanValue(), this, this, c2125f, null, usVar);
        m8237a((pe) a);
        a.m14973b(c3048a.f8963a.f8576v);
        oh.m13072a(a, (C2147a) this);
        return a;
    }

    public void m8348a() {
        super.m8204a();
        if (C2243w.m8779D().m14494d()) {
            this.f5005p.m14475a(false);
        }
    }

    public void m8349a(C3048a c3048a, mg mgVar) {
        Object obj = 1;
        if (!((Boolean) ly.aW.m12563c()).booleanValue()) {
            super.m8238a(c3048a, mgVar);
        } else if (c3048a.f8967e != -2) {
            super.m8238a(c3048a, mgVar);
        } else {
            Bundle bundle = c3048a.f8963a.f8557c.f7359m.getBundle("com.google.ads.mediation.admob.AdMobAdapter");
            Object obj2 = (bundle == null || !bundle.containsKey("gw")) ? 1 : null;
            if (c3048a.f8964b.f8606h) {
                obj = null;
            }
            if (!(obj2 == null || r2 == null)) {
                this.f.f5356k = C2148m.m8342b(c3048a);
            }
            super.m8238a(this.f.f5356k, mgVar);
        }
    }

    public void m8350a(boolean z, float f) {
        this.f5003n = z;
        this.f5004o = f;
    }

    public boolean m8351a(ka kaVar, mg mgVar) {
        if (this.f.f5355j == null) {
            return super.m8210a(kaVar, mgVar);
        }
        wg.m14620e("An interstitial is already loading. Aborting.");
        return false;
    }

    protected boolean m8352a(ka kaVar, vb vbVar, boolean z) {
        if (this.f.m8820e() && vbVar.f8981b != null) {
            C2243w.m8788g().m14773a(vbVar.f8981b);
        }
        return this.e.m8724d();
    }

    public boolean m8353a(vb vbVar, vb vbVar2) {
        if (!super.m8239a(vbVar, vbVar2)) {
            return false;
        }
        if (!(this.f.m8820e() || this.f.f5335E == null || vbVar2.f8989j == null)) {
            this.h.m11921a(this.f.f5354i, vbVar2, this.f.f5335E);
        }
        return true;
    }

    public void m8354b(un unVar) {
        if (this.f.f5355j != null) {
            if (this.f.f5355j.f9005z != null) {
                C2243w.m8786e().m14713a(this.f.f5348c, this.f.f5350e.f9227a, this.f.f5355j.f9005z);
            }
            if (this.f.f5355j.f9003x != null) {
                unVar = this.f.f5355j.f9003x;
            }
        }
        m8138a(unVar);
    }

    public void m8355b(boolean z) {
        this.f.f5338H = z;
    }

    public void m8356d() {
        m8199F();
        super.m8218d();
        if (!(this.f.f5355j == null || this.f.f5355j.f8981b == null)) {
            wy l = this.f.f5355j.f8981b.m14986l();
            if (l != null) {
                l.m15036h();
            }
        }
        if (C2243w.m8779D().m14494d()) {
            C2243w.m8779D().m14484a(this.f.f5348c, this.f.f5347b, C2243w.m8779D().m14482a(this.f.f5348c));
            this.f5005p.m14475a(true);
        }
    }

    protected void m8357s() {
        m8345O();
        super.m8170s();
    }

    protected void m8358v() {
        super.m8173v();
        this.f5001l = true;
    }
}
