package com.google.android.gms.ads.internal.overlay;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.SurfaceTexture;
import android.graphics.SurfaceTexture.OnFrameAvailableListener;
import android.opengl.GLES20;
import android.opengl.GLUtils;
import android.util.Log;
import com.google.android.gms.ads.internal.C2243w;
import com.google.android.gms.ads.internal.overlay.C2199z.C2153a;
import com.google.android.gms.p095b.lt;
import com.google.android.gms.p095b.ly;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.wg;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.concurrent.CountDownLatch;
import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.egl.EGLSurface;

@TargetApi(14)
@sc
public class aa extends Thread implements OnFrameAvailableListener, C2153a {
    private static final float[] f5028a;
    private volatile boolean f5029A;
    private volatile boolean f5030B;
    private final C2199z f5031b;
    private final float[] f5032c;
    private final float[] f5033d;
    private final float[] f5034e;
    private final float[] f5035f;
    private final float[] f5036g;
    private final float[] f5037h;
    private final float[] f5038i;
    private float f5039j;
    private float f5040k;
    private float f5041l;
    private int f5042m;
    private int f5043n;
    private SurfaceTexture f5044o;
    private SurfaceTexture f5045p;
    private int f5046q;
    private int f5047r;
    private int f5048s;
    private FloatBuffer f5049t;
    private final CountDownLatch f5050u;
    private final Object f5051v;
    private EGL10 f5052w;
    private EGLDisplay f5053x;
    private EGLContext f5054y;
    private EGLSurface f5055z;

    static {
        f5028a = new float[]{-1.0f, -1.0f, -1.0f, 1.0f, -1.0f, -1.0f, -1.0f, 1.0f, -1.0f, 1.0f, 1.0f, -1.0f};
    }

    public aa(Context context) {
        super("SphericalVideoProcessor");
        this.f5049t = ByteBuffer.allocateDirect(f5028a.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        this.f5049t.put(f5028a).position(0);
        this.f5032c = new float[9];
        this.f5033d = new float[9];
        this.f5034e = new float[9];
        this.f5035f = new float[9];
        this.f5036g = new float[9];
        this.f5037h = new float[9];
        this.f5038i = new float[9];
        this.f5039j = Float.NaN;
        this.f5031b = new C2199z(context);
        this.f5031b.m8557a((C2153a) this);
        this.f5050u = new CountDownLatch(1);
        this.f5051v = new Object();
    }

    private float m8373a(float[] fArr) {
        float[] a = m8378a(fArr, new float[]{0.0f, 1.0f, 0.0f});
        return ((float) Math.atan2((double) a[1], (double) a[0])) - 1.5707964f;
    }

    private int m8374a(int i, String str) {
        int glCreateShader = GLES20.glCreateShader(i);
        m8375a("createShader");
        if (glCreateShader != 0) {
            GLES20.glShaderSource(glCreateShader, str);
            m8375a("shaderSource");
            GLES20.glCompileShader(glCreateShader);
            m8375a("compileShader");
            int[] iArr = new int[1];
            GLES20.glGetShaderiv(glCreateShader, 35713, iArr, 0);
            m8375a("getShaderiv");
            if (iArr[0] == 0) {
                Log.e("SphericalVideoRenderer", "Could not compile shader " + i + ":");
                Log.e("SphericalVideoRenderer", GLES20.glGetShaderInfoLog(glCreateShader));
                GLES20.glDeleteShader(glCreateShader);
                m8375a("deleteShader");
                return 0;
            }
        }
        return glCreateShader;
    }

    private void m8375a(String str) {
        int glGetError = GLES20.glGetError();
        if (glGetError != 0) {
            Log.e("SphericalVideoRenderer", new StringBuilder(String.valueOf(str).length() + 21).append(str).append(": glError ").append(glGetError).toString());
        }
    }

    private void m8376a(float[] fArr, float f) {
        fArr[0] = 1.0f;
        fArr[1] = 0.0f;
        fArr[2] = 0.0f;
        fArr[3] = 0.0f;
        fArr[4] = (float) Math.cos((double) f);
        fArr[5] = (float) (-Math.sin((double) f));
        fArr[6] = 0.0f;
        fArr[7] = (float) Math.sin((double) f);
        fArr[8] = (float) Math.cos((double) f);
    }

    private void m8377a(float[] fArr, float[] fArr2, float[] fArr3) {
        fArr[0] = ((fArr2[0] * fArr3[0]) + (fArr2[1] * fArr3[3])) + (fArr2[2] * fArr3[6]);
        fArr[1] = ((fArr2[0] * fArr3[1]) + (fArr2[1] * fArr3[4])) + (fArr2[2] * fArr3[7]);
        fArr[2] = ((fArr2[0] * fArr3[2]) + (fArr2[1] * fArr3[5])) + (fArr2[2] * fArr3[8]);
        fArr[3] = ((fArr2[3] * fArr3[0]) + (fArr2[4] * fArr3[3])) + (fArr2[5] * fArr3[6]);
        fArr[4] = ((fArr2[3] * fArr3[1]) + (fArr2[4] * fArr3[4])) + (fArr2[5] * fArr3[7]);
        fArr[5] = ((fArr2[3] * fArr3[2]) + (fArr2[4] * fArr3[5])) + (fArr2[5] * fArr3[8]);
        fArr[6] = ((fArr2[6] * fArr3[0]) + (fArr2[7] * fArr3[3])) + (fArr2[8] * fArr3[6]);
        fArr[7] = ((fArr2[6] * fArr3[1]) + (fArr2[7] * fArr3[4])) + (fArr2[8] * fArr3[7]);
        fArr[8] = ((fArr2[6] * fArr3[2]) + (fArr2[7] * fArr3[5])) + (fArr2[8] * fArr3[8]);
    }

    private float[] m8378a(float[] fArr, float[] fArr2) {
        return new float[]{((fArr[0] * fArr2[0]) + (fArr[1] * fArr2[1])) + (fArr[2] * fArr2[2]), ((fArr[3] * fArr2[0]) + (fArr[4] * fArr2[1])) + (fArr[5] * fArr2[2]), ((fArr[6] * fArr2[0]) + (fArr[7] * fArr2[1])) + (fArr[8] * fArr2[2])};
    }

    private void m8379b(float[] fArr, float f) {
        fArr[0] = (float) Math.cos((double) f);
        fArr[1] = (float) (-Math.sin((double) f));
        fArr[2] = 0.0f;
        fArr[3] = (float) Math.sin((double) f);
        fArr[4] = (float) Math.cos((double) f);
        fArr[5] = 0.0f;
        fArr[6] = 0.0f;
        fArr[7] = 0.0f;
        fArr[8] = 1.0f;
    }

    private void m8380h() {
        GLES20.glViewport(0, 0, this.f5043n, this.f5042m);
        m8375a("viewport");
        int glGetUniformLocation = GLES20.glGetUniformLocation(this.f5046q, "uFOVx");
        int glGetUniformLocation2 = GLES20.glGetUniformLocation(this.f5046q, "uFOVy");
        if (this.f5043n > this.f5042m) {
            GLES20.glUniform1f(glGetUniformLocation, 0.87266463f);
            GLES20.glUniform1f(glGetUniformLocation2, (((float) this.f5042m) * 0.87266463f) / ((float) this.f5043n));
            return;
        }
        GLES20.glUniform1f(glGetUniformLocation, (((float) this.f5043n) * 0.87266463f) / ((float) this.f5042m));
        GLES20.glUniform1f(glGetUniformLocation2, 0.87266463f);
    }

    private int m8381i() {
        int a = m8374a(35633, m8383k());
        if (a == 0) {
            return 0;
        }
        int a2 = m8374a(35632, m8384l());
        if (a2 == 0) {
            return 0;
        }
        int glCreateProgram = GLES20.glCreateProgram();
        m8375a("createProgram");
        if (glCreateProgram != 0) {
            GLES20.glAttachShader(glCreateProgram, a);
            m8375a("attachShader");
            GLES20.glAttachShader(glCreateProgram, a2);
            m8375a("attachShader");
            GLES20.glLinkProgram(glCreateProgram);
            m8375a("linkProgram");
            int[] iArr = new int[1];
            GLES20.glGetProgramiv(glCreateProgram, 35714, iArr, 0);
            m8375a("getProgramiv");
            if (iArr[0] != 1) {
                Log.e("SphericalVideoRenderer", "Could not link program: ");
                Log.e("SphericalVideoRenderer", GLES20.glGetProgramInfoLog(glCreateProgram));
                GLES20.glDeleteProgram(glCreateProgram);
                m8375a("deleteProgram");
                return 0;
            }
            GLES20.glValidateProgram(glCreateProgram);
            m8375a("validateProgram");
        }
        return glCreateProgram;
    }

    private EGLConfig m8382j() {
        int[] iArr = new int[1];
        EGLConfig[] eGLConfigArr = new EGLConfig[1];
        return !this.f5052w.eglChooseConfig(this.f5053x, new int[]{12352, 4, 12324, 8, 12323, 8, 12322, 8, 12325, 16, 12344}, eGLConfigArr, 1, iArr) ? null : iArr[0] > 0 ? eGLConfigArr[0] : null;
    }

    private String m8383k() {
        lt ltVar = ly.bi;
        return !((String) ltVar.m12563c()).equals(ltVar.m12562b()) ? (String) ltVar.m12563c() : "attribute highp vec3 aPosition;varying vec3 pos;void main() {  gl_Position = vec4(aPosition, 1.0);  pos = aPosition;}";
    }

    private String m8384l() {
        lt ltVar = ly.bj;
        return !((String) ltVar.m12563c()).equals(ltVar.m12562b()) ? (String) ltVar.m12563c() : "#extension GL_OES_EGL_image_external : require\n#define INV_PI 0.3183\nprecision highp float;varying vec3 pos;uniform samplerExternalOES uSplr;uniform mat3 uVMat;uniform float uFOVx;uniform float uFOVy;void main() {  vec3 ray = vec3(pos.x * tan(uFOVx), pos.y * tan(uFOVy), -1);  ray = (uVMat * ray).xyz;  ray = normalize(ray);  vec2 texCrd = vec2(    0.5 + atan(ray.x, - ray.z) * INV_PI * 0.5, acos(ray.y) * INV_PI);  gl_FragColor = vec4(texture2D(uSplr, texCrd).xyz, 1.0);}";
    }

    public void m8385a() {
        synchronized (this.f5051v) {
            this.f5051v.notifyAll();
        }
    }

    public void m8386a(float f, float f2) {
        float f3;
        float f4;
        if (this.f5043n > this.f5042m) {
            f3 = (1.7453293f * f) / ((float) this.f5043n);
            f4 = (1.7453293f * f2) / ((float) this.f5043n);
        } else {
            f3 = (1.7453293f * f) / ((float) this.f5042m);
            f4 = (1.7453293f * f2) / ((float) this.f5042m);
        }
        this.f5040k -= f3;
        this.f5041l -= f4;
        if (this.f5041l < -1.5707964f) {
            this.f5041l = -1.5707964f;
        }
        if (this.f5041l > 1.5707964f) {
            this.f5041l = 1.5707964f;
        }
    }

    public void m8387a(int i, int i2) {
        synchronized (this.f5051v) {
            this.f5043n = i;
            this.f5042m = i2;
            this.f5029A = true;
            this.f5051v.notifyAll();
        }
    }

    public void m8388a(SurfaceTexture surfaceTexture, int i, int i2) {
        this.f5043n = i;
        this.f5042m = i2;
        this.f5045p = surfaceTexture;
    }

    public void m8389b() {
        synchronized (this.f5051v) {
            this.f5030B = true;
            this.f5045p = null;
            this.f5051v.notifyAll();
        }
    }

    public SurfaceTexture m8390c() {
        if (this.f5045p == null) {
            return null;
        }
        try {
            this.f5050u.await();
        } catch (InterruptedException e) {
        }
        return this.f5044o;
    }

    void m8391d() {
        while (this.f5048s > 0) {
            this.f5044o.updateTexImage();
            this.f5048s--;
        }
        if (this.f5031b.m8560b(this.f5032c)) {
            if (Float.isNaN(this.f5039j)) {
                this.f5039j = -m8373a(this.f5032c);
            }
            m8379b(this.f5037h, this.f5039j + this.f5040k);
        } else {
            m8376a(this.f5032c, -1.5707964f);
            m8379b(this.f5037h, this.f5040k);
        }
        m8376a(this.f5033d, 1.5707964f);
        m8377a(this.f5034e, this.f5037h, this.f5033d);
        m8377a(this.f5035f, this.f5032c, this.f5034e);
        m8376a(this.f5036g, this.f5041l);
        m8377a(this.f5038i, this.f5036g, this.f5035f);
        GLES20.glUniformMatrix3fv(this.f5047r, 1, false, this.f5038i, 0);
        GLES20.glDrawArrays(5, 0, 4);
        m8375a("drawArrays");
        GLES20.glFinish();
        this.f5052w.eglSwapBuffers(this.f5053x, this.f5055z);
    }

    int m8392e() {
        this.f5046q = m8381i();
        GLES20.glUseProgram(this.f5046q);
        m8375a("useProgram");
        int glGetAttribLocation = GLES20.glGetAttribLocation(this.f5046q, "aPosition");
        GLES20.glVertexAttribPointer(glGetAttribLocation, 3, 5126, false, 12, this.f5049t);
        m8375a("vertexAttribPointer");
        GLES20.glEnableVertexAttribArray(glGetAttribLocation);
        m8375a("enableVertexAttribArray");
        int[] iArr = new int[1];
        GLES20.glGenTextures(1, iArr, 0);
        m8375a("genTextures");
        glGetAttribLocation = iArr[0];
        GLES20.glBindTexture(36197, glGetAttribLocation);
        m8375a("bindTextures");
        GLES20.glTexParameteri(36197, 10240, 9729);
        m8375a("texParameteri");
        GLES20.glTexParameteri(36197, 10241, 9729);
        m8375a("texParameteri");
        GLES20.glTexParameteri(36197, 10242, 33071);
        m8375a("texParameteri");
        GLES20.glTexParameteri(36197, 10243, 33071);
        m8375a("texParameteri");
        this.f5047r = GLES20.glGetUniformLocation(this.f5046q, "uVMat");
        GLES20.glUniformMatrix3fv(this.f5047r, 1, false, new float[]{1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f}, 0);
        return glGetAttribLocation;
    }

    boolean m8393f() {
        this.f5052w = (EGL10) EGLContext.getEGL();
        this.f5053x = this.f5052w.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY);
        if (this.f5053x == EGL10.EGL_NO_DISPLAY) {
            return false;
        }
        if (!this.f5052w.eglInitialize(this.f5053x, new int[2])) {
            return false;
        }
        EGLConfig j = m8382j();
        if (j == null) {
            return false;
        }
        this.f5054y = this.f5052w.eglCreateContext(this.f5053x, j, EGL10.EGL_NO_CONTEXT, new int[]{12440, 2, 12344});
        if (this.f5054y == null || this.f5054y == EGL10.EGL_NO_CONTEXT) {
            return false;
        }
        this.f5055z = this.f5052w.eglCreateWindowSurface(this.f5053x, j, this.f5045p, null);
        return (this.f5055z == null || this.f5055z == EGL10.EGL_NO_SURFACE) ? false : this.f5052w.eglMakeCurrent(this.f5053x, this.f5055z, this.f5055z, this.f5054y);
    }

    boolean m8394g() {
        boolean z = false;
        if (!(this.f5055z == null || this.f5055z == EGL10.EGL_NO_SURFACE)) {
            z = (this.f5052w.eglMakeCurrent(this.f5053x, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_CONTEXT) | 0) | this.f5052w.eglDestroySurface(this.f5053x, this.f5055z);
            this.f5055z = null;
        }
        if (this.f5054y != null) {
            z |= this.f5052w.eglDestroyContext(this.f5053x, this.f5054y);
            this.f5054y = null;
        }
        if (this.f5053x == null) {
            return z;
        }
        z |= this.f5052w.eglTerminate(this.f5053x);
        this.f5053x = null;
        return z;
    }

    public void onFrameAvailable(SurfaceTexture surfaceTexture) {
        this.f5048s++;
        synchronized (this.f5051v) {
            this.f5051v.notifyAll();
        }
    }

    public void run() {
        Object obj = 1;
        if (this.f5045p == null) {
            wg.m14617c("SphericalVideoProcessor started with no output texture.");
            this.f5050u.countDown();
            return;
        }
        boolean f = m8393f();
        int e = m8392e();
        if (this.f5046q == 0) {
            obj = null;
        }
        if (!f || r0 == null) {
            String str = "EGL initialization failed: ";
            String valueOf = String.valueOf(GLUtils.getEGLErrorString(this.f5052w.eglGetError()));
            valueOf = valueOf.length() != 0 ? str.concat(valueOf) : new String(str);
            wg.m14617c(valueOf);
            C2243w.m8790i().m14562a(new Throwable(valueOf), "SphericalVideoProcessor.run.1");
            m8394g();
            this.f5050u.countDown();
            return;
        }
        this.f5044o = new SurfaceTexture(e);
        this.f5044o.setOnFrameAvailableListener(this);
        this.f5050u.countDown();
        this.f5031b.m8559b();
        try {
            this.f5029A = true;
            while (!this.f5030B) {
                m8391d();
                if (this.f5029A) {
                    m8380h();
                    this.f5029A = false;
                }
                try {
                    synchronized (this.f5051v) {
                        if (!(this.f5030B || this.f5029A || this.f5048s != 0)) {
                            this.f5051v.wait();
                        }
                    }
                } catch (InterruptedException e2) {
                }
            }
        } catch (IllegalStateException e3) {
            wg.m14620e("SphericalVideoProcessor halted unexpectedly.");
        } catch (Throwable th) {
            wg.m14616b("SphericalVideoProcessor died.", th);
            C2243w.m8790i().m14562a(th, "SphericalVideoProcessor.run.2");
        } finally {
            this.f5031b.m8561c();
            this.f5044o.setOnFrameAvailableListener(null);
            this.f5044o = null;
            m8394g();
        }
    }
}
