package com.google.android.gms.ads.internal;

import android.os.Build.VERSION;
import com.google.android.gms.ads.internal.overlay.C2152a;
import com.google.android.gms.ads.internal.overlay.C2180h;
import com.google.android.gms.ads.internal.overlay.C2192t;
import com.google.android.gms.ads.internal.overlay.C2193u;
import com.google.android.gms.ads.internal.purchase.C2221i;
import com.google.android.gms.common.util.C3293c;
import com.google.android.gms.common.util.C3295e;
import com.google.android.gms.p095b.ja;
import com.google.android.gms.p095b.jk;
import com.google.android.gms.p095b.jl;
import com.google.android.gms.p095b.lv;
import com.google.android.gms.p095b.lw;
import com.google.android.gms.p095b.lx;
import com.google.android.gms.p095b.mb;
import com.google.android.gms.p095b.ol;
import com.google.android.gms.p095b.ot;
import com.google.android.gms.p095b.ph;
import com.google.android.gms.p095b.pr;
import com.google.android.gms.p095b.rn;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.sd;
import com.google.android.gms.p095b.ti;
import com.google.android.gms.p095b.uv;
import com.google.android.gms.p095b.ve;
import com.google.android.gms.p095b.vo;
import com.google.android.gms.p095b.vp;
import com.google.android.gms.p095b.vs;
import com.google.android.gms.p095b.vw;
import com.google.android.gms.p095b.vx;
import com.google.android.gms.p095b.wp;
import com.google.android.gms.p095b.ws;
import com.google.android.gms.p095b.wz;

@sc
/* renamed from: com.google.android.gms.ads.internal.w */
public class C2243w {
    private static final Object f5294a;
    private static C2243w f5295b;
    private final C2192t f5296A;
    private final C2193u f5297B;
    private final pr f5298C;
    private final vx f5299D;
    private final C2228r f5300E;
    private final ol f5301F;
    private final ws f5302G;
    private final uv f5303H;
    private final C2152a f5304c;
    private final sd f5305d;
    private final C2180h f5306e;
    private final rn f5307f;
    private final vo f5308g;
    private final wz f5309h;
    private final vp f5310i;
    private final ja f5311j;
    private final ve f5312k;
    private final jk f5313l;
    private final jl f5314m;
    private final C3293c f5315n;
    private final C2137h f5316o;
    private final mb f5317p;
    private final vs f5318q;
    private final ti f5319r;
    private final lv f5320s;
    private final lw f5321t;
    private final lx f5322u;
    private final wp f5323v;
    private final C2221i f5324w;
    private final ot f5325x;
    private final ph f5326y;
    private final vw f5327z;

    static {
        f5294a = new Object();
        C2243w.m8782a(new C2243w());
    }

    protected C2243w() {
        this.f5304c = new C2152a();
        this.f5305d = new sd();
        this.f5306e = new C2180h();
        this.f5307f = new rn();
        this.f5308g = new vo();
        this.f5309h = new wz();
        this.f5310i = vp.m14759a(VERSION.SDK_INT);
        this.f5311j = new ja();
        this.f5312k = new ve(this.f5308g);
        this.f5313l = new jk();
        this.f5314m = new jl();
        this.f5315n = C3295e.m16316d();
        this.f5316o = new C2137h();
        this.f5317p = new mb();
        this.f5318q = new vs();
        this.f5319r = new ti();
        this.f5320s = new lv();
        this.f5321t = new lw();
        this.f5322u = new lx();
        this.f5323v = new wp();
        this.f5324w = new C2221i();
        this.f5325x = new ot();
        this.f5326y = new ph();
        this.f5327z = new vw();
        this.f5296A = new C2192t();
        this.f5297B = new C2193u();
        this.f5298C = new pr();
        this.f5299D = new vx();
        this.f5300E = new C2228r();
        this.f5301F = new ol();
        this.f5302G = new ws();
        this.f5303H = new uv();
    }

    public static C2137h m8776A() {
        return C2243w.m8780E().f5316o;
    }

    public static ol m8777B() {
        return C2243w.m8780E().f5301F;
    }

    public static ws m8778C() {
        return C2243w.m8780E().f5302G;
    }

    public static uv m8779D() {
        return C2243w.m8780E().f5303H;
    }

    private static C2243w m8780E() {
        C2243w c2243w;
        synchronized (f5294a) {
            c2243w = f5295b;
        }
        return c2243w;
    }

    public static sd m8781a() {
        return C2243w.m8780E().f5305d;
    }

    protected static void m8782a(C2243w c2243w) {
        synchronized (f5294a) {
            f5295b = c2243w;
        }
    }

    public static C2152a m8783b() {
        return C2243w.m8780E().f5304c;
    }

    public static C2180h m8784c() {
        return C2243w.m8780E().f5306e;
    }

    public static rn m8785d() {
        return C2243w.m8780E().f5307f;
    }

    public static vo m8786e() {
        return C2243w.m8780E().f5308g;
    }

    public static wz m8787f() {
        return C2243w.m8780E().f5309h;
    }

    public static vp m8788g() {
        return C2243w.m8780E().f5310i;
    }

    public static ja m8789h() {
        return C2243w.m8780E().f5311j;
    }

    public static ve m8790i() {
        return C2243w.m8780E().f5312k;
    }

    public static jl m8791j() {
        return C2243w.m8780E().f5314m;
    }

    public static C3293c m8792k() {
        return C2243w.m8780E().f5315n;
    }

    public static mb m8793l() {
        return C2243w.m8780E().f5317p;
    }

    public static vs m8794m() {
        return C2243w.m8780E().f5318q;
    }

    public static ti m8795n() {
        return C2243w.m8780E().f5319r;
    }

    public static lw m8796o() {
        return C2243w.m8780E().f5321t;
    }

    public static lv m8797p() {
        return C2243w.m8780E().f5320s;
    }

    public static lx m8798q() {
        return C2243w.m8780E().f5322u;
    }

    public static wp m8799r() {
        return C2243w.m8780E().f5323v;
    }

    public static C2221i m8800s() {
        return C2243w.m8780E().f5324w;
    }

    public static ot m8801t() {
        return C2243w.m8780E().f5325x;
    }

    public static vw m8802u() {
        return C2243w.m8780E().f5327z;
    }

    public static C2192t m8803v() {
        return C2243w.m8780E().f5296A;
    }

    public static C2193u m8804w() {
        return C2243w.m8780E().f5297B;
    }

    public static pr m8805x() {
        return C2243w.m8780E().f5298C;
    }

    public static C2228r m8806y() {
        return C2243w.m8780E().f5300E;
    }

    public static vx m8807z() {
        return C2243w.m8780E().f5299D;
    }
}
