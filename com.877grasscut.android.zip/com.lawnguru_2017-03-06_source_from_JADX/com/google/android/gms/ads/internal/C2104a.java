package com.google.android.gms.ads.internal;

import android.os.Debug;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewParent;
import com.google.android.gms.ads.internal.C2245x.C2244a;
import com.google.android.gms.ads.internal.overlay.C2101s;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.common.util.C3296f;
import com.google.android.gms.p095b.io;
import com.google.android.gms.p095b.ju;
import com.google.android.gms.p095b.ka;
import com.google.android.gms.p095b.kb;
import com.google.android.gms.p095b.ke;
import com.google.android.gms.p095b.kj;
import com.google.android.gms.p095b.km;
import com.google.android.gms.p095b.kn;
import com.google.android.gms.p095b.kr.C2100a;
import com.google.android.gms.p095b.kt;
import com.google.android.gms.p095b.kv;
import com.google.android.gms.p095b.kz;
import com.google.android.gms.p095b.lb;
import com.google.android.gms.p095b.ll;
import com.google.android.gms.p095b.ln;
import com.google.android.gms.p095b.ly;
import com.google.android.gms.p095b.me;
import com.google.android.gms.p095b.mg;
import com.google.android.gms.p095b.mk;
import com.google.android.gms.p095b.ns;
import com.google.android.gms.p095b.rb;
import com.google.android.gms.p095b.rf;
import com.google.android.gms.p095b.rn.C2102a;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.sd.C2103a;
import com.google.android.gms.p095b.tp;
import com.google.android.gms.p095b.tv;
import com.google.android.gms.p095b.un;
import com.google.android.gms.p095b.vb;
import com.google.android.gms.p095b.vb.C3048a;
import com.google.android.gms.p095b.vc;
import com.google.android.gms.p095b.vg;
import com.google.android.gms.p095b.vh;
import com.google.android.gms.p095b.wg;
import com.google.android.gms.p097a.C2046a;
import com.google.android.gms.p097a.C2060d;
import io.card.payment.BuildConfig;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.CountDownLatch;

@sc
/* renamed from: com.google.android.gms.ads.internal.a */
public abstract class C2104a extends C2100a implements C2101s, ju, ns, C2102a, C2103a, vg {
    protected mg f4903a;
    protected me f4904b;
    protected me f4905c;
    protected boolean f4906d;
    protected final C2236t f4907e;
    protected final C2245x f4908f;
    protected transient ka f4909g;
    protected final io f4910h;
    protected final C2124e f4911i;

    /* renamed from: com.google.android.gms.ads.internal.a.1 */
    class C20991 extends TimerTask {
        final /* synthetic */ CountDownLatch f4900a;
        final /* synthetic */ Timer f4901b;
        final /* synthetic */ C2104a f4902c;

        C20991(C2104a c2104a, CountDownLatch countDownLatch, Timer timer) {
            this.f4902c = c2104a;
            this.f4900a = countDownLatch;
            this.f4901b = timer;
        }

        public void run() {
            if (((long) ((Integer) ly.cv.m12563c()).intValue()) != this.f4900a.getCount()) {
                wg.m14615b("Stopping method tracing");
                Debug.stopMethodTracing();
                if (this.f4900a.getCount() == 0) {
                    this.f4901b.cancel();
                    return;
                }
            }
            String concat = String.valueOf(this.f4902c.f4908f.f5348c.getPackageName()).concat("_adsTrace_");
            try {
                wg.m14615b("Starting method tracing");
                this.f4900a.countDown();
                Debug.startMethodTracing(new StringBuilder(String.valueOf(concat).length() + 20).append(concat).append(C2243w.m8792k().m16301a()).toString(), ((Integer) ly.cw.m12563c()).intValue());
            } catch (Throwable e) {
                wg.m14618c("Exception occurred while starting method tracing.", e);
            }
        }
    }

    C2104a(C2245x c2245x, C2236t c2236t, C2124e c2124e) {
        this.f4906d = false;
        this.f4908f = c2245x;
        if (c2236t == null) {
            c2236t = new C2236t(this);
        }
        this.f4907e = c2236t;
        this.f4911i = c2124e;
        C2243w.m8786e().m14735b(this.f4908f.f5348c);
        C2243w.m8790i().m14556a(this.f4908f.f5348c, this.f4908f.f5350e);
        C2243w.m8791j().m12133a(this.f4908f.f5348c);
        this.f4910h = C2243w.m8790i().m14592s();
        C2243w.m8789h().m12066a(this.f4908f.f5348c);
        m8123y();
    }

    private TimerTask m8121a(Timer timer, CountDownLatch countDownLatch) {
        return new C20991(this, countDownLatch, timer);
    }

    private ka m8122d(ka kaVar) {
        return (!C3296f.m16323c(this.f4908f.f5348c) || kaVar.f7357k == null) ? kaVar : new kb(kaVar).m12226a(null).m12225a();
    }

    private void m8123y() {
        if (((Boolean) ly.ct.m12563c()).booleanValue()) {
            Timer timer = new Timer();
            timer.schedule(m8121a(timer, new CountDownLatch(((Integer) ly.cv.m12563c()).intValue())), 0, ((Long) ly.cu.m12563c()).longValue());
        }
    }

    protected List<String> m8124a(String str, List<String> list) {
        if (str == null) {
            return list;
        }
        ArrayList arrayList = new ArrayList(list.size());
        for (String b : list) {
            arrayList.add(m8150b(str, b));
        }
        return arrayList;
    }

    protected void m8125a(int i) {
        wg.m14620e("Failed to load ad: " + i);
        this.f4906d = false;
        if (this.f4908f.f5359n != null) {
            try {
                this.f4908f.f5359n.m12160a(i);
            } catch (Throwable e) {
                wg.m14618c("Could not call AdListener.onAdFailedToLoad().", e);
            }
        }
        if (this.f4908f.f5331A != null) {
            try {
                this.f4908f.f5331A.m13138a(i);
            } catch (Throwable e2) {
                wg.m14618c("Could not call RewardedVideoAdListener.onRewardedVideoAdFailedToLoad().", e2);
            }
        }
    }

    protected void m8126a(View view) {
        C2244a c2244a = this.f4908f.f5351f;
        if (c2244a != null) {
            c2244a.addView(view, C2243w.m8788g().m14782d());
        }
    }

    public void m8127a(ke keVar) {
        C3234c.m16050b("setAdSize must be called on the main UI thread.");
        this.f4908f.f5354i = keVar;
        if (!(this.f4908f.f5355j == null || this.f4908f.f5355j.f8981b == null || this.f4908f.f5336F != 0)) {
            this.f4908f.f5355j.f8981b.m14962a(keVar);
        }
        if (this.f4908f.f5351f != null) {
            if (this.f4908f.f5351f.getChildCount() > 1) {
                this.f4908f.f5351f.removeView(this.f4908f.f5351f.getNextView());
            }
            this.f4908f.f5351f.setMinimumWidth(keVar.f7388f);
            this.f4908f.f5351f.setMinimumHeight(keVar.f7385c);
            this.f4908f.f5351f.requestLayout();
        }
    }

    public void m8128a(km kmVar) {
        C3234c.m16050b("setAdListener must be called on the main UI thread.");
        this.f4908f.f5358m = kmVar;
    }

    public void m8129a(kn knVar) {
        C3234c.m16050b("setAdListener must be called on the main UI thread.");
        this.f4908f.f5359n = knVar;
    }

    public void m8130a(kt ktVar) {
        C3234c.m16050b("setAppEventListener must be called on the main UI thread.");
        this.f4908f.f5360o = ktVar;
    }

    public void m8131a(kv kvVar) {
        C3234c.m16050b("setCorrelationIdProvider must be called on the main UI thread");
        this.f4908f.f5361p = kvVar;
    }

    public void m8132a(lb lbVar) {
        C3234c.m16050b("setIconAdOptions must be called on the main UI thread.");
        this.f4908f.f5370y = lbVar;
    }

    public void m8133a(ln lnVar) {
        C3234c.m16050b("setVideoOptions must be called on the main UI thread.");
        this.f4908f.f5369x = lnVar;
    }

    public void m8134a(mk mkVar) {
        throw new IllegalStateException("setOnCustomRenderedAdLoadedListener is not supported for current ad type");
    }

    public void m8135a(rb rbVar) {
        throw new IllegalStateException("setInAppPurchaseListener is not supported for current ad type");
    }

    public void m8136a(rf rfVar, String str) {
        throw new IllegalStateException("setPlayStorePurchaseParams is not supported for current ad type");
    }

    public void m8137a(tv tvVar) {
        C3234c.m16050b("setRewardedVideoAdListener can only be called from the UI thread.");
        this.f4908f.f5331A = tvVar;
    }

    protected void m8138a(un unVar) {
        if (this.f4908f.f5331A != null) {
            try {
                String str = BuildConfig.FLAVOR;
                int i = 1;
                if (unVar != null) {
                    str = unVar.f8931a;
                    i = unVar.f8932b;
                }
                this.f4908f.f5331A.m13139a(new tp(str, i));
            } catch (Throwable e) {
                wg.m14618c("Could not call RewardedVideoAdListener.onRewarded().", e);
            }
        }
    }

    public void m8139a(C3048a c3048a) {
        if (!(c3048a.f8964b.f8612n == -1 || TextUtils.isEmpty(c3048a.f8964b.f8623y))) {
            long b = m8149b(c3048a.f8964b.f8623y);
            if (b != -1) {
                me a = this.f4903a.m12661a(b + c3048a.f8964b.f8612n);
                this.f4903a.m12666a(a, "stc");
            }
        }
        this.f4903a.m12663a(c3048a.f8964b.f8623y);
        this.f4903a.m12666a(this.f4904b, "arf");
        this.f4905c = this.f4903a.m12660a();
        this.f4903a.m12664a("gqi", c3048a.f8964b.f8624z);
        this.f4908f.f5352g = null;
        this.f4908f.f5356k = c3048a;
        m8140a(c3048a, this.f4903a);
    }

    protected abstract void m8140a(C3048a c3048a, mg mgVar);

    public void m8141a(String str) {
        wg.m14620e("RewardedVideoAd.setUserId() is deprecated. Please do not call this method.");
    }

    public void m8142a(String str, String str2) {
        if (this.f4908f.f5360o != null) {
            try {
                this.f4908f.f5360o.m12242a(str, str2);
            } catch (Throwable e) {
                wg.m14618c("Could not call the AppEventListener.", e);
            }
        }
    }

    public void m8143a(HashSet<vc> hashSet) {
        this.f4908f.m8815a((HashSet) hashSet);
    }

    public void m8144a(boolean z) {
        throw new UnsupportedOperationException("Attempt to call setManualImpressionsEnabled for an unsupported ad type.");
    }

    public boolean m8145a(ka kaVar) {
        C3234c.m16050b("loadAd must be called on the main UI thread.");
        C2243w.m8791j().m12132a();
        if (((Boolean) ly.aR.m12563c()).booleanValue()) {
            ka.m12224a(kaVar);
        }
        ka d = m8122d(kaVar);
        if (this.f4908f.f5352g == null && this.f4908f.f5353h == null) {
            wg.m14619d("Starting ad request.");
            m8159h();
            this.f4904b = this.f4903a.m12660a();
            if (!d.f7352f) {
                String valueOf = String.valueOf(kj.m12293a().m14897a(this.f4908f.f5348c));
                wg.m14619d(new StringBuilder(String.valueOf(valueOf).length() + 71).append("Use AdRequest.Builder.addTestDevice(\"").append(valueOf).append("\") to get test ads on this device.").toString());
            }
            this.f4907e.m8719a(d);
            this.f4906d = m8146a(d, this.f4903a);
            return this.f4906d;
        }
        if (this.f4909g != null) {
            wg.m14620e("Aborting last ad request since another ad request is already in progress. The current request object will still be cached for future refreshes.");
        } else {
            wg.m14620e("Loading already in progress, saving this object for future refreshes.");
        }
        this.f4909g = d;
        return false;
    }

    protected abstract boolean m8146a(ka kaVar, mg mgVar);

    boolean m8147a(vb vbVar) {
        return false;
    }

    protected abstract boolean m8148a(vb vbVar, vb vbVar2);

    long m8149b(String str) {
        int indexOf = str.indexOf("ufe");
        int indexOf2 = str.indexOf(44, indexOf);
        if (indexOf2 == -1) {
            indexOf2 = str.length();
        }
        try {
            return Long.parseLong(str.substring(indexOf + 4, indexOf2));
        } catch (IndexOutOfBoundsException e) {
            wg.m14620e("Invalid index for Url fetch time in CSI latency info.");
            return -1;
        } catch (NumberFormatException e2) {
            wg.m14620e("Cannot find valid format of Url fetch time in CSI latency info.");
            return -1;
        }
    }

    protected String m8150b(String str, String str2) {
        return (str == null || TextUtils.isEmpty(str2)) ? str2 : C2243w.m8786e().m14691a(str2, "fbs_aeid", str).toString();
    }

    public void m8151b(vb vbVar) {
        this.f4903a.m12666a(this.f4905c, "awr");
        this.f4908f.f5353h = null;
        if (!(vbVar.f8983d == -2 || vbVar.f8983d == 3)) {
            C2243w.m8790i().m14563a(this.f4908f.m8814a());
        }
        if (vbVar.f8983d == -1) {
            this.f4906d = false;
            return;
        }
        if (m8147a(vbVar)) {
            wg.m14615b("Ad refresh scheduled.");
        }
        if (vbVar.f8983d != -2) {
            m8125a(vbVar.f8983d);
            return;
        }
        if (this.f4908f.f5334D == null) {
            this.f4908f.f5334D = new vh(this.f4908f.f5347b);
        }
        this.f4910h.m11926b(this.f4908f.f5355j);
        if (m8148a(this.f4908f.f5355j, vbVar)) {
            this.f4908f.f5355j = vbVar;
            this.f4908f.m8824i();
            this.f4903a.m12664a("is_mraid", this.f4908f.f5355j.m14527a() ? "1" : "0");
            this.f4903a.m12664a("is_mediation", this.f4908f.f5355j.f8993n ? "1" : "0");
            if (!(this.f4908f.f5355j.f8981b == null || this.f4908f.f5355j.f8981b.m14986l() == null)) {
                this.f4903a.m12664a("is_delay_pl", this.f4908f.f5355j.f8981b.m14986l().m15034f() ? "1" : "0");
            }
            this.f4903a.m12666a(this.f4904b, "ttc");
            if (C2243w.m8790i().m14579f() != null) {
                C2243w.m8790i().m14579f().m12642a(this.f4903a);
            }
            if (this.f4908f.m8820e()) {
                m8173v();
            }
        }
        if (vbVar.f8979I != null) {
            C2243w.m8786e().m14716a(this.f4908f.f5348c, vbVar.f8979I);
        }
    }

    protected boolean m8152b(ka kaVar) {
        if (this.f4908f.f5351f == null) {
            return false;
        }
        ViewParent parent = this.f4908f.f5351f.getParent();
        if (!(parent instanceof View)) {
            return false;
        }
        View view = (View) parent;
        return C2243w.m8786e().m14724a(view, view.getContext());
    }

    public void m8153c(ka kaVar) {
        if (m8152b(kaVar)) {
            m8145a(kaVar);
            return;
        }
        wg.m14619d("Ad is not visible. Not refreshing ad.");
        this.f4907e.m8722b(kaVar);
    }

    protected void m8154c(vb vbVar) {
        if (vbVar == null) {
            wg.m14620e("Ad state was null when trying to ping impression URLs.");
            return;
        }
        wg.m14615b("Pinging Impression URLs.");
        if (this.f4908f.f5357l != null) {
            this.f4908f.f5357l.m14532a();
        }
        if (vbVar.f8984e != null && !vbVar.f8976F) {
            String d = C2243w.m8779D().m14492d(this.f4908f.f5348c);
            C2243w.m8786e().m14713a(this.f4908f.f5348c, this.f4908f.f5350e.f9227a, m8124a(d, vbVar.f8984e));
            vbVar.f8976F = true;
            m8155d(vbVar);
            if (vbVar.f8984e.size() > 0) {
                C2243w.m8779D().m14493d(this.f4908f.f5348c, d);
            }
        }
    }

    protected void m8155d(vb vbVar) {
        if (vbVar != null && !TextUtils.isEmpty(vbVar.f8974D) && !vbVar.f8978H && C2243w.m8794m().m14839b()) {
            wg.m14615b("Sending troubleshooting signals to the server.");
            C2243w.m8794m().m14834a(this.f4908f.f5348c, this.f4908f.f5350e.f9227a, vbVar.f8974D, this.f4908f.f5347b);
            vbVar.f8978H = true;
        }
    }

    public void m8156e() {
        if (this.f4908f.f5355j == null) {
            wg.m14620e("Ad state was null when trying to ping click URLs.");
            return;
        }
        wg.m14615b("Pinging click URLs.");
        if (this.f4908f.f5357l != null) {
            this.f4908f.f5357l.m14536b();
        }
        if (this.f4908f.f5355j.f8982c != null) {
            String d = C2243w.m8779D().m14492d(this.f4908f.f5348c);
            C2243w.m8786e().m14713a(this.f4908f.f5348c, this.f4908f.f5350e.f9227a, m8124a(d, this.f4908f.f5355j.f8982c));
            if (this.f4908f.f5355j.f8982c.size() > 0) {
                C2243w.m8779D().m14490c(this.f4908f.f5348c, d);
            }
        }
        if (this.f4908f.f5358m != null) {
            try {
                this.f4908f.f5358m.m12156a();
            } catch (Throwable e) {
                wg.m14618c("Could not notify onAdClicked event.", e);
            }
        }
    }

    public void m8157f() {
        m8171t();
    }

    public C2124e m8158g() {
        return this.f4911i;
    }

    public void m8159h() {
        this.f4903a = new mg(((Boolean) ly.f7584T.m12563c()).booleanValue(), "load_ad", this.f4908f.f5354i.f7383a);
        this.f4904b = new me(-1, null, null);
        this.f4905c = new me(-1, null, null);
    }

    public void m8160i() {
        C3234c.m16050b("destroy must be called on the main UI thread.");
        this.f4907e.m8718a();
        this.f4910h.m11927c(this.f4908f.f5355j);
        this.f4908f.m8825j();
    }

    public C2046a m8161j() {
        C3234c.m16050b("getAdFrame must be called on the main UI thread.");
        return C2060d.m7973a(this.f4908f.f5351f);
    }

    public ke m8162k() {
        C3234c.m16050b("getAdSize must be called on the main UI thread.");
        return this.f4908f.f5354i == null ? null : new ll(this.f4908f.f5354i);
    }

    public boolean m8163l() {
        C3234c.m16050b("isLoaded must be called on the main UI thread.");
        return this.f4908f.f5352g == null && this.f4908f.f5353h == null && this.f4908f.f5355j != null;
    }

    public void m8164m() {
        C3234c.m16050b("recordManualImpression must be called on the main UI thread.");
        if (this.f4908f.f5355j == null) {
            wg.m14620e("Ad state was null when trying to ping manual tracking URLs.");
            return;
        }
        wg.m14615b("Pinging manual tracking URLs.");
        if (this.f4908f.f5355j.f8985f != null && !this.f4908f.f5355j.f8977G) {
            C2243w.m8786e().m14713a(this.f4908f.f5348c, this.f4908f.f5350e.f9227a, this.f4908f.f5355j.f8985f);
            this.f4908f.f5355j.f8977G = true;
            m8175x();
        }
    }

    public void m8165n() {
        C3234c.m16050b("pause must be called on the main UI thread.");
    }

    public void m8166o() {
        C3234c.m16050b("resume must be called on the main UI thread.");
    }

    public void m8167p() {
        C3234c.m16050b("stopLoading must be called on the main UI thread.");
        this.f4906d = false;
        this.f4908f.m8816a(true);
    }

    public boolean m8168q() {
        return this.f4906d;
    }

    public kz m8169r() {
        return null;
    }

    protected void m8170s() {
        wg.m14619d("Ad closing.");
        if (this.f4908f.f5359n != null) {
            try {
                this.f4908f.f5359n.m12159a();
            } catch (Throwable e) {
                wg.m14618c("Could not call AdListener.onAdClosed().", e);
            }
        }
        if (this.f4908f.f5331A != null) {
            try {
                this.f4908f.f5331A.m13142d();
            } catch (Throwable e2) {
                wg.m14618c("Could not call RewardedVideoAdListener.onRewardedVideoAdClosed().", e2);
            }
        }
    }

    protected void m8171t() {
        wg.m14619d("Ad leaving application.");
        if (this.f4908f.f5359n != null) {
            try {
                this.f4908f.f5359n.m12161b();
            } catch (Throwable e) {
                wg.m14618c("Could not call AdListener.onAdLeftApplication().", e);
            }
        }
        if (this.f4908f.f5331A != null) {
            try {
                this.f4908f.f5331A.m13143e();
            } catch (Throwable e2) {
                wg.m14618c("Could not call  RewardedVideoAdListener.onRewardedVideoAdLeftApplication().", e2);
            }
        }
    }

    protected void m8172u() {
        wg.m14619d("Ad opening.");
        if (this.f4908f.f5359n != null) {
            try {
                this.f4908f.f5359n.m12163d();
            } catch (Throwable e) {
                wg.m14618c("Could not call AdListener.onAdOpened().", e);
            }
        }
        if (this.f4908f.f5331A != null) {
            try {
                this.f4908f.f5331A.m13140b();
            } catch (Throwable e2) {
                wg.m14618c("Could not call RewardedVideoAdListener.onRewardedVideoAdOpened().", e2);
            }
        }
    }

    protected void m8173v() {
        wg.m14619d("Ad finished loading.");
        this.f4906d = false;
        if (this.f4908f.f5359n != null) {
            try {
                this.f4908f.f5359n.m12162c();
            } catch (Throwable e) {
                wg.m14618c("Could not call AdListener.onAdLoaded().", e);
            }
        }
        if (this.f4908f.f5331A != null) {
            try {
                this.f4908f.f5331A.m13137a();
            } catch (Throwable e2) {
                wg.m14618c("Could not call RewardedVideoAdListener.onRewardedVideoAdLoaded().", e2);
            }
        }
    }

    protected void m8174w() {
        if (this.f4908f.f5331A != null) {
            try {
                this.f4908f.f5331A.m13141c();
            } catch (Throwable e) {
                wg.m14618c("Could not call RewardedVideoAdListener.onVideoStarted().", e);
            }
        }
    }

    public void m8175x() {
        m8155d(this.f4908f.f5355j);
    }
}
