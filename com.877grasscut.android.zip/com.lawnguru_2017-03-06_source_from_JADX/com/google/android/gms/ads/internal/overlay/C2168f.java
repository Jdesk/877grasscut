package com.google.android.gms.ads.internal.overlay;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.SurfaceTexture;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnBufferingUpdateListener;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnInfoListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaPlayer.OnVideoSizeChangedListener;
import android.net.Uri;
import android.os.Build.VERSION;
import android.view.TextureView.SurfaceTextureListener;
import android.view.View.MeasureSpec;
import com.google.android.gms.ads.internal.C2243w;
import com.google.android.gms.p095b.jp;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.vk;
import com.google.android.gms.p095b.vo;
import com.google.android.gms.p095b.wg;
import io.card.payment.BuildConfig;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@TargetApi(14)
@sc
/* renamed from: com.google.android.gms.ads.internal.overlay.f */
public class C2168f extends C2167l implements OnBufferingUpdateListener, OnCompletionListener, OnErrorListener, OnInfoListener, OnPreparedListener, OnVideoSizeChangedListener, SurfaceTextureListener {
    private static final Map<Integer, String> f5103c;
    private final ab f5104d;
    private final boolean f5105e;
    private int f5106f;
    private int f5107g;
    private MediaPlayer f5108h;
    private Uri f5109i;
    private int f5110j;
    private int f5111k;
    private int f5112l;
    private int f5113m;
    private int f5114n;
    private aa f5115o;
    private boolean f5116p;
    private int f5117q;
    private C2182k f5118r;

    /* renamed from: com.google.android.gms.ads.internal.overlay.f.1 */
    class C21591 implements Runnable {
        final /* synthetic */ C2168f f5089a;

        C21591(C2168f c2168f) {
            this.f5089a = c2168f;
        }

        public void run() {
            if (this.f5089a.f5118r != null) {
                this.f5089a.f5118r.m8505b();
            }
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.overlay.f.2 */
    class C21602 implements Runnable {
        final /* synthetic */ C2168f f5090a;

        C21602(C2168f c2168f) {
            this.f5090a = c2168f;
        }

        public void run() {
            if (this.f5090a.f5118r != null) {
                this.f5090a.f5118r.m8508e();
            }
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.overlay.f.3 */
    class C21613 implements Runnable {
        final /* synthetic */ String f5091a;
        final /* synthetic */ String f5092b;
        final /* synthetic */ C2168f f5093c;

        C21613(C2168f c2168f, String str, String str2) {
            this.f5093c = c2168f;
            this.f5091a = str;
            this.f5092b = str2;
        }

        public void run() {
            if (this.f5093c.f5118r != null) {
                this.f5093c.f5118r.m8504a(this.f5091a, this.f5092b);
            }
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.overlay.f.4 */
    class C21624 implements Runnable {
        final /* synthetic */ C2168f f5094a;

        C21624(C2168f c2168f) {
            this.f5094a = c2168f;
        }

        public void run() {
            if (this.f5094a.f5118r != null) {
                this.f5094a.f5118r.m8502a();
            }
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.overlay.f.5 */
    class C21635 implements Runnable {
        final /* synthetic */ int f5095a;
        final /* synthetic */ int f5096b;
        final /* synthetic */ C2168f f5097c;

        C21635(C2168f c2168f, int i, int i2) {
            this.f5097c = c2168f;
            this.f5095a = i;
            this.f5096b = i2;
        }

        public void run() {
            if (this.f5097c.f5118r != null) {
                this.f5097c.f5118r.m8503a(this.f5095a, this.f5096b);
            }
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.overlay.f.6 */
    class C21646 implements Runnable {
        final /* synthetic */ C2168f f5098a;

        C21646(C2168f c2168f) {
            this.f5098a = c2168f;
        }

        public void run() {
            if (this.f5098a.f5118r != null) {
                this.f5098a.f5118r.m8507d();
                this.f5098a.f5118r.m8509f();
            }
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.overlay.f.7 */
    class C21657 implements Runnable {
        final /* synthetic */ C2168f f5099a;

        C21657(C2168f c2168f) {
            this.f5099a = c2168f;
        }

        public void run() {
            if (this.f5099a.f5118r != null) {
                this.f5099a.f5118r.m8506c();
            }
        }
    }

    /* renamed from: com.google.android.gms.ads.internal.overlay.f.8 */
    class C21668 implements Runnable {
        final /* synthetic */ C2168f f5100a;

        C21668(C2168f c2168f) {
            this.f5100a = c2168f;
        }

        public void run() {
            if (this.f5100a.f5118r != null) {
                this.f5100a.f5118r.m8507d();
            }
        }
    }

    static {
        f5103c = new HashMap();
        if (VERSION.SDK_INT >= 17) {
            f5103c.put(Integer.valueOf(-1004), "MEDIA_ERROR_IO");
            f5103c.put(Integer.valueOf(-1007), "MEDIA_ERROR_MALFORMED");
            f5103c.put(Integer.valueOf(-1010), "MEDIA_ERROR_UNSUPPORTED");
            f5103c.put(Integer.valueOf(-110), "MEDIA_ERROR_TIMED_OUT");
            f5103c.put(Integer.valueOf(3), "MEDIA_INFO_VIDEO_RENDERING_START");
        }
        f5103c.put(Integer.valueOf(100), "MEDIA_ERROR_SERVER_DIED");
        f5103c.put(Integer.valueOf(1), "MEDIA_ERROR_UNKNOWN");
        f5103c.put(Integer.valueOf(1), "MEDIA_INFO_UNKNOWN");
        f5103c.put(Integer.valueOf(700), "MEDIA_INFO_VIDEO_TRACK_LAGGING");
        f5103c.put(Integer.valueOf(701), "MEDIA_INFO_BUFFERING_START");
        f5103c.put(Integer.valueOf(702), "MEDIA_INFO_BUFFERING_END");
        f5103c.put(Integer.valueOf(800), "MEDIA_INFO_BAD_INTERLEAVING");
        f5103c.put(Integer.valueOf(801), "MEDIA_INFO_NOT_SEEKABLE");
        f5103c.put(Integer.valueOf(802), "MEDIA_INFO_METADATA_UPDATE");
        if (VERSION.SDK_INT >= 19) {
            f5103c.put(Integer.valueOf(901), "MEDIA_INFO_UNSUPPORTED_SUBTITLE");
            f5103c.put(Integer.valueOf(902), "MEDIA_INFO_SUBTITLE_TIMED_OUT");
        }
    }

    public C2168f(Context context, boolean z, boolean z2, ab abVar) {
        super(context);
        this.f5106f = 0;
        this.f5107g = 0;
        setSurfaceTextureListener(this);
        this.f5104d = abVar;
        this.f5116p = z;
        this.f5105e = z2;
        this.f5104d.m8399a((C2167l) this);
    }

    private void m8431a(boolean z) {
        vk.m14621a("AdMediaPlayerView release");
        if (this.f5115o != null) {
            this.f5115o.m8389b();
            this.f5115o = null;
        }
        if (this.f5108h != null) {
            this.f5108h.reset();
            this.f5108h.release();
            this.f5108h = null;
            m8433b(0);
            if (z) {
                this.f5107g = 0;
                m8434c(0);
            }
        }
    }

    private void m8432b(float f) {
        if (this.f5108h != null) {
            try {
                this.f5108h.setVolume(f, f);
                return;
            } catch (IllegalStateException e) {
                return;
            }
        }
        wg.m14620e("AdMediaPlayerView setMediaPlayerVolume() called before onPrepared().");
    }

    private void m8433b(int i) {
        if (i == 3) {
            this.f5104d.m8402c();
            this.b.m8414b();
        } else if (this.f5106f == 3) {
            this.f5104d.m8403d();
            this.b.m8415c();
        }
        this.f5106f = i;
    }

    private void m8434c(int i) {
        this.f5107g = i;
    }

    private void m8435h() {
        Throwable e;
        String valueOf;
        vk.m14621a("AdMediaPlayerView init MediaPlayer");
        SurfaceTexture surfaceTexture = getSurfaceTexture();
        if (this.f5109i != null && surfaceTexture != null) {
            m8431a(false);
            try {
                SurfaceTexture c;
                this.f5108h = C2243w.m8803v().m8550a();
                this.f5108h.setOnBufferingUpdateListener(this);
                this.f5108h.setOnCompletionListener(this);
                this.f5108h.setOnErrorListener(this);
                this.f5108h.setOnInfoListener(this);
                this.f5108h.setOnPreparedListener(this);
                this.f5108h.setOnVideoSizeChangedListener(this);
                this.f5112l = 0;
                if (this.f5116p) {
                    this.f5115o = new aa(getContext());
                    this.f5115o.m8388a(surfaceTexture, getWidth(), getHeight());
                    this.f5115o.start();
                    c = this.f5115o.m8390c();
                    if (c == null) {
                        this.f5115o.m8389b();
                        this.f5115o = null;
                    }
                    this.f5108h.setDataSource(getContext(), this.f5109i);
                    this.f5108h.setSurface(C2243w.m8804w().m8551a(c));
                    this.f5108h.setAudioStreamType(3);
                    this.f5108h.setScreenOnWhilePlaying(true);
                    this.f5108h.prepareAsync();
                    m8433b(1);
                }
                c = surfaceTexture;
                this.f5108h.setDataSource(getContext(), this.f5109i);
                this.f5108h.setSurface(C2243w.m8804w().m8551a(c));
                this.f5108h.setAudioStreamType(3);
                this.f5108h.setScreenOnWhilePlaying(true);
                this.f5108h.prepareAsync();
                m8433b(1);
            } catch (IOException e2) {
                e = e2;
                valueOf = String.valueOf(this.f5109i);
                wg.m14618c(new StringBuilder(String.valueOf(valueOf).length() + 36).append("Failed to initialize MediaPlayer at ").append(valueOf).toString(), e);
                onError(this.f5108h, 1, 0);
            } catch (IllegalArgumentException e3) {
                e = e3;
                valueOf = String.valueOf(this.f5109i);
                wg.m14618c(new StringBuilder(String.valueOf(valueOf).length() + 36).append("Failed to initialize MediaPlayer at ").append(valueOf).toString(), e);
                onError(this.f5108h, 1, 0);
            } catch (IllegalStateException e4) {
                e = e4;
                valueOf = String.valueOf(this.f5109i);
                wg.m14618c(new StringBuilder(String.valueOf(valueOf).length() + 36).append("Failed to initialize MediaPlayer at ").append(valueOf).toString(), e);
                onError(this.f5108h, 1, 0);
            }
        }
    }

    private void m8436i() {
        if (this.f5105e && m8437j() && this.f5108h.getCurrentPosition() > 0 && this.f5107g != 3) {
            vk.m14621a("AdMediaPlayerView nudging MediaPlayer");
            m8432b(0.0f);
            this.f5108h.start();
            int currentPosition = this.f5108h.getCurrentPosition();
            long a = C2243w.m8792k().m16301a();
            while (m8437j() && this.f5108h.getCurrentPosition() == currentPosition) {
                if (C2243w.m8792k().m16301a() - a > 250) {
                    break;
                }
            }
            this.f5108h.pause();
            m8438a();
        }
    }

    private boolean m8437j() {
        return (this.f5108h == null || this.f5106f == -1 || this.f5106f == 0 || this.f5106f == 1) ? false : true;
    }

    public void m8438a() {
        m8432b(this.b.m8411a());
    }

    public void m8439a(float f, float f2) {
        if (this.f5115o != null) {
            this.f5115o.m8386a(f, f2);
        }
    }

    public void m8440a(int i) {
        vk.m14621a("AdMediaPlayerView seek " + i);
        if (m8437j()) {
            this.f5108h.seekTo(i);
            this.f5117q = 0;
            return;
        }
        this.f5117q = i;
    }

    public void m8441a(C2182k c2182k) {
        this.f5118r = c2182k;
    }

    public String m8442b() {
        String str = "MediaPlayer";
        String valueOf = String.valueOf(this.f5116p ? " spherical" : BuildConfig.FLAVOR);
        return valueOf.length() != 0 ? str.concat(valueOf) : new String(str);
    }

    public void m8443c() {
        vk.m14621a("AdMediaPlayerView stop");
        if (this.f5108h != null) {
            this.f5108h.stop();
            this.f5108h.release();
            this.f5108h = null;
            m8433b(0);
            m8434c(0);
        }
        this.f5104d.m8400b();
    }

    public void m8444d() {
        vk.m14621a("AdMediaPlayerView play");
        if (m8437j()) {
            this.f5108h.start();
            m8433b(3);
            this.a.m8553a();
            vo.f9130a.post(new C21657(this));
        }
        m8434c(3);
    }

    public void m8445e() {
        vk.m14621a("AdMediaPlayerView pause");
        if (m8437j() && this.f5108h.isPlaying()) {
            this.f5108h.pause();
            m8433b(4);
            vo.f9130a.post(new C21668(this));
        }
        m8434c(4);
    }

    public int getCurrentPosition() {
        return m8437j() ? this.f5108h.getCurrentPosition() : 0;
    }

    public int getDuration() {
        return m8437j() ? this.f5108h.getDuration() : -1;
    }

    public int getVideoHeight() {
        return this.f5108h != null ? this.f5108h.getVideoHeight() : 0;
    }

    public int getVideoWidth() {
        return this.f5108h != null ? this.f5108h.getVideoWidth() : 0;
    }

    public void onBufferingUpdate(MediaPlayer mediaPlayer, int i) {
        this.f5112l = i;
    }

    public void onCompletion(MediaPlayer mediaPlayer) {
        vk.m14621a("AdMediaPlayerView completion");
        m8433b(5);
        m8434c(5);
        vo.f9130a.post(new C21602(this));
    }

    public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
        String str = (String) f5103c.get(Integer.valueOf(i));
        String str2 = (String) f5103c.get(Integer.valueOf(i2));
        wg.m14620e(new StringBuilder((String.valueOf(str).length() + 38) + String.valueOf(str2).length()).append("AdMediaPlayerView MediaPlayer error: ").append(str).append(":").append(str2).toString());
        m8433b(-1);
        m8434c(-1);
        vo.f9130a.post(new C21613(this, str, str2));
        return true;
    }

    public boolean onInfo(MediaPlayer mediaPlayer, int i, int i2) {
        String str = (String) f5103c.get(Integer.valueOf(i));
        String str2 = (String) f5103c.get(Integer.valueOf(i2));
        vk.m14621a(new StringBuilder((String.valueOf(str).length() + 37) + String.valueOf(str2).length()).append("AdMediaPlayerView MediaPlayer info: ").append(str).append(":").append(str2).toString());
        return true;
    }

    protected void onMeasure(int i, int i2) {
        int defaultSize = C2168f.getDefaultSize(this.f5110j, i);
        int defaultSize2 = C2168f.getDefaultSize(this.f5111k, i2);
        if (this.f5110j > 0 && this.f5111k > 0 && this.f5115o == null) {
            int mode = MeasureSpec.getMode(i);
            int size = MeasureSpec.getSize(i);
            int mode2 = MeasureSpec.getMode(i2);
            defaultSize2 = MeasureSpec.getSize(i2);
            if (mode == 1073741824 && mode2 == 1073741824) {
                if (this.f5110j * defaultSize2 < this.f5111k * size) {
                    defaultSize = (this.f5110j * defaultSize2) / this.f5111k;
                } else if (this.f5110j * defaultSize2 > this.f5111k * size) {
                    defaultSize2 = (this.f5111k * size) / this.f5110j;
                    defaultSize = size;
                } else {
                    defaultSize = size;
                }
            } else if (mode == 1073741824) {
                defaultSize = (this.f5111k * size) / this.f5110j;
                if (mode2 != RtlSpacingHelper.UNDEFINED || defaultSize <= defaultSize2) {
                    defaultSize2 = defaultSize;
                    defaultSize = size;
                } else {
                    defaultSize = size;
                }
            } else if (mode2 == 1073741824) {
                defaultSize = (this.f5110j * defaultSize2) / this.f5111k;
                if (mode == RtlSpacingHelper.UNDEFINED && defaultSize > size) {
                    defaultSize = size;
                }
            } else {
                int i3 = this.f5110j;
                defaultSize = this.f5111k;
                if (mode2 != RtlSpacingHelper.UNDEFINED || defaultSize <= defaultSize2) {
                    defaultSize2 = defaultSize;
                    defaultSize = i3;
                } else {
                    defaultSize = (this.f5110j * defaultSize2) / this.f5111k;
                }
                if (mode == RtlSpacingHelper.UNDEFINED && r1 > size) {
                    defaultSize2 = (this.f5111k * size) / this.f5110j;
                    defaultSize = size;
                }
            }
        }
        setMeasuredDimension(defaultSize, defaultSize2);
        if (this.f5115o != null) {
            this.f5115o.m8387a(defaultSize, defaultSize2);
        }
        if (VERSION.SDK_INT == 16) {
            if ((this.f5113m > 0 && this.f5113m != defaultSize) || (this.f5114n > 0 && this.f5114n != defaultSize2)) {
                m8436i();
            }
            this.f5113m = defaultSize;
            this.f5114n = defaultSize2;
        }
    }

    public void onPrepared(MediaPlayer mediaPlayer) {
        vk.m14621a("AdMediaPlayerView prepared");
        m8433b(2);
        this.f5104d.m8398a();
        vo.f9130a.post(new C21591(this));
        this.f5110j = mediaPlayer.getVideoWidth();
        this.f5111k = mediaPlayer.getVideoHeight();
        if (this.f5117q != 0) {
            m8440a(this.f5117q);
        }
        m8436i();
        int i = this.f5110j;
        wg.m14619d("AdMediaPlayerView stream dimensions: " + i + " x " + this.f5111k);
        if (this.f5107g == 3) {
            m8444d();
        }
        m8438a();
    }

    public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i, int i2) {
        vk.m14621a("AdMediaPlayerView surface created");
        m8435h();
        vo.f9130a.post(new C21624(this));
    }

    public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
        vk.m14621a("AdMediaPlayerView surface destroyed");
        if (this.f5108h != null && this.f5117q == 0) {
            this.f5117q = this.f5108h.getCurrentPosition();
        }
        if (this.f5115o != null) {
            this.f5115o.m8389b();
        }
        vo.f9130a.post(new C21646(this));
        m8431a(true);
        return true;
    }

    public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i2) {
        Object obj = 1;
        vk.m14621a("AdMediaPlayerView surface changed");
        Object obj2 = this.f5107g == 3 ? 1 : null;
        if (!(this.f5110j == i && this.f5111k == i2)) {
            obj = null;
        }
        if (!(this.f5108h == null || obj2 == null || r1 == null)) {
            if (this.f5117q != 0) {
                m8440a(this.f5117q);
            }
            m8444d();
        }
        if (this.f5115o != null) {
            this.f5115o.m8387a(i, i2);
        }
        vo.f9130a.post(new C21635(this, i, i2));
    }

    public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
        this.f5104d.m8401b(this);
        this.a.m8554a(surfaceTexture, this.f5118r);
    }

    public void onVideoSizeChanged(MediaPlayer mediaPlayer, int i, int i2) {
        vk.m14621a("AdMediaPlayerView size changed: " + i + " x " + i2);
        this.f5110j = mediaPlayer.getVideoWidth();
        this.f5111k = mediaPlayer.getVideoHeight();
        if (this.f5110j != 0 && this.f5111k != 0) {
            requestLayout();
        }
    }

    public void setVideoPath(String str) {
        setVideoURI(Uri.parse(str));
    }

    public void setVideoURI(Uri uri) {
        jp a = jp.m12146a(uri);
        if (a != null) {
            uri = Uri.parse(a.f7316a);
        }
        this.f5109i = uri;
        this.f5117q = 0;
        m8435h();
        requestLayout();
        invalidate();
    }

    public String toString() {
        String valueOf = String.valueOf(getClass().getName());
        String valueOf2 = String.valueOf(Integer.toHexString(hashCode()));
        return new StringBuilder((String.valueOf(valueOf).length() + 1) + String.valueOf(valueOf2).length()).append(valueOf).append("@").append(valueOf2).toString();
    }
}
