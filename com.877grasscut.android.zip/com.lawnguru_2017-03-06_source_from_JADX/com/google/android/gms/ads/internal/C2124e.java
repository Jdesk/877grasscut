package com.google.android.gms.ads.internal;

import com.google.android.gms.ads.internal.overlay.C2183m;
import com.google.android.gms.ads.internal.overlay.C2188p;
import com.google.android.gms.ads.internal.overlay.C2189q;
import com.google.android.gms.ads.internal.overlay.C2195w;
import com.google.android.gms.p095b.nu;
import com.google.android.gms.p095b.oo;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.up;
import com.google.android.gms.p095b.ut;

@sc
/* renamed from: com.google.android.gms.ads.internal.e */
public class C2124e {
    public final oo f4934a;
    public final C2183m f4935b;
    public final C2188p f4936c;
    public final ut f4937d;

    public C2124e(oo ooVar, C2183m c2183m, C2188p c2188p, ut utVar) {
        this.f4934a = ooVar;
        this.f4935b = c2183m;
        this.f4936c = c2188p;
        this.f4937d = utVar;
    }

    public static C2124e m8243a() {
        return new C2124e(new nu(), new C2189q(), new C2195w(), new up());
    }
}
