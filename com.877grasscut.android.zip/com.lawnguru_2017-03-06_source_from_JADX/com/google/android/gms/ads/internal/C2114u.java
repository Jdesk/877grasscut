package com.google.android.gms.ads.internal;

/* renamed from: com.google.android.gms.ads.internal.u */
public interface C2114u {
    void m8184I();

    void m8185J();
}
