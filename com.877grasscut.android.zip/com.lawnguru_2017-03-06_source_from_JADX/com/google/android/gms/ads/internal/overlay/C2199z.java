package com.google.android.gms.ads.internal.overlay;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.view.Display;
import android.view.WindowManager;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.wg;
import net.cachapa.expandablelayout.C5541a.C5538a;

@sc
/* renamed from: com.google.android.gms.ads.internal.overlay.z */
class C2199z implements SensorEventListener {
    private final SensorManager f5180a;
    private final Object f5181b;
    private final Display f5182c;
    private final float[] f5183d;
    private final float[] f5184e;
    private float[] f5185f;
    private Handler f5186g;
    private C2153a f5187h;

    /* renamed from: com.google.android.gms.ads.internal.overlay.z.a */
    interface C2153a {
        void m8372a();
    }

    /* renamed from: com.google.android.gms.ads.internal.overlay.z.1 */
    class C21981 implements Runnable {
        C21981(C2199z c2199z) {
        }

        public void run() {
            Looper.myLooper().quit();
        }
    }

    C2199z(Context context) {
        this.f5180a = (SensorManager) context.getSystemService("sensor");
        this.f5182c = ((WindowManager) context.getSystemService("window")).getDefaultDisplay();
        this.f5183d = new float[9];
        this.f5184e = new float[9];
        this.f5181b = new Object();
    }

    private void m8555a(int i, int i2) {
        float f = this.f5184e[i];
        this.f5184e[i] = this.f5184e[i2];
        this.f5184e[i2] = f;
    }

    int m8556a() {
        return this.f5182c.getRotation();
    }

    void m8557a(C2153a c2153a) {
        this.f5187h = c2153a;
    }

    void m8558a(float[] fArr) {
        if (fArr[0] != 0.0f || fArr[1] != 0.0f || fArr[2] != 0.0f) {
            synchronized (this.f5181b) {
                if (this.f5185f == null) {
                    this.f5185f = new float[9];
                }
            }
            SensorManager.getRotationMatrixFromVector(this.f5183d, fArr);
            switch (m8556a()) {
                case C5538a.ExpandableLayout_el_duration /*1*/:
                    SensorManager.remapCoordinateSystem(this.f5183d, 2, 129, this.f5184e);
                    break;
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    SensorManager.remapCoordinateSystem(this.f5183d, 129, 130, this.f5184e);
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    SensorManager.remapCoordinateSystem(this.f5183d, 130, 1, this.f5184e);
                    break;
                default:
                    System.arraycopy(this.f5183d, 0, this.f5184e, 0, 9);
                    break;
            }
            m8555a(1, 3);
            m8555a(2, 6);
            m8555a(5, 7);
            synchronized (this.f5181b) {
                System.arraycopy(this.f5184e, 0, this.f5185f, 0, 9);
            }
            if (this.f5187h != null) {
                this.f5187h.m8372a();
            }
        }
    }

    void m8559b() {
        if (this.f5186g == null) {
            Sensor defaultSensor = this.f5180a.getDefaultSensor(11);
            if (defaultSensor == null) {
                wg.m14617c("No Sensor of TYPE_ROTATION_VECTOR");
                return;
            }
            HandlerThread handlerThread = new HandlerThread("OrientationMonitor");
            handlerThread.start();
            this.f5186g = new Handler(handlerThread.getLooper());
            if (!this.f5180a.registerListener(this, defaultSensor, 0, this.f5186g)) {
                wg.m14617c("SensorManager.registerListener failed.");
                m8561c();
            }
        }
    }

    boolean m8560b(float[] fArr) {
        boolean z = false;
        synchronized (this.f5181b) {
            if (this.f5185f == null) {
            } else {
                System.arraycopy(this.f5185f, 0, fArr, 0, this.f5185f.length);
                z = true;
            }
        }
        return z;
    }

    void m8561c() {
        if (this.f5186g != null) {
            this.f5180a.unregisterListener(this);
            this.f5186g.post(new C21981(this));
            this.f5186g = null;
        }
    }

    public void onAccuracyChanged(Sensor sensor, int i) {
    }

    public void onSensorChanged(SensorEvent sensorEvent) {
        m8558a(sensorEvent.values);
    }
}
