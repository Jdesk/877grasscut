package com.google.android.gms.ads.internal.overlay;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C3263b;
import com.google.android.gms.common.internal.safeparcel.C3263b.C3262a;
import com.google.android.gms.common.internal.safeparcel.C3264c;
import io.techery.properratingbar.C5501a.C5500d;
import net.cachapa.expandablelayout.C5541a.C5538a;

/* renamed from: com.google.android.gms.ads.internal.overlay.d */
public class C2157d implements Creator<C2158e> {
    static void m8416a(C2158e c2158e, Parcel parcel, int i) {
        int a = C3264c.m16163a(parcel);
        C3264c.m16177a(parcel, 2, c2158e.f5081a, false);
        C3264c.m16177a(parcel, 3, c2158e.f5082b, false);
        C3264c.m16177a(parcel, 4, c2158e.f5083c, false);
        C3264c.m16177a(parcel, 5, c2158e.f5084d, false);
        C3264c.m16177a(parcel, 6, c2158e.f5085e, false);
        C3264c.m16177a(parcel, 7, c2158e.f5086f, false);
        C3264c.m16177a(parcel, 8, c2158e.f5087g, false);
        C3264c.m16172a(parcel, 9, c2158e.f5088h, i, false);
        C3264c.m16164a(parcel, a);
    }

    public C2158e m8417a(Parcel parcel) {
        Intent intent = null;
        int b = C3263b.m16139b(parcel);
        String str = null;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        String str5 = null;
        String str6 = null;
        String str7 = null;
        while (parcel.dataPosition() < b) {
            int a = C3263b.m16133a(parcel);
            switch (C3263b.m16132a(a)) {
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    str7 = C3263b.m16154n(parcel, a);
                    break;
                case C5538a.ExpandableLayout_layout_expandable /*3*/:
                    str6 = C3263b.m16154n(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_clickable /*4*/:
                    str5 = C3263b.m16154n(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTick /*5*/:
                    str4 = C3263b.m16154n(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickNormalColor /*6*/:
                    str3 = C3263b.m16154n(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_symbolicTickSelectedColor /*7*/:
                    str2 = C3263b.m16154n(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickNormalDrawable /*8*/:
                    str = C3263b.m16154n(parcel, a);
                    break;
                case C5500d.ProperRatingBar_prb_tickSelectedDrawable /*9*/:
                    intent = (Intent) C3263b.m16135a(parcel, a, Intent.CREATOR);
                    break;
                default:
                    C3263b.m16140b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new C2158e(str7, str6, str5, str4, str3, str2, str, intent);
        }
        throw new C3262a("Overread allowed size end=" + b, parcel);
    }

    public C2158e[] m8418a(int i) {
        return new C2158e[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m8417a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m8418a(i);
    }
}
