package com.google.android.gms.ads.internal.overlay;

import android.annotation.TargetApi;
import android.graphics.SurfaceTexture;
import com.google.android.gms.p095b.ly;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.vo;
import java.util.concurrent.TimeUnit;

@TargetApi(14)
@sc
/* renamed from: com.google.android.gms.ads.internal.overlay.y */
public class C2197y {
    private final long f5177a;
    private long f5178b;
    private boolean f5179c;

    /* renamed from: com.google.android.gms.ads.internal.overlay.y.1 */
    class C21961 implements Runnable {
        final /* synthetic */ C2182k f5176a;

        C21961(C2197y c2197y, C2182k c2182k) {
            this.f5176a = c2182k;
        }

        public void run() {
            this.f5176a.m8510g();
        }
    }

    C2197y() {
        this.f5177a = TimeUnit.MILLISECONDS.toNanos(((Long) ly.f7566B.m12563c()).longValue());
        this.f5179c = true;
    }

    public void m8553a() {
        this.f5179c = true;
    }

    public void m8554a(SurfaceTexture surfaceTexture, C2182k c2182k) {
        if (c2182k != null) {
            long timestamp = surfaceTexture.getTimestamp();
            if (this.f5179c || Math.abs(timestamp - this.f5178b) >= this.f5177a) {
                this.f5179c = false;
                this.f5178b = timestamp;
                vo.f9130a.post(new C21961(this, c2182k));
            }
        }
    }
}
