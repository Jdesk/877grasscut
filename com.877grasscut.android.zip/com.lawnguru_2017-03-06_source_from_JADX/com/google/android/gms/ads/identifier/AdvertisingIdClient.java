package com.google.android.gms.ads.identifier;

import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Bundle;
import android.util.Log;
import com.google.android.gms.common.C3180n;
import com.google.android.gms.common.C3204l;
import com.google.android.gms.common.C3206d;
import com.google.android.gms.common.C3217h;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.internal.C3234c;
import com.google.android.gms.common.stats.C3286a;
import com.google.android.gms.p095b.im;
import com.google.android.gms.p095b.im.C2652a;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import net.cachapa.expandablelayout.C5541a.C5538a;

public class AdvertisingIdClient {
    private final Context mContext;
    C3217h zzsa;
    im zzsb;
    boolean zzsc;
    Object zzsd;
    C2096a zzse;
    final long zzsf;

    /* renamed from: com.google.android.gms.ads.identifier.AdvertisingIdClient.1 */
    class C20951 extends Thread {
        final /* synthetic */ String f4895a;

        C20951(AdvertisingIdClient advertisingIdClient, String str) {
            this.f4895a = str;
        }

        public void run() {
            new C2097a().m8088a(this.f4895a);
        }
    }

    public static final class Info {
        private final String zzsl;
        private final boolean zzsm;

        public Info(String str, boolean z) {
            this.zzsl = str;
            this.zzsm = z;
        }

        public String getId() {
            return this.zzsl;
        }

        public boolean isLimitAdTrackingEnabled() {
            return this.zzsm;
        }

        public String toString() {
            String str = this.zzsl;
            return new StringBuilder(String.valueOf(str).length() + 7).append("{").append(str).append("}").append(this.zzsm).toString();
        }
    }

    /* renamed from: com.google.android.gms.ads.identifier.AdvertisingIdClient.a */
    static class C2096a extends Thread {
        CountDownLatch f4896a;
        boolean f4897b;
        private WeakReference<AdvertisingIdClient> f4898c;
        private long f4899d;

        public C2096a(AdvertisingIdClient advertisingIdClient, long j) {
            this.f4898c = new WeakReference(advertisingIdClient);
            this.f4899d = j;
            this.f4896a = new CountDownLatch(1);
            this.f4897b = false;
            start();
        }

        private void m8085c() {
            AdvertisingIdClient advertisingIdClient = (AdvertisingIdClient) this.f4898c.get();
            if (advertisingIdClient != null) {
                advertisingIdClient.finish();
                this.f4897b = true;
            }
        }

        public void m8086a() {
            this.f4896a.countDown();
        }

        public boolean m8087b() {
            return this.f4897b;
        }

        public void run() {
            try {
                if (!this.f4896a.await(this.f4899d, TimeUnit.MILLISECONDS)) {
                    m8085c();
                }
            } catch (InterruptedException e) {
                m8085c();
            }
        }
    }

    public AdvertisingIdClient(Context context) {
        this(context, 30000, false);
    }

    public AdvertisingIdClient(Context context, long j, boolean z) {
        this.zzsd = new Object();
        C3234c.m16042a((Object) context);
        if (z) {
            Context applicationContext = context.getApplicationContext();
            if (applicationContext != null) {
                context = applicationContext;
            }
            this.mContext = context;
        } else {
            this.mContext = context;
        }
        this.zzsc = false;
        this.zzsf = j;
    }

    public static Info getAdvertisingIdInfo(Context context) {
        float f = 0.0f;
        boolean z = false;
        try {
            Context remoteContext = C3180n.getRemoteContext(context);
            if (remoteContext != null) {
                SharedPreferences sharedPreferences = remoteContext.getSharedPreferences("google_ads_flags", 1);
                z = sharedPreferences.getBoolean("gads:ad_id_app_context:enabled", false);
                f = sharedPreferences.getFloat("gads:ad_id_app_context:ping_ratio", 0.0f);
            }
        } catch (Throwable e) {
            Log.w("AdvertisingIdClient", "Error while reading from SharedPreferences ", e);
        }
        AdvertisingIdClient advertisingIdClient = new AdvertisingIdClient(context, -1, z);
        Info info;
        try {
            advertisingIdClient.zze(false);
            info = advertisingIdClient.getInfo();
            advertisingIdClient.zza(info, z, f, null);
            return info;
        } catch (Throwable th) {
            info = th;
            advertisingIdClient.zza(null, z, f, info);
            return null;
        } finally {
            advertisingIdClient.finish();
        }
    }

    public static void setShouldSkipGmsCoreVersionCheck(boolean z) {
    }

    static im zza(Context context, C3217h c3217h) {
        try {
            return C2652a.m11911a(c3217h.m16000a(10000, TimeUnit.MILLISECONDS));
        } catch (InterruptedException e) {
            throw new IOException("Interrupted exception");
        } catch (Throwable th) {
            IOException iOException = new IOException(th);
        }
    }

    private void zza(Info info, boolean z, float f, Throwable th) {
        if (Math.random() <= ((double) f)) {
            new C20951(this, zza(info, z, th).toString()).start();
        }
    }

    private void zzbw() {
        synchronized (this.zzsd) {
            if (this.zzse != null) {
                this.zzse.m8086a();
                try {
                    this.zzse.join();
                } catch (InterruptedException e) {
                }
            }
            if (this.zzsf > 0) {
                this.zzse = new C2096a(this, this.zzsf);
            }
        }
    }

    static C3217h zzf(Context context) {
        try {
            context.getPackageManager().getPackageInfo(GooglePlayServicesUtil.GOOGLE_PLAY_STORE_PACKAGE, 0);
            switch (C3204l.m15931b().m15933a(context)) {
                case C5538a.ExpandableLayout_android_orientation /*0*/:
                case C5538a.ExpandableLayout_el_expanded /*2*/:
                    ServiceConnection c3217h = new C3217h();
                    Intent intent = new Intent("com.google.android.gms.ads.identifier.service.START");
                    intent.setPackage(GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE);
                    try {
                        if (C3286a.m16282a().m16286a(context, intent, c3217h, 1)) {
                            return c3217h;
                        }
                        throw new IOException("Connection failure");
                    } catch (Throwable th) {
                        IOException iOException = new IOException(th);
                    }
                default:
                    throw new IOException("Google Play services not available");
            }
        } catch (NameNotFoundException e) {
            throw new C3206d(9);
        }
    }

    protected void finalize() {
        finish();
        super.finalize();
    }

    public void finish() {
        C3234c.m16054c("Calling this from your main thread can lead to deadlock");
        synchronized (this) {
            if (this.mContext == null || this.zzsa == null) {
                return;
            }
            try {
                if (this.zzsc) {
                    C3286a.m16282a().m16284a(this.mContext, this.zzsa);
                }
            } catch (Throwable e) {
                Log.i("AdvertisingIdClient", "AdvertisingIdClient unbindService failed.", e);
            } catch (Throwable e2) {
                Log.i("AdvertisingIdClient", "AdvertisingIdClient unbindService failed.", e2);
            }
            this.zzsc = false;
            this.zzsb = null;
            this.zzsa = null;
        }
    }

    public Info getInfo() {
        Info info;
        C3234c.m16054c("Calling this from your main thread can lead to deadlock");
        synchronized (this) {
            if (!this.zzsc) {
                synchronized (this.zzsd) {
                    if (this.zzse == null || !this.zzse.m8087b()) {
                        throw new IOException("AdvertisingIdClient is not connected.");
                    }
                }
                try {
                    zze(false);
                    if (!this.zzsc) {
                        throw new IOException("AdvertisingIdClient cannot reconnect.");
                    }
                } catch (Throwable e) {
                    Log.i("AdvertisingIdClient", "GMS remote exception ", e);
                    throw new IOException("Remote exception");
                } catch (Throwable e2) {
                    throw new IOException("AdvertisingIdClient cannot reconnect.", e2);
                }
            }
            C3234c.m16042a(this.zzsa);
            C3234c.m16042a(this.zzsb);
            info = new Info(this.zzsb.m11903a(), this.zzsb.m11906a(true));
        }
        zzbw();
        return info;
    }

    public void start() {
        zze(true);
    }

    Uri zza(Info info, boolean z, Throwable th) {
        Bundle bundle = new Bundle();
        bundle.putString("app_context", z ? "1" : "0");
        if (info != null) {
            bundle.putString("limit_ad_tracking", info.isLimitAdTrackingEnabled() ? "1" : "0");
        }
        if (!(info == null || info.getId() == null)) {
            bundle.putString("ad_id_size", Integer.toString(info.getId().length()));
        }
        if (th != null) {
            bundle.putString("error", th.getClass().getName());
        }
        Builder buildUpon = Uri.parse("https://pagead2.googlesyndication.com/pagead/gen_204?id=gmob-apps").buildUpon();
        for (String str : bundle.keySet()) {
            buildUpon.appendQueryParameter(str, bundle.getString(str));
        }
        return buildUpon.build();
    }

    protected void zze(boolean z) {
        C3234c.m16054c("Calling this from your main thread can lead to deadlock");
        synchronized (this) {
            if (this.zzsc) {
                finish();
            }
            this.zzsa = zzf(this.mContext);
            this.zzsb = zza(this.mContext, this.zzsa);
            this.zzsc = true;
            if (z) {
                zzbw();
            }
        }
    }
}
