package com.google.android.gms.ads;

import android.content.Context;
import android.support.v7.widget.ListPopupWindow;
import android.support.v7.widget.helper.ItemTouchHelper.Callback;
import com.google.android.gms.p095b.ke;
import com.google.android.gms.p095b.kj;

/* renamed from: com.google.android.gms.ads.d */
public final class C2088d {
    public static final C2088d f4876a;
    public static final C2088d f4877b;
    public static final C2088d f4878c;
    public static final C2088d f4879d;
    public static final C2088d f4880e;
    public static final C2088d f4881f;
    public static final C2088d f4882g;
    public static final C2088d f4883h;
    public static final C2088d f4884i;
    public static final C2088d f4885j;
    private final int f4886k;
    private final int f4887l;
    private final String f4888m;

    static {
        f4876a = new C2088d(320, 50, "320x50_mb");
        f4877b = new C2088d(468, 60, "468x60_as");
        f4878c = new C2088d(320, 100, "320x100_as");
        f4879d = new C2088d(728, 90, "728x90_as");
        f4880e = new C2088d(300, Callback.DEFAULT_SWIPE_ANIMATION_DURATION, "300x250_as");
        f4881f = new C2088d(160, 600, "160x600_as");
        f4882g = new C2088d(-1, -2, "smart_banner");
        f4883h = new C2088d(-3, -4, "fluid");
        f4884i = new C2088d(50, 50, "50x50_mb");
        f4885j = new C2088d(-3, 0, "search_v2");
    }

    public C2088d(int i, int i2) {
        String valueOf = i == -1 ? "FULL" : String.valueOf(i);
        String valueOf2 = i2 == -2 ? "AUTO" : String.valueOf(i2);
        String valueOf3 = String.valueOf("_as");
        this(i, i2, new StringBuilder(((String.valueOf(valueOf).length() + 1) + String.valueOf(valueOf2).length()) + String.valueOf(valueOf3).length()).append(valueOf).append("x").append(valueOf2).append(valueOf3).toString());
    }

    C2088d(int i, int i2, String str) {
        if (i < 0 && i != -1 && i != -3) {
            throw new IllegalArgumentException("Invalid width for AdSize: " + i);
        } else if (i2 >= 0 || i2 == -2 || i2 == -4) {
            this.f4886k = i;
            this.f4887l = i2;
            this.f4888m = str;
        } else {
            throw new IllegalArgumentException("Invalid height for AdSize: " + i2);
        }
    }

    public int m8061a() {
        return this.f4887l;
    }

    public int m8062a(Context context) {
        switch (this.f4887l) {
            case -4:
            case -3:
                return -1;
            case ListPopupWindow.WRAP_CONTENT /*-2*/:
                return ke.m12235b(context.getResources().getDisplayMetrics());
            default:
                return kj.m12293a().m14895a(context, this.f4887l);
        }
    }

    public int m8063b() {
        return this.f4886k;
    }

    public int m8064b(Context context) {
        switch (this.f4886k) {
            case -4:
            case -3:
                return -1;
            case ErrorResponse.NON_HTTP_ERROR /*-1*/:
                return ke.m12232a(context.getResources().getDisplayMetrics());
            default:
                return kj.m12293a().m14895a(context, this.f4886k);
        }
    }

    public boolean m8065c() {
        return this.f4886k == -3 && this.f4887l == -4;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C2088d)) {
            return false;
        }
        C2088d c2088d = (C2088d) obj;
        return this.f4886k == c2088d.f4886k && this.f4887l == c2088d.f4887l && this.f4888m.equals(c2088d.f4888m);
    }

    public int hashCode() {
        return this.f4888m.hashCode();
    }

    public String toString() {
        return this.f4888m;
    }
}
