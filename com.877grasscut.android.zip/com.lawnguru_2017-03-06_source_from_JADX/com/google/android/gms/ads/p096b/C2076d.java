package com.google.android.gms.ads.p096b;

import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;
import com.google.android.gms.p095b.nd;
import com.google.android.gms.p095b.wg;
import com.google.android.gms.p097a.C2046a;
import com.google.android.gms.p097a.C2060d;

/* renamed from: com.google.android.gms.ads.b.d */
public abstract class C2076d extends FrameLayout {
    private final FrameLayout f4854a;
    private final nd f4855b;

    protected View m8005a(String str) {
        try {
            C2046a a = this.f4855b.m12896a(str);
            if (a != null) {
                return (View) C2060d.m7974a(a);
            }
        } catch (Throwable e) {
            wg.m14616b("Unable to call getAssetView on delegate", e);
        }
        return null;
    }

    protected void m8006a(String str, View view) {
        try {
            this.f4855b.m12899a(str, C2060d.m7973a((Object) view));
        } catch (Throwable e) {
            wg.m14616b("Unable to call setAssetView on delegate", e);
        }
    }

    public void addView(View view, int i, LayoutParams layoutParams) {
        super.addView(view, i, layoutParams);
        super.bringChildToFront(this.f4854a);
    }

    public void bringChildToFront(View view) {
        super.bringChildToFront(view);
        if (this.f4854a != view) {
            super.bringChildToFront(this.f4854a);
        }
    }

    public C2070a getAdChoicesView() {
        View a = m8005a("1098");
        return a instanceof C2070a ? (C2070a) a : null;
    }

    public void onVisibilityChanged(View view, int i) {
        super.onVisibilityChanged(view, i);
        if (this.f4855b != null) {
            try {
                this.f4855b.m12898a(C2060d.m7973a((Object) view), i);
            } catch (Throwable e) {
                wg.m14616b("Unable to call onVisibilityChanged on delegate", e);
            }
        }
    }

    public void removeAllViews() {
        super.removeAllViews();
        super.addView(this.f4854a);
    }

    public void removeView(View view) {
        if (this.f4854a != view) {
            super.removeView(view);
        }
    }

    public void setAdChoicesView(C2070a c2070a) {
        m8006a("1098", c2070a);
    }

    public void setNativeAd(C2072b c2072b) {
        try {
            this.f4855b.m12897a((C2046a) c2072b.m7988a());
        } catch (Throwable e) {
            wg.m14616b("Unable to call setNativeAd on delegate", e);
        }
    }
}
