package com.google.android.gms.ads.p096b;

import com.google.android.gms.ads.C2094i;
import com.google.android.gms.ads.p096b.C2072b.C2071a;
import java.util.List;

/* renamed from: com.google.android.gms.ads.b.f */
public abstract class C2078f extends C2072b {

    /* renamed from: com.google.android.gms.ads.b.f.a */
    public interface C2023a {
        void m7889a(C2078f c2078f);
    }

    public abstract CharSequence m8016b();

    public abstract List<C2071a> m8017c();

    public abstract CharSequence m8018d();

    public abstract C2071a m8019e();

    public abstract CharSequence m8020f();

    public abstract CharSequence m8021g();

    public abstract C2094i m8022h();
}
