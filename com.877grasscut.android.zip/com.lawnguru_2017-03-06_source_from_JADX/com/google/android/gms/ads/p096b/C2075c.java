package com.google.android.gms.ads.p096b;

import com.google.android.gms.ads.C2248j;
import com.google.android.gms.p095b.sc;

@sc
/* renamed from: com.google.android.gms.ads.b.c */
public final class C2075c {
    private final boolean f4849a;
    private final int f4850b;
    private final boolean f4851c;
    private final int f4852d;
    private final C2248j f4853e;

    /* renamed from: com.google.android.gms.ads.b.c.a */
    public static final class C2074a {
        private boolean f4844a;
        private int f4845b;
        private boolean f4846c;
        private C2248j f4847d;
        private int f4848e;

        public C2074a() {
            this.f4844a = false;
            this.f4845b = 0;
            this.f4846c = false;
            this.f4848e = 1;
        }

        public C2074a m7994a(int i) {
            this.f4845b = i;
            return this;
        }

        public C2074a m7995a(C2248j c2248j) {
            this.f4847d = c2248j;
            return this;
        }

        public C2074a m7996a(boolean z) {
            this.f4844a = z;
            return this;
        }

        public C2075c m7997a() {
            return new C2075c();
        }

        public C2074a m7998b(int i) {
            this.f4848e = i;
            return this;
        }

        public C2074a m7999b(boolean z) {
            this.f4846c = z;
            return this;
        }
    }

    private C2075c(C2074a c2074a) {
        this.f4849a = c2074a.f4844a;
        this.f4850b = c2074a.f4845b;
        this.f4851c = c2074a.f4846c;
        this.f4852d = c2074a.f4848e;
        this.f4853e = c2074a.f4847d;
    }

    public boolean m8000a() {
        return this.f4849a;
    }

    public int m8001b() {
        return this.f4850b;
    }

    public boolean m8002c() {
        return this.f4851c;
    }

    public int m8003d() {
        return this.f4852d;
    }

    public C2248j m8004e() {
        return this.f4853e;
    }
}
