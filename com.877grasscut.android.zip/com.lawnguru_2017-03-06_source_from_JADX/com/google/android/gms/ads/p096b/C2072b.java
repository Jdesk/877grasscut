package com.google.android.gms.ads.p096b;

import android.graphics.drawable.Drawable;
import android.net.Uri;

/* renamed from: com.google.android.gms.ads.b.b */
public abstract class C2072b {

    /* renamed from: com.google.android.gms.ads.b.b.a */
    public static abstract class C2071a {
        public abstract Drawable m7985a();

        public abstract Uri m7986b();

        public abstract double m7987c();
    }

    protected abstract Object m7988a();
}
