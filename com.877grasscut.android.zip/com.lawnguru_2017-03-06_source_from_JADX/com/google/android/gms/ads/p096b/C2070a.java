package com.google.android.gms.ads.p096b;

import android.content.Context;
import android.widget.RelativeLayout;

/* renamed from: com.google.android.gms.ads.b.a */
public class C2070a extends RelativeLayout {
    public C2070a(Context context) {
        super(context);
    }
}
