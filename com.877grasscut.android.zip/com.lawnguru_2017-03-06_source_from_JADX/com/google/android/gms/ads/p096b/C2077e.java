package com.google.android.gms.ads.p096b;

import com.google.android.gms.ads.C2094i;
import com.google.android.gms.ads.p096b.C2072b.C2071a;
import java.util.List;

/* renamed from: com.google.android.gms.ads.b.e */
public abstract class C2077e extends C2072b {

    /* renamed from: com.google.android.gms.ads.b.e.a */
    public interface C2022a {
        void m7888a(C2077e c2077e);
    }

    public abstract CharSequence m8007b();

    public abstract List<C2071a> m8008c();

    public abstract CharSequence m8009d();

    public abstract C2071a m8010e();

    public abstract CharSequence m8011f();

    public abstract Double m8012g();

    public abstract CharSequence m8013h();

    public abstract CharSequence m8014i();

    public abstract C2094i m8015j();
}
