package com.google.android.gms.ads;

/* renamed from: com.google.android.gms.ads.k */
public final class C2249k {
    public static C2088d m8830a(int i, int i2, String str) {
        return new C2088d(i, i2, str);
    }
}
