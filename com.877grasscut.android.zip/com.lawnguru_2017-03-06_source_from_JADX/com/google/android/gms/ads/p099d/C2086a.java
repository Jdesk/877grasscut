package com.google.android.gms.ads.p099d;

/* renamed from: com.google.android.gms.ads.d.a */
public final class C2086a {
    private final int f4861a;
    private final int f4862b;
    private final int f4863c;
    private final int f4864d;
    private final int f4865e;
    private final int f4866f;
    private final int f4867g;
    private final int f4868h;
    private final String f4869i;
    private final int f4870j;
    private final String f4871k;
    private final int f4872l;
    private final int f4873m;
    private final String f4874n;

    public int m8047a() {
        return this.f4861a;
    }

    public int m8048b() {
        return this.f4862b;
    }

    public int m8049c() {
        return this.f4863c;
    }

    public int m8050d() {
        return this.f4864d;
    }

    public int m8051e() {
        return this.f4865e;
    }

    public int m8052f() {
        return this.f4866f;
    }

    public int m8053g() {
        return this.f4867g;
    }

    public int m8054h() {
        return this.f4868h;
    }

    public String m8055i() {
        return this.f4869i;
    }

    public int m8056j() {
        return this.f4870j;
    }

    public String m8057k() {
        return this.f4871k;
    }

    public int m8058l() {
        return this.f4872l;
    }

    public int m8059m() {
        return this.f4873m;
    }

    public String m8060n() {
        return this.f4874n;
    }
}
