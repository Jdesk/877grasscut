package com.google.android.gms.ads.p099d;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.ads.C2019a;
import com.google.android.gms.ads.C2088d;
import com.google.android.gms.p095b.le;
import com.google.android.gms.p095b.sc;
import com.google.android.gms.p095b.wg;

@sc
/* renamed from: com.google.android.gms.ads.d.b */
public final class C2087b extends ViewGroup {
    private final le f4875a;

    public C2019a getAdListener() {
        return this.f4875a.m12468b();
    }

    public C2088d getAdSize() {
        return this.f4875a.m12470c();
    }

    public String getAdUnitId() {
        return this.f4875a.m12472e();
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        View childAt = getChildAt(0);
        if (childAt != null && childAt.getVisibility() != 8) {
            int measuredWidth = childAt.getMeasuredWidth();
            int measuredHeight = childAt.getMeasuredHeight();
            int i5 = ((i3 - i) - measuredWidth) / 2;
            int i6 = ((i4 - i2) - measuredHeight) / 2;
            childAt.layout(i5, i6, measuredWidth + i5, measuredHeight + i6);
        }
    }

    protected void onMeasure(int i, int i2) {
        int b;
        int i3 = 0;
        View childAt = getChildAt(0);
        if (childAt == null || childAt.getVisibility() == 8) {
            C2088d adSize;
            C2088d c2088d = null;
            try {
                adSize = getAdSize();
            } catch (Throwable e) {
                wg.m14616b("Unable to retrieve ad size.", e);
                adSize = c2088d;
            }
            if (adSize != null) {
                Context context = getContext();
                b = adSize.m8064b(context);
                i3 = adSize.m8062a(context);
            } else {
                b = 0;
            }
        } else {
            measureChild(childAt, i, i2);
            b = childAt.getMeasuredWidth();
            i3 = childAt.getMeasuredHeight();
        }
        setMeasuredDimension(View.resolveSize(Math.max(b, getSuggestedMinimumWidth()), i), View.resolveSize(Math.max(i3, getSuggestedMinimumHeight()), i2));
    }

    public void setAdListener(C2019a c2019a) {
        this.f4875a.m12458a(c2019a);
    }

    public void setAdSize(C2088d c2088d) {
        this.f4875a.m12466a(c2088d);
    }

    public void setAdUnitId(String str) {
        this.f4875a.m12464a(str);
    }
}
