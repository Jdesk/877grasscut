package com.google.android.gms.ads;

import android.content.Context;
import com.google.android.gms.ads.purchase.C2269b;

/* renamed from: com.google.android.gms.ads.e */
public final class C2090e extends C2089f {
    public C2090e(Context context) {
        super(context, 0);
    }

    public /* bridge */ /* synthetic */ void m8070a() {
        super.m8066a();
    }

    public /* bridge */ /* synthetic */ void m8071a(C2085c c2085c) {
        super.m8067a(c2085c);
    }

    public /* bridge */ /* synthetic */ void m8072b() {
        super.m8068b();
    }

    public /* bridge */ /* synthetic */ void m8073c() {
        super.m8069c();
    }

    public /* bridge */ /* synthetic */ C2019a getAdListener() {
        return super.getAdListener();
    }

    public /* bridge */ /* synthetic */ C2088d getAdSize() {
        return super.getAdSize();
    }

    public /* bridge */ /* synthetic */ String getAdUnitId() {
        return super.getAdUnitId();
    }

    public /* bridge */ /* synthetic */ C2269b getInAppPurchaseListener() {
        return super.getInAppPurchaseListener();
    }

    public /* bridge */ /* synthetic */ String getMediationAdapterClassName() {
        return super.getMediationAdapterClassName();
    }

    public /* bridge */ /* synthetic */ void setAdListener(C2019a c2019a) {
        super.setAdListener(c2019a);
    }

    public /* bridge */ /* synthetic */ void setAdSize(C2088d c2088d) {
        super.setAdSize(c2088d);
    }

    public /* bridge */ /* synthetic */ void setAdUnitId(String str) {
        super.setAdUnitId(str);
    }

    public /* bridge */ /* synthetic */ void setInAppPurchaseListener(C2269b c2269b) {
        super.setInAppPurchaseListener(c2269b);
    }
}
