package com.google.android.gms.ads;

import com.google.android.gms.p095b.sc;

@sc
/* renamed from: com.google.android.gms.ads.j */
public final class C2248j {
    private final boolean f5373a;

    /* renamed from: com.google.android.gms.ads.j.a */
    public static final class C2247a {
        private boolean f5372a;

        public C2247a() {
            this.f5372a = false;
        }

        public C2247a m8827a(boolean z) {
            this.f5372a = z;
            return this;
        }

        public C2248j m8828a() {
            return new C2248j();
        }
    }

    private C2248j(C2247a c2247a) {
        this.f5373a = c2247a.f5372a;
    }

    public boolean m8829a() {
        return this.f5373a;
    }
}
