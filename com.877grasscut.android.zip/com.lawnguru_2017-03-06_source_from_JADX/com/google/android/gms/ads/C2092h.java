package com.google.android.gms.ads;

import android.content.Context;
import com.google.android.gms.ads.p093c.C2012b;
import com.google.android.gms.p095b.ju;
import com.google.android.gms.p095b.lf;

/* renamed from: com.google.android.gms.ads.h */
public final class C2092h {
    private final lf f4891a;

    public C2092h(Context context) {
        this.f4891a = new lf(context);
    }

    public void m8075a() {
        this.f4891a.m12486a();
    }

    public void m8076a(C2019a c2019a) {
        this.f4891a.m12487a(c2019a);
        if (c2019a != null && (c2019a instanceof ju)) {
            this.f4891a.m12489a((ju) c2019a);
        } else if (c2019a == null) {
            this.f4891a.m12489a(null);
        }
    }

    public void m8077a(C2012b c2012b) {
        this.f4891a.m12488a(c2012b);
    }

    public void m8078a(C2085c c2085c) {
        this.f4891a.m12490a(c2085c.m8046a());
    }

    public void m8079a(String str) {
        this.f4891a.m12491a(str);
    }

    public void m8080a(boolean z) {
        this.f4891a.m12492a(z);
    }
}
