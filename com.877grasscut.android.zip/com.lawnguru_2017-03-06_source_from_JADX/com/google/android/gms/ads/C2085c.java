package com.google.android.gms.ads;

import android.location.Location;
import android.os.Bundle;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.mediation.C2006b;
import com.google.android.gms.p095b.ld;
import com.google.android.gms.p095b.ld.C2737a;
import java.util.Date;

/* renamed from: com.google.android.gms.ads.c */
public final class C2085c {
    private final ld f4860a;

    /* renamed from: com.google.android.gms.ads.c.a */
    public static final class C2081a {
        private final C2737a f4859a;

        public C2081a() {
            this.f4859a = new C2737a();
            this.f4859a.m12428b("B3EEABB8EE11C2BE770B684D95219ECB");
        }

        public C2081a m8026a(int i) {
            this.f4859a.m12422a(i);
            return this;
        }

        public C2081a m8027a(Location location) {
            this.f4859a.m12423a(location);
            return this;
        }

        public C2081a m8028a(Class<? extends C2006b> cls, Bundle bundle) {
            this.f4859a.m12424a(cls, bundle);
            if (cls.equals(AdMobAdapter.class) && bundle.getBoolean("_emulatorLiveAds")) {
                this.f4859a.m12430c("B3EEABB8EE11C2BE770B684D95219ECB");
            }
            return this;
        }

        public C2081a m8029a(String str) {
            this.f4859a.m12425a(str);
            return this;
        }

        public C2081a m8030a(Date date) {
            this.f4859a.m12426a(date);
            return this;
        }

        public C2081a m8031a(boolean z) {
            this.f4859a.m12427a(z);
            return this;
        }

        public C2085c m8032a() {
            return new C2085c();
        }

        public C2081a m8033b(String str) {
            this.f4859a.m12428b(str);
            return this;
        }

        public C2081a m8034b(boolean z) {
            this.f4859a.m12429b(z);
            return this;
        }
    }

    private C2085c(C2081a c2081a) {
        this.f4860a = new ld(c2081a.f4859a);
    }

    public ld m8046a() {
        return this.f4860a;
    }
}
