package com.google.android.gms.ads.p098a;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.ads.C2019a;
import com.google.android.gms.ads.C2088d;
import com.google.android.gms.ads.C2091g;
import com.google.android.gms.ads.C2094i;
import com.google.android.gms.ads.C2248j;
import com.google.android.gms.p095b.le;
import com.google.android.gms.p095b.wg;

/* renamed from: com.google.android.gms.ads.a.d */
public final class C2067d extends ViewGroup {
    private final le f4841a;

    public C2019a getAdListener() {
        return this.f4841a.m12468b();
    }

    public C2088d getAdSize() {
        return this.f4841a.m12470c();
    }

    public C2088d[] getAdSizes() {
        return this.f4841a.m12471d();
    }

    public String getAdUnitId() {
        return this.f4841a.m12472e();
    }

    public C2064a getAppEventListener() {
        return this.f4841a.m12473f();
    }

    public String getMediationAdapterClassName() {
        return this.f4841a.m12478k();
    }

    public C2066c getOnCustomRenderedAdLoadedListener() {
        return this.f4841a.m12475h();
    }

    public C2094i getVideoController() {
        return this.f4841a.m12479l();
    }

    public C2248j getVideoOptions() {
        return this.f4841a.m12481n();
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        View childAt = getChildAt(0);
        if (childAt != null && childAt.getVisibility() != 8) {
            int measuredWidth = childAt.getMeasuredWidth();
            int measuredHeight = childAt.getMeasuredHeight();
            int i5 = ((i3 - i) - measuredWidth) / 2;
            int i6 = ((i4 - i2) - measuredHeight) / 2;
            childAt.layout(i5, i6, measuredWidth + i5, measuredHeight + i6);
        }
    }

    protected void onMeasure(int i, int i2) {
        int b;
        int i3 = 0;
        View childAt = getChildAt(0);
        if (childAt == null || childAt.getVisibility() == 8) {
            C2088d adSize;
            C2088d c2088d = null;
            try {
                adSize = getAdSize();
            } catch (Throwable e) {
                wg.m14616b("Unable to retrieve ad size.", e);
                adSize = c2088d;
            }
            if (adSize != null) {
                Context context = getContext();
                b = adSize.m8064b(context);
                i3 = adSize.m8062a(context);
            } else {
                b = 0;
            }
        } else {
            measureChild(childAt, i, i2);
            b = childAt.getMeasuredWidth();
            i3 = childAt.getMeasuredHeight();
        }
        setMeasuredDimension(View.resolveSize(Math.max(b, getSuggestedMinimumWidth()), i), View.resolveSize(Math.max(i3, getSuggestedMinimumHeight()), i2));
    }

    public void setAdListener(C2019a c2019a) {
        this.f4841a.m12458a(c2019a);
    }

    public void setAdSizes(C2088d... c2088dArr) {
        if (c2088dArr == null || c2088dArr.length < 1) {
            throw new IllegalArgumentException("The supported ad sizes must contain at least one valid ad size.");
        }
        this.f4841a.m12469b(c2088dArr);
    }

    public void setAdUnitId(String str) {
        this.f4841a.m12464a(str);
    }

    public void setAppEventListener(C2064a c2064a) {
        this.f4841a.m12456a(c2064a);
    }

    public void setCorrelator(C2091g c2091g) {
        this.f4841a.m12459a(c2091g);
    }

    public void setManualImpressionsEnabled(boolean z) {
        this.f4841a.m12465a(z);
    }

    public void setOnCustomRenderedAdLoadedListener(C2066c c2066c) {
        this.f4841a.m12457a(c2066c);
    }

    public void setVideoOptions(C2248j c2248j) {
        this.f4841a.m12460a(c2248j);
    }
}
