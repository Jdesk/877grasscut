package com.google.android.gms.ads.p098a;

/* renamed from: com.google.android.gms.ads.a.c */
public interface C2066c {
    void m7979a(C2065b c2065b);
}
