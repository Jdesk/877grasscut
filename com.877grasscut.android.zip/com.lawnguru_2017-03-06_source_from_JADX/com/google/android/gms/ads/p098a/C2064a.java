package com.google.android.gms.ads.p098a;

/* renamed from: com.google.android.gms.ads.a.a */
public interface C2064a {
    void m7978a(String str, String str2);
}
