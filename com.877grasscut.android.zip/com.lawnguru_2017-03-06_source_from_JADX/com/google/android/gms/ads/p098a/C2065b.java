package com.google.android.gms.ads.p098a;

/* renamed from: com.google.android.gms.ads.a.b */
public interface C2065b {
}
