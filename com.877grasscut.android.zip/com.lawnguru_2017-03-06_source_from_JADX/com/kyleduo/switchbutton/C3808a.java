package com.kyleduo.switchbutton;

import android.content.res.ColorStateList;

/* renamed from: com.kyleduo.switchbutton.a */
public class C3808a {
    public static ColorStateList m18670a(int i) {
        r0 = new int[6][];
        r0[1] = new int[]{-16842910};
        r0[2] = new int[]{16842919, -16842912};
        r0[3] = new int[]{16842919, 16842912};
        r0[4] = new int[]{16842912};
        r0[5] = new int[]{-16842912};
        return new ColorStateList(r0, new int[]{i - -1442840576, -4539718, i - -1728053248, i - -1728053248, -16777216 | i, -1118482});
    }

    public static ColorStateList m18671b(int i) {
        r0 = new int[6][];
        r0[1] = new int[]{-16842910};
        r0[2] = new int[]{16842912, 16842919};
        r0[3] = new int[]{-16842912, 16842919};
        r0[4] = new int[]{16842912};
        r0[5] = new int[]{-16842912};
        return new ColorStateList(r0, new int[]{i - -520093696, 268435456, i - -805306368, 536870912, i - -805306368, 536870912});
    }
}
