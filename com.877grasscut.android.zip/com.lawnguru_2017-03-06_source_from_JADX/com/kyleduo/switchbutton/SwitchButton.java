package com.kyleduo.switchbutton;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.content.C0267b;
import android.text.Layout;
import android.text.Layout.Alignment;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View.BaseSavedState;
import android.view.View.MeasureSpec;
import android.view.ViewParent;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import net.cachapa.expandablelayout.C5541a.C5538a;

public class SwitchButton extends CompoundButton {
    private static int[] f10946a;
    private static int[] f10947b;
    private Paint f10948A;
    private boolean f10949B;
    private boolean f10950C;
    private boolean f10951D;
    private ObjectAnimator f10952E;
    private float f10953F;
    private RectF f10954G;
    private float f10955H;
    private float f10956I;
    private float f10957J;
    private int f10958K;
    private int f10959L;
    private Paint f10960M;
    private CharSequence f10961N;
    private CharSequence f10962O;
    private TextPaint f10963P;
    private Layout f10964Q;
    private Layout f10965R;
    private float f10966S;
    private float f10967T;
    private float f10968U;
    private OnCheckedChangeListener f10969V;
    private Drawable f10970c;
    private Drawable f10971d;
    private ColorStateList f10972e;
    private ColorStateList f10973f;
    private float f10974g;
    private float f10975h;
    private RectF f10976i;
    private float f10977j;
    private long f10978k;
    private boolean f10979l;
    private int f10980m;
    private PointF f10981n;
    private int f10982o;
    private int f10983p;
    private int f10984q;
    private int f10985r;
    private int f10986s;
    private Drawable f10987t;
    private Drawable f10988u;
    private RectF f10989v;
    private RectF f10990w;
    private RectF f10991x;
    private RectF f10992y;
    private RectF f10993z;

    /* renamed from: com.kyleduo.switchbutton.SwitchButton.a */
    static class C3807a extends BaseSavedState {
        public static final Creator<C3807a> CREATOR;
        CharSequence f10944a;
        CharSequence f10945b;

        /* renamed from: com.kyleduo.switchbutton.SwitchButton.a.1 */
        static class C38061 implements Creator<C3807a> {
            C38061() {
            }

            public /* synthetic */ Object createFromParcel(Parcel parcel) {
                return m18657a(parcel);
            }

            public /* synthetic */ Object[] newArray(int i) {
                return m18658a(i);
            }

            public C3807a m18657a(Parcel parcel) {
                return new C3807a(null);
            }

            public C3807a[] m18658a(int i) {
                return new C3807a[i];
            }
        }

        C3807a(Parcelable parcelable) {
            super(parcelable);
        }

        private C3807a(Parcel parcel) {
            super(parcel);
            this.f10944a = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.f10945b = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            TextUtils.writeToParcel(this.f10944a, parcel, i);
            TextUtils.writeToParcel(this.f10945b, parcel, i);
        }

        static {
            CREATOR = new C38061();
        }
    }

    static {
        f10946a = new int[]{16842912, 16842910, 16842919};
        f10947b = new int[]{-16842912, 16842910, 16842919};
    }

    public SwitchButton(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f10951D = false;
        m18663a(attributeSet);
    }

    public SwitchButton(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f10951D = false;
        m18663a(attributeSet);
    }

    public SwitchButton(Context context) {
        super(context);
        this.f10951D = false;
        m18663a(null);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m18663a(android.util.AttributeSet r27) {
        /*
        r26 = this;
        r4 = r26.getContext();
        r4 = android.view.ViewConfiguration.get(r4);
        r4 = r4.getScaledTouchSlop();
        r0 = r26;
        r0.f10958K = r4;
        r4 = android.view.ViewConfiguration.getPressedStateDuration();
        r5 = android.view.ViewConfiguration.getTapTimeout();
        r4 = r4 + r5;
        r0 = r26;
        r0.f10959L = r4;
        r4 = new android.graphics.Paint;
        r5 = 1;
        r4.<init>(r5);
        r0 = r26;
        r0.f10948A = r4;
        r4 = new android.graphics.Paint;
        r5 = 1;
        r4.<init>(r5);
        r0 = r26;
        r0.f10960M = r4;
        r0 = r26;
        r4 = r0.f10960M;
        r5 = android.graphics.Paint.Style.STROKE;
        r4.setStyle(r5);
        r0 = r26;
        r4 = r0.f10960M;
        r5 = r26.getResources();
        r5 = r5.getDisplayMetrics();
        r5 = r5.density;
        r4.setStrokeWidth(r5);
        r4 = r26.getPaint();
        r0 = r26;
        r0.f10963P = r4;
        r4 = new android.graphics.RectF;
        r4.<init>();
        r0 = r26;
        r0.f10989v = r4;
        r4 = new android.graphics.RectF;
        r4.<init>();
        r0 = r26;
        r0.f10990w = r4;
        r4 = new android.graphics.RectF;
        r4.<init>();
        r0 = r26;
        r0.f10991x = r4;
        r4 = new android.graphics.PointF;
        r4.<init>();
        r0 = r26;
        r0.f10981n = r4;
        r4 = new android.graphics.RectF;
        r4.<init>();
        r0 = r26;
        r0.f10976i = r4;
        r4 = new android.graphics.RectF;
        r4.<init>();
        r0 = r26;
        r0.f10992y = r4;
        r4 = new android.graphics.RectF;
        r4.<init>();
        r0 = r26;
        r0.f10993z = r4;
        r4 = "process";
        r5 = 2;
        r5 = new float[r5];
        r5 = {0, 0};
        r0 = r26;
        r4 = android.animation.ObjectAnimator.ofFloat(r0, r4, r5);
        r6 = 250; // 0xfa float:3.5E-43 double:1.235E-321;
        r4 = r4.setDuration(r6);
        r0 = r26;
        r0.f10952E = r4;
        r0 = r26;
        r4 = r0.f10952E;
        r5 = new android.view.animation.AccelerateDecelerateInterpolator;
        r5.<init>();
        r4.setInterpolator(r5);
        r4 = new android.graphics.RectF;
        r4.<init>();
        r0 = r26;
        r0.f10954G = r4;
        r4 = r26.getResources();
        r4 = r4.getDisplayMetrics();
        r0 = r4.density;
        r24 = r0;
        r21 = 0;
        r20 = 0;
        r4 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r25 = r24 * r4;
        r19 = 0;
        r18 = 0;
        r17 = 0;
        r16 = 0;
        r4 = 1101004800; // 0x41a00000 float:20.0 double:5.439686476E-315;
        r15 = r24 * r4;
        r4 = 1101004800; // 0x41a00000 float:20.0 double:5.439686476E-315;
        r14 = r24 * r4;
        r4 = 1101004800; // 0x41a00000 float:20.0 double:5.439686476E-315;
        r4 = r4 * r24;
        r5 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r13 = r4 / r5;
        r12 = 0;
        r11 = 0;
        r10 = 1072064102; // 0x3fe66666 float:1.8 double:5.29670043E-315;
        r9 = 250; // 0xfa float:3.5E-43 double:1.235E-321;
        r8 = 1;
        r7 = 0;
        r6 = 0;
        r5 = 0;
        r4 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r4 = r4 * r24;
        if (r27 != 0) goto L_0x0332;
    L_0x00fc:
        r22 = 0;
        r23 = r22;
    L_0x0100:
        if (r23 == 0) goto L_0x0374;
    L_0x0102:
        r5 = com.kyleduo.switchbutton.C3811b.C3810b.SwitchButton_kswThumbDrawable;
        r0 = r23;
        r22 = r0.getDrawable(r5);
        r5 = com.kyleduo.switchbutton.C3811b.C3810b.SwitchButton_kswThumbColor;
        r0 = r23;
        r21 = r0.getColorStateList(r5);
        r5 = com.kyleduo.switchbutton.C3811b.C3810b.SwitchButton_kswThumbMargin;
        r0 = r23;
        r1 = r25;
        r5 = r0.getDimension(r5, r1);
        r6 = com.kyleduo.switchbutton.C3811b.C3810b.SwitchButton_kswThumbMarginLeft;
        r0 = r23;
        r20 = r0.getDimension(r6, r5);
        r6 = com.kyleduo.switchbutton.C3811b.C3810b.SwitchButton_kswThumbMarginRight;
        r0 = r23;
        r19 = r0.getDimension(r6, r5);
        r6 = com.kyleduo.switchbutton.C3811b.C3810b.SwitchButton_kswThumbMarginTop;
        r0 = r23;
        r18 = r0.getDimension(r6, r5);
        r6 = com.kyleduo.switchbutton.C3811b.C3810b.SwitchButton_kswThumbMarginBottom;
        r0 = r23;
        r17 = r0.getDimension(r6, r5);
        r5 = com.kyleduo.switchbutton.C3811b.C3810b.SwitchButton_kswThumbWidth;
        r0 = r23;
        r16 = r0.getDimension(r5, r15);
        r5 = com.kyleduo.switchbutton.C3811b.C3810b.SwitchButton_kswThumbHeight;
        r0 = r23;
        r15 = r0.getDimension(r5, r14);
        r5 = com.kyleduo.switchbutton.C3811b.C3810b.SwitchButton_kswThumbRadius;
        r0 = r16;
        r6 = java.lang.Math.min(r0, r15);
        r8 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r6 = r6 / r8;
        r0 = r23;
        r14 = r0.getDimension(r5, r6);
        r5 = com.kyleduo.switchbutton.C3811b.C3810b.SwitchButton_kswBackRadius;
        r6 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r6 = r6 * r24;
        r6 = r6 + r14;
        r0 = r23;
        r13 = r0.getDimension(r5, r6);
        r5 = com.kyleduo.switchbutton.C3811b.C3810b.SwitchButton_kswBackDrawable;
        r0 = r23;
        r12 = r0.getDrawable(r5);
        r5 = com.kyleduo.switchbutton.C3811b.C3810b.SwitchButton_kswBackColor;
        r0 = r23;
        r11 = r0.getColorStateList(r5);
        r5 = com.kyleduo.switchbutton.C3811b.C3810b.SwitchButton_kswBackMeasureRatio;
        r0 = r23;
        r10 = r0.getFloat(r5, r10);
        r5 = com.kyleduo.switchbutton.C3811b.C3810b.SwitchButton_kswAnimationDuration;
        r0 = r23;
        r9 = r0.getInteger(r5, r9);
        r5 = com.kyleduo.switchbutton.C3811b.C3810b.SwitchButton_kswFadeBack;
        r6 = 1;
        r0 = r23;
        r8 = r0.getBoolean(r5, r6);
        r5 = com.kyleduo.switchbutton.C3811b.C3810b.SwitchButton_kswTintColor;
        r0 = r23;
        r7 = r0.getColor(r5, r7);
        r5 = com.kyleduo.switchbutton.C3811b.C3810b.SwitchButton_kswTextOn;
        r0 = r23;
        r6 = r0.getString(r5);
        r5 = com.kyleduo.switchbutton.C3811b.C3810b.SwitchButton_kswTextOff;
        r0 = r23;
        r5 = r0.getString(r5);
        r24 = com.kyleduo.switchbutton.C3811b.C3810b.SwitchButton_kswTextMarginH;
        r0 = r23;
        r1 = r24;
        r4 = r0.getDimension(r1, r4);
        r23.recycle();
        r23 = r22;
        r22 = r21;
        r21 = r20;
        r20 = r19;
        r19 = r18;
        r18 = r17;
        r17 = r14;
        r14 = r11;
        r11 = r7;
        r7 = r10;
        r10 = r6;
        r6 = r16;
        r16 = r13;
        r13 = r9;
        r9 = r5;
        r5 = r15;
        r15 = r12;
        r12 = r8;
        r8 = r4;
    L_0x01d4:
        if (r27 != 0) goto L_0x0346;
    L_0x01d6:
        r4 = 0;
    L_0x01d7:
        if (r4 == 0) goto L_0x0200;
    L_0x01d9:
        r24 = 0;
        r25 = 1;
        r0 = r24;
        r1 = r25;
        r24 = r4.getBoolean(r0, r1);
        r25 = 1;
        r0 = r25;
        r1 = r24;
        r25 = r4.getBoolean(r0, r1);
        r0 = r26;
        r1 = r24;
        r0.setFocusable(r1);
        r0 = r26;
        r1 = r25;
        r0.setClickable(r1);
        r4.recycle();
    L_0x0200:
        r0 = r26;
        r0.f10961N = r10;
        r0 = r26;
        r0.f10962O = r9;
        r0 = r26;
        r0.f10968U = r8;
        r0 = r23;
        r1 = r26;
        r1.f10970c = r0;
        r0 = r22;
        r1 = r26;
        r1.f10973f = r0;
        r0 = r26;
        r4 = r0.f10970c;
        if (r4 == 0) goto L_0x035f;
    L_0x021e:
        r4 = 1;
    L_0x021f:
        r0 = r26;
        r0.f10949B = r4;
        r0 = r26;
        r0.f10980m = r11;
        r0 = r26;
        r4 = r0.f10980m;
        if (r4 != 0) goto L_0x0249;
    L_0x022d:
        r4 = new android.util.TypedValue;
        r4.<init>();
        r8 = r26.getContext();
        r8 = r8.getTheme();
        r9 = com.kyleduo.switchbutton.C3811b.C3809a.colorAccent;
        r10 = 1;
        r8 = r8.resolveAttribute(r9, r4, r10);
        if (r8 == 0) goto L_0x0362;
    L_0x0243:
        r4 = r4.data;
        r0 = r26;
        r0.f10980m = r4;
    L_0x0249:
        r0 = r26;
        r4 = r0.f10949B;
        if (r4 != 0) goto L_0x026d;
    L_0x024f:
        r0 = r26;
        r4 = r0.f10973f;
        if (r4 != 0) goto L_0x026d;
    L_0x0255:
        r0 = r26;
        r4 = r0.f10980m;
        r4 = com.kyleduo.switchbutton.C3808a.m18670a(r4);
        r0 = r26;
        r0.f10973f = r4;
        r0 = r26;
        r4 = r0.f10973f;
        r4 = r4.getDefaultColor();
        r0 = r26;
        r0.f10982o = r4;
    L_0x026d:
        r0 = r26;
        r4 = r0.f10949B;
        if (r4 == 0) goto L_0x0370;
    L_0x0273:
        r0 = r26;
        r4 = r0.f10970c;
        r4 = r4.getMinimumWidth();
        r4 = (float) r4;
        r6 = java.lang.Math.max(r6, r4);
        r0 = r26;
        r4 = r0.f10970c;
        r4 = r4.getMinimumHeight();
        r4 = (float) r4;
        r4 = java.lang.Math.max(r5, r4);
        r5 = r6;
    L_0x028e:
        r0 = r26;
        r6 = r0.f10981n;
        r6.set(r5, r4);
        r0 = r26;
        r0.f10971d = r15;
        r0 = r26;
        r0.f10972e = r14;
        r0 = r26;
        r4 = r0.f10971d;
        if (r4 == 0) goto L_0x036b;
    L_0x02a3:
        r4 = 1;
    L_0x02a4:
        r0 = r26;
        r0.f10950C = r4;
        r0 = r26;
        r4 = r0.f10950C;
        if (r4 != 0) goto L_0x02de;
    L_0x02ae:
        r0 = r26;
        r4 = r0.f10972e;
        if (r4 != 0) goto L_0x02de;
    L_0x02b4:
        r0 = r26;
        r4 = r0.f10980m;
        r4 = com.kyleduo.switchbutton.C3808a.m18671b(r4);
        r0 = r26;
        r0.f10972e = r4;
        r0 = r26;
        r4 = r0.f10972e;
        r4 = r4.getDefaultColor();
        r0 = r26;
        r0.f10983p = r4;
        r0 = r26;
        r4 = r0.f10972e;
        r5 = f10946a;
        r0 = r26;
        r6 = r0.f10983p;
        r4 = r4.getColorForState(r5, r6);
        r0 = r26;
        r0.f10984q = r4;
    L_0x02de:
        r0 = r26;
        r4 = r0.f10976i;
        r0 = r21;
        r1 = r19;
        r2 = r20;
        r3 = r18;
        r4.set(r0, r1, r2, r3);
        r0 = r26;
        r4 = r0.f10976i;
        r4 = r4.width();
        r5 = 0;
        r4 = (r4 > r5 ? 1 : (r4 == r5 ? 0 : -1));
        if (r4 < 0) goto L_0x036e;
    L_0x02fa:
        r4 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r4 = java.lang.Math.max(r7, r4);
    L_0x0300:
        r0 = r26;
        r0.f10977j = r4;
        r0 = r17;
        r1 = r26;
        r1.f10974g = r0;
        r0 = r16;
        r1 = r26;
        r1.f10975h = r0;
        r4 = (long) r13;
        r0 = r26;
        r0.f10978k = r4;
        r0 = r26;
        r0.f10979l = r12;
        r0 = r26;
        r4 = r0.f10952E;
        r0 = r26;
        r6 = r0.f10978k;
        r4.setDuration(r6);
        r4 = r26.isChecked();
        if (r4 == 0) goto L_0x0331;
    L_0x032a:
        r4 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r0 = r26;
        r0.setProcess(r4);
    L_0x0331:
        return;
    L_0x0332:
        r22 = r26.getContext();
        r23 = com.kyleduo.switchbutton.C3811b.C3810b.SwitchButton;
        r0 = r22;
        r1 = r27;
        r2 = r23;
        r22 = r0.obtainStyledAttributes(r1, r2);
        r23 = r22;
        goto L_0x0100;
    L_0x0346:
        r4 = r26.getContext();
        r24 = 2;
        r0 = r24;
        r0 = new int[r0];
        r24 = r0;
        r24 = {16842970, 16842981};
        r0 = r27;
        r1 = r24;
        r4 = r4.obtainStyledAttributes(r0, r1);
        goto L_0x01d7;
    L_0x035f:
        r4 = 0;
        goto L_0x021f;
    L_0x0362:
        r4 = 3309506; // 0x327fc2 float:4.637606E-39 double:1.635113E-317;
        r0 = r26;
        r0.f10980m = r4;
        goto L_0x0249;
    L_0x036b:
        r4 = 0;
        goto L_0x02a4;
    L_0x036e:
        r4 = r7;
        goto L_0x0300;
    L_0x0370:
        r4 = r5;
        r5 = r6;
        goto L_0x028e;
    L_0x0374:
        r22 = r20;
        r23 = r21;
        r20 = r18;
        r21 = r19;
        r18 = r16;
        r19 = r17;
        r16 = r13;
        r17 = r13;
        r13 = r9;
        r9 = r5;
        r5 = r14;
        r14 = r11;
        r11 = r7;
        r7 = r10;
        r10 = r6;
        r6 = r15;
        r15 = r12;
        r12 = r8;
        r8 = r4;
        goto L_0x01d4;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.kyleduo.switchbutton.SwitchButton.a(android.util.AttributeSet):void");
    }

    private Layout m18661a(CharSequence charSequence) {
        return new StaticLayout(charSequence, this.f10963P, (int) Math.ceil((double) Layout.getDesiredWidth(charSequence, this.f10963P)), Alignment.ALIGN_CENTER, 1.0f, 0.0f, false);
    }

    protected void onMeasure(int i, int i2) {
        if (this.f10964Q == null && this.f10961N != null) {
            this.f10964Q = m18661a(this.f10961N);
        }
        if (this.f10965R == null && this.f10962O != null) {
            this.f10965R = m18661a(this.f10962O);
        }
        setMeasuredDimension(m18660a(i), m18664b(i2));
    }

    private int m18660a(int i) {
        float width;
        int size = MeasureSpec.getSize(i);
        int mode = MeasureSpec.getMode(i);
        int a = m18659a((double) (this.f10981n.x * this.f10977j));
        if (this.f10950C) {
            a = Math.max(a, this.f10971d.getMinimumWidth());
        }
        float width2 = this.f10964Q != null ? (float) this.f10964Q.getWidth() : 0.0f;
        if (this.f10965R != null) {
            width = (float) this.f10965R.getWidth();
        } else {
            width = 0.0f;
        }
        if (!(width2 == 0.0f && width == 0.0f)) {
            this.f10966S = Math.max(width2, width) + (this.f10968U * 2.0f);
            width2 = ((float) a) - this.f10981n.x;
            if (width2 < this.f10966S) {
                a = (int) (((float) a) + (this.f10966S - width2));
            }
        }
        a = Math.max(a, m18659a((double) ((((float) a) + this.f10976i.left) + this.f10976i.right)));
        a = Math.max(Math.max(a, (getPaddingLeft() + a) + getPaddingRight()), getSuggestedMinimumWidth());
        if (mode == 1073741824) {
            return Math.max(a, size);
        }
        if (mode == RtlSpacingHelper.UNDEFINED) {
            return Math.min(a, size);
        }
        return a;
    }

    private int m18664b(int i) {
        float height;
        int i2;
        int mode = MeasureSpec.getMode(i);
        int size = MeasureSpec.getSize(i);
        int a = m18659a((double) Math.max(this.f10981n.y, (this.f10981n.y + this.f10976i.top) + this.f10976i.right));
        float height2 = this.f10964Q != null ? (float) this.f10964Q.getHeight() : 0.0f;
        if (this.f10965R != null) {
            height = (float) this.f10965R.getHeight();
        } else {
            height = 0.0f;
        }
        if (height2 == 0.0f && height == 0.0f) {
            i2 = a;
        } else {
            this.f10967T = Math.max(height2, height);
            i2 = m18659a((double) Math.max((float) a, this.f10967T));
        }
        i2 = Math.max(i2, getSuggestedMinimumHeight());
        i2 = Math.max(i2, (getPaddingTop() + i2) + getPaddingBottom());
        if (mode == 1073741824) {
            return Math.max(i2, size);
        }
        if (mode == RtlSpacingHelper.UNDEFINED) {
            return Math.min(i2, size);
        }
        return i2;
    }

    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        if (i != i3 || i2 != i4) {
            m18662a();
        }
    }

    private int m18659a(double d) {
        return (int) Math.ceil(d);
    }

    private void m18662a() {
        int i = 1;
        float paddingTop = ((float) getPaddingTop()) + Math.max(0.0f, this.f10976i.top);
        float paddingLeft = ((float) getPaddingLeft()) + Math.max(0.0f, this.f10976i.left);
        if (!(this.f10964Q == null || this.f10965R == null || this.f10976i.top + this.f10976i.bottom <= 0.0f)) {
            paddingTop += (((((float) ((getMeasuredHeight() - getPaddingBottom()) - getPaddingTop())) - this.f10981n.y) - this.f10976i.top) - this.f10976i.bottom) / 2.0f;
        }
        if (this.f10949B) {
            this.f10981n.x = Math.max(this.f10981n.x, (float) this.f10970c.getMinimumWidth());
            this.f10981n.y = Math.max(this.f10981n.y, (float) this.f10970c.getMinimumHeight());
        }
        this.f10989v.set(paddingLeft, paddingTop, this.f10981n.x + paddingLeft, this.f10981n.y + paddingTop);
        paddingTop = this.f10989v.left - this.f10976i.left;
        paddingLeft = Math.min(0.0f, ((Math.max(this.f10981n.x * this.f10977j, this.f10981n.x + this.f10966S) - this.f10989v.width()) - this.f10966S) / 2.0f);
        float min = Math.min(0.0f, (((this.f10989v.height() + this.f10976i.top) + this.f10976i.bottom) - this.f10967T) / 2.0f);
        this.f10990w.set(paddingTop + paddingLeft, (this.f10989v.top - this.f10976i.top) + min, (((paddingTop + this.f10976i.left) + Math.max(this.f10981n.x * this.f10977j, this.f10981n.x + this.f10966S)) + this.f10976i.right) - paddingLeft, (this.f10989v.bottom + this.f10976i.bottom) - min);
        this.f10991x.set(this.f10989v.left, 0.0f, (this.f10990w.right - this.f10976i.right) - this.f10989v.width(), 0.0f);
        this.f10975h = Math.min(Math.min(this.f10990w.width(), this.f10990w.height()) / 2.0f, this.f10975h);
        if (this.f10971d != null) {
            this.f10971d.setBounds((int) this.f10990w.left, (int) this.f10990w.top, m18659a((double) this.f10990w.right), m18659a((double) this.f10990w.bottom));
        }
        if (this.f10964Q != null) {
            paddingTop = (((float) (this.f10976i.left > 0.0f ? 1 : -1)) * this.f10968U) + ((this.f10990w.left + (((this.f10990w.width() - this.f10989v.width()) - ((float) this.f10964Q.getWidth())) / 2.0f)) - this.f10976i.left);
            paddingLeft = this.f10990w.top + ((this.f10990w.height() - ((float) this.f10964Q.getHeight())) / 2.0f);
            this.f10992y.set(paddingTop, paddingLeft, ((float) this.f10964Q.getWidth()) + paddingTop, ((float) this.f10964Q.getHeight()) + paddingLeft);
        }
        if (this.f10965R != null) {
            paddingTop = ((this.f10990w.right - (((this.f10990w.width() - this.f10989v.width()) - ((float) this.f10965R.getWidth())) / 2.0f)) + this.f10976i.right) - ((float) this.f10965R.getWidth());
            paddingLeft = this.f10968U;
            if (this.f10976i.right <= 0.0f) {
                i = -1;
            }
            paddingTop -= ((float) i) * paddingLeft;
            float height = this.f10990w.top + ((this.f10990w.height() - ((float) this.f10965R.getHeight())) / 2.0f);
            this.f10993z.set(paddingTop, height, ((float) this.f10965R.getWidth()) + paddingTop, ((float) this.f10965R.getHeight()) + height);
        }
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int process;
        if (this.f10950C) {
            if (!this.f10979l || this.f10987t == null || this.f10988u == null) {
                this.f10971d.setAlpha(255);
                this.f10971d.draw(canvas);
            } else {
                process = (int) ((isChecked() ? getProcess() : 1.0f - getProcess()) * 255.0f);
                this.f10987t.setAlpha(process);
                this.f10987t.draw(canvas);
                this.f10988u.setAlpha(255 - process);
                this.f10988u.draw(canvas);
            }
        } else if (this.f10979l) {
            float process2;
            if (isChecked()) {
                process2 = getProcess();
            } else {
                process2 = 1.0f - getProcess();
            }
            process = (int) (process2 * 255.0f);
            this.f10948A.setARGB((Color.alpha(this.f10983p) * process) / 255, Color.red(this.f10983p), Color.green(this.f10983p), Color.blue(this.f10983p));
            canvas.drawRoundRect(this.f10990w, this.f10975h, this.f10975h, this.f10948A);
            this.f10948A.setARGB(((255 - process) * Color.alpha(this.f10984q)) / 255, Color.red(this.f10984q), Color.green(this.f10984q), Color.blue(this.f10984q));
            canvas.drawRoundRect(this.f10990w, this.f10975h, this.f10975h, this.f10948A);
            this.f10948A.setAlpha(255);
        } else {
            this.f10948A.setColor(this.f10983p);
            canvas.drawRoundRect(this.f10990w, this.f10975h, this.f10975h, this.f10948A);
        }
        Layout layout = ((double) getProcess()) > 0.5d ? this.f10964Q : this.f10965R;
        RectF rectF = ((double) getProcess()) > 0.5d ? this.f10992y : this.f10993z;
        if (!(layout == null || rectF == null)) {
            float process3 = ((double) getProcess()) >= 0.75d ? (getProcess() * 4.0f) - 3.0f : ((double) getProcess()) < 0.25d ? 1.0f - (getProcess() * 4.0f) : 0.0f;
            int i = (int) (process3 * 255.0f);
            int i2 = ((double) getProcess()) > 0.5d ? this.f10985r : this.f10986s;
            layout.getPaint().setARGB((i * Color.alpha(i2)) / 255, Color.red(i2), Color.green(i2), Color.blue(i2));
            canvas.save();
            canvas.translate(rectF.left, rectF.top);
            layout.draw(canvas);
            canvas.restore();
        }
        this.f10954G.set(this.f10989v);
        this.f10954G.offset(this.f10953F * this.f10991x.width(), 0.0f);
        if (this.f10949B) {
            this.f10970c.setBounds((int) this.f10954G.left, (int) this.f10954G.top, m18659a((double) this.f10954G.right), m18659a((double) this.f10954G.bottom));
            this.f10970c.draw(canvas);
        } else {
            this.f10948A.setColor(this.f10982o);
            canvas.drawRoundRect(this.f10954G, this.f10974g, this.f10974g, this.f10948A);
        }
        if (this.f10951D) {
            this.f10960M.setColor(Color.parseColor("#AA0000"));
            canvas.drawRect(this.f10990w, this.f10960M);
            this.f10960M.setColor(Color.parseColor("#0000FF"));
            canvas.drawRect(this.f10954G, this.f10960M);
            this.f10960M.setColor(Color.parseColor("#00CC00"));
            canvas.drawRect(((double) getProcess()) > 0.5d ? this.f10992y : this.f10993z, this.f10960M);
        }
    }

    protected void drawableStateChanged() {
        super.drawableStateChanged();
        if (this.f10949B || this.f10973f == null) {
            setDrawableState(this.f10970c);
        } else {
            this.f10982o = this.f10973f.getColorForState(getDrawableState(), this.f10982o);
        }
        int[] iArr = isChecked() ? f10947b : f10946a;
        ColorStateList textColors = getTextColors();
        if (textColors != null) {
            int defaultColor = textColors.getDefaultColor();
            this.f10985r = textColors.getColorForState(f10946a, defaultColor);
            this.f10986s = textColors.getColorForState(f10947b, defaultColor);
        }
        if (this.f10950C || this.f10972e == null) {
            if ((this.f10971d instanceof StateListDrawable) && this.f10979l) {
                this.f10971d.setState(iArr);
                this.f10988u = this.f10971d.getCurrent().mutate();
            } else {
                this.f10988u = null;
            }
            setDrawableState(this.f10971d);
            if (this.f10971d != null) {
                this.f10987t = this.f10971d.getCurrent().mutate();
                return;
            }
            return;
        }
        this.f10983p = this.f10972e.getColorForState(getDrawableState(), this.f10983p);
        this.f10984q = this.f10972e.getColorForState(iArr, this.f10983p);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (!isEnabled() || !isClickable() || !isFocusable()) {
            return false;
        }
        float x = motionEvent.getX() - this.f10955H;
        float y = motionEvent.getY() - this.f10956I;
        switch (motionEvent.getAction()) {
            case C5538a.ExpandableLayout_android_orientation /*0*/:
                m18665b();
                this.f10955H = motionEvent.getX();
                this.f10956I = motionEvent.getY();
                this.f10957J = this.f10955H;
                setPressed(true);
                return true;
            case C5538a.ExpandableLayout_el_duration /*1*/:
            case C5538a.ExpandableLayout_layout_expandable /*3*/:
                setPressed(false);
                boolean statusBasedOnPos = getStatusBasedOnPos();
                float eventTime = (float) (motionEvent.getEventTime() - motionEvent.getDownTime());
                if (x < ((float) this.f10958K) && y < ((float) this.f10958K) && eventTime < ((float) this.f10959L)) {
                    performClick();
                    return true;
                } else if (statusBasedOnPos != isChecked()) {
                    playSoundEffect(0);
                    setChecked(statusBasedOnPos);
                    return true;
                } else {
                    m18669a(statusBasedOnPos);
                    return true;
                }
            case C5538a.ExpandableLayout_el_expanded /*2*/:
                float x2 = motionEvent.getX();
                setProcess(getProcess() + ((x2 - this.f10957J) / this.f10991x.width()));
                this.f10957J = x2;
                return true;
            default:
                return true;
        }
    }

    private boolean getStatusBasedOnPos() {
        return getProcess() > 0.5f;
    }

    public final float getProcess() {
        return this.f10953F;
    }

    public final void setProcess(float f) {
        if (f > 1.0f) {
            f = 1.0f;
        } else if (f < 0.0f) {
            f = 0.0f;
        }
        this.f10953F = f;
        invalidate();
    }

    public boolean performClick() {
        return super.performClick();
    }

    protected void m18669a(boolean z) {
        if (this.f10952E != null) {
            if (this.f10952E.isRunning()) {
                this.f10952E.cancel();
            }
            this.f10952E.setDuration(this.f10978k);
            if (z) {
                this.f10952E.setFloatValues(new float[]{this.f10953F, 1.0f});
            } else {
                this.f10952E.setFloatValues(new float[]{this.f10953F, 0.0f});
            }
            this.f10952E.start();
        }
    }

    private void m18665b() {
        ViewParent parent = getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(true);
        }
    }

    public void setChecked(boolean z) {
        if (isChecked() != z) {
            m18669a(z);
        }
        super.setChecked(z);
    }

    public void setCheckedNoEvent(boolean z) {
        if (this.f10969V == null) {
            setChecked(z);
            return;
        }
        super.setOnCheckedChangeListener(null);
        setChecked(z);
        setOnCheckedChangeListener(this.f10969V);
    }

    public void setCheckedImmediatelyNoEvent(boolean z) {
        if (this.f10969V == null) {
            setCheckedImmediately(z);
            return;
        }
        super.setOnCheckedChangeListener(null);
        setCheckedImmediately(z);
        setOnCheckedChangeListener(this.f10969V);
    }

    public void setOnCheckedChangeListener(OnCheckedChangeListener onCheckedChangeListener) {
        super.setOnCheckedChangeListener(onCheckedChangeListener);
        this.f10969V = onCheckedChangeListener;
    }

    public void setCheckedImmediately(boolean z) {
        super.setChecked(z);
        if (this.f10952E != null && this.f10952E.isRunning()) {
            this.f10952E.cancel();
        }
        setProcess(z ? 1.0f : 0.0f);
        invalidate();
    }

    private void setDrawableState(Drawable drawable) {
        if (drawable != null) {
            drawable.setState(getDrawableState());
            invalidate();
        }
    }

    public void setDrawDebugRect(boolean z) {
        this.f10951D = z;
        invalidate();
    }

    public long getAnimationDuration() {
        return this.f10978k;
    }

    public void setAnimationDuration(long j) {
        this.f10978k = j;
    }

    public Drawable getThumbDrawable() {
        return this.f10970c;
    }

    public void setThumbDrawable(Drawable drawable) {
        this.f10970c = drawable;
        this.f10949B = this.f10970c != null;
        m18662a();
        refreshDrawableState();
        requestLayout();
        invalidate();
    }

    public void setThumbDrawableRes(int i) {
        setThumbDrawable(C0267b.m1182a(getContext(), i));
    }

    public Drawable getBackDrawable() {
        return this.f10971d;
    }

    public void setBackDrawable(Drawable drawable) {
        this.f10971d = drawable;
        this.f10950C = this.f10971d != null;
        m18662a();
        refreshDrawableState();
        requestLayout();
        invalidate();
    }

    public void setBackDrawableRes(int i) {
        setBackDrawable(C0267b.m1182a(getContext(), i));
    }

    public ColorStateList getBackColor() {
        return this.f10972e;
    }

    public void setBackColor(ColorStateList colorStateList) {
        this.f10972e = colorStateList;
        if (this.f10972e != null) {
            setBackDrawable(null);
        }
        invalidate();
    }

    public void setBackColorRes(int i) {
        setBackColor(C0267b.m1188b(getContext(), i));
    }

    public ColorStateList getThumbColor() {
        return this.f10973f;
    }

    public void setThumbColor(ColorStateList colorStateList) {
        this.f10973f = colorStateList;
        if (this.f10973f != null) {
            setThumbDrawable(null);
        }
    }

    public void setThumbColorRes(int i) {
        setThumbColor(C0267b.m1188b(getContext(), i));
    }

    public float getBackMeasureRatio() {
        return this.f10977j;
    }

    public void setBackMeasureRatio(float f) {
        this.f10977j = f;
        requestLayout();
    }

    public RectF getThumbMargin() {
        return this.f10976i;
    }

    public void setThumbMargin(RectF rectF) {
        if (rectF == null) {
            m18667a(0.0f, 0.0f, 0.0f, 0.0f);
        } else {
            m18667a(rectF.left, rectF.top, rectF.right, rectF.bottom);
        }
    }

    public void m18667a(float f, float f2, float f3, float f4) {
        this.f10976i.set(f, f2, f3, f4);
        requestLayout();
    }

    public void m18666a(float f, float f2) {
        this.f10981n.set(f, f2);
        m18662a();
        requestLayout();
    }

    public float getThumbWidth() {
        return this.f10981n.x;
    }

    public float getThumbHeight() {
        return this.f10981n.y;
    }

    public void setThumbSize(PointF pointF) {
        if (pointF == null) {
            float f = getResources().getDisplayMetrics().density * 20.0f;
            m18666a(f, f);
            return;
        }
        m18666a(pointF.x, pointF.y);
    }

    public PointF getThumbSizeF() {
        return this.f10981n;
    }

    public float getThumbRadius() {
        return this.f10974g;
    }

    public void setThumbRadius(float f) {
        this.f10974g = f;
        if (!this.f10949B) {
            invalidate();
        }
    }

    public PointF getBackSizeF() {
        return new PointF(this.f10990w.width(), this.f10990w.height());
    }

    public float getBackRadius() {
        return this.f10975h;
    }

    public void setBackRadius(float f) {
        this.f10975h = f;
        if (!this.f10950C) {
            invalidate();
        }
    }

    public void setFadeBack(boolean z) {
        this.f10979l = z;
    }

    public int getTintColor() {
        return this.f10980m;
    }

    public void setTintColor(int i) {
        this.f10980m = i;
        this.f10973f = C3808a.m18670a(this.f10980m);
        this.f10972e = C3808a.m18671b(this.f10980m);
        this.f10950C = false;
        this.f10949B = false;
        refreshDrawableState();
        invalidate();
    }

    public void m18668a(CharSequence charSequence, CharSequence charSequence2) {
        this.f10961N = charSequence;
        this.f10962O = charSequence2;
        this.f10964Q = null;
        this.f10965R = null;
        requestLayout();
    }

    public Parcelable onSaveInstanceState() {
        Parcelable c3807a = new C3807a(super.onSaveInstanceState());
        c3807a.f10944a = this.f10961N;
        c3807a.f10945b = this.f10962O;
        return c3807a;
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        C3807a c3807a = (C3807a) parcelable;
        m18668a(c3807a.f10944a, c3807a.f10945b);
        super.onRestoreInstanceState(c3807a.getSuperState());
    }
}
